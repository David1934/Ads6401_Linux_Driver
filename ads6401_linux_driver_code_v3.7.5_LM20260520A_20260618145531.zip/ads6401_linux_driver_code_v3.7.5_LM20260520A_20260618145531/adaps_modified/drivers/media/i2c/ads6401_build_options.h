/* EEPROM data file path for calibration data when built-in eeprom is not available. */
#define EEPROM_DATA_FILE_PATH           "/userdata/ads6401_eeprom_data.bin"

/* Default debug control flags */
#define DEFAULT_DBG_CTRL                0 // (ADAPS_DBG_POWER_CTRL | ADAPS_DBG_TRACE_REGS_WRITE | ADAPS_DBG_V4L2_CALLBACK)

/* Module type configuration */
#define SWIFT_MODULE_TYPE               ADS6401_MODULE_BIG_FOV_FLOOD_V2  // (ADS6401_MODULE_SPOT / ADS6401_MODULE_SMALL_FLOOD / ADS6401_MODULE_BIG_FOV_FLOOD)
//#define ENABLE_TXD_3018_MODULE
//#define ENABLE_SIP_TEST
//#define ENABLE_SPECIAL_SETTING_4_AMZ_PER_HUAIYI

/* Frame synchronization configuration */
// Option 1: SoC outputs fsync signal to slave ADS6401
#define ENABLE_SOC_OUTPUT_FSYNC_TO_SLAVE_ADS6401

// Option 2: Ads6401 work as Slave, External fsync signal (which is from the external rgb-camera or MCU) to slave ADS6401
// #define ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401

// Option 3: ADS6401 works as master (default if above options are not enabled)



/* Application and interface configuration */
#define DTOF_APP_NAME                                   "SpadisQT"
#define TTY_DRIVERNAME_4_UART                           "ttyFIQ"
#define MIPI_RESET_DEFAULT_CFG                          STREAM_ON_WITH_MIPI_IP_RESET_FIRST
#define VCSEL_LASER_PERIOD                              96  // 127          // <=127, laser repetition frequency period, unit is ns
#define MIPI_SPEED                                      MIPISPEED_1G_BPS
#define DEFAULT_WORK_MODE                               ADAPS_PTM_FHR_MODE

#define NON_CONTINUOUS_MIPI_CLK
#define IGNORE_PROBE_FAILURE
#define ENABLE_RUNTIME_REGISTER_UPDATE
#define ENABLE_VCSEL_DRV_ERROR_IRQ
#define DEVICE_CONCURRENCY_OPEN_CHECK
//#define PM_RUNTIME_ENABLE

// For i2c_rk3x.c bus driver of rockchip platform, the polling mode costs less time than the default interrupt mode,
// please make sure your i2c-rk3x.c is not too old to support the polling mode well,
// otherwize I suggest you to update it from https://github.com/armbian/linux-rockchip/blob/rk-5.10-rkr8/drivers/i2c/busses/i2c-rk3x.c,
//
// If you are porting to other SoC platform whose i2c bus driver does not support polling mode, you may comment out the following option 'I2C_BURST_WRITE_SPEED_OPTIMIZE_4_ROISRAM';
#define I2C_BURST_WRITE_SPEED_OPTIMIZE_4_ROISRAM

#if defined(ENABLE_SOC_OUTPUT_FSYNC_TO_SLAVE_ADS6401)
    #define DEFAULT_FPS_CONFIG_4_SLAVE_MODE     40
    #define DEFAULT_FSYNC_SIGNAL_PULSE_WIDTH    10 // unit is us

    #define ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_HRTIMER
#else
    #define ENABLE_SENSOR_FSYNC_IRQ
    #define ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ
#endif

#if (ADS6401_MODULE_SMALL_FLOOD != SWIFT_MODULE_TYPE)
    #if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE)
        #if defined(ENABLE_TXD_3018_MODULE)
            #define ADS6401_MODULE_TYPE_NAME                        "Big_FoV_Flood_V2-TXD"
            #define I2C_ADDRESS_4_EEPROM                            0x50
            #define ENABLE_ADC_TEMPERATURE
            #define SENSOR_XCLK_FROM_SOC
            #define ENABLE_GPIO_4_POWER_CTRL
            #define ENABLE_TPS62864_DVCC1V1_DRIVER
            #define ENABLE_SOC_PWM_4_PVDD_VOLTAGE
            //#define ENABLE_TMP112_DRIVER                          // for 3018 vcsel driver
            //#define CALIB_DATA_READY_IN_EEPROM_CHIP
            #define EEPROM_REAL_CAPACITY_SIZE                       EEPROM_CAPACITY_SIZE_64K
        #else
            #define ADS6401_MODULE_TYPE_NAME                        "Big_FoV_Flood_V2"
            #define I2C_ADDRESS_4_EEPROM                            0x54        // 7 bits i2c address, E2 = 1, E1 = 0, A16 = 0
            #define I2C_ADDRESS_4_EEPROM_2ND_64KB                   0x55        // 7 bits i2c address, E2 = 1, E1 = 0, A16 = 1
            //#define ENABLE_OPN7020_VCSEL_DRIVER                   // for opn7020 vcsel driver
            #define ENABLE_TMP112_DRIVER                            // for 3018 vcsel driver
            #define CALIB_DATA_READY_IN_EEPROM_CHIP
            #define EEPROM_REAL_CAPACITY_SIZE                       EEPROM_CAPACITY_SIZE_128K
        #endif
    #elif (ADS6401_MODULE_BIG_FOV_FLOOD == SWIFT_MODULE_TYPE)
        #define ADS6401_MODULE_TYPE_NAME                        "Big_FoV_Flood"
        #define I2C_ADDRESS_4_EEPROM                            0x50        // 7 bits i2c address
        #define SENSOR_XCLK_FROM_SOC
        #define ENABLE_GPIO_4_POWER_CTRL
        #define ENABLE_TPS62864_DVCC1V1_DRIVER
        #define ENABLE_SOC_PWM_4_PVDD_VOLTAGE
        #define ENABLE_OPN7020_VCSEL_DRIVER
        // #define ENABLE_TMP112_DRIVER                         // NST112A-CWLR is compatiable with TMP112's driver code
        #define EEPROM_REAL_CAPACITY_SIZE                       EEPROM_CAPACITY_SIZE_64K
    #else
        #define ADS6401_MODULE_TYPE_NAME                        "Classic_Spot"
        #define I2C_ADDRESS_4_EEPROM                            0x50        // 7 bits i2c address
        #define SENSOR_XCLK_FROM_SOC
        #define ENABLE_GPIO_4_POWER_CTRL
        #define ENABLE_TPS62864_DVCC1V1_DRIVER
        #define ENABLE_SOC_PWM_4_PVDD_VOLTAGE
        #define ENABLE_OPN7020_VCSEL_DRIVER
        #define CALIB_DATA_READY_IN_EEPROM_CHIP
        #define EEPROM_REAL_CAPACITY_SIZE                       EEPROM_CAPACITY_SIZE_64K
        #define ENABLE_ROISRAM_ANCHOR_PREPROCCESS
    #endif


    // for rk3568 + new adapter board: 2 PWM output from rk3568 for pvdd and vop voltage adjustment.
    #define ENABLE_SOC_PWM_4_VOP_VOLTAGE
#else
        //#error "ADS6401_MODULE_SMALL_FLOOD is selected!"
    #define ADS6401_MODULE_TYPE_NAME                            "Small_Flood"
    #define I2C_ADDRESS_4_EEPROM                                0x50        // 7 bits i2c address
    #define SENSOR_XCLK_FROM_SOC
    #define ENABLE_GPIO_4_POWER_CTRL
    #define ENABLE_TPS62864_DVCC1V1_DRIVER

    #define ENABLE_SOC_PWM_4_VBAT_VOLTAGE
    #define ENABLE_SOC_PWM_4_VOP_VOLTAGE                        // VOP_ADJUST_BY_BUILT_IN_MCU
    #define CALIB_DATA_READY_IN_EEPROM_CHIP
    #define EEPROM_REAL_CAPACITY_SIZE                           EEPROM_CAPACITY_SIZE_32K
    #define ENABLE_VCSEL_4_PCM_MODE_CFG                         true // enable vcsel for pcm mode of flood module

    #define ENABLE_SYSFREQ_ADJUST_4_LOW_POWER                   // only apply to 1G mipi speed now.

    #define ENABLE_VCSEL_ERR_DETECT
#endif

#if defined(CONFIG_SWIFT_MINI_DEMO_BOX)
    #define MINI_DEMO_BOX
#endif

#define MIPISPEED_1G5_BPS                   1500     // 1.5G
#define MIPISPEED_1G2_BPS                   1200
#define MIPISPEED_1G_BPS                    1000
#define MIPISPEED_720M_BPS                  720
#define MIPISPEED_500M_BPS                  500
//#define MIPISPEED_328M_BPS                328
//#define MIPISPEED_250M_BPS                250
#define MIPISPEED_200M_BPS                  200
#define MIPISPEED_166M64_BPS                166     // 166.64M

#define DEFAULT_PKT_DELAY_4_1G_MIPI         0x10    // 0x08 for 10 FPS requirement of tree.

#if defined(FRAMERATE_TEST_4_60FPS)
    #undef MIPI_SPEED
    #define MIPI_SPEED                      MIPISPEED_1G5_BPS
#endif


#if defined(NON_CONTINUOUS_MIPI_CLK)
    #undef MIPI_RESET_DEFAULT_CFG
    #define MIPI_RESET_DEFAULT_CFG          STREAM_ON_WITHOUT_MIPI_IP_RESET
#endif

#if defined(ENABLE_SYS_CLK_125M)
    #define SYS_CLK_FACTOR                  2
#else
    #define SYS_CLK_FACTOR                  1
#endif

// TPS62864 I2C slave address (assuming 1000 101 from datasheet)
#define TPS62864_I2C_ADDR                   0x45

#if (ADS6401_MODULE_SMALL_FLOOD != SWIFT_MODULE_TYPE)
    #define I2C_ADDR_4_VCSELDRV             0x31
    #define I2C_ADDR_4_TMP112x              0x48

    #define TMP112_REG_TEMP                 0x00
    #define TMP112_REG_CONFIG               0x01
    #define TMP112_REG_T_LOW                0x02
    #define TMP112_REG_T_HIGH               0x03
#else
    #define I2C_ADDR_4_MCUCTRL              0x60
#endif

#if defined(ENABLE_SIP_TEST)
#define SENSOR_DATA_LANE_COUNT              1
#else
#define SENSOR_DATA_LANE_COUNT              2
#endif

#if (SENSOR_DATA_LANE_COUNT == 1)
    #undef MIPI_SPEED
    #define MIPI_SPEED                      MIPISPEED_1G2_BPS
#endif

#define TDC_DELAY_L_DEFAULT                 0x08
#define TDC_DELAY_H_DEFAULT                 0x0A

