#if (ADS6401_MODULE_SMALL_FLOOD != SWIFT_MODULE_TYPE)

#define COARSE_EXPOSURE_TIME            0x01    // unit is 80us, for register 0xBF
#define PRXMT_EXPOSURE_TIME             0x01    // unit is 80us, for register 0xC1
#define PCM_EXPOSURE_TIME               0x19    // unit is 80us, for register 0xC2

#if defined(FRAMERATE_TEST_4_60FPS)
#define FINE_EXPOSURE_TIME              0x01    //0x12    // unit is 80us, for register 0xC0
#else
    #if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE)
        #define FINE_EXPOSURE_TIME      0x38    // xialing@20251126 Set fine exposure to 4480us (0x38 * 80us) for Big FOV V2 module, for register 0xC0
    #else
        #define FINE_EXPOSURE_TIME      0x3C    // 4800us, unit is 80us, for register 0xC0
    #endif
#endif

#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
// ADDRESS RANGE: 0x00--0x7F   The registers of VCSel driver from OPNOUS
#define VCSEL_DEV_ID                0x00                // DEV_ID
#define     VCSEL_DEV_ID_DFT                0x30

#define VCSEL_STATUS1               0x01                // software_reset
#define     VCSEL_STATUS_CLEAR_ALL          0x00

#define VCSEL_STATUS3               0x03                // status 3

#define VCSEL_EXT_TEMP_VAL          0x0C                // external temperature value

#define VCSEL_EXT_TEMP_VAL_DEC      0x0D                // external temperature value decimal part

#define VCSEL_INT_TEMP_VAL          0x0E                // internal temperature value

#define VCSEL_INT_TEMP_VAL_DEC      0x0F                // internal temperature value decimal part

#define VCSEL_DELAY_RANGE           0x21                // delay range

#define VCSEL_PLL_DIV               0x22                // PLL_REF_DIV[1:0],PLL_FB_DIV[4:0]

#define VCSEL_PLL_CTRL              0x23                // PLL control

#define VCSEL_DLY_CTRL              0x24                // Delay control

#define VCSEL_CORR_FREQ             0x25                // smart correction frequency

#define VCSEL_DLY_COMP              0x26                // Delay Compensation

#define VCSEL_EXT_TEMP_THRES_H      0x36                // external temperature high threshold
#define     VCSEL_TEMP_THRES_BASE           43            //
#define     VCSEL_EXT_TEMP_THRES_H_VAL      125          // degree

#define VCSEL_EXT_TEMP_SENSOR_CTRL  0x38                // external temperature sensor

#define VCSEL_INT_TEMP_THRES_H      0x39                // internal temperature high threshold
#define     VCSEL_INT_TEMP_THRES_H_VAL      125          // degree

#define VCSEL_INT_TEMP_SENSOR_CTRL  0x3b                // internal temperature sensor

#define VCSEL_AUX_ADC_CTRL          0x3e                // aux ADC

#define VCSEL_PHOTO_DIODE_DET       0x4e                // photo diode sensing

#define VCSEL_OUT_CURRENT_LIMIT     0x50                // output current limit

#define VCSEL_PULSE_N_DUTY_LIMIT    0x52                // Pulse & Duty Limit

#define VCSEL_LVDS_CTRL             0x54                // 

#define VCSEL_RESIST_N_EDGE_SPEED   0x5b                // series resistance & rising/falling speed select

#define VCSEL_VLD_DISCHARGE_ENABLE  0x5d                // VLD Discharge enable

#define VCSEL_CHANNELS_ENABLE       0x5e                // Channels enable control

#define VCSEL_GENERAL_CTRL          0x5f                // general control

#define VCSEL_SOFT_RST              0x7f                // software_reset
#define     VCSEL_SOFT_RST_EN               0x00
#endif

#define PVDD_VOLTAGE_4_INDOOR_MODE          7600    // unit is mv, for indoor mode
#define PVDD_VOLTAGE_4_OUTDOOR_MODE         11500   // unit is mv, for outdoor mode



#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)

#define PVDD_VOLTAGE_ADJUST_STEPS           1000
#define PWM_DUTY_4_PVDD_DISABLE             0       // 0 % duty cycle is to disable pvdd output


#endif

#if (ADS6401_MODULE_SPOT == SWIFT_MODULE_TYPE)
static const char crc8_table[] = {
  0, 94, 188, 226, 97, 63, 221, 131, 194, 156, 126, 32, 163, 253, 31, 65,
  157, 195, 33, 127, 252, 162, 64, 30, 95, 1, 227, 189, 62, 96, 130, 220,
  35, 125, 159, 193, 66, 28, 254, 160, 225, 191, 93, 3, 128, 222, 60, 98,
  190, 224, 2, 92, 223, 129, 99, 61, 124, 34, 192, 158, 29, 67, 161, 255,
  70, 24, 250, 164, 39, 121, 155, 197, 132, 218, 56, 102, 229, 187, 89, 7,
  219, 133, 103, 57, 186, 228, 6, 88, 25, 71, 165, 251, 120, 38, 196, 154,
  101, 59, 217, 135, 4, 90, 184, 230, 167, 249, 27, 69, 198, 152, 122, 36,
  248, 166, 68, 26, 153, 199, 37, 123, 58, 100, 134, 216, 91, 5, 231, 185,
  140, 210, 48, 110, 237, 179, 81, 15, 78, 16, 242, 172, 47, 113, 147, 205,
  17, 79, 173, 243, 112, 46, 204, 146, 211, 141, 111, 49, 178, 236, 14, 80,
  175, 241, 19, 77, 206, 144, 114, 44, 109, 51, 209, 143, 12, 82, 176, 238,
  50, 108, 142, 208, 83, 13, 239, 177, 240, 174, 76, 18, 145, 207, 45, 115,
  202, 148, 118, 40, 171, 245, 23, 73, 8, 86, 180, 234, 105, 55, 213, 139,
  87, 9, 235, 181, 54, 104, 138, 212, 149, 203, 41, 119, 244, 170, 72, 22,
  233, 183, 85, 11, 136, 214, 52, 106, 43, 117, 151, 201, 74, 20, 246, 168,
  116, 42, 200, 150, 21, 75, 169, 247, 182, 232, 10, 84, 215, 137, 107, 53
};
#endif

#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
static const struct setting_rvd vcsel_init_regs[] = { // for opn7020
    {0x7f, 0x00, 0},
    {0x01, 0x00, 0},
    {0x38, 0x1d, 0},
    {0x3B, 0x9d, 0},
    {0x3e, 0x0a, 0},
    {0x4e, 0x22, 0},
    {0x54, 0x09, 0},
#if defined(ENABLE_SIP_TEST)
    {0x52, 0x01, 0},
    {0x50, 0x84, 0},
    {0x5f, 0x1d, 0},
    {0x5e, 0xff, 0},
#else
    {0x52, 0x11, 0},
    {0x50, 0x83, 0},
#if ((ADS6401_MODULE_BIG_FOV_FLOOD == SWIFT_MODULE_TYPE) || (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE))
    {0x5f, 0x1d, 0},
    {0x5e, 0x11, 0},
#else
    {0x5f, 0x1b, 0},
    {0x5e, 0x0f, 0},
#endif
#endif
    {0x5B, 0x3c, 0},
    {0x5d, 0x20, 0},
    {REG_NULL, 0x00, 0},
};
#endif

static const struct setting_rvd sensor_init_regs[] = {
    {0xA8, 0x30, 0},
    {0xD4, 0x32, 0},
    {0xD5, 0xFA/SYS_CLK_FACTOR, 0}, // 250/125M sys clock

    #if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x66, 0},
        {0x7E, 0x07, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x02, 0},
        {0x8E, 0x02, 0},
    #elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x65, 0},
        {0x7E, 0x0B, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x03, 0},
        {0x8E, 0x03, 0},
    #elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x62, 0},
        {0x7E, 0x0F, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x05, 0},
        {0x8E, 0x05, 0},
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x78, 0},
        {0xE9, 0x42, 0},
        {0x7E, 0x0F, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x07, 0},
        {0x8E, 0x07, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xE6, 0x00, 0},
        #if !defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER) // // recommended config, mipi speed 1000 Mbps
        {0xE7, 0x7D, 0},
        {0xE9, 0x61, 0},
        #else // optional config, mipi speed 1008 Mbps, original low power setting use this configure.
        {0xE7, 0x54, 0},
        {0xE9, 0x41, 0},
        #endif
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},
        {0x88, 0x09, 0},
        {0x8E, 0x09, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xE6, 0x00, 0},    // MIPIPLL_LPDH, bit0
        {0xE7, 0x64, 0},    // MIPIPLL_LPDL
        {0xE9, 0x41, 0},    // MIPIPLL_PPD, pre-divider and post-divider
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},    // SYSCLK_DIV
        {0x88, 0x0B, 0},    // ClkTxThstrailCnt
        {0x8E, 0x0B, 0},    // DataTxThstrailCnt
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x41, 0},
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},
        {0x88, 0x0D, 0},
        {0x8E, 0x0D, 0},
    #endif

    {0xD3, 0x01, 0},
#if defined(DISABLE_MIPI_LANES_UNTIL_STREAM_ON)
    {0x0A, 0x00, 0},
#endif
    {0xC6, 0x3F, 0},
    {0xAE, 0x40, 0},
    {0xD9, 0x1A, 0},
    {0xDA, 0x60, 0},
    {0xCB, 0x07, 0},

    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0x0A, 0x11, 0},   // enable clock lane and data lane0
    #endif

    #if defined(NON_CONTINUOUS_MIPI_CLK)
        {0x04, 0x04, 0},
        {0x05, 0x18, 0},     //TCLW
        {0x06, 0x18, 0},     //TCLT
        {0x07, 0x78, 0},     //TDLW
        #if defined(ENABLE_SYS_CLK_125M)
        {0x50, 0xF0, 0},
        #endif
    #else
        {0x04, 0x0C, 0},
        #if defined(ENABLE_SYS_CLK_125M)
        {0x50, 0xF0, 0},
        #endif
    #endif

    {0x08, 0xFA, 0},
    {0x0C, 0x05, 0},
    //{0xB5, 0x0F, 0},	// Masking SPAD0 Configuration (X1, X4, X10, X100 enabled)
    #if defined(ENABLE_SYS_CLK_125M)
        {0xA6, 0x0F, 0},  // 30 fps for 125M sys clock
    #else
        {0xA6, 0x0B, 0},  // 30 fps for 250M sys clock
    #endif
    {0xAA, 0x01, 0},
    {REG_NULL, 0x00, 0},
};


static const struct setting_rvd sensor_phr_regs[] = {
    {0xBA, 0x0C, 0},
    {0xB2, 0x01, 0},
    {0xB3, 0x32, 0},
    {0xB4, 0x16, 0},
#if defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401)
    {0xA4, 0x00, 0},
#else
    {0xA4, 0x01, 0},
#endif
    {0xAF, 0x00, 0},
    {0xBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},
    {0xBF, 0x13, 0},    // 0x13
    {0xC0, 0x26, 0},      // 0x26
    {0xB0, 0x21, 0},
    {0xB1, 0x21, 0},
    {0xBD, 0x66, 0},
    {0xBE, 0x66, 0},
    {0xC3, 0x0C, 0},
    {0xC4, 0x08, 0},
    {0xC5, 0x10, 0},
    {0xB5, 0x0F, 0},
    {0xBB, 0x06, 0},
    {0xB7, 0xF9, 0},
    {0xB8, 0x43, 0},
    {0xB9, 0x08, 0},
    #if (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xA9, 0x10, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xA9, 0x0, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif
    {0x50, 0x20, 0}, // vc0 fifo THRESHOLD
    {0x18, 0x08, 0},
    {0x19, 0x04, 0},
    {0xB6, 0x06, 0},
    {REG_NULL, 0x00, 0}
};

static const struct setting_rvd sensor_pcm_regs[] = {
    {0xBA, 0x18, 0},
    {0xA4, 0x01, 0},
    {0xAF, 0x20, 0},
#if defined(ENABLE_TXD_3018_MODULE)
    {0xBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},                    // depend on hw desgin
    {0xBE, 0xAA, 0},
#else
    {0xBC, 0xA8, 0},
    #if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE) && !defined(ENABLE_OPN7020_VCSEL_DRIVER) // xialing@20251224 for 3018+905
        {0xBE, 0x66, 0},
    #endif
#endif
    {0xC3, 0x0D, 0},
    {0xC4, 0x0A, 0},
    {0xC5, 0x0A, 0},
    {0xC2, PCM_EXPOSURE_TIME, 0},
    #if (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xA9, DEFAULT_PKT_DELAY_4_1G_MIPI, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xA9, 0x0, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif
    {0x50, 0xC0, 0},
    {0x18, 0x00, 0},
    {0x19, 0x0A, 0},
    {0xB6, 0x01, 0},
    {REG_NULL, 0x00, 0}
};

static const struct setting_rvd sensor_fhr_regs[] = {
    {0xBA, 0x18, 0},
    {0xB2, 0x01, 0},
    {0xB3, 0x32, 0},
    {0xB4, 0x16, 0},
#if defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401)
    {0xA4, 0x00, 0},
#else
    {0xA4, 0x01, 0},
#endif
    {0xAF, 0x00, 0},
    {0xBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},                    // depend on hw desgin
    {0xBF, COARSE_EXPOSURE_TIME, 0},
    {0xC0, FINE_EXPOSURE_TIME/SYS_CLK_FACTOR, 0},
    {0xC1, PRXMT_EXPOSURE_TIME, 0},
    {0xB0, 0x21, 0},
    {0xB1, 0x21, 0},
#if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE) && !defined(ENABLE_OPN7020_VCSEL_DRIVER) && !defined(ENABLE_TXD_3018_MODULE) // xialing@20251217 for 3018+905
    {0xBD, 0xAA, 0},
#else
    {0xBD, 0x66, 0},
#endif
    {0xBE, 0x66, 0},
    {0xC3, 0x0C, 0},
    {0xC4, 0x08, 0},
    {0xC5, 0x10, 0},
    {0xB5, 0x0F, 0},  // Masking SPAD0 Configuration (X1,X4,X10,X100 Enabled)
    {0xBB, 0x06, 0},
    {0xB7, 0xF9, 0},
    {0xB8, 0x43, 0},
    {0xB9, 0x08, 0},
    #if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0xA9, 0x32, 0},
    #elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0xA9, 0x1D, 0},
    #elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20/SYS_CLK_FACTOR, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15/SYS_CLK_FACTOR, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        #if (SENSOR_DATA_LANE_COUNT == 1)
            {0xA9, 0x20, 0},
        #else
            {0xA9, DEFAULT_PKT_DELAY_4_1G_MIPI/SYS_CLK_FACTOR, 0},
        #endif
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
#if (SENSOR_DATA_LANE_COUNT == 1)
        {0xA9, 0x0C, 0},
#else
        {0xA9, 0x0, 0},
#endif
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif

#if defined(ENABLE_SYS_CLK_125M)
    {0x50, 0xF0, 0},
#else
    {0x50, 0xC0, 0},
#endif
    {0x18, 0x08, 0},
    {0x19, 0x10, 0},
    {0xB6, 0x26, 0}, // TDC LSB accuracy: 0x26 for 125 ps, 0x22 for 62.5 ps
    {REG_NULL, 0x00, 0}
};

#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
/*
    ---swift rk3568转接板适配PVDD电压控制PWM计算方法---

    PVDD电压调节激光峰值功率，供电＜12V
    运行indoor模式7.6V，outdoor模式11.5V

    PWM频率10KHz，占空比0.1%可调
    Vfb = Duty_pwm × 1.229V
    PVDD = Vfb x ( Ra + Rb ) / Rb

    Ra = 5.6K + 82K
    Rb = 10K

    Here, PVDD should be a float number with two decimal places, and the unit is volt.

    PVDD = Duty_pwm × 1.229V x ( 82 + 5.6 + 10 ) / 10
         = Duty_pwm x 1.229V x 9.76
         = Duty_pwm x 11.99504

    Duty-pwm = PVDD/11.99504
    Duty-pwm% = PVDD*100/11.99504
    expected_duty_permillage = pvdd_mv/12

    indoor mode, PVDD=7.6v, Duty_pwm=63.4%, expected_duty_permillage = 7600/12 = 633
    outdoor mode, PVDD=11.5v, Duty_pwm=95.9%, expected_duty_permillage = 11500/12 = 958

*/
static int sensor_pvdd_pwm_convert_voltage_to_duty(struct sensor *sensor, u16 pvdd_mv)
{
    int duty_ns = 0;
    int expected_duty_permillage;
    int duty_permillage_max = 1000; //pwm adjust step is 1/1000

    expected_duty_permillage = pvdd_mv/12;

    duty_ns = (expected_duty_permillage * sensor->pwm_4_pvdd.current_period_ns) / duty_permillage_max;

    DBG_NOTICE("pvdd volt: %d mv, current environment type: %d, expected_duty_permillage: %d, duty_ns: %d ns.", pvdd_mv, sensor->cur_etype, expected_duty_permillage, duty_ns);

    return duty_ns;
}

static int sensor_pvdd_pwm_set_duty(struct sensor *sensor, int duty_ns)
{
    int ret;

    if (duty_ns < 0 || duty_ns > sensor->pwm_4_pvdd.current_period_ns)
    {
        DBG_ERROR("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_pvdd.current_period_ns);
        return -EINVAL;
    }

    ret = pwm_config(sensor->pwm_4_pvdd.pwm_dev, duty_ns, sensor->pwm_4_pvdd.current_period_ns);
    if (ret) {
        DBG_ERROR("Failed to configure PWM, duty: %d ns, period: %d ns", duty_ns, sensor->pwm_4_pvdd.current_period_ns);
        return ret;
    }
    sensor->pwm_4_pvdd.current_duty_ns = duty_ns;

    return ret;
}

static void sensor_pvdd_pwm_enable(struct sensor *sensor)
{

    pwm_config(sensor->pwm_4_pvdd.pwm_dev, sensor->pwm_4_pvdd.current_duty_ns, sensor->pwm_4_pvdd.current_period_ns);
    pwm_enable(sensor->pwm_4_pvdd.pwm_dev);
}

static void sensor_pvdd_pwm_disable(struct sensor *sensor)
{
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_pvdd.pwm_dev, &state);
    if (!state.enabled)
        return;

    pwm_config(sensor->pwm_4_pvdd.pwm_dev, PWM_INITDUTYCYCLE_4_PVDD, sensor->pwm_4_pvdd.current_period_ns);
    common_delay(DELAY_4_PWM_DISABLE * MS_TO_NS);
    pwm_disable(sensor->pwm_4_pvdd.pwm_dev);
}

static ssize_t pvdd_pwm_test_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_pvdd.pwm_dev, &state);

    return scnprintf(buf, PAGE_SIZE, 
        "period_ns:             %d ns\n"
        "duty_ns:               %d ns\n"
        "current set voltage:   %d\n"
        "current status:        %s\n\n",

        sensor->pwm_4_pvdd.current_period_ns,
        sensor->pwm_4_pvdd.current_duty_ns,
        sensor->pwm_4_pvdd.current_set_voltage,
        true == state.enabled ? "Enabled" : "Disabled"
    );
}

static ssize_t pvdd_pwm_test_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;
    int test_case;
    int param2;
    int duty_ns;

    ret = sscanf(buf, "%d %d", &test_case, &param2);
    if (2 == ret) {
        if (2 == test_case) // test_case:2 set PWM duty by voltage (unit is mv)
        {
            u16 voltage = 0;
            if (param2 < PVDD_VOLTAGE_4_INDOOR_MODE || param2 > PVDD_VOLTAGE_4_OUTDOOR_MODE)
            {
                printk2console("Invalid pvdd voltage: %d.%d V\n", param2/1000, param2%1000);
                return -EINVAL;
            }

            voltage = param2;
            duty_ns = sensor_pvdd_pwm_convert_voltage_to_duty(sensor, voltage);
            ret = sensor_pvdd_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("pvdd voltage is adjusted to %d.%d V\n", param2/1000, param2%1000);
            }
        }
        else if (3 == test_case) // test_case:3 set PWM duty by duty (ns)
        {
            duty_ns = param2;
            if (duty_ns < 0 || duty_ns > sensor->pwm_4_pvdd.current_period_ns)
            {
                printk2console("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_pvdd.current_duty_ns);
                return -EINVAL;
            }

            ret = sensor_pvdd_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else if (4 == test_case) // test_case:4 set PWM duty by permillage 
        {
            int permillage = param2;
            if (permillage < 500 || permillage > PWM_VOLTAGE_ADJUST_STEPS)
            {
                printk2console("Invalid permillage: %d\n", permillage);
                return -EINVAL;
            }

            duty_ns = (sensor->pwm_4_pvdd.current_period_ns * permillage) / PWM_VOLTAGE_ADJUST_STEPS;
            ret = sensor_pvdd_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else {
            return -EINVAL;
        }
    }
    else if (1 == ret) {
        if (0 == test_case) // test_case:0  disable PWM
        {
            sensor_pvdd_pwm_disable(sensor);
            printk2console("pvdd PWM is disabled\n");
        }
        else if (1 == test_case) // test_case:1  enable PWM
        {
            sensor_pvdd_pwm_enable(sensor);
            printk2console("pvdd PWM is enabled\n");
        }
        else {
            return -EINVAL;
        }
    }
    else {
        return -EINVAL;
    }

    return count;
}

static DEVICE_ATTR_RW(pvdd_pwm_test);
#endif

static int sensor_set_pvdd_voltage(struct sensor *sensor, u16 pvdd_mv, int callline)
{
#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    int duty_ns;
#endif
    int ret=0;

    // if sensor->force_pvdd_voltage is set (not 0), I always use it for current pvdd voltage setting, for test purpose.
    if (0 != sensor->force_pvdd_voltage)   // volt's unit is mv
    {
        pvdd_mv = sensor->force_pvdd_voltage;
    }
    else {
        if (pvdd_mv < PVDD_VOLTAGE_4_INDOOR_MODE || pvdd_mv > PVDD_VOLTAGE_4_OUTDOOR_MODE)   // volt's unit is mv
        {
            DBG_ERROR("Invalid pvdd voltage %d mv",pvdd_mv);
            return -EINVAL;
        }
    }

#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    duty_ns = sensor_pvdd_pwm_convert_voltage_to_duty(sensor, pvdd_mv);
    ret = sensor_pvdd_pwm_set_duty(sensor, duty_ns);
#endif
    if (ret < 0) {
        DBG_ERROR("Fail to set pvdd voltage to %d.%03d v.", pvdd_mv/1000, pvdd_mv % 1000);
    }
    else {
#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
        sensor->pwm_4_pvdd.current_set_voltage = pvdd_mv;
#endif
        sensor->cur_pvdd_x100 = pvdd_mv/10;
        LOG2T_NOTICE(OT_BOTH, "set pvdd voltage to %d.%03d v, requested from line: %d.", pvdd_mv/1000, pvdd_mv % 1000, callline);
    }

    return ret;
}

#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
static int __maybe_unused sensor_vcsel_reg_dump(struct sensor *sensor, bool out_2_console)
{
    u8 value,reg,startAddr = 0;
    int i,j;
    int buf_len = 0;
    char *buf;
    uint32_t data;
    int rc = 0;

    buf = kzalloc(PAGE_SIZE, GFP_KERNEL);
    if (!buf)
    {
        return -ENOMEM;
    }

    buf_len += sprintf(buf, "%s", "====================VCSEL Register Dump============================");
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    buf_len += sprintf(buf+buf_len, "---");

    for (i=0; i< 0x10; i++)
    {
        buf_len += sprintf(buf+buf_len, "---%x",i);
    }
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    for (i=0; i< 0x8; i++)
    {
        buf_len += sprintf(buf+buf_len, "%x0:",i);
        for (j=0; j< 0x10; j++)
        {
            reg = (i << 4) | j;

            if ((startAddr <= reg && 0xef >= reg))
            {
                rc = i2c_dev_read_reg(sensor, sensor->vcsel_i2c, reg, 1, &data);
                value = (u8) data & 0xff;
                buf_len += sprintf(buf+buf_len, "  %02X",value);
            }
            else {
                buf_len += sprintf(buf+buf_len, "  --");
            }
        }
        printout_2_select_target(buf, out_2_console);
        buf_len = 0;
    }
    buf_len = 0;
    buf_len += sprintf(buf+buf_len, "===================================================================");
    printout_2_select_target(buf, out_2_console);

    kfree(buf);
    buf = NULL;
    return buf_len;
}

static int vcseldrv_setting_update(
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsVcselZoneCountType vcselzonecount_type,
    AdapsVcselMode vmode)
{
    int ret = 0;
    u8 reg, val;

    if (NULL == sensor)
    {
        DBG_ERROR("sensor is NULL");
        return -EINVAL;
    }

    if (etype < AdapsEnvTypeIndoor || etype > AdapsEnvTypeOutdoor)
    {
        DBG_ERROR("Invalid EnvironmentType, etype:%d",etype);
        return -EINVAL;
    }

#if ((ADS6401_MODULE_BIG_FOV_FLOOD == SWIFT_MODULE_TYPE) || (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE))
    reg = 0x5f;
    val = 0x1d;
    ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c,
        reg,
        &val,
        1);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }
    
    reg = 0x5e;
    if (AdapsVcselModeOff == vmode)
    {
        val = 0x00;
    }
    else {
        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_VCSEL_L_MODE)) // the tranditional vcsel flood mode
        {
            val = 0x11;
        }
        else {
            val = 0x22;
        }
    }

    ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c, 
        reg, 
        &val, 
        1);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }
#else
    reg = 0x5e;
    if (AdapsVcselModeOff == vmode)
    {
        val = 0x00;
    }
    else {
        if (AdapsVcselZoneCount1 == vcselzonecount_type)
        {
            val = 0x01;
        }
        else {
            val = 0x0f;
        }
    }
    ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c, 
        reg, 
        &val, 
        1);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }
#endif

    reg = 0x50;
    if (AdapsEnvTypeOutdoor == etype)
    {
#if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE)
        val = 0x40; // xialing@20251126, 取消限流
#else
        val = 0xC0;
#endif
    }
    else {
        val = 0x83;
    }
    ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c, 
        reg, 
        &val, 
        1);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

#if (ADS6401_MODULE_BIG_FOV_FLOOD_V2 == SWIFT_MODULE_TYPE)
    reg = 0x52;
    if (AdapsEnvTypeOutdoor == etype)
    {
        val = 0xF1; // xialing@20251126 脉宽加大到1.8ns
        ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c, 
            reg, 
            &val, 
            1);
        if (ret) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
    }
#endif

    return ret;
}

static int vcseldrv_setting_init(struct sensor *sensor)
{
    int ret = 0;

    if (FALSE == sensor->load_script)
    {
        ret = i2c_dev_write_reg_list(sensor, sensor->vcsel_i2c, vcsel_init_regs);
        if (ret >= 0)
        {
            sensor->vcsel_inited = true;
        }
    }
    else {
        if (NULL != sensor->loaded_vcsel_reg_setting && 0 != sensor->loaded_vcsel_reg_setting_cnt)
        {
            ret = i2c_dev_write_reg_list(sensor, sensor->vcsel_i2c, (const struct setting_rvd *) sensor->loaded_vcsel_reg_setting);
            if (ret) {
                DBG_ERROR("fail to write vcsel setting registers\n");
                return ret;
            }
        }
        else {
            DBG_ERROR("Invalid loaded_sensor_reg_setting, %p, %d", sensor->loaded_vcsel_reg_setting, sensor->loaded_vcsel_reg_setting_cnt);
            return -EINVAL;
        }
    }

    return ret;
}

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
static irqreturn_t vcsel_err_handle_handler(int irq, void *privateData)
{
    struct sensor *sensor = privateData;
    u8 status1, status3, val[1];
    u32 data;

    if ((sensor->streaming) && (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRIVER)))
    {
        i2c_dev_read_reg(sensor, sensor->vcsel_i2c, VCSEL_STATUS1,1, &data);
        status1 = data & 0xff;
        i2c_dev_read_reg(sensor, sensor->vcsel_i2c, VCSEL_STATUS3,1, &data);
        status3 = data & 0xff;
        if (status1)
        {
            DBG_ERROR( "status1:0x%x\n",status1);
            if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_ERR_IRQ_HANDLE)) {
                if (NULL != sensor->client_task_4_sensor)
                {
                    // send a user signal 1 to let the userspace App stop the streaming
                    send_sig(SIGUSR1, sensor->client_task_4_sensor, 1);
                }
            }
            else {
                DBG_NOTICE("VCSEL error (0x%x) happened, but stop-streaming is disabled now.\n", status1);
            }
            val[0] = VCSEL_STATUS_CLEAR_ALL;
            i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c,VCSEL_STATUS1,val,1);
        }
        if (status3)
        {
            DBG_ERROR( "----status3:0x%x\n",status3);
            if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_ERR_IRQ_HANDLE)) {
                if (NULL != sensor->client_task_4_sensor)
                {
                    // send a user signal 2 to let the userspace App stop the streaming
                    send_sig(SIGUSR2, sensor->client_task_4_sensor, 1);
                }
            }
            else {
                DBG_NOTICE("VCSEL error (0x%x) happened, but stop-streaming is disabled now.\n", status3);
            }
            val[0] = VCSEL_STATUS_CLEAR_ALL;
            i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c,VCSEL_STATUS3,val,1);
        }
    }

    return IRQ_HANDLED;
}
#endif

#endif

static int sensor_get_inside_temperature(struct sensor *sensor, u32 *temperature_x_100)
{
    int ret = 0;
#if defined(ENABLE_ADC_TEMPERATURE)
    u32 t_centi_adc = 0;
#endif
#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
    u32 t_centi_7020 = 0;
#endif

#if defined(ENABLE_TMP112_DRIVER)
    u32 t_centi_tmp112 = 0;
    u16 raw;
    s16 temp;

    mutex_lock(&sensor->temperature_mutex);

    // 读取温度寄存器
    ret = tmp112_read_reg(sensor->temperature_i2c, TMP112_REG_TEMP, &raw);

    mutex_unlock(&sensor->temperature_mutex);

    if (ret < 0) {
        DBG_ERROR("Fail to read sensor inside temperature from TMP112x, ret:%d", ret);
    }
    else {
        /* 
         * TMP112 温度数据格式：
         * - 16位数据，高12位有效
         * - 二进制补码格式
         * - 分辨率：0.0625°C/LSB
         */
        raw >>= 4; // 取高12位

        // 处理符号扩展（12位有符号数）
        if (raw & 0x800) { // 检查符号位（第11位）
            raw |= 0xF000; // 符号扩展到16位
        }

        // 转换为有符号16位整数
        temp = (s16)raw;

        // 转换为 0.01°C 精度：temp * 0.0625 * 100 = temp * 100 / 16
        t_centi_tmp112 = (u32)temp * 100 / 16;
        *temperature_x_100 = t_centi_tmp112;
        if (sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE)
        {
            DBG_NOTICE("----TMP112-----*t_x_100: %d  raw: 0x%04x (%d)\n", *temperature_x_100, raw, temp);
        }
    }
#endif

#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
    #define DRIVER_TEMPERATURE_OFFSET           4300    // X 100
    #define DRIVER_TEMPERATURE_FACTOR           25      // X 100

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRIVER))
    {
        u8 val[2];
        u8 reg;

        reg = 0x0c;
        ret = i2c_dev_burst_read_reg(sensor, sensor->vcsel_i2c, reg, val, 2);
        if (ret < 0) {
            DBG_ERROR("Fail to read sensor inside temperature from opn7020, ret:%d", ret);
        }
        else {
            t_centi_7020 = val[0]*100 - DRIVER_TEMPERATURE_OFFSET +
               (val[1] * DRIVER_TEMPERATURE_FACTOR);

            if (t_centi_7020 > CHIP_TEMPERATURE_MAX_THRESHOLD)
            {
                DBG_ERROR("t_centi_7020: %d, val[0]: 0x%02x, val[1]: 0x%02x\n", t_centi_7020, val[0], val[1]);
            }
            *temperature_x_100 = t_centi_7020;

            if (sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE)
            {
//                DBG_NOTICE("----OPN7020-----*t_x_100: %d\n", *temperature_x_100);
            }
        }
    }

#endif

#if defined(ENABLE_ADC_TEMPERATURE)
    ret = sensor_read_adc_temperature(sensor, &t_centi_adc);
    if (ret < 0) {
        DBG_ERROR("Fail to read sensor ADC temperature, ret:%d", ret);
        // sensor_reg_dump(sensor, false, __func__, __LINE__);
    }
    else {
        *temperature_x_100 = t_centi_adc;
    }

#if defined(ENABLE_OPN7020_VCSEL_DRIVER)
    if ((sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE) && (0 != t_centi_adc))
    {
        DBG_NOTICE("------t_centi_diff: %d, t_centi_adc: %d, t_centi_7020: %d, adc_t_offset: %d, k=-0.%d",
            t_centi_adc - t_centi_7020, t_centi_adc, t_centi_7020, sensor->adc_t_offset, sensor->adc_t_k_coeff_numerator);
    }
#elif defined(ENABLE_TMP112_DRIVER)
    if ((sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE) && (0 != t_centi_adc))
    {
        DBG_NOTICE("------t_centi_diff: %d, t_centi_adc: %d, t_centi_tmp112: %d, adc_t_offset: %d, k=-0.%d",
            t_centi_adc - t_centi_tmp112, t_centi_adc, t_centi_tmp112, sensor->adc_t_offset, sensor->adc_t_k_coeff_numerator);
    }
#else
    if (sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE)
    {
        DBG_NOTICE("------t_centi_adc: %d, adc_t_offset: %d, k=-0.%d",
            t_centi_adc, sensor->adc_t_offset, sensor->adc_t_k_coeff_numerator);
    }
#endif
#endif

    return ret;
}

static int sensor_set_power_on(struct sensor *sensor, u32 powerOnReason, int callline)
{
    int ret = 0;
    //struct device *dev = &sensor->sensor_i2c->dev;

    if (!IS_ERR(sensor->reset_gpio))
    {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_ENABLED);
    }

#if defined(ENABLE_GPIO_4_POWER_CTRL)
    if (!IS_ERR(sensor->dvcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->dvcc_en_gpio, FUNCTION_ENABLE);
    #if defined(ENABLE_TPS62864_DVCC1V1_DRIVER)
        usleep_range(TPS62864_ENABLE_DELAY_TIME, TPS62864_ENABLE_DELAY_TIME+100);
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            tps62864_reg_dump(sensor, false);
        }
        sensor_set_dvcc_voltage(sensor);
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            tps62864_reg_dump(sensor, false);
        }
    #endif
    }

    if (!IS_ERR(sensor->iovcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->iovcc_en_gpio, FUNCTION_ENABLE);
    }

#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->avcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->avcc_en_gpio, FUNCTION_ENABLE);
    }

    if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_ENABLE);
    }
#endif
#endif

    set_vop_voltage(sensor, DEFAULT_VOP_VOLTAGE, __LINE__);
#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    sensor_vop_pwm_enable(sensor, __LINE__);
#endif

    // pvdd voltage
    if (AdapsEnvTypeOutdoor == sensor->cur_etype)
    {
        sensor_set_pvdd_voltage(sensor, PVDD_VOLTAGE_4_OUTDOOR_MODE, __LINE__);
    }
    else {
        sensor_set_pvdd_voltage(sensor, PVDD_VOLTAGE_4_INDOOR_MODE, __LINE__);
    }
#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    sensor_pvdd_pwm_enable(sensor);
#endif

#if defined(ENABLE_GPIO_4_POWER_CTRL) && defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->vbat_en_gpio)) {
        gpiod_set_value_cansleep(sensor->vbat_en_gpio, FUNCTION_ENABLE);
    }
#endif

    usleep_range(500, 1000);

#if defined(SENSOR_XCLK_FROM_SOC)
    ret = clk_prepare_enable(sensor->xvclk);
    if (ret < 0) {
        DBG_ERROR("Failed to enable xvclk\n");
        return ret;
    }
#endif

    if (!IS_ERR(sensor->reset_gpio)) {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_DISABLED);
    }

    usleep_range(500, 1000);

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_SKIP_SENSOR_READY_CHECK))
    {
        ret = sensor_ready_check(sensor);
        if (ret < 0) {
            DBG_ERROR("Fail to wait to sensor ready, ret: %d\n", ret);
            return ret;
        }
        else {
            sensor->power_on = true;

            if ((sensor->probe_success) && (false == sensor->static_data_ready) && (powerOnReason >= POWER_REASON_READ_CHIPID)) // if fail to read module_static_data at probe(), try to re-read it once more
            {
                ret = sensor_read_module_static_data(sensor);
                if (ret < 0) {
                    DBG_ERROR( "Fail to read module static data, ret: %d.", ret);
                }
            }
        }
    }
    else {
        sensor->power_on = true;
    }

    sensor->power_on_times++;

    TRACE_POWER_CTRL("<%s> is called from %d, ret: %d\n", __func__, callline, ret);

    return ret;
}

static void sensor_set_power_off(struct sensor *sensor, int callline)
{
#if !defined(VOP_ADJUST_BY_MCU) && defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    int ret = 0;
#endif

#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    ret = sensor_pvdd_pwm_set_duty(sensor, PWM_DUTY_4_PVDD_DISABLE);
    if (ret < 0) {
        DBG_ERROR("Fail to set pvdd voltage disable.");
    }
    else {
        sensor->pwm_4_pvdd.current_set_voltage = 0;
        sensor->cur_pvdd_x100 = 0;
    }
    sensor_pvdd_pwm_disable(sensor); // TODO: to be confirmed
//    common_delay(DELAY_4_VBAT_POWER_DOWN * MS_TO_NS);
#endif

#if defined(ENABLE_GPIO_4_POWER_CTRL)
#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->vbat_en_gpio)) {
        gpiod_set_value_cansleep(sensor->vbat_en_gpio, FUNCTION_DISABLE);
    }
#endif
#endif

#if !defined(VOP_ADJUST_BY_MCU) && defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    ret = sensor_vop_pwm_set_duty(sensor, PWM_INITDUTYCYCLE_4_VOP, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to set vop voltage disable.");
    }
    else {
        sensor->pwm_4_vop.current_set_voltage = 0;
    }

    sensor_vop_pwm_disable(sensor, __LINE__);
    common_delay(DELAY_4_VOP_POWER_DOWN * MS_TO_NS);
#endif

#if defined(ENABLE_GPIO_4_POWER_CTRL)
#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_DISABLE);
    }

    if (!IS_ERR(sensor->avcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->avcc_en_gpio, FUNCTION_DISABLE);
    }
#endif

    if (!IS_ERR(sensor->iovcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->iovcc_en_gpio, FUNCTION_DISABLE);
    }

    if (!IS_ERR(sensor->dvcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->dvcc_en_gpio, FUNCTION_DISABLE);
    }
#endif

#if defined(SENSOR_XCLK_FROM_SOC)
    clk_disable_unprepare(sensor->xvclk);
#endif
    if (!IS_ERR(sensor->reset_gpio)) {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_ENABLED);
    }

    TRACE_POWER_CTRL("<%s> is called from %d\n", __func__, callline);
    sensor->power_on = false;
    sensor->vcsel_inited = false;
}

#if (ADS6401_MODULE_SPOT == SWIFT_MODULE_TYPE)
static unsigned char crc8_calculate(const unsigned char buffer[], int len)
{
    int i;
    unsigned char crc8 = 0x77;

    for (i = len-1; i>= 0 ; i--)
    {
        crc8 = crc8_table[(crc8 ^ buffer[i]) & 0xFF];
    }
    return crc8;
}

static void EepromGetSwiftDeviceNumAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_VERSION_INFO_OFFSET;
    *length = ADS6401_EEPROM_VERSION_INFO_SIZE;
}

static void EepromGetSwiftSramDataAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_ROISRAM_DATA_OFFSET;
    *length = ADS6401_EEPROM_ROISRAM_DATA_SIZE;
}

static void EepromGetSwiftIntrinsicAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_INTRINSIC_OFFSET;
    *length = ADS6401_EEPROM_INTRINSIC_SIZE;
}

/*
static void EepromGetSwiftSpotPosAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_ACCURATESPODPOS_OFFSET; //OFFSET(swift_eeprom_data_t, spotPos);
    *length = ADS6401_EEPROM_ACCURATESPODPOS_SIZE; //MEMBER_SIZE(swift_eeprom_data_t, spotPos);
}
*/

static void EepromGetSwiftOutDoorOffsetAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_ACCURATESPODPOS_OFFSET; //OFFSET(swift_eeprom_data_t, spotPos);
    *length = ADS6401_EEPROM_ACCURATESPODPOS_SIZE / 2; //MEMBER_SIZE(swift_eeprom_data_t, spotPos) / 2;
}

static void EepromGetSwiftSpotOffsetbAddress(uint32_t* offset, uint32_t* length) {
    // *offset = OFFSET(swift_eeprom_data_t, spotPos) + SPOT_MODULE_OFFSET_SIZE * sizeof(float);
    *offset = ADS6401_EEPROM_ACCURATESPODPOS_OFFSET + SPOT_MODULE_OFFSET_SIZE * sizeof(float);
    *length = ADS6401_EEPROM_ACCURATESPODPOS_SIZE / 2; //MEMBER_SIZE(swift_eeprom_data_t, spotPos) / 2;
}

static void EepromGetSwiftSpotOffsetaAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_SPOTOFFSET_OFFSET;
    *length = ADS6401_EEPROM_SPOTOFFSET_SIZE;
}

#if 0 // unused
static void EepromGetSwiftSpotOffsetAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_SPOTOFFSET_OFFSET;
    *length = ADS6401_EEPROM_SPOTOFFSET_SIZE;
}
#endif

static void EepromGetSwiftTdcDelayAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_TDCDELAY_OFFSET;
    *length = ADS6401_EEPROM_TDCDELAY_SIZE;
}

static void EepromGetSwiftRefDistanceAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_OFFSET;
    *length = ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE
        + ADS6401_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE
        + ADS6401_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE
        + ADS6401_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE
        + ADS6401_EEPROM_CALIBRATIONINFO_SIZE;
}

#if 0 // unused
static void EepromGetSwiftCalibInfoAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_OFFSET;
    *length = ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE
        + ADS6401_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE
        + ADS6401_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE
        + ADS6401_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE;
}
#endif

static void EepromGetSwiftPxyAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_PROX_HISTOGRAM_OFFSET;
    *length = ADS6401_EEPROM_PROX_HISTOGRAM_SIZE
        + ADS6401_EEPROM_PROX_DEPTH_SIZE
        + ADS6401_EEPROM_PROX_NO_OF_PULSE_SIZE;
}

static void EepromGetSwiftMarkedPixelAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_MARKED_PIXELS_OFFSET;
    *length = ADS6401_EEPROM_MARKED_PIXELS_SIZE;
}

#if 0 // unused
static void EepromGetSwiftModuleInfoAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_MODULE_INFO_OFFSET;
    *length = ADS6401_EEPROM_MODULE_INFO_SIZE;
}
#endif

static void EepromGetSwiftWalkErrorAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_WALK_ERROR_OFFSET;
    *length = ADS6401_EEPROM_WALK_ERROR_SIZE;
}

static void EepromGetSwiftSpotEnergyAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_SPOT_ENERGY_OFFSET;
    *length = ADS6401_EEPROM_SPOT_ENERGY_SIZE;
}

#if 0 // unused
static void EepromGetSwiftRawDepthAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_RAW_DEPTH_MEAN_OFFSET;
    *length = ADS6401_EEPROM_RAW_DEPTH_MEAN_SIZE;
}
#endif

static void EepromGetSwiftNoiseAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_NOISE_OFFSET;
    *length = ADS6401_EEPROM_NOISE_SIZE;
}

static void EepromGetSwiftChecksumAddress(uint32_t* offset, uint32_t* length) {
    *offset = ADS6401_EEPROM_CHKSUM_OFFSET;
    *length = ADS6401_EEPROM_CHKSUM_SIZE;
}

static bool check_crc_4_eeprom_item(struct sensor *sensor, uint8_t *pEEPROMData, uint32_t offset, uint32_t length, uint8_t savedCRC, char *tag) {
    bool ret = true;
    unsigned char computedCRC = 0;
    pEEPROMData += offset;

    computedCRC = crc8_calculate(pEEPROMData, length);

    if (computedCRC != savedCRC) {
        DBG_ERROR("crc8 MISMATCHED for eeprom[%s] at offset:%d, lenth: %d, saved crc8: 0x%02x, calc crc8: 0x%02x", tag, offset, length, savedCRC, computedCRC);
        ret = false;
    }
    else {
        DBG_INFO("crc8 matched for eeprom[%s] at offset:%d, lenth: %d, saved crc8: 0x%02x, calc crc8: 0x%02x", tag, offset, length, savedCRC, computedCRC);
        ret = true;
    }

    return ret;
}

static int sensor_eeprom_checksum_verify(struct sensor *sensor)
{
    int ret = 0;
    uint32_t offset;
    uint32_t length;
    uint8_t checkSum[ADS6401_EEPROM_CHKSUM_SIZE] = { 0 };
    uint8_t *pEEPROMData = (uint8_t *) sensor->eeprom_data;

    EepromGetSwiftChecksumAddress(&offset, &length);
    memcpy(checkSum, pEEPROMData + offset, length);
    //hexdump(checkSum, length, "saved_chksum");

    // checksum1 - calibrationInfo
    EepromGetSwiftDeviceNumAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[CALIBRATION_INFO], "1.CALIBRATION_INFO")) {
        DBG_ERROR("Checksum calibrationInfo (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum2 - sramData
    EepromGetSwiftSramDataAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[SRAM_DATA], "2.SRAM_DATA")) {
        DBG_ERROR("Checksum sramdata (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum3 - intrinsic
    EepromGetSwiftIntrinsicAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[INTRINSIC], "3.INTRINSIC")) {
        DBG_ERROR("Checksum intrinsic (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum4 - outdoor offset
    EepromGetSwiftOutDoorOffsetAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[OUTDOOR_OFFSET], "4.OUTDOOR_OFFSET")) {
        DBG_ERROR("Checksum outdoor offset (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum5 - spotOffsetB
    EepromGetSwiftSpotOffsetbAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[SPOT_OFFSET_B], "5.SPOT_OFFSET_B")) {
        DBG_ERROR("Checksum spotOffsetB (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum6 - spotOffsetA
    EepromGetSwiftSpotOffsetaAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[SPOT_OFFSET_A], "6.SPOT_OFFSET_A")) {
        DBG_ERROR("Checksum spotOffsetA (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum7 - tdcDelay
    EepromGetSwiftTdcDelayAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[TDC_DELAY], "7.TDC_DELAY")) {
        DBG_ERROR("Checksum tdcDelay (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum8 - refDistance
    EepromGetSwiftRefDistanceAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[REF_DISTANCE], "8.REF_DISTANCE")) {
        DBG_ERROR("Checksum refDistance (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum9 - proximity
    EepromGetSwiftPxyAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[PROXIMITY], "9.PROXIMITY")) {
        DBG_ERROR("Checksum proximity (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum10 - hotPixel & deadPixel
    EepromGetSwiftMarkedPixelAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[HOTPIXEL_DEADPIXEL], "10.HOTPIXEL_DEADPIXEL")) {
        DBG_ERROR("Checksum hotPixel & deadPixel (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum11 - WalkError
    EepromGetSwiftWalkErrorAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[WALKERROR], "11.WALKERROR")) {
        DBG_ERROR("Checksum WalkError (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum12 - SpotEnergy
    EepromGetSwiftSpotEnergyAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[SPOT_ENERGY], "12.SPOT_ENERGY")) {
        DBG_ERROR("Checksum SpotEnergy (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum13 - noise
    EepromGetSwiftNoiseAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, offset, length, checkSum[NOISE], "13.NOISE")) {
        DBG_ERROR("Checksum noise (offset:%d, lenth: %d) validation fail.\n", offset, length);
        ret = -EIO;
    }

    // checksum_all 
    EepromGetSwiftChecksumAddress(&offset, &length);
    if (!check_crc_4_eeprom_item(sensor, pEEPROMData, 0, sensor->eeprom_data_size - length, checkSum[CHECKSUM_ALL], "14.CHECKSUM_ALL")) {
        DBG_ERROR("Checksum checksum_all validation fail.\n");
        ret = -EIO;
    }

    return ret;
}

#else
static int sensor_eeprom_checksum_verify(struct sensor *sensor)
{
    int ret = 0;

    return ret;
}
#endif

#endif
