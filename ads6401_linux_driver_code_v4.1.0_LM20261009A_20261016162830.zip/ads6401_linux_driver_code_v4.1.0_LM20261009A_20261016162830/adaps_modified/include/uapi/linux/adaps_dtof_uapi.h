/*
 * Copyright (C) 2023-2024 Adaps Photonics Inc.
 */

#ifndef _ADAPS_DTOF_UAPI_H
#define _ADAPS_DTOF_UAPI_H

#include <linux/types.h>

#define ADAPS_DTOF_PRIVATE              0x1000

#define ADAPS_ROI_SRAM_DATA_CNT         2

#define RKMODULE_MAX_SENSOR_MODE        10
#define RKMODULE_MODE_NAME_MAX          8

#define SOC_PLATFORM_ROCKCHIP           0x0000
#define SOC_PLATFORM_RK3568             (SOC_PLATFORM_ROCKCHIP + 1)

#define SOC_PLATFORM_TI                 0x1000
#define SOC_PLATFORM_TI_AM62A           (SOC_PLATFORM_TI + 1)

#if !defined(BIT)
#define BIT(n)                  (1 << n)
#endif

typedef enum {
    MIPI_TWO_DT_MODE = 0,
    MIPI_ONE_DT_MODE,

    MIPI_DT_MODE_COUNT
} mipi_datatype_mode_t;

typedef enum {
    SYS_CLOCK_330M_HZ = 330,
    SYS_CLOCK_250M_HZ = 250,
    SYS_CLOCK_200M_HZ = 200,
}sys_clock_freq_t;

typedef enum {
    MIPI_CLOCK_CONTINUOUS = 0,
    MIPI_CLOCK_NON_CONTINUOUS,
}mipi_clock_t;

typedef enum {
    MIPI_DATA_LANES_4 = 4,             // data lane 0 -- 3
    MIPI_DATA_LANES_2 = 2,             // data lane 0 -- 1
    MIPI_DATA_LANES_1 = 1,             // data lane 0
}mipi_data_lane_t;

typedef enum {
    MIPI_SPEED_1G_BPS       = 1000, // default value, available for ads6311 and ads6401
    MIPI_SPEED_1G5_BPS      = 1500, // available for ads6311 and ads6401
    MIPI_SPEED_1G2_BPS      = 1200, // available for ads6311 and ads6401
    MIPI_SPEED_800M_BPS     = 800,  // available for ads6311 only now
    MIPI_SPEED_720M_BPS     = 720,  // available for ads6401 only now
    MIPI_SPEED_600M_BPS     = 600,  // NOT availabe now
    MIPI_SPEED_500M_BPS     = 500,  // available for ads6401 only now
    MIPI_SPEED_200M_BPS     = 200,  // available for ads6401 only now
    MIPI_SPEED_166M64_BPS   = 166,  // NOT availabe now
    MIPI_SPEED_2G_BPS       = 2000, // available for ads6521 only now
    MIPI_SPEED_2G5_BPS      = 2500, // available for ads6521
}mipi_speed_per_lane_t;

struct sys_perf_param {
    sys_clock_freq_t           sys_clk_freq;
    mipi_clock_t               mipi_clk_type;
    mipi_speed_per_lane_t      mipi_speed_per_lane;
    mipi_data_lane_t           mipi_data_lane_cnt;
}__attribute__ ((packed));


#ifdef __KERNEL__

#if defined(CONFIG_VIDEO_ADS6311) || defined(CONFIG_VIDEO_ADS65XX) || defined(CONFIG_VIDEO_ADS6521) // FOR ADAPS_HAWK and CRANE
#if defined(CONFIG_VIDEO_ADS6311) || defined(CONFIG_VIDEO_ADS6521)
#define SENSOR_OTP_DATA_SIZE    0x20 // unit is word (16-bits)
#endif

#if defined(CONFIG_VIDEO_ADS65XX)
#define SENSOR_OTP_DATA_SIZE    0x40 // unit is word (16-bits)
#endif

struct rkmodule_sensor_mode {
    char modename[RKMODULE_MODE_NAME_MAX];
    __u32 image_width;
    __u32 image_height;
    __u16 userdata_width;
    __u16 userdata_height;
    __u32 image_datatype;
    __u32 userdata_datatype;
} __attribute__ ((packed));

struct rkmodule_sensor_module_inf {
    struct rkmodule_sensor_mode  sensor_mode[RKMODULE_MAX_SENSOR_MODE];
    __u8 mode_size;
} __attribute__ ((packed));

typedef struct {
    __u16 addr;
    __u16 val;
} reg16_data16_t;

typedef struct {
    __u16 addr;
    __u8 reserved;
    __u8 val;
} reg16_data8_t;

#if defined(NEWER_ADS6311_DRV_COWORK_WITH_OLDER_APP) // if use the new ads6311.c driver co-work with old user space App whose release version <= v3.2.0
typedef struct {
    __u32 workMode;
    __u16 subFrameNum;
    __u16 regSet1;
    __u16 regSet2;
    __u16 roiSram;
} enable_script_t;

#else

typedef struct {
    __u32 workMode;
#if defined(CONFIG_VIDEO_ADS65XX) || defined(CONFIG_VIDEO_ADS6521)
    __u32 dataType;
#endif
    __u16 subFrameNum;
    __u16 regSet1;
    __u16 regSet2;
    __u16 roiSram[ADAPS_ROI_SRAM_DATA_CNT];
} enable_script_t;
#endif

typedef enum hawk_soc_board_version {
    HAWK_SOC_BOARD_VER_UNKNOWN = 0,
    HAWK_SOC_BOARD_VER_DEMO3   = SOC_PLATFORM_RK3568,       // 0x0001
    HAWK_SOC_BOARD_VER_MINI_DEMO4,

    HAWK_SOC_BOARD_VER_TI_AM62A   = SOC_PLATFORM_TI_AM62A,  // 0x1001
}hawk_soc_board_version_t;

typedef enum sensor_chip_eco_version {
    SENSOR_CHIP_ECO_VER_UNKNOWN = 0,
    SENSOR_CHIP_ECO_VER_NTO,  // NewTapeOut
    SENSOR_CHIP_ECO_VER_ECO1,
    SENSOR_CHIP_ECO_VER_ECO2,
    SENSOR_CHIP_ECO_VER_ECO3,
    SENSOR_CHIP_ECO_VER_ECO4,
    SENSOR_CHIP_ECO_VER_ECO5,
    SENSOR_CHIP_ECO_VER_ECO6,
    SENSOR_CHIP_ECO_VER_ECO7,
    SENSOR_CHIP_ECO_VER_ECO8,
}sensor_chip_eco_version_t;

typedef enum lens_type {
    LENS_TYPE_WIDEANGLE = 0,
    LENS_TYPE_TELEPHOTO,

    LENS_TYPE_COUNT
}lens_t;

typedef enum vcsel_drv_op_code {
    VCSEL_DRV_OP_UNININT = 0,
    VCSEL_DRV_OP_START = 1,
    VCSEL_DRV_OP_STOP = 2,
}vcsel_drv_op_code_t;

enum hawk_rx_error_type_e {
    HAWK_RX_FSM_ALARM               = BIT(0),  // internal state-machine mismatch alarm
    HAWK_RX_WDT_ALARM               = BIT(1),  // watch-dog timer overflow alarm
    HAWK_RX_DV11_ALARM              = BIT(2),  // DV11 voltage abnormal alarm
    HAWK_RX_AV11_ALARM              = BIT(3),  // AV11 voltage abnormal alarm
    HAWK_RX_SV11_ALARM              = BIT(4),  // SV11 voltage abnormal alarm
    HAWK_RX_AV33_ALARM              = BIT(5),  // DV33 voltage abnormal alarm
    HAWK_RX_NOT_APPLIED6            = BIT(6),  // not applied
    HAWK_RX_NOT_APPLIED7            = BIT(7),  // not applied

    HAWK_RX_NOT_APPLIED8            = BIT(8),  // not applied
    HAWK_RX_NOT_APPLIED9            = BIT(9),  // not applied
    HAWK_RX_TRIGO0_ALARM            = BIT(10),  // triger o0 alarm
    HAWK_RX_TRIGO1_ALARM            = BIT(11),  // triger o1 alarm
    HAWK_RX_TRIGO2_ALARM            = BIT(12),  // triger o2 alarm
    HAWK_RX_TRIGO3_ALARM            = BIT(13),  // triger o3 alarm
    HAWK_RX_DRV_ERR_ALARM           = BIT(14),  // tx driver error alarm
    HAWK_RX_RESERVED                = BIT(15),  // reserved

    HAWK_RX_LOW_TEMP_OTP_DATA_ERR   = BIT(16),  // Low temperature otp parameter has some error
    HAWK_RX_NORMAL_OTP_DATA_ERR     = BIT(17),  // Normal otp parameter has some error
    HAWK_RX_HIGH_OTP_DATA_ERR       = BIT(18),  // High temperature otp parameter has some error
};

typedef enum hawk_pvdd_switch_strategy_e {
    HAWK_PVDD_SWITCH_AUTO               = 0,    // strong <-> weak PVDD switch cycle if two ROI sram data are available, otherwize use strong PVDD if only the first ROI sram is available.
    HAWK_PVDD_SWITCH_FORCE_TO_STRONG    = 1,    // use strong PVDD although the second ROI sram is available.
    HAWK_PVDD_SWITCH_FORCE_TO_WEAK      = 2,    // use weak PVDD if the second ROI sram is available.
    HAWK_PVDD_SWITCH_STRATEGY_CNT
} pvdd_swt_strategy_t;

enum {
    SENSOR_OTP_TEMPERATURE_PARAM_LOW,
    SENSOR_OTP_TEMPERATURE_PARAM_ROOM,
    SENSOR_OTP_TEMPERATURE_PARAM_HIGH,
    SENSOR_OTP_TEMPERATURE_PARAM_COUNT,
};

enum sensor_otp_checksum_state{
    SENSOR_OTP_CHECKSUM_UNSAVED,     // only for these BLANK chip without CP test
    SENSOR_OTP_CHECKSUM_MATCHED,
    SENSOR_OTP_CHECKSUM_MISMATCHED,
};

#if defined(CONFIG_VIDEO_ADS6311) || defined(CONFIG_VIDEO_ADS6521)
struct sensor_otp_temperature_param
{
    __u8 chksum_state;              // refer to the enum sensor_otp_checksum_state
    __u16 vbe_code;
    __u16 vbr_voltage;              // value x10 mv
    __u8 temperature;               // low temperature use signed 8-bit integer, while room and high temperature use unsigned temperature
}__attribute__ ((packed));
#endif

#if defined(CONFIG_VIDEO_ADS65XX)
struct sensor_otp_temperature_param
{
    __u8 chksum_state;              // refer to the enum sensor_otp_checksum_state
    __u16 vbe_code1;
    __u16 vbe_code2;
    __u16 vbd_voltage;              // value x10 mv
    __u8 temperature;               // low temperature use signed 8-bit integer, while room and high temperature use unsigned temperature
}__attribute__ ((packed));
#endif

struct sensor_otp_key_data
{
    __u16 chip_eco_version;
    struct sensor_otp_temperature_param temperature_param[SENSOR_OTP_TEMPERATURE_PARAM_COUNT];
}__attribute__ ((packed));

struct sensor_otp_ref_voltage
{
    bool otp_blank;
    bool otp_read;   // whether read the otp data or not?
    __u16 adc_reference_voltage;      // unit is mV
}__attribute__ ((packed));

struct sensor_otp_raw_data
{
    bool otp_blank;
    bool otp_read;   // whether read the otp data or not?
    __u16 raw_data[SENSOR_OTP_DATA_SIZE];
}__attribute__ ((packed));

struct sensor_norflash_op_param
{
    __u32 op_code; //0:read,1:write
    __u32 offset;
    __u32 len;
}__attribute__ ((packed));

struct sensor_cfg_data
{
    __u8 hVldSeg;
    __u8 startVroll;
    __u8 vRollNum;
    __u8 hRollNum;
    __u8 scanMode;
}__attribute__ ((packed));

typedef struct {
    __u8 workMode;
    __u8 video_stream_count;
    __u8 one_dt_mode;      // ADAPS DTOF MIPI DATA-TYPE MODE, 0 -- normal (two data type) mode, 1 -- one data type mode
    __u16 mipi_speed_per_lane;   // unit is M (Mega)
    __u8 mipi_data_lane_cnt;

    __u8 mainstream_dt_hex;
    __u32 mainstream_pixel_format;
    __u16 mainstream_payload_num;
    __u16 mainstream_flnr;

    __u8 infostream_dt_hex;
    __u32 infostream_pixel_format;
    __u16 infostream_payload_num;
    __u16 infostream_flnr;

    __u16 subFrameNum;
    __u16 loaded_reg_setting1_cnt;
    //__u16 loaded_reg_setting2_cnt;
    //__u16 roiSram[ADAPS_ROI_SRAM_DATA_CNT];
} sensor_workmode_param_t;

#define ADTOF_ENABLE_STREAM_NUM      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 2, __u32 *)

#define ADTOF_ENABLE_SCRIPT_START      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 3, enable_script_t *)

#define ADTOF_SET_VCSEL_CHANNEL      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 4, __u16 *)

#define ADTOF_SET_SENSOR_REGISTER       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 5, reg16_data8_t *)

#define ADTOF_GET_SENSOR_REGISTER       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 6, reg16_data8_t *)

#define ADTOF_SET_MCU_REGISTER       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 7, reg16_data16_t *)

#define ADTOF_GET_MCU_REGISTER       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 8, reg16_data16_t *)

#define ADTOF_GET_DRIVER_VERSION      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 9, __u32 *)

#define ADTOF_GET_MCU_RUNNING_FW_TYPE \
    _IOW('T', ADAPS_DTOF_PRIVATE + 10, __u16 *)             // 0x0A

#define ADTOF_GET_MCUFIRMWARE_VERSION \
    _IOR('T', ADAPS_DTOF_PRIVATE + 11, __u16 *)             // 0x0B

#define ADTOF_LET_MCU_ENTER_BOOTLOADER      \
    _IO('T', ADAPS_DTOF_PRIVATE + 12)                       // 0x0C

#define ADTOF_SET_MCU_FW_CRC32      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 13, __u32 *)             // 0x0D

#define ADTOF_SET_MCU_FW_LENGTH      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 14, __u32 *)             // 0x0E

#define ADTOF_GET_BLOCK_SIZE_4_FLASH_WRITE      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 15, __u32 *)             // 0x0F

#define ADTOF_TRANSFER_DATA_WITH_OFFSET      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 16, __u32 *)             // 0x10

#define ADTOF_GET_FLASH_WRITE_STATUS \
    _IOW('T', ADAPS_DTOF_PRIVATE + 17, __u16 *)             // 0x11

#define ADTOF_SET_FLASH_WRITE_STATUS \
    _IOW('T', ADAPS_DTOF_PRIVATE + 18, __u16 *)             // 0x12

#define ADTOF_GET_MCU_FW_UPGRADE_STATUS \
    _IOW('T', ADAPS_DTOF_PRIVATE + 19, __u16 *)             // 0x13

#define ADTOF_LET_MCU_REBOOT      \
    _IO('T', ADAPS_DTOF_PRIVATE + 20)                       // 0x14

#define ADTOF_GET_MCUHARDWARE_VERSION \
    _IOR('T', ADAPS_DTOF_PRIVATE + 21, __u16 *)             // 0x15

//for sensor norflash data
#define ADTOF_NORFLASH_OPERATION       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 22, struct sensor_norflash_op_param *)     // 0x16

#define ADTOF_VCSEL_OPERATION       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 23, __u32 *)             // 0x17

#define ADTOF_SET_VOP_VOLTAGE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 24, __s16 *)             // 0x18

#define ADTOF_SET_PVDD_VOLTAGE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 25, __u16 *)             // 0x19

#define ADTOF_GET_TX_TEMPERATURE      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 26, __u16 *)             // 0x1A

#define ADTOF_GET_RX_TEMPERATURE      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 27, __s16 *)             // 0x1B

#define ADTOF_GET_SENSOR_CHIP_ECO_VERSION      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 28, __u16 *)             // 0x1C

#define ADTOF_GET_SENSOR_CHIP_ASC_ALARM      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 29, __u32 *)             // 0x1D

#define ADTOF_GET_SENSOR_OTP_KEY_DATA       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 30, struct sensor_otp_key_data *)          // 0x1E

#define ADTOF_SET_LENS_TYPE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 31, __u8 *)              // 0x1F

#define ADTOF_SWITCH_ROI_SRAM      \
    _IO('T', ADAPS_DTOF_PRIVATE + 32)                       // 0x20

#define ADTOF_GET_SOC_BOARD_VERSION      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 33, __u16 *)             // 0x21

#define ADTOF_GET_SENSOR_OTP_REF_VOLTAGE       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 34, struct sensor_otp_ref_voltage *)          // 0x22

#define ADTOF_SET_MCU_ERR_REPORT_MASK      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 35, __u16 *)             // 0x23

#define ADTOF_SET_PVDD_VOLTAGE_4_WEAK_LASER      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 36, __u16 *)             // 0x24

#define ADTOF_SET_MIPI_DATATYPE_MODE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 37, __u8 *)              // 0x25

#define ADTOF_GET_MIPI_DATATYPE_MODE       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 38, __u8 *)          // 0x26

#define ADTOF_SET_SYS_PERF_PARAMETERS      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 39, struct sys_perf_param *)              // 0x27

#define ADTOF_GET_SYS_PERF_PARAMETERS       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 40, struct sys_perf_param *)          // 0x28

#define ADTOF_SET_EXPO_PBRS_ENABLE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 41, bool *)              // 0x29

#define ADTOF_SET_ASC_ENABLE_CFG      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 42, __u8 *)              // 0x2A

#define ADTOF_SET_PVDD_SWITCH_STRATEGY      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 43, __u8 *)              // 0x2B   see also pvdd_swt_strategy_t

#define ADTOF_GET_SENSOR_OTP_RAW_DATA       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 44, struct sensor_otp_raw_data *)          // 0x2C

#define ADTOF_SET_SENSOR_CFG_DATA       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 45, struct sensor_cfg_data *)          // 0x2D

#define ADTOF_SET_PBRS_SEED_INCREASE_ENABLE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 46, bool *)              // 0x2E

#define ADTOF_GET_FIRST_EXP_PBRS_SEED       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 47, __u8 *)          // 0x2F

#define ADTOF_SET_SPAD_CFG_SWITCH_PER_FSYNC_ENABLE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 48, bool *)              // 0x30

#define ADTOF_SET_SENSOR_WORKMODE_PARAM      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 49, sensor_workmode_param_t *)

#endif // FOR ADAPS_HAWK



//==========================================================================
#if defined(CONFIG_VIDEO_ADS6401) || defined(CONFIG_VIDEO_PACIFIC)  || defined(CONFIG_VIDEO_ADS6401S)// FOR ADAPS_SWIFT

#include "adaps_types.h"

//#define ENABLE_UP_TO_80_SUBFRAMES_ROIROLLING_4_SWIFT
//#define ENABLE_DEEP_MLP_WALKERROR

#define FW_VERSION_LENGTH                   12

// There are two group Calibration SRAM for spod address, every group has 4 calibration registers.
#define CALIB_SRAM_REG_BASE0                0xFB
#define CALIB_SRAM_REG_BASE1                0xF7
#define CSRU_SRAM_OFFSET_REG                0xC7

#define PER_ZONE_MAX_SPOT_COUNT             240

#define PER_CALIB_SRAM_ZONE_SIZE            512     //unit is bytes, actual use size is 480 bytes, the remaining 32 bytes is 0
#define ZONE_COUNT_PER_SRAM_GROUP           4
#define CALIB_SRAM_GROUP_COUNT              2       // swift has 2 ROI SRAM registers, which are 0xFB and 0xF7

#define REG_SETTING_BUF_MAX_SIZE_PER_SEG    2048       // unit is bytes, there may be 2 segments

#define PER_ROISRAM_GROUP_SIZE              (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP) //unit is bytes

#define ALL_ROISRAM_GROUP_SIZE              (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP * CALIB_SRAM_GROUP_COUNT)

#define SWIFT_MAX_SPOT_COUNT                (PER_ZONE_MAX_SPOT_COUNT * ZONE_COUNT_PER_SRAM_GROUP * CALIB_SRAM_GROUP_COUNT)

#if defined(ENABLE_UP_TO_80_SUBFRAMES_ROIROLLING_4_SWIFT)
    #define MAX_CALIB_SRAM_ROLLING_GROUP_CNT                    20  // The max zone count is up to 80 (20x4)
#else
    #define MAX_CALIB_SRAM_ROLLING_GROUP_CNT                    9   // The max zone count is up to 36 (9x4)
#endif

#define SWIFT_PRODUCT_ID_SIZE               12

#define OFFSET(structure, member)           ((uintptr_t)&((structure*)0)->member)
#define MEMBER_SIZE(structure, member)      sizeof(((structure*)0)->member)

#pragma pack(1)
typedef struct WalkErrorParameters {
    __u8 zoneId;
    __u8 spotId;
    __u8 x;
    __u8 y;
    float paramD;
    float paramX;
    float paramY;
    float paramZ;
    float param0;
    __u8 dummy1;//reserved
    __u8 dummy2;//reserved
}WalkErrorParam_t;
#pragma pack()

#if defined(ENABLE_DEEP_MLP_WALKERROR)
// -------------------- DeepMLP walk error model definition start -------------
typedef float mlp_param_t;

#define DEEPMLP_MAGIC                           0x4D4C5001u  /* "MLP" */
#define DEEPMLP_VERSION                         1u
#define DEEPMLP_INPUT_DIM_MAX                   16u
#define DEEPMLP_PARAM_SIZE                      37764u       /* Weight + Bias, excluding header/reserved */
#define DEEPMLP_EEPROM_SIZE                     40960u       /* 4096-byte aligned total size */

#pragma pack(1)
typedef struct {
    __u32 magic;       /* 0x4D4C5001 */
    __u16 version;     /* 1 */
    __u16 input_dim;   /* 1..16, runtime uses l1_weight[32][input_dim] */
    __u32 model_size;  /* 40960 */
    __u32 crc32;
} DeepMLP_Header_t;

#define DEEPMLP_RESERVED_SIZE                   (DEEPMLP_EEPROM_SIZE - sizeof(DeepMLP_Header_t) - DEEPMLP_PARAM_SIZE)

typedef struct {
    DeepMLP_Header_t header;
    mlp_param_t l1_weight[32][DEEPMLP_INPUT_DIM_MAX];  /* 32 x 16 */
    mlp_param_t l1_bias[32];
    mlp_param_t l2_weight[64][32];
    mlp_param_t l2_bias[64];
    mlp_param_t l3_weight[64][64];
    mlp_param_t l3_bias[64];
    mlp_param_t l4_weight[32][64];
    mlp_param_t l4_bias[32];
    mlp_param_t l5_weight[16][32];
    mlp_param_t l5_bias[16];
    mlp_param_t l6_weight[16];
    mlp_param_t l6_bias;
    __u8 reserved[DEEPMLP_RESERVED_SIZE];
} DeepMLP_WalkErrorParam_t;
#pragma pack()
// -------------------- DeepMLP walk error model definition end -------------
#endif

// -------------------- swift SPOT module definition start -------------
enum {
    CALIBRATION_INFO,
    SRAM_DATA,
    INTRINSIC,
    OUTDOOR_OFFSET,
    SPOT_OFFSET_B,
    SPOT_OFFSET_A,
    TDC_DELAY,
    REF_DISTANCE,
    PROXIMITY,
    HOTPIXEL_DEADPIXEL,
    WALKERROR,
    SPOT_ENERGY,
    NOISE,
    RESERVED,
    RESERVED2,
    CHECKSUM_ALL = 19
};

#define SPOT_MODULE_DEVICE_NAME_LENGTH                  64
#define SPOT_MODULE_INFO_LENGTH                         16
#define SPOT_MODULE_OFFSET_SIZE                         960

#define SPOT_MODULE_WALKERROR_SIZE                      (sizeof(WalkErrorParam_t) * PER_ZONE_MAX_SPOT_COUNT *ZONE_COUNT_PER_SRAM_GROUP) //26 * 960
#define SPOT_MODULE_SPOTENERGY_SIZE                     960
#define SPOT_MODULE_NOISE_SIZE                          10732
#define SPOT_MODULE_CHECKSUM_SIZE                       20
#define SPOT_MODULE_MODULE_INFO_RESERVED_SIZE           176
#define SPOT_MODULE_WALKERROR_RESERVED_SIZE             5760

#define SPOT_MODULE_EEPROM_PAGE_SIZE                    64

#pragma pack(4)
typedef struct SwiftSpotModuleEepromData
{
    // In Swift EEPROM, one page has 64 bytes.
    // Page 1
    char            deviceName[SPOT_MODULE_DEVICE_NAME_LENGTH]; // Calibration version infomation
    // Page 2 - 65
    unsigned char   sramData[ALL_ROISRAM_GROUP_SIZE];
    // Page 66
    float           intrinsic[9];     // 36 bytes
    float           offset;           // 4 bytes
    __u32           refSpadSelection; // 4 bytes
    __u32           driverChannelOffset[4];  // 16 bytes
    __u32           distanceTemperatureCoefficient;
    // Page 67 - 186
    float           spotPos[SWIFT_MAX_SPOT_COUNT]; // 7680 bytes, 120 pages, reused for offset B and outdoor
    // Page 187 - 246
    float           spotOffset[SPOT_MODULE_OFFSET_SIZE]; // 3840 bytes, 60 pages, offset A
    // Page 247
    __u32           tdcDelay[16]; // 64 bytes
    // Page 248
    float           indoorCalibTemperature; // Calibration temperature.
    float           indoorCalibRefDistance; // Calibration reference distance.
    float           outdoorCalibTemperature; // Calibration temperature.
    float           outdoorCalibRefDistance; // Calibration reference distance.
    float           calibrationInfo[12]; // reserved
    // Page 249 - 252 
    __u8            pxyHistogram[248]; // pxy histogram
    float           pxyDepth;          // pxy depth
    float           pxyNumberOfPulse;  // pxy number of pulse
    // Page 253
    __u16           markedPixels[32];  // 16 hot pixels, 16 dead pixels.
    // Page 254
    char            moduleInfo[SPOT_MODULE_INFO_LENGTH]; // adaps calibration info.
    //Page  255-256
    char            reserved1[SPOT_MODULE_MODULE_INFO_RESERVED_SIZE];
    //Page  257-622
    char            WalkError[SPOT_MODULE_WALKERROR_SIZE];
    //Page  623-736
    char            reserved2[SPOT_MODULE_WALKERROR_RESERVED_SIZE];
    //Page  737-796           
    float           SpotEnergy[SPOT_MODULE_SPOTENERGY_SIZE];

    float           RawDepthMean[SPOT_MODULE_SPOTENERGY_SIZE];
    //Page  796-1023
    char            noise[SPOT_MODULE_NOISE_SIZE];
    //Page  1024
    __u8            checksum[SPOT_MODULE_CHECKSUM_SIZE];
}swift_spot_module_eeprom_data_t;
#pragma pack()

#define  ADS6401_EEPROM_VERSION_INFO_OFFSET                  OFFSET(swift_spot_module_eeprom_data_t, deviceName)               /// 0, 0x00
#define  ADS6401_EEPROM_VERSION_INFO_SIZE                    MEMBER_SIZE(swift_spot_module_eeprom_data_t, deviceName)

// please refer to data struct 'swift_eeprom_data_t' in SpadisPC
#define  ADS6401_EEPROM_ROISRAM_DATA_OFFSET                  OFFSET(swift_spot_module_eeprom_data_t, sramData)               /// 64, 0x40
#define  ADS6401_EEPROM_ROISRAM_DATA_SIZE                    MEMBER_SIZE(swift_spot_module_eeprom_data_t, sramData)

#define  ADS6401_EEPROM_INTRINSIC_OFFSET                     OFFSET(swift_spot_module_eeprom_data_t, intrinsic)              /// 4160 0x1040
#define  ADS6401_EEPROM_INTRINSIC_SIZE                       MEMBER_SIZE(swift_spot_module_eeprom_data_t, intrinsic)         /// 9xsizeof(float)

#define  ADS6401_EEPROM_ACCURATESPODPOS_OFFSET               OFFSET(swift_spot_module_eeprom_data_t, spotPos)        /// 4224 0x1080
#define  ADS6401_EEPROM_ACCURATESPODPOS_SIZE                 MEMBER_SIZE(swift_spot_module_eeprom_data_t, spotPos)   /// 4x240x2xsizeof(float)=1920x4=7680

#define  ADS6401_EEPROM_SPOTOFFSET_OFFSET                    OFFSET(swift_spot_module_eeprom_data_t, spotOffset)             /// 11904 0x2e80
#define  ADS6401_EEPROM_SPOTOFFSET_SIZE                      MEMBER_SIZE(swift_spot_module_eeprom_data_t, spotOffset)        /// 4x240xsizeof(float)=960x4=3840

#define  ADS6401_EEPROM_TDCDELAY_OFFSET                      OFFSET(swift_spot_module_eeprom_data_t, tdcDelay)               /// 15744 0x3d80 
#define  ADS6401_EEPROM_TDCDELAY_SIZE                        MEMBER_SIZE(swift_spot_module_eeprom_data_t, tdcDelay)          /// 2xsizeof(__u32)=16x4=64

#define  ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_OFFSET       OFFSET(swift_spot_module_eeprom_data_t, indoorCalibTemperature)               /// 15808 0x3dc0
#define  ADS6401_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE         MEMBER_SIZE(swift_spot_module_eeprom_data_t, indoorCalibTemperature)          /// 1xsizeof(float)=1x4=4

#define  ADS6401_EEPROM_INDOOR_CALIBREFDISTANCE_OFFSET       OFFSET(swift_spot_module_eeprom_data_t, indoorCalibRefDistance)               /// 15812 0x3dc4
#define  ADS6401_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE         MEMBER_SIZE(swift_spot_module_eeprom_data_t, indoorCalibRefDistance)          /// 1xsizeof(float)=1x4=4

#define  ADS6401_EEPROM_OUTDOOR_CALIBTEMPERATURE_OFFSET      OFFSET(swift_spot_module_eeprom_data_t, outdoorCalibTemperature)               /// 15816
#define  ADS6401_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE        MEMBER_SIZE(swift_spot_module_eeprom_data_t, outdoorCalibTemperature)          /// 1xsizeof(float)=1x4=4

#define  ADS6401_EEPROM_OUTDOOR_CALIBREFDISTANCE_OFFSET      OFFSET(swift_spot_module_eeprom_data_t, outdoorCalibRefDistance)               /// 15820
#define  ADS6401_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE        MEMBER_SIZE(swift_spot_module_eeprom_data_t, outdoorCalibRefDistance)          /// 1xsizeof(float)=1x4=4

#define  ADS6401_EEPROM_CALIBRATIONINFO_OFFSET              OFFSET(swift_spot_module_eeprom_data_t, calibrationInfo)
#define  ADS6401_EEPROM_CALIBRATIONINFO_SIZE                MEMBER_SIZE(swift_spot_module_eeprom_data_t, calibrationInfo)

#define  ADS6401_EEPROM_PROX_HISTOGRAM_OFFSET                OFFSET(swift_spot_module_eeprom_data_t, pxyHistogram)               /// 15824+12x(sizeof(float))=15872
#define  ADS6401_EEPROM_PROX_HISTOGRAM_SIZE                  MEMBER_SIZE(swift_spot_module_eeprom_data_t, pxyHistogram)          /// 256

#define  ADS6401_EEPROM_PROX_DEPTH_OFFSET                   OFFSET(swift_spot_module_eeprom_data_t, pxyDepth)
#define  ADS6401_EEPROM_PROX_DEPTH_SIZE                     MEMBER_SIZE(swift_spot_module_eeprom_data_t, pxyDepth)

#define  ADS6401_EEPROM_PROX_NO_OF_PULSE_OFFSET              OFFSET(swift_spot_module_eeprom_data_t, pxyNumberOfPulse)
#define  ADS6401_EEPROM_PROX_NO_OF_PULSE_SIZE                MEMBER_SIZE(swift_spot_module_eeprom_data_t, pxyNumberOfPulse)

#define  ADS6401_EEPROM_MARKED_PIXELS_OFFSET                   OFFSET(swift_spot_module_eeprom_data_t, markedPixels)
#define  ADS6401_EEPROM_MARKED_PIXELS_SIZE                     MEMBER_SIZE(swift_spot_module_eeprom_data_t, markedPixels)

#define  ADS6401_EEPROM_MODULE_INFO_OFFSET                   OFFSET(swift_spot_module_eeprom_data_t, moduleInfo)
#define  ADS6401_EEPROM_MODULE_INFO_SIZE                     MEMBER_SIZE(swift_spot_module_eeprom_data_t, moduleInfo)

#define  ADS6401_EEPROM_WALK_ERROR_OFFSET                    OFFSET(swift_spot_module_eeprom_data_t, WalkError)
#define  ADS6401_EEPROM_WALK_ERROR_SIZE                      MEMBER_SIZE(swift_spot_module_eeprom_data_t, WalkError)

#define  ADS6401_EEPROM_SPOT_ENERGY_OFFSET                   OFFSET(swift_spot_module_eeprom_data_t, SpotEnergy)
#define  ADS6401_EEPROM_SPOT_ENERGY_SIZE                     MEMBER_SIZE(swift_spot_module_eeprom_data_t, SpotEnergy)

#define  ADS6401_EEPROM_RAW_DEPTH_MEAN_OFFSET                   OFFSET(swift_spot_module_eeprom_data_t, RawDepthMean)
#define  ADS6401_EEPROM_RAW_DEPTH_MEAN_SIZE                     MEMBER_SIZE(swift_spot_module_eeprom_data_t, RawDepthMean)

#define  ADS6401_EEPROM_NOISE_OFFSET                      OFFSET(swift_spot_module_eeprom_data_t, noise)
#define  ADS6401_EEPROM_NOISE_SIZE                        MEMBER_SIZE(swift_spot_module_eeprom_data_t, noise)

#define  ADS6401_EEPROM_CHKSUM_OFFSET                      OFFSET(swift_spot_module_eeprom_data_t, checksum)
#define  ADS6401_EEPROM_CHKSUM_SIZE                        MEMBER_SIZE(swift_spot_module_eeprom_data_t, checksum)

// -------------------- swift SPOT module definition end -------------

// -------------------- swift SMALL_FLOOD module definition start -------------

// EEPROM-I2C--P24C256F-D4H-MIR
#define FLOOD_MODULE_EEPROM_PAGE_SIZE                       64

#define FLOOD_MODULE_SWIFT_OFFSET_SIZE                      1920  //960 * 2

#define FLOOD_MODULE_CRC32_SPACE                            4
#define FLOOD_MODULE_OFFSET_NUM                             8

//page0
#define FLOOD_MODULE_DEVICE_VERSION_LENGTH                  6
#define FLOOD_MODULE_DEVICE_SN_LENGTH                       16
#define FLOOD_MODULE_PAGE0_RESERVED_SIZE                    (FLOOD_MODULE_EEPROM_PAGE_SIZE - FLOOD_MODULE_DEVICE_VERSION_LENGTH - FLOOD_MODULE_DEVICE_SN_LENGTH - FLOOD_MODULE_CRC32_SPACE)

//page1
#define FLOOD_MODULE_DEVICE_MODULEINFO_LENGTH               60

//page2

//sram data
#define FLOOD_MODULE_SRAM_ZONE_OCUPPY_SPACE                 512
#define FLOOD_MODULE_SRAM_ZONE_VALID_DATA_LENGTH            480

//offset
#define FLOOD_MODULE_OFFSET_VALID_DATA_LENGTH               960

// from SpadisPC\SpadisLib\eepromSettings.h
enum SwiftFloodEEPROMSizeInfo
{
    PageStartSoftwareVersion = 0,
    PageLenSoftwareVersion = 1,
    PageStartModuleInfo = 1,
    PageLenModuleInfo = 1,
    PageStartCalibrationData = 2,
    PageLenCalibrationData = 1,
    PageStartSram1Data = 3,
    PageLenSram1Data = 32,
    PageStartSram0Data = 35,
    PageLenSram0Data = 32,
    PageStartOffset1Data = 67,
    PageLenOffset1Data = 60,
    PageStartOffset0Data = 127,
    PageLenOffset0Data = 60,
    PageStartOffsetCRC = 187,
    PageLenOffsetCRC = 1
};


#pragma pack(1)
typedef struct SwiftFloodModuleEepromData
{
    // In Swift EEPROM, one page has 64 bytes.
    // Page 0
    char            Version[FLOOD_MODULE_DEVICE_VERSION_LENGTH];//6
    char            SerialNumber[FLOOD_MODULE_DEVICE_SN_LENGTH];//16
    unsigned int    Crc32Pg0;//4
    unsigned char   Pg0Reserved[FLOOD_MODULE_PAGE0_RESERVED_SIZE];//38

    //page 1
    char            ModuleInfo[FLOOD_MODULE_DEVICE_MODULEINFO_LENGTH];//60
    unsigned int    Crc32Pg1; //4

    //page2
    unsigned char   tdcDelay[2];
    float           intrinsic[9]; // 36 bytes
    float           indoorCalibTemperature; // Calibration temperature.
    float           outdoorCalibTemperature; // Calibration temperature.
    float           indoorCalibRefDistance; // Calibration reference distance.
    float           outdoorCalibRefDistance; // Calibration reference distance.
    unsigned int    Crc32Pg2;
    unsigned char   Pg2Reserved[FLOOD_MODULE_EEPROM_PAGE_SIZE-2-36-16-4]; //64-2-36-16-4=6

    //page 3---66
    unsigned char   sramData[ALL_ROISRAM_GROUP_SIZE];// 512*8 ,BUT 480(datat)+4(crc) is valid for every 512 bytes

    //page 67-186
    float           spotOffset[FLOOD_MODULE_SWIFT_OFFSET_SIZE]; // 64*60=3840 bytes = 960*4, 60 pages  for one offset.  here we have 2 offset

    //page 187
    unsigned int    Crc32Offset[FLOOD_MODULE_OFFSET_NUM];
    unsigned char   Pg187Reserved[FLOOD_MODULE_EEPROM_PAGE_SIZE-32]; //64-32=32
}swift_flood_module_eeprom_data_t;
#pragma pack()

#define  FLOOD_EEPROM_VERSION_INFO_OFFSET                  OFFSET(swift_flood_module_eeprom_data_t, Version)
#define  FLOOD_EEPROM_VERSION_INFO_SIZE                    MEMBER_SIZE(swift_flood_module_eeprom_data_t, Version)

#define  FLOOD_EEPROM_SN_INFO_OFFSET                       OFFSET(swift_flood_module_eeprom_data_t, SerialNumber)
#define  FLOOD_EEPROM_SN_INFO_SIZE                         MEMBER_SIZE(swift_flood_module_eeprom_data_t, SerialNumber)

#define  FLOOD_EEPROM_MODULE_INFO_OFFSET                   OFFSET(swift_flood_module_eeprom_data_t, ModuleInfo)
#define  FLOOD_EEPROM_MODULE_INFO_SIZE                     MEMBER_SIZE(swift_flood_module_eeprom_data_t, ModuleInfo)


// please refer to data struct 'swift_eeprom_data_t' in SpadisPC
#define  FLOOD_EEPROM_ROISRAM_DATA_OFFSET                  OFFSET(swift_flood_module_eeprom_data_t, sramData)
#define  FLOOD_EEPROM_ROISRAM_DATA_SIZE                    MEMBER_SIZE(swift_flood_module_eeprom_data_t, sramData)

#define  FLOOD_EEPROM_INTRINSIC_OFFSET                     OFFSET(swift_flood_module_eeprom_data_t, intrinsic)              /// 4160 0x1040
#define  FLOOD_EEPROM_INTRINSIC_SIZE                       MEMBER_SIZE(swift_flood_module_eeprom_data_t, intrinsic)         /// 9xsizeof(float)

//#define  FLOOD_EEPROM_ACCURATESPODPOS_OFFSET       OFFSET(swift_flood_module_eeprom_data_t, spotPos)
//#define  FLOOD_EEPROM_ACCURATESPODPOS_SIZE         MEMBER_SIZE(swift_flood_module_eeprom_data_t, spotPos)

#define  FLOOD_EEPROM_SPOTOFFSET_OFFSET                    OFFSET(swift_flood_module_eeprom_data_t, spotOffset)
#define  FLOOD_EEPROM_SPOTOFFSET_SIZE                      MEMBER_SIZE(swift_flood_module_eeprom_data_t, spotOffset)

#define  FLOOD_EEPROM_TDCDELAY_OFFSET                      OFFSET(swift_flood_module_eeprom_data_t, tdcDelay)
#define  FLOOD_EEPROM_TDCDELAY_SIZE                        MEMBER_SIZE(swift_flood_module_eeprom_data_t, tdcDelay)

#define  FLOOD_EEPROM_INDOOR_CALIBTEMPERATURE_OFFSET       OFFSET(swift_flood_module_eeprom_data_t, indoorCalibTemperature)
#define  FLOOD_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE         MEMBER_SIZE(swift_flood_module_eeprom_data_t, indoorCalibTemperature)

#define  FLOOD_EEPROM_INDOOR_CALIBREFDISTANCE_OFFSET       OFFSET(swift_flood_module_eeprom_data_t, indoorCalibRefDistance)
#define  FLOOD_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE         MEMBER_SIZE(swift_flood_module_eeprom_data_t, indoorCalibRefDistance)

#define  FLOOD_EEPROM_OUTDOOR_CALIBTEMPERATURE_OFFSET      OFFSET(swift_flood_module_eeprom_data_t, outdoorCalibTemperature)
#define  FLOOD_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE        MEMBER_SIZE(swift_flood_module_eeprom_data_t, outdoorCalibTemperature)

#define  FLOOD_EEPROM_OUTDOOR_CALIBREFDISTANCE_OFFSET      OFFSET(swift_flood_module_eeprom_data_t, outdoorCalibRefDistance)
#define  FLOOD_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE        MEMBER_SIZE(swift_flood_module_eeprom_data_t, outdoorCalibRefDistance)

#define FLOOD_ONE_SPOD_OFFSET_BYTE_SIZE                    3840//240*4*4

// -------------------- swift SMALL_FLOOD module definition end -------------

// -------------------- swift BIG_FOV FLOOD module definition start -------------


#if defined(ENABLE_DEEP_MLP_WALKERROR)
#define BIG_FOV_EEPROM_DATA_STRUCT_VERSION                  0x20260708
#else
#define BIG_FOV_EEPROM_DATA_STRUCT_VERSION                  0x20251229
#endif

#define BIG_FOV_EEPROM_MAGIC                                0xEEAD6401

#define BIG_FOV_MODULE_SN_LENGTH                            32
#define BIG_FOV_MAX_SPOT_ZONE_COUNT                         (ZONE_COUNT_PER_SRAM_GROUP * MAX_CALIB_SRAM_ROLLING_GROUP_CNT)
#define BIG_FOV_MODULE_EEPROM_PAGE_SIZE                     256


#pragma pack(1)
typedef struct SwiftEepromV2Data
{
    //HEAD
    __u32        magic_id;                               // 数据结构头魔术字，固定为十六进制值0xEEAD6401，用于识别是否ads6401模组的eeprom数据
    __u32        data_structure_version;                 // eeprom数据结构的版本，格式为最后修改的日期（十六进制值），比如0x20251229
    __u8         calibrationInfo[32];                    // 标定工具软件的版本号信息
    __u8         LastCalibratedTime[32];                 // 最后标定时间，比如：2025/11/27 14:59:04
    __u8         serialNumber[BIG_FOV_MODULE_SN_LENGTH]; // 模组序列号
    __u32        data_length;                            // HEAD后的所有DATA字段（BASIC_DATA + 压缩前BIG_DATA）的长度
    __u32        data_crc32;                             // HEAD后的所有DATA字段（BASIC_DATA + 压缩前BIG_DATA）的CRC32值
    __u32        compressed_data_length;                 // HEAD后的所有DATA字段（BASIC_DATA + 压缩后BIG_DATA）的长度
    __u32        compressed_data_crc32;                  // HEAD后的所有DATA字段（BASIC_DATA + 压缩后BIG_DATA）的CRC32值

    //BASIC_DATA
    __u8         real_spot_zone_count;                   // X, 本模组实际有多少个spot zone (每个zone,最多有240个散点坐标)，必须是4的整数倍(4X)
    __u8         tdcDelay[2];                            // Tdc delay Max and Min值，需用来写ads6401寄存器
    __u8         lensType;                               // 
    float           indoorCalibTemperature;                 // 室内标定温度，需要传给算法库
    float           indoorCalibRefDistance;                 // 室内标定参考距离，需要传给算法库
    float           outdoorCalibTemperature;                // 室外标定温度，需要传给算法库
    float           outdoorCalibRefDistance;                // 室外标定参考距离，需要传给算法库
    float           intrinsic[9];                           // dToF镜头的内参（9个参数）
    float           rgb_intrinsic[8];                       // RGB镜头的内参（8个参数）
    float           common_extrinsic[7];                    // RGB及dToF镜头的联合外参（7个参数）
    __u8         Reserved[20];                           // 保留空间，为了凑整到256 bytes

    //BIG_DATA, 标定工具写入eeprom前需要压缩，Linux驱动读出后立即解压缩，压缩操作对应用层是不可见的
    __u8          sramData[PER_CALIB_SRAM_ZONE_SIZE * BIG_FOV_MAX_SPOT_ZONE_COUNT];
#if defined(ENABLE_DEEP_MLP_WALKERROR)
    // MLP version: swift_eeprom_v2_data_t uncompressed size ~94208 bytes (walkerrorData = 40960 bytes shared DeepMLP).
    DeepMLP_WalkErrorParam_t walkerrorData;                          /* Shared DeepMLP walk error model; input_dim in header.input_dim */
#else
    WalkErrorParam_t walkerrorData[PER_ZONE_MAX_SPOT_COUNT * BIG_FOV_MAX_SPOT_ZONE_COUNT];
#endif
    float            spotOffset[PER_ZONE_MAX_SPOT_COUNT * BIG_FOV_MAX_SPOT_ZONE_COUNT];
}swift_eeprom_v2_data_t;
#pragma pack()

#define  BIG_FOV_MODULE_EEPROM_CALIBRATIONINFO_OFFSET               OFFSET(swift_eeprom_v2_data_t, calibrationInfo)
#define  BIG_FOV_MODULE_EEPROM_CALIBRATIONINFO_SIZE                 MEMBER_SIZE(swift_eeprom_v2_data_t, calibrationInfo)

#define  BIG_FOV_MODULE_EEPROM_LASTCALIBRATEDTIME_OFFSET            OFFSET(swift_eeprom_v2_data_t, LastCalibratedTime)
#define  BIG_FOV_MODULE_EEPROM_LASTCALIBRATEDTIME_SIZE              MEMBER_SIZE(swift_eeprom_v2_data_t, LastCalibratedTime)

#define  BIG_FOV_MODULE_EEPROM_SERIALNUMBER_OFFSET                  OFFSET(swift_eeprom_v2_data_t, serialNumber)
#define  BIG_FOV_MODULE_EEPROM_SERIALNUMBER_SIZE                    MEMBER_SIZE(swift_eeprom_v2_data_t, serialNumber)

#define  BIG_FOV_MODULE_EEPROM_TDCDELAY_OFFSET                      OFFSET(swift_eeprom_v2_data_t, tdcDelay)
#define  BIG_FOV_MODULE_EEPROM_TDCDELAY_SIZE                        MEMBER_SIZE(swift_eeprom_v2_data_t, tdcDelay)

#define  BIG_FOV_MODULE_EEPROM_INDOOR_CALIBTEMPERATURE_OFFSET       OFFSET(swift_eeprom_v2_data_t, indoorCalibTemperature)
#define  BIG_FOV_MODULE_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE         MEMBER_SIZE(swift_eeprom_v2_data_t, indoorCalibTemperature)

#define  BIG_FOV_MODULE_EEPROM_INDOOR_CALIBREFDISTANCE_OFFSET       OFFSET(swift_eeprom_v2_data_t, indoorCalibRefDistance)
#define  BIG_FOV_MODULE_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE         MEMBER_SIZE(swift_eeprom_v2_data_t, indoorCalibRefDistance)

#define  BIG_FOV_MODULE_EEPROM_OUTDOOR_CALIBTEMPERATURE_OFFSET      OFFSET(swift_eeprom_v2_data_t, outdoorCalibTemperature)
#define  BIG_FOV_MODULE_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE        MEMBER_SIZE(swift_eeprom_v2_data_t, outdoorCalibTemperature)

#define  BIG_FOV_MODULE_EEPROM_OUTDOOR_CALIBREFDISTANCE_OFFSET      OFFSET(swift_eeprom_v2_data_t, outdoorCalibRefDistance)
#define  BIG_FOV_MODULE_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE        MEMBER_SIZE(swift_eeprom_v2_data_t, outdoorCalibRefDistance)

#define  BIG_FOV_MODULE_EEPROM_CALIBRATIONINFO_OFFSET               OFFSET(swift_eeprom_v2_data_t, calibrationInfo)
#define  BIG_FOV_MODULE_EEPROM_CALIBRATIONINFO_SIZE                 MEMBER_SIZE(swift_eeprom_v2_data_t, calibrationInfo)

#define  BIG_FOV_MODULE_EEPROM_INTRINSIC_OFFSET                     OFFSET(swift_eeprom_v2_data_t, intrinsic)
#define  BIG_FOV_MODULE_EEPROM_INTRINSIC_SIZE                       MEMBER_SIZE(swift_eeprom_v2_data_t, intrinsic)         /// 9xsizeof(float)

#define  BIG_FOV_MODULE_EEPROM_RGB_INTRINSIC_OFFSET                 OFFSET(swift_eeprom_v2_data_t, rgb_intrinsic)
#define  BIG_FOV_MODULE_EEPROM_RGB_INTRINSIC_SIZE                   MEMBER_SIZE(swift_eeprom_v2_data_t, rgb_intrinsic)         /// 8xsizeof(float)

#define  BIG_FOV_MODULE_EEPROM_COMMON_EXTRINSIC_OFFSET              OFFSET(swift_eeprom_v2_data_t, common_extrinsic)
#define  BIG_FOV_MODULE_EEPROM_COMMON_EXTRINSIC_SIZE                MEMBER_SIZE(swift_eeprom_v2_data_t, common_extrinsic)         /// 7xsizeof(float)

#define  BIG_FOV_MODULE_EEPROM_ROISRAM_DATA_OFFSET                  OFFSET(swift_eeprom_v2_data_t, sramData)
#define  BIG_FOV_MODULE_EEPROM_ROISRAM_DATA_MAX_SIZE                MEMBER_SIZE(swift_eeprom_v2_data_t, sramData)

#define  BIG_FOV_MODULE_EEPROM_WALK_ERROR_OFFSET                    OFFSET(swift_eeprom_v2_data_t, walkerrorData)
#define  BIG_FOV_MODULE_EEPROM_WALK_ERROR_MAX_SIZE                  MEMBER_SIZE(swift_eeprom_v2_data_t, walkerrorData)

#define  BIG_FOV_MODULE_EEPROM_SPOTOFFSET_OFFSET                    OFFSET(swift_eeprom_v2_data_t, spotOffset)
#define  BIG_FOV_MODULE_EEPROM_SPOTOFFSET_MAX_SIZE                  MEMBER_SIZE(swift_eeprom_v2_data_t, spotOffset)

// WARNING: This value should be an integer multiple of 4096 and greater than(>=) the EEPROM data size of ALL kinds of modules, sizeof(swift_eeprom_v2_data_t) is biggest now.
#define MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA                    (((sizeof(swift_eeprom_v2_data_t) + 4095)/4096) * 4096)


#define  BIG_FOV_MODULE_EEPROM_BASICDATA_OFFSET                     OFFSET(swift_eeprom_v2_data_t, real_spot_zone_count)
#define  BIG_FOV_MODULE_EEPROM_BIGDATA_OFFSET                       BIG_FOV_MODULE_EEPROM_ROISRAM_DATA_OFFSET

#define  BIG_FOV_MODULE_EEPROM_HEAD_SIZE                            BIG_FOV_MODULE_EEPROM_BASICDATA_OFFSET
#define  BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE                       (BIG_FOV_MODULE_EEPROM_BIGDATA_OFFSET - BIG_FOV_MODULE_EEPROM_BASICDATA_OFFSET)
#define  BIG_FOV_MODULE_EEPROM_BIGDATA_MAX_SIZE                     (BIG_FOV_MODULE_EEPROM_ROISRAM_DATA_MAX_SIZE + BIG_FOV_MODULE_EEPROM_WALK_ERROR_MAX_SIZE + BIG_FOV_MODULE_EEPROM_SPOTOFFSET_MAX_SIZE)

// -------------------- swift BIG_FOV FLOOD module definition end -------------

struct adaps_dtof_intial_param {
    AdapsEnvironmentType env_type;
    AdapsMeasurementType measure_type;
    AdapsPowerMode  power_mode;
    AdapsFramerateType framerate_type;
    AdapsVcselZoneCountType vcselzonecount_type;

    __u8 rowOffset;
    __u8 colOffset;
    __u8 rowSearchingRange;
    __u8 colSearchingRange;

    // The following config are for Advanced user only, just set them to 0 (the default setting will be used in ads6401.c driver code) if you are not clear what they are.
    __u8 grayExposure;
    __u8 coarseExposure;
    __u8 fineExposure;
    __u8 laserExposurePeriod;  // laser_exposure_period, register configure value
    bool roi_sram_rolling;
};

struct adaps_dtof_runtime_param{
   AdapsEnvironmentType env_type;
   AdapsMeasurementType measure_type;
   AdapsVcselMode vcsel_mode;
   bool env_valid;
   bool measure_valid;
   bool vcsel_valid;
};

struct adaps_dtof_exposure_param{
    __u8 ptm_coarse_exposure_value;//ptm_coarse_exposure_value, register configure value
    __u8 ptm_fine_exposure_value;// ptm_fine_exposure_value, register configure value
    __u8 pcm_gray_exposure_value;// pcm_gray_exposure_value, register configure value
    __u8 exposure_period;  // laser_exposure_period, register configure value
};

struct adaps_dtof_runtime_status_param {
    bool test_pattern_enabled;
    __u32 inside_temperature_x100; //since kernel doesn't use float type, this is a expanded integer value (x100), Eg 4515 means 45.15 degree
    __u32 expected_vop_abs_x100;
    __u32 expected_pvdd_x100;
};

struct adaps_dtof_module_static_data{
    __u32 module_type;            // refer to ADS6401_MODULE_SPOT/ADS6401_MODULE_SMALL_FLOOD/... of adaps_types.h file
    __u32 eeprom_capacity;       // unit is byte
    __u16 otp_vbe25;
    __u16 otp_vbd;        // unit is 10mv, or the related V X 100
    __u16 otp_adc_vref;
    __u8 chip_product_id[SWIFT_PRODUCT_ID_SIZE];
    __u8 sensor_drv_version[FW_VERSION_LENGTH];
    __u8 ready;
    __u8 eeprom_crc_matched;
};

struct adaps_dtof_update_eeprom_data{
    __u32 module_type;            // refer to ADS6401_MODULE_SPOT/ADS6401_MODULE_SMALL_FLOOD/... of adaps_types.h file
    __u32 eeprom_capacity;       // unit is byte
    __u32 offset;             //eeprom data start offset
    __u32 length;                //eeprom data length
};

typedef struct {
    __u8 work_mode;
    __u16 sensor_reg_setting_cnt;
    __u16 vcsel_reg_setting_cnt;
} external_config_script_param_t;

typedef struct {
    __u32 roi_sram_size;
} external_roisram_data_size_t;

#define ADAPS_SET_DTOF_INITIAL_PARAM       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 0, struct adaps_dtof_intial_param)

// This command has been deprecated; do not use it anymore. 
#define ADAPS_UPDATE_DTOF_RUNTIME_PARAM       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 1, struct adaps_dtof_runtime_param)

#define ADAPS_GET_DTOF_RUNTIME_STATUS_PARAM       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 2, struct adaps_dtof_runtime_status_param)

#define ADAPS_GET_DTOF_MODULE_STATIC_DATA       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 3, struct adaps_dtof_module_static_data)

#define ADAPS_GET_DTOF_EXPOSURE_PARAM       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 4, struct adaps_dtof_exposure_param)

#define ADTOF_SET_DEVICE_REGISTER       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 5, register_op_data_t *)

#define ADTOF_GET_DEVICE_REGISTER       \
    _IOR('T', ADAPS_DTOF_PRIVATE + 6, register_op_data_t *)

#define ADTOF_SET_EXTERNAL_CONFIG_SCRIPT      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 7, external_config_script_param_t *)

// This command carries the risk of damaging the module calibration data and is restricted to internal use at adaps company only.
#define ADTOF_UPDATE_EEPROM_DATA       \
    _IOW('T', ADAPS_DTOF_PRIVATE + 8, struct adaps_dtof_update_eeprom_data)

#define ADTOF_SET_EXTERNAL_ROISRAM_DATA_SIZE      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 9, external_roisram_data_size_t *)

#define ADTOF_GET_MCU_RUNNING_FW_TYPE \
    _IOR('T', ADAPS_DTOF_PRIVATE + 10, __u16 *)             // 0x0A

#define ADTOF_GET_MCUFIRMWARE_VERSION \
    _IOR('T', ADAPS_DTOF_PRIVATE + 11, __u16 *)             // 0x0B

#define ADTOF_LET_MCU_ENTER_BOOTLOADER      \
    _IO('T', ADAPS_DTOF_PRIVATE + 12)                       // 0x0C

#define ADTOF_SET_MCU_FW_CRC32      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 13, __u32 *)             // 0x0D

#define ADTOF_SET_MCU_FW_LENGTH      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 14, __u32 *)             // 0x0E

#define ADTOF_GET_BLOCK_SIZE_4_FLASH_WRITE      \
    _IOR('T', ADAPS_DTOF_PRIVATE + 15, __u16 *)             // 0x0F

#define ADTOF_TRANSFER_DATA_WITH_OFFSET      \
    _IOW('T', ADAPS_DTOF_PRIVATE + 16, __u32 *)             // 0x10

#define ADTOF_GET_FLASH_WRITE_STATUS \
    _IOR('T', ADAPS_DTOF_PRIVATE + 17, __u8 *)             // 0x11

#define ADTOF_SET_FLASH_WRITE_STATUS \
    _IOW('T', ADAPS_DTOF_PRIVATE + 18, __u8 *)             // 0x12

#define ADTOF_GET_MCU_FW_UPGRADE_STATUS \
    _IOR('T', ADAPS_DTOF_PRIVATE + 19, __u8 *)             // 0x13

#define ADTOF_LET_MCU_REBOOT      \
    _IO('T', ADAPS_DTOF_PRIVATE + 20)                       // 0x14

#endif // FOR ADAPS_SWIFT
#endif


#endif /* _ADAPS_DTOF_UAPI_H */

