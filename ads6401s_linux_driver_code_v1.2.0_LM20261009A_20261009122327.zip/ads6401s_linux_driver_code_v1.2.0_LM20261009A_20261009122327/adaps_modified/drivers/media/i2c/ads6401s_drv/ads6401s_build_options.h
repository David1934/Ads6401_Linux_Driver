/* Default debug control flags */
#define DEFAULT_DBG_CTRL                                0 // (ADAPS_DBG_TRACE_REGS_READ | ADAPS_DBG_TRACE_REGS_WRITE | ADAPS_DBG_V4L2_CALLBACK)

/* Module type configuration */
#define SWIFT_MODULE_TYPE                               ADS6401_MODULE_BIG_FOV_FLOOD_SMART
#define ADS6401_MODULE_TYPE_NAME                        "Big_FoV_Flood_Smart"

#define ENABLE_MCU_FIRMWARE_UPGRADE
#define CALIB_DATA_READY_IN_EEPROM_CHIP
//#define CALIB_DATA_FROM_EEPROM_BIN_FILE

/* Frame synchronization configuration */
// Option 1: Built-in-MCU outputs fsync signal to slave ADS6401
#define ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401

// Option 2: Ads6401 work as Slave, External fsync signal (which is from the external rgb-camera or MCU) to slave ADS6401
// #define ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401

// Option 3: ADS6401 works as master (default if above options are not enabled)

#if defined(ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401)
    #define DEFAULT_FSYNC_SRC                               FSYNC_FROM_MODULE_BUILTIN_MCU
#elif defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401)
    #define DEFAULT_FSYNC_SRC                               FSYNC_FROM_MODULE_EXTERNAL
#else
    #define DEFAULT_FSYNC_SRC                               FSYNC_FROM_MODULE_BUILTIN_DTOF
#endif

#define DEFAULT_FSYNC_FREQUENCY                         40

#define PVDD_VOLTAGE_4_INDOOR_MODE                      7600    // unit is mv, for indoor mode
#define PVDD_VOLTAGE_4_OUTDOOR_MODE                     16000   // unit is mv, for outdoor mode

#define VOP_ADJUST_INTERVAL                             1000 //unit is ms



#define DEFAULT_PKT_DELAY_4_1G_MIPI                     0x10    // for register 0xA9, 0x08 for 10 FPS requirement of tree.

#define PTM_VCSEL_LASER_PERIOD                          127     // <=127, value for register 0xBC, laser repetition frequency period, unit is ns
#define PCM_VCSEL_LASER_PERIOD                          127     // <=127, value for register 0xBC, laser repetition frequency period, unit is ns
#define PTM_VCSEL_LASER_PULSE_WIDTH                     0xEE    // value for register 0xBD
#define PCM_PROX_VCSEL_LASER_PULSE_WIDTH                0xEE    // value for register 0xBE, 0xEE is 3.5ns, 0x66 is 3.0ns

#define COARSE_EXPOSURE_TIME                            0x01    // unit is 80us, for register 0xBF
#define FINE_EXPOSURE_TIME                              0x32    // unit is 80us, for register 0xC0, xialing@20251126 Set fine exposure to 4480us (0x38 * 80us) for Big FOV V2 module
#define PRXMT_EXPOSURE_TIME                             0x01    // unit is 80us, for register 0xC1
#define PCM_EXPOSURE_TIME                               0x19    // unit is 80us, for register 0xC2

#define TDC_DELAY_H_DEFAULT                             0x0A    // for register 0xC3
#define TDC_DELAY_L_DEFAULT                             0x08    // for register 0xC4

#define DEFAULT_COARSE_MASK_CONFIG                      0x21    // for register 0xB0
#define DEFAULT_FINE_MASK_CONFIG                        0x21    // for register 0xB1

#define MINI_DEMO_BOX // adaps ads6401s demo only runs on demo4 mini SoC box.

/* Application and interface configuration */
#define DTOF_APP_NAME                                   "SpadisQT"
#define TTY_DRIVERNAME_4_UART                           "ttyFIQ"
#define MIPI_RESET_DEFAULT_CFG                          STREAM_ON_WITH_MIPI_IP_RESET_FIRST

#define MIPI_SPEED                                      MIPISPEED_1G5_BPS
#define DEFAULT_WORK_MODE                               ADAPS_PTM_FHR_MODE

#define NON_CONTINUOUS_MIPI_CLK
#define IGNORE_PROBE_FAILURE
#define ENABLE_RUNTIME_REGISTER_UPDATE
#define ENABLE_VCSEL_DRV_ERROR_IRQ
#define DEVICE_CONCURRENCY_OPEN_CHECK
//#define PM_RUNTIME_ENABLE

// For i2c_rk3x.c bus driver of rockchip platform, the polling mode costs less time than the default interrupt mode,
// please make sure your i2c-rk3x.c is not too old to support the polling mode well,
// otherwize I suggest you to update it from https://github.com/armbian/linux-rockchip/blob/rk-5.10-rkr8/drivers/i2c/busses/i2c-rk3x.c,
//
// If you are porting to other SoC platform whose i2c bus driver does not support polling mode, you may comment out the following option 'I2C_BURST_WRITE_SPEED_OPTIMIZE_4_ROISRAM';
#define I2C_BURST_WRITE_SPEED_OPTIMIZE_4_ROISRAM


#define ENABLE_SENSOR_FSYNC_IRQ
#define ENABLE_MCU_ERROR_IRQ

#if !defined(CALIB_DATA_READY_IN_EEPROM_CHIP) && defined(CALIB_DATA_FROM_EEPROM_BIN_FILE)
    /* EEPROM data file path for calibration data when built-in eeprom is not available. */
    #define EEPROM_DATA_FILE_PATH           "/userdata/ads6401_eeprom_data.bin"
#endif

#define EEPROM_REAL_CAPACITY_SIZE                       EEPROM_CAPACITY_SIZE_64K

#define MIPISPEED_1G5_BPS                               1500     // 1.5G
#define MIPISPEED_1G2_BPS                               1200
#define MIPISPEED_1G_BPS                                1000
#define MIPISPEED_720M_BPS                              720
#define MIPISPEED_500M_BPS                              500
//#define MIPISPEED_328M_BPS                            328
//#define MIPISPEED_250M_BPS                            250
#define MIPISPEED_200M_BPS                              200
#define MIPISPEED_166M64_BPS                            166     // 166.64M

#if defined(NON_CONTINUOUS_MIPI_CLK)
    #undef MIPI_RESET_DEFAULT_CFG
    #define MIPI_RESET_DEFAULT_CFG                      STREAM_ON_WITHOUT_MIPI_IP_RESET
#endif

#if defined(ENABLE_SYS_CLK_125M)
    #define SYS_CLK_FACTOR                              2
#else
    #define SYS_CLK_FACTOR                              1
#endif


#define SENSOR_DATA_LANE_COUNT                          2

#if (SENSOR_DATA_LANE_COUNT == 1)
    #undef MIPI_SPEED
    #define MIPI_SPEED                                  MIPISPEED_1G2_BPS
#endif

