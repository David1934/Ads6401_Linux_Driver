#ifndef __ADS6401S_COMMON_H
#define __ADS6401S_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#define MCU_CHIP_ID                         0x90E1  // PY32L090E1BY7  WLCSP25 E1

enum {
    SUB_DEV_ID_MCU_SELF                     = 0x00,
    SUB_DEV_ID_ADS6401_DTOF                 = 0x10,
    SUB_DEV_ID_EEPROM_CHIP                  = 0x20,
};

typedef enum
{
    MCU_FW_TYPE_UNKNOWN                     = 0x00,
    MCU_FW_TYPE_APPLICATION                 = 0x0a,
    MCU_FW_TYPE_BOOTLOADER                  = 0x0b
} mcu_fw_type_t;

typedef enum
{
    MFS_IDLE                                = 0x00,
    MFS_TO_WRITE                            = 0x01,
    MFS_WRITE_DONE                          = 0x02,
} mcu_flashwrite_status_e;

typedef enum
{
    APP_FW_UPGRADE_NOT_START_YET            = 0,
    APP_FW_UPGRADE_SET_FW_LENGTH,
    APP_FW_UPGRADE_SET_FW_CRC32,
    APP_FW_UPGRADE_WRITE_UPGRADE_INFO_PARTITION,
    APP_FW_UPGRADE_WRITE_UPGRADE_INFO_PARTITION_SUCCESS,
    APP_FW_UPGRADE_WRITE_UPGRADE_INFO_PARTITION_FAILURE,
    APP_FW_UPGRADE_RX_FW_DATA,
    APP_FW_UPGRADE_WRITE_FW_DATA,
    APP_FW_UPGRADE_WRITE_FW_DATA_SUCCESS,
    APP_FW_UPGRADE_WRITE_FW_DATA_FAILURE,
    APP_FW_UPGRADE_CRC32_CHECK,
    APP_FW_UPGRADE_CRC32_CHECK_PASS         = 0x66,
    APP_FW_UPGRADE_CRC32_CHECK_FAILURE      = 0xFF,

    APP_FW_UPGRADE_SUCCESS                  = APP_FW_UPGRADE_CRC32_CHECK_PASS,
    APP_FW_UPGRADE_FAILURE                  = APP_FW_UPGRADE_CRC32_CHECK_FAILURE
} mcu_fwupgrade_status_e;

typedef enum
{
    ROISRAM_DATA_CRC_VERIFY_NOT_YET        = 0x00,
    ROISRAM_DATA_CRC_VERIFY_PASS           = 0x66,
    ROISRAM_DATA_CRC_VERIFY_FAIL           = 0xFF,
} roisram_data_crc_verify_result_e;

typedef enum
{
    VOP_OFF                                = 0x00,
    VOP_INITIAL_VOLTAGE                    = 0x01,
    VOP_PER_TEMPERATURE                    = 0x02,
} vop_adjust_policy_e;

typedef enum
{
    FSYNC_FROM_MODULE_BUILTIN_DTOF         = 0x00,
    FSYNC_FROM_MODULE_BUILTIN_MCU          = 0x01,
    FSYNC_FROM_MODULE_EXTERNAL_INPUT       = 0x02,
} fsync_source_e;

enum {
    SWIFT_VOP_ALGO_VER_UNKNOWN = 0,
    SWIFT_VOP_ALGO_VER_1,
    SWIFT_VOP_ALGO_VER_2,
    SWIFT_VOP_ALGO_VER_3,
    SWIFT_VOP_ALGO_VER_CNT = SWIFT_VOP_ALGO_VER_3,
};

typedef enum
{
    MOD_POWER_OFF = 0,
    MOD_POWER_UP_ING,
    MOD_POWER_ON,
    MOD_POWER_DOWN_ING,
}module_power_state_e;

typedef enum
{
    OP_STATE_IDLE= 0, // 空闲,尚没有操作请求

    DTOF_WRITE_OP_REQUESTED, // 已收到SoC端的读请求, 在i2c slave中断处理里置位
    DTOF_WRITE_OP_PROCESSING, // 当MCU在开始处理写请求时,置位
    DTOF_WRITE_OP_SUCCESS, // 当MCU端已完成该寄存器写操作时, 置位
    DTOF_WRITE_OP_FAILURE, // 当MCU端写寄存器失败时,置位

    EEPROM_READ_DATA_READY, // EEPROM数据块读取就绪
    EEPROM_READ_DATA_FAILURE, // EEPROM数据块读取失败
    EEPROM_WRITE_DATA_SUCCESS, // EEPROM数据块写入成功
    EEPROM_WRITE_DATA_FAILURE, // EEPROM数据块写入失败
}sub_dev_op_state_e;

enum {
    DTOF_CONFIG_STAGE_NOT_YET = 0,
    DTOF_CONFIG_STAGE_INIT,
    DTOF_CONFIG_STAGE_WORKMODE,
    DTOF_CONFIG_STAGE_STREAMING_ON,
    DTOF_CONFIG_STAGE_STREAMING_OFF,
    DTOF_CONFIG_STAGE_LOADED_SCRIPT,
};

enum {
    // ================= PART 1: these STATUS registers have fixed values =================
    STATUS_REG_START = 0x0000,

    STATUS_REG_MCU_CHIP_ID_L = STATUS_REG_START,        // 0x0000
    STATUS_REG_MCU_CHIP_ID_H,
    STATUS_REG_MAX_EEPROM_OP_SIZE_PER_TIME_L,
    STATUS_REG_MAX_EEPROM_OP_SIZE_PER_TIME_H,
    STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_L,              // 0x0004
    STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_H,
    STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST_L,
    STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST_H,
    STATUS_REG_EEPROM_PAGE_SIZE_L,                      // 0x0008
    STATUS_REG_EEPROM_PAGE_SIZE_H,
    STATUS_REG_EEPROM_CAPACITY_SIZE_BYTE0,
    STATUS_REG_EEPROM_CAPACITY_SIZE_BYTE1,
    STATUS_REG_EEPROM_CAPACITY_SIZE_BYTE2,              // 0x000C

    // ================= PART 2: these STATUS registers need be read when cat /sys/kernal/adaps/ads6401s/status =================
    STATUS_REG_RUNNING_FW_TYPE,
    STATUS_REG_RUNNING_FW_VERSION_L,
    STATUS_REG_RUNNING_FW_VERSION_H,
    STATUS_REG_MODULE_POWER_STATE,                      // 0x0010
    STATUS_REG_CUR_PVDD_VOL_L,
    STATUS_REG_CUR_PVDD_VOL_H,
    STATUS_REG_CUR_VOP_VOL_ABS_L,
    STATUS_REG_CUR_VOP_VOL_ABS_H,                       // 0x0014
    STATUS_REG_CUR_TEMPERATURE_L,
    STATUS_REG_CUR_TEMPERATURE_H,
    STATUS_REG_MODULE_FSM,
    STATUS_REG_VOP_ALGO_VERSION,                        // 0x0018
    STATUS_REG_CUR_ROISRAM_DATA_GROUP_INDEX,

    // ================= PART 3: these STATUS registers need be read to confirm some operate status =================
    STATUS_REG_SUB_DEV_OP_STATE,
    STATUS_REG_FW_UPGRADE_STATUS,
    STATUS_REG_DTOF_OTP_DATA_READY,                     // 0x001C
    STATUS_REG_ROISRAM_DATA_CRC_VERIFY_RESULT,
    STATUS_REG_INIT_ROISRAM_WRITE_DONE,
    STATUS_REG_DTOF_STREAM_ON_READY,

    STATUS_REG_END = 0x002F,

    // ================= PART 4: these CTRL registers need be read when cat /sys/kernal/adaps/ads6401s/status =================
    CTRL_REG_START = 0x0030,

    CTRL_REG_ERROR_STATUS_L = CTRL_REG_START,           // 0x0030
    CTRL_REG_ERROR_STATUS_H,
    CTRL_REG_WARNING_STATUS_L,
    CTRL_REG_WARNING_STATUS_H,
    CTRL_REG_ERROR_MASK_L,                              // 0x0034
    CTRL_REG_ERROR_MASK_H,
    CTRL_REG_WARNING_MASK_L,
    CTRL_REG_WARNING_MASK_H,
    CTRL_REG_VOP_CTRL_POLICY,                           // 0x0038
    CTRL_REG_VOP_ADJUST_INTERVAL,                       // unit is 100ms
    CTRL_REG_ROISRAM_ROLLING_ENABLE,
    CTRL_REG_ROISRAM_DATA_GROUP_COUNT,
    CTRL_REG_ROISRAM_DATA_SIZE_L,                       // 0x003C
    CTRL_REG_ROISRAM_DATA_SIZE_H,

    // ================= PART 5: these CTRL registers used to let MCU do something =================
    CTRL_REG_ROISRAM_DATA_CRC32_BYTE0,
    CTRL_REG_ROISRAM_DATA_CRC32_BYTE1,
    CTRL_REG_ROISRAM_DATA_CRC32_BYTE2,                  // 0x0040
    CTRL_REG_ROISRAM_DATA_CRC32_BYTE3,
    CTRL_REG_ROISRAM_DATA_CRC_VERIFY,
    CTRL_REG_WRITE_INIT_ROISRAM_DATA,

    CTRL_REG_MODULE_POWER_CTRL,                         // 0x0044
    CTRL_REG_SET_PVDD_VOL_L,
    CTRL_REG_SET_PVDD_VOL_H,
    CTRL_REG_FSYNC_SOURCE,
    CTRL_REG_FSYNC_PULSE_WIDTH,                         // 0x0048
    CTRL_REG_FSYNC_FREQUENCY,
    CTRL_REG_DTOF_CONFIG_STAGE,
    CTRL_REG_DTOF_STREAMING_STATE,

    CTRL_REG_EEPROM_OP_TYPE,                            // 0x004C
    CTRL_REG_EEPROM_OP_START_OFFSET_L,
    CTRL_REG_EEPROM_OP_START_OFFSET_H,
    CTRL_REG_EEPROM_CUR_OP_SIZE,

    CTRL_REG_LET_MCU_ENTER_BOOTLOADER,                  // 0x0050
    CTRL_REG_LET_MCU_REBOOT,
    CTRL_REG_MCU_FW_SIZE_BYTE0,
    CTRL_REG_MCU_FW_SIZE_BYTE1,
    CTRL_REG_MCU_FW_SIZE_BYTE2,                         // 0x0054
    CTRL_REG_MCU_FW_CRC32_BYTE0,
    CTRL_REG_MCU_FW_CRC32_BYTE1,
    CTRL_REG_MCU_FW_CRC32_BYTE2,
    CTRL_REG_MCU_FW_CRC32_BYTE3,                        // 0x0058
    CTRL_REG_MCU_FW_NEW_VERSION_L,
    CTRL_REG_MCU_FW_NEW_VERSION_H,
    CTRL_REG_WRITE_UPGRADE_INFO_TO_FLASH,
    CTRL_REG_MCU_FW_DATA_WRITE_STATUS,                  // 0x005C

    CTRL_REG_MCU_UART_SR_BYTE0,
    CTRL_REG_MCU_UART_SR_BYTE1,
    CTRL_REG_MCU_UART_SR_BYTE2,
    CTRL_REG_MCU_UART_SR_BYTE3,                         // 0x0060

    CTRL_REG_DTOF_CALISRAM_CTRL_READBACK,
    CTRL_REG_DVCC_VOLTAGE_MV_L,
    CTRL_REG_DVCC_VOLTAGE_MV_H,

    CTRL_REG_END = 0x006F,

    // ================= PART 6: these CTRL registers are used for big block data transfer =================
    DT_REG_START = 0x0070,

    DT_REG_EEPROM_DATA_TRANSFER    = DT_REG_START,      // 0x0070
    DT_REG_OTP_DATA_TRANSFER,
    DT_REG_ROISRAM_DATA_TRANSFER,
    DT_REG_MCU_FW_TRANSFER,
    DT_REG_MCU_REG_DUMP,                                // 0x0074
    DT_REG_ADS6401_REG_DUMP,
    DT_REG_RT_TEMPERATURE_VOLTAGE,
    DT_REG_RINGBUF_LOG,

    DT_REG_END = 0x007F,
};

#define MCU_BASIC_REG_SIZE                  DT_REG_START    // MCU基本寄存器个数, 包括STATUS and CTRL寄存器, 不包括DT寄存器

typedef union mcu_fw_version
{
    struct{
        uint16_t version_revision:8;
        uint16_t version_minor:4;
        uint16_t version_major:4;
    }field;

    uint16_t fw_version;
}mcu_fw_version_t;




#ifdef __cplusplus
}
#endif

#endif /* __ADS6401S_COMMON_H */
