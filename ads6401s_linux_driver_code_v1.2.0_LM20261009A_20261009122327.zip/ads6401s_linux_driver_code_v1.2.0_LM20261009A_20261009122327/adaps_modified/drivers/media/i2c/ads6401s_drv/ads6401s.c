// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (C) 2026- Adaps Photonics Inc.
 *
 * Driver for the Adaps ADS6401s dToF (direct Time-of-Flight) smart module.
 *
 * This driver implements a V4L2 sub-device interface to control the sensor.
 * It supports various hardware configurations through conditional compilation.
 *
 * The driver manages sensor initialization, streaming control, power sequencing,
 * and provides sysfs/debugfs interfaces for debugging and advanced configuration.
 */

#include <linux/clk.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/i2c.h>
#include <linux/module.h>
#include <linux/regulator/consumer.h>
#include <linux/sysfs.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/tty.h>
#include <linux/debugfs.h>
#include <media/media-entity.h>
#include <media/v4l2-async.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-subdev.h>
#include <linux/v4l2-mediabus.h>
#include <linux/of_irq.h>
#include <linux/miscdevice.h>
#include <linux/mman.h>
#include <linux/crc32.h>
#include <generated/compile.h>
#include <linux/gpio.h>
#include <linux/zlib.h>
#include <linux/pm_runtime.h>
//#include <generated/utsversion.h>

#include <linux/rk-camera-module.h>
#include <linux/adaps_types.h>

#define VERSION_MAJOR                   1
#define VERSION_MINOR                   2
#define VERSION_REVISION                0
#define LAST_MODIFIED_TIME              "20261009A"


#include "ads6401s_build_options.h"

//#define __weak                              __attribute__((weak))
#define ZLIB_COMPRESS_LEVEL                 6
#define ZLIB_WINDOW_BITS                    12
#define ZLIB_MEM_LEVEL                      4

#define MAX(a, b)                           ((a) > (b) ? (a) : (b))
#define GPIO_LEVEL_TOGGLE(cur_lvl)          (GPIO_LEVEL_LOW == (cur_lvl) ? GPIO_LEVEL_HIGH: GPIO_LEVEL_LOW)

#define VERSION_CODE                        (VERSION_MAJOR << 16 | VERSION_MINOR << 8 | VERSION_REVISION)
#define VERSION_STRING                      __stringify(VERSION_MAJOR) "."  \
        __stringify(VERSION_MINOR) "."  \
        __stringify(VERSION_REVISION)
#define FULL_VERSION_STRING                 VERSION_STRING "_LM" LAST_MODIFIED_TIME

#define VENDOR_NAME                         "adaps"
#define DRIVER_NAME                         "Adaps ads6401 dToF sensor driver"
#define SENSOR_NAME                         "ads6401s"
#define DEV_COMPATIBLE_STRING               "adaps,ads6401s-mbox"

#define LOG_TAG                             "<DRV_ADS6401S> "

#define SENSOR_MODE_NAME_GRAY               "PCM-Gray"
#define SENSOR_MODE_NAME_PHR                "PTM-PHR"
#define SENSOR_MODE_NAME_FHR                "PTM-FHR"

#define SENSOR_OTP_DATA_SIZE                32 // unit is word (16-bits)

#define REG16_NULL                          0xFFFF

#define EEPROM_CAPACITY_SIZE_32K            (32 * 1024)         // 32KB
#define EEPROM_CAPACITY_SIZE_64K            (64 * 1024)         // 64KB, where A16 changes
#define EEPROM_CAPACITY_SIZE_128K           (128 * 1024)        // 128 Kbytes = 131,072 bytes
#define EEPROM_WRITE_TIMEOUT                5000000    // unit is us
#define EEPROM_READ_TIMEOUT                 5000000    // unit is us

#define MEGA                                1000000

#define SOC_MIPI_RX_CLOCK_FREQ              MAX(MIPI_SPEED/2, 500)     // The min is 500MHz, SoC MIPI RX clock frequency

#define SENSOR_BITS_PER_SAMPLE              8
#define SENSOR_LINK_FREQ                    (SOC_MIPI_RX_CLOCK_FREQ * MEGA)
/* pixel rate = link frequency * 2 * lanes / BITS_PER_SAMPLE */
//#define SENSOR_PIXEL_RATE                 ((SENSOR_LINK_FREQ / SENSOR_BITS_PER_SAMPLE) * 2 * SENSOR_DATA_LANE_COUNT)

#define SENSOR_XVCLK_FREQ_M                 24
#define SENSOR_XVCLK_FREQ                   (SENSOR_XVCLK_FREQ_M * MEGA)

#define SENSOR_MEDIA_BUS_FMT                MEDIA_BUS_FMT_SBGGR8_1X8
#define SENSOR_RAW_DATA_TYPE                0x2A        // RAW8

#define SENSOR_CHIP_ID                      0x5E01
#define MCU_CHIP_ID_PY32L090E1BY7           0x90E1
#define SENSOR_REG_SYSC_FSM                 0x00AD
#define SECOND_I2C_ADDRESS_4_SENSOR         0x4A

#define SENSOR_READY_CHECK_BASE_DELAY       1000     // unit is us
#define SENSOR_READY_CHECK_INRERVAL         1000     // unit is us
#define SENSOR_READY_CHECK_TIMEOUT          10000     // unit is us

#define SENSOR_EXPOSURE_MIN                 1
#define SENSOR_EXPOSURE_STEP                1
#define SENSOR_EXPOSURE_MAX                 255

#define I2C_M_WR                            0

#define SENSOR_FSM_WAIT_TIMEOUT             50000        // unit is us
#define SENSOR_FSM_IDLE_STATE               0
#define SENSOR_FSM_WAIT_SYNC_STATE          2

#define OTP_TEMPERATURE_LOW                 2500   // it is fixed to 25.00 degree

#define MCU_CHECKSUM_SALT                   0x0F
#define MCU_CHECKSUM_BYTES                  1
#define MCU_READY_CHECK_BASE_DELAY          5000     // unit is us
#define MCU_READY_CHECK_INRERVAL            5000     // unit is us
#define MCU_READY_CHECK_TIMEOUT             5000000     // unit is us
#define MCU_I2C_OP_EXTRA_DELAY              2000     // unit is us

#define MODULE_POWER_ON_WAIT_MS             2000     // unit is ms, to wait MCU to read ads6401 basic registers and otp data
#define MODULE_POWER_READY_CHECK_TIMEOUT    10000     // unit is us
#define MODULE_SENSOR_REG_UPDATE_WAIT_MS    500     // unit is ms, to wait MCU to read ads6401 basic registers and otp data
#define MCU_STATUS_WAIT_TIMEOUT_US          1000000

#define MCU_CSD_REG_BASE                    0x000000

#define MCU_DTOF_REG_BASE                   0x100000
#define MCU_DTOF_REG_SIZE                   0xF0

#define MCU_EEPROM_REG_BASE                 0x200000
#define MCU_EEPROM_REG_SIZE                 0x10000

#define MS_TO_NS                            1000000

#define DEFAULT_FSYNC_PULSE_WIDTH           10          // unit is us

#define NO_FORCE_MASK_CONFIG                0xFF

#define ARRAY_LEN(arr)                      (sizeof(arr) / sizeof(arr[0]))

#define CURRENT_CLIENT                      (((current->tgid << 16) & 0xFFFF0000) | (current->pid & 0xFFFF))
#define CLIENT_TO_PID(CLIENT)               (((CLIENT) >> 16) & 0xFFFF)
#define CLIENT_TO_TID(CLIENT)               ((CLIENT) & 0xFFFF)

#ifndef ENABLE_MCU_ERROR_IRQ
#define ENABLE_MCU_ERROR_IRQ
#endif

#if !defined(DISABLE_DBG_MACRO_4_WARNING_CHECK)

inline const char* get_filename(const char* path) {
    const char* file = strrchr(path, '/');
    if (!file) {
        file = strrchr(path, '\\');
    }
    return file ? file + 1 : path;
}

#define CONSOLE_ERROR(fmt, args ...)                                                                        \
    do {                                                                                                    \
        printk2console("<%s> %s L%d <ERR> " fmt "\n",                                                       \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define CONSOLE_PRINT(fmt, args ...)                                                                        \
    do {                                                                                                    \
        printk2console("[%s L%d] " fmt "\n",                                                                  \
            get_filename(__FILE__), __LINE__, ##args);                                                      \
    }while(0)

#define DBG_PRINTK(fmt, args ...)                                                                           \
    do {                                                                                                    \
        printk(KERN_ERR "%s <%s> %s L%d " fmt "\n",                                                         \
            LOG_TAG, __func__, get_filename(__FILE__), __LINE__, ##args);                                   \
    }while(0)

#define DBG_ERROR(fmt, args ...)                                                                            \
    do {                                                                                                    \
        struct timespec64 ts;                                                                               \
        struct tm tm_res;                                                                                   \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                                \
        pr_err("%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <E> <%s> %s L%d " fmt "\n",             \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                                 \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                                   \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define DBG_NOTICE(fmt, args ...)                                                                           \
    do {                                                                                                    \
        struct timespec64 ts;                                                                               \
        struct tm tm_res;                                                                                   \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                                \
        printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <N> <%s> %s L%d " fmt "\n",    \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                                 \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                                   \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define DBG_INFO(fmt, args ...)                                                                             \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_DEBUG_INFO_ENABLE))                           \
    {                                                                                                       \
        struct timespec64 ts;                                                                               \
        struct tm t;                                                                                        \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                     \
                                                                                                            \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] <I> <%s> %s L%d " fmt "\n",   \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                            \
            t.tm_hour, t.tm_min, t.tm_sec,                                                                  \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }

#define TRACE_REG_RW(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & (ADAPS_DBG_TRACE_REGS_READ | ADAPS_DBG_TRACE_REGS_WRITE)))                       \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] <%s> %s L%d " fmt "\n",   \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
        __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }

#define TRACE_IOCTL(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_IOCTL_CMD))                               \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        pr_err("%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] ioctl <%s> %s L%d " fmt "\n",      \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#define TRACE_V4L2_CB(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_V4L2_CALLBACK))                           \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] v4l2_cb <%s> %s L%d:"fmt"\n", \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#define TRACE_PM_RUNTIME(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_PM_RUNTIME))                                  \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] " fmt "\n",               \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
        ##args);                                \
    }

#define TRACE_POWER_CTRL(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_POWER_CTRL))                              \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] power_ctl <%s> %s L%d:"fmt"\n", \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#define LOG2T_NOTICE(o_t, fmt, args ...)                                                                    \
do {                                                                                                    \
    struct timespec64 ts;                                                                               \
    struct tm tm_res;                                                                                   \
    if (o_t & OT_KERNEL) {                                                                              \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                            \
        printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <N> %s()-%04d " fmt "\n",  \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                             \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                               \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __FUNCTION__, __LINE__, ##args);                                                            \
    }                                                                                                   \
    if (o_t & OT_CONSOLE) {                                                                             \
        printk2target(o_t, "%s <N> %s()-%04d " fmt,                                                    \
             LOG_TAG, __FUNCTION__, __LINE__, ##args);                                                  \
    }                                                                                                   \
}while(0)

#define LOG2T_ERROR(o_t, fmt, args ...)                                                                     \
do {                                                                                                    \
    struct timespec64 ts;                                                                               \
    struct tm tm_res;                                                                                   \
    if (o_t & OT_KERNEL) {                                                                              \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                            \
        printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <E> %s()-%04d " fmt "\n",  \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                             \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                               \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __FUNCTION__, __LINE__, ##args);                                                            \
    }                                                                                                   \
    if (o_t & OT_CONSOLE ) {                                                                            \
        printk2target(o_t, "%s <E> %s()-%04d " fmt,                                                    \
            LOG_TAG, __FUNCTION__, __LINE__, ##args);                                                   \
    }                                                                                                   \
}while(0)

#else
#define CONSOLE_ERROR                   printk2console
#define CONSOLE_PRINT                   printk2console
#define DBG_PRINTK                      printk
#define DBG_ERROR                       printk
#define DBG_NOTICE                      printk
#define DBG_INFO                        printk
#define TRACE_REG_RW                    printk
#define TRACE_IOCTL                     printk
#define TRACE_V4L2_CB                   printk
#define TRACE_POWER_CTRL                printk
#define LOG2T_NOTICE(o_t, fmt, args ...)                      printk(fmt, ##args)
#define LOG2T_ERROR(o_t, fmt, args ...)                      printk(fmt, ##args)
#endif

#ifdef TRACE_MUTEX_LOCK
    #define MUTEX_LOCK(mutex)                                                                                   \
        do {                                                                                                    \
            if ((NULL == g_sensor) || (g_sensor->dbg_ctrl & ADAPS_DBG_MUTEX_LOCK))                              \
            {                                                                                                   \
                struct timespec64 ts;                                                                           \
                struct tm tm_res;                                                                               \
                ktime_get_real_ts64(&ts);                                                                       \
                time64_to_tm(ts.tv_sec, 0, &tm_res);                                                            \
                printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] MUTEX_LOCK on <%s> %d\n",  \
                    LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                             \
                    tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                               \
                    ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
                    __func__, __LINE__);                                                                        \
            }                                                                                                   \
            mutex_lock((mutex));                                                                                \
        }while(0)

    #define MUTEX_UNLOCK(mutex)                                                                                     \
        do {                                                                                                    \
            if ((NULL == g_sensor) || (g_sensor->dbg_ctrl & ADAPS_DBG_MUTEX_LOCK))                              \
            {                                                                                                   \
                struct timespec64 ts;                                                                           \
                struct tm tm_res;                                                                               \
                ktime_get_real_ts64(&ts);                                                                       \
                time64_to_tm(ts.tv_sec, 0, &tm_res);                                                            \
                printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] MUTEX_UNLOCK on <%s> %d\n",\
                    LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                             \
                    tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                               \
                    ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
                    __func__, __LINE__);                                                                        \
            }                                                                                                   \
            mutex_unlock((mutex));                                                                              \
        }while(0)
#else
    #define MUTEX_LOCK(mutex)               mutex_lock((mutex))
    #define MUTEX_UNLOCK(mutex)             mutex_unlock((mutex))
#endif

#if !defined(BIT)
#define BIT(n)                      (1 << n)
#endif

enum adaps_dbg_type_t {
    ADAPS_DBG_TRACE_REGS_READ           = BIT(0),
    ADAPS_DBG_DUMP_REGS                 = BIT(1),
    ADAPS_DBG_TRACE_REGS_WRITE          = BIT(2),
    ADAPS_DBG_TESTPATTERN_ENABLE        = BIT(3),

    ADAPS_DBG_POWER_CTRL                = BIT(4),
    ADAPS_DBG_DEBUG_INFO_ENABLE         = BIT(5),
    ADAPS_DBG_DUMP_SRAM_REG             = BIT(6),
    ADAPS_DBG_PM_RUNTIME                = BIT(7),

    ADAPS_DBG_VOLTAGE_UPDATE            = BIT(8),
    ADAPS_DBG_DISABLE_VCSEL_DRIVER      = BIT(9),
    ADAPS_DBG_ROISRAM_RB_4_VERIFY       = BIT(10),
    ADAPS_DBG_IOCTL_CMD                 = BIT(11),

    ADAPS_DBG_V4L2_CALLBACK             = BIT(12),
    ADAPS_DBG_MUTEX_LOCK                = BIT(13),
    ADAPS_DBG_DISABLE_ROI_SWITCH        = BIT(14),
    ADAPS_DBG_DISABLE_ERR_IRQ_HANDLE    = BIT(15),

    ADAPS_DBG_DISABLE_RUNTIME_UPDATE    = BIT(16),
    ADAPS_DBG_TRACE_FSYNC_IRQ           = BIT(17),
    ADAPS_DBG_DISABLE_LOAD_SCRIPT       = BIT(18),
    ADAPS_DBG_TRACE_ROI_SWITCH          = BIT(19),

    ADAPS_DBG_SKIP_SENSOR_READY_CHECK   = BIT(20),
    ADAPS_DBG_DISABLE_ROI_WRITE_POLL_MD = BIT(21),
    ADAPS_DBG_ENABLE_VCSEL_L_MODE       = BIT(22),
    ADAPS_DBG_FORCE_VCSEL_DRIVER_OFF    = BIT(23),

    ADAPS_DBG_SKIP_EEPROM_DATA_READ     = BIT(24), // if use loaded data from PC SpadisApp

    ADAPS_DBG_ONCE                      = BIT(25)  // keep at LAST seat.
};

enum log_output_target_e {
    OT_KERNEL       = BIT(0),
    OT_CONSOLE      = BIT(1),
    OT_BOTH         = (OT_KERNEL | OT_CONSOLE)
};

enum {
    FORCE_SENSOR_ROLE_NONE = 0,    // No force
    FORCE_SENSOR_ROLE_AS_MASTER,
    FORCE_SENSOR_ROLE_AS_SLAVE
};

enum {
    FUNCTION_DISABLE = 0,
    FUNCTION_ENABLE = 1
};

enum {
    GPIO_LEVEL_LOW = 0,
    GPIO_LEVEL_HIGH = 1
};

enum {
    SENSOR_RESET_DISABLED = 0,
    SENSOR_RESET_ENABLED = 1
};

enum {
    STREAM_ON_WITHOUT_MIPI_IP_RESET         = 0, // No reset
    STREAM_ON_WITH_MIPI_IP_RESET_FIRST      = 1, // reset mipi module before stream on
    STREAM_ON_FIRST_AND_THEN_RESET_MIPI_IP  = 2  // reset mipi module after stream on
};

enum {
    POWER_REASON_UNKNOWN            = 0,
    POWER_REASON_READ_CALIB_EEPROM  = 1,
    POWER_REASON_WRITE_CALIB_EEPROM = 2,
    POWER_REASON_READ_ADC_DATA      = 3,
    POWER_REASON_MANUAL             = 4,
    POWER_REASON_LINUX_DRIVER_REMOVE= 5,
    POWER_REASON_LINUX_DRIVER_PROBE = 6,
    POWER_REASON_V4L2_S_POWER_CB    = 7,
    POWER_REASON_RUMTIME_PM         = 8,
};

#include "ads6401s_common.h"


struct sensor_mode {
    u32                 width;
    u32                 height;
    struct v4l2_fract   max_fps;
    u32                 exp_def;
    const struct setting_r16vd  *wkmode_reg_cfg_list;
    const u32 wkmode_reg_cfg_count;
};

/**
 * struct sensor - Main sensor device structure
 * 
 * This structure contains all the state information for the ADS6401 sensor.
 * It manages I2C communication, power states, operation modes, and V4L2 integration.
 */
struct sensor {
    const struct of_device_id       *matched_dev_id;
    u16                             sensor_chipid;
    u32                             version_code;
    spinlock_t                      fsync_spinlock;
    struct mutex                    sensor_mutex;
    struct mutex                    mcu_comm_mutex;              // serialize SoC<=>MCU I2C txn (send+recv)
    struct mutex                    fsync_mutex;
    struct kobject                  *link_kobj;

    bool                            otp_read;   // whether read the otp data or not?
    bool                            otp_blank;
    uint16_t                        otp_vbe25;
    uint16_t                        otp_vbd_low;        // unit is 10mv/0.01v
    uint16_t                        otp_vbd_high;        // unit is 10mv/0.01v
    uint16_t                        otp_adc_vref;
    u16                             otp_raw_data[SENSOR_OTP_DATA_SIZE];
    u8                              otp_product_id[SWIFT_PRODUCT_ID_SIZE];
    uint16_t                        otp_K_high;
    uint16_t                        otp_T_high;
    uint16_t                        otp_K_low;
    uint16_t                        otp_T_low;
    u8                              vop_algo_version;
    uint16_t                        vop_adjust_interval;       // unit is ms

    struct i2c_client               *mcu_i2c_client;
    u32                             mcu_comm_extra_delay;       // unit is us
    u16                             mcu_chipid;
    mcu_fw_type_t                   mcu_fw_type;
    mcu_fw_version_t                mcu_fw_version;
    bool                            mcu_power_on;
    u8                              mcu_fsm;
    u16                             mcu_cur_temperature_x100;      // Eg. the value 2715 means 27.15 degree
    u16                             mcu_cur_vop_abs_x100;           // it is vop absolute value X 100, since the real vop is negative. Eg. the value 2405 means 24.05v
    u8                              mcu_vop_ctrl_policy;
    u8                              mcu_vop_algo_version;
    u8                              mcu_vop_adjust_interval;     // unit is 100 ms
    u16                             mcu_cur_pvdd_x100;              // it is pvdd value X 100. Eg. the value 760 means 7.60v
    u8                              mcu_cur_roisram_group_index;

    u16                             mcu_error_status;
    u16                             mcu_warning_status;
    bool                            mcu_roisram_rolling;
    bool                            mcu_roisram_data_group_cnt;
    u16                             mcu_roisram_data_size;

    u32                             chksum_fail_times;
    u32                             read_fail_times;
    u32                             write_fail_times;

#if defined(ENABLE_MCU_FIRMWARE_UPGRADE)
    u32                             new_fw_total_length;
    u32                             new_fw_total_crc32;
    u32                             new_fw_transfered_offset;
    u16                             block_size_4_flash_write;
    mcu_flashwrite_status_e         flashwrite_status;
    mcu_fwupgrade_status_e          upgrade_status;
#endif

    u16                             max_transfer_size_per_burst;
    u16                             max_eeprom_op_size_per_time;

    swift_eeprom_v2_data_t*         eeprom_data;
    u32                             eeprom_capacity;       // unit is byte
    u32                             eeprom_page_size;       // unit is byte
    u32                             eeprom_data_size;       // sizeof(swift_spot_module_eeprom_data_t) or sizeof(swift_flood_module_eeprom_data_t)
    bool                            eeprom_data_crc_matched;
    bool                            static_data_ready;

    struct mutex                    misc_mutex;                  // mutex protect for misc device related callback
    u32                             client_id_4_misc;           // high 16 bits for process id, low 16 bits for thread id.
    struct task_struct              *client_task_4_misc;
    u8                              *mmap_buffer_base;
    u32                             mmap_buffer_max_size;       // This value should be a multiple of PAGE_SIZE (4096)

    struct device                   *dev;
    struct miscdevice               misc_device;
    bool                            load_script;
    u8                              *loaded_sensor_reg_setting;   // loaded register setting buffer(struct setting_rvd array[]) for sensor config
    u16                             loaded_sensor_reg_setting_cnt;    // loaded register setting count for sensor config
    u8                              *loaded_vcsel_reg_setting;   // loaded register setting buffer(struct setting_rvd/setting_rvd16 array[]) for vcsel driver config
    u16                             loaded_vcsel_reg_setting_cnt;    // loaded register setting count for vcsel driver config
    u8                              *loaded_roi_sram;
    u16                             loaded_roi_sram_size;
    u32                             i2c_bus_freq_hz;
    u32                             dbg_ctrl;
    u8                              reset_mipi_4_streamon;
    struct dentry                   *dbgfs_dentry_4_root;
    struct debugfs_blob_wrapper     dbgfs_blob_4_calib_data;
    struct dentry                   *dbgfs_dentry_4_calib_data;
    struct debugfs_blob_wrapper     dbgfs_blob_4_roisram_data;
    struct dentry                   *dbgfs_dentry_4_roisram_data;
    u8                              mipi_data_lanes;

    struct gpio_desc                *mcu_reset_gpio;
    struct gpio_desc                *iovcc_en_gpio;
    struct gpio_desc                *avcc_en_gpio;
    struct gpio_desc                *drv_vcc_en_gpio;

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    int                             fsync_irq;                  // frame sync interrupt
#endif

    u32                             fsync_times;
    ktime_t                         first_fsync_time;
    ktime_t                         last_fsync_time;
    s64                             min_fsync_gap;
    s64                             max_fsync_gap;
    bool                            roi_sram_rolling;
    u8                              max_calib_sram_data_group_cnt;

#if defined(ENABLE_MCU_ERROR_IRQ)
    int                             mcu_err_irq;                  // mcu error handle interrupt
    u32                             mcu_err_irq_times;
#endif

    struct v4l2_subdev              subdev;
    struct media_pad                pad;
    struct v4l2_ctrl_handler        ctrl_handler;
    struct v4l2_ctrl                *ctrl_linkfreqency;
    struct v4l2_ctrl                *ctrl_pixelrate;
    struct v4l2_ctrl                *ctrl_exposure;
//    struct v4l2_rect                crop;

    bool                            probe_success;
    bool                            power_on;
    u32                             power_on_times;
    bool                            sensor_cfg_done;
    bool                            test_pattern_enabled;
    bool                            streaming;
    ktime_t                         stream_start;

    u32                             client_id_4_sensor;         // high 16 bits for process id, low 16 bits for thread id.
    struct task_struct              *client_task_4_sensor;

    u32                             module_index;
    const char                      *module_facing;
    const char                      *module_name;
    const char                      *len_name;

    const struct sensor_mode        *cur_sensor_mode;
    u8                              tdc_delay_major;
    u8                              tdc_delay_minor;
    u8                              anchor_x;
    u8                              anchor_y;
    u8                              rowSearchingRange;
    u8                              colSearchingRange;
    u8                              coarseExposureCfg;
    u8                              fineExposureCfg;
    u8                              grayExposureCfg;
    u8                              laserExposurePeriodCfg;

    int                             cur_wkmode;
    u8                              cur_mtype;                  // current measurement type
    u8                              cur_etype;                  // current enviroment type
    u8                              cur_pmode;                  // current power mode
    u8                              cur_frtype;                 // current frame rate type, refer to AdapsFramerateType
    u8                              cur_vmode;                  // current vcsel mode
    u8                              cur_v_zone_cnt;             // current vcsel zone count

    u8                              cur_coarse_exposure_val;
    u8                              cur_gray_exposure_val;
    u8                              cur_fine_exposure_val;     // to be notified to algo lib
    u8                              cur_laser_exposure_period;  // to be notified to algo lib
    u16                             force_pvdd_voltage;           // unit is mv
    u16                             force_dvcc_voltage;           // unit is mv
    bool                            dtof_calisramctrl_reg_rb_enable;

    u8                              slave_fps_config;

    u8                              force_coarse_mask_cfg;        //for register 0xB0
    u8                              force_fine_mask_cfg;          //for register 0xB1

    u8                              force_mipi_tx_delay;        //for register 0xA9
    u8                              force_vcsel_laser_period;   //for register 0xBC
    u8                              force_vcsel_laser_pulse_width;  //for register 0xBD and 0xBE
    u8                              force_fine_exposure_time;   //for register 0xC0
    u8                              force_pcm_exposure_time;    //for register 0xC2
    u8                              force_tdc_delay_time_h;       //for register 0xC3
    u8                              force_tdc_delay_time_l;       //for register 0xC4
};

#define to_sensor(sd)       container_of(sd, struct sensor, subdev)


static const struct setting_r16vd sensor_streamoff_regs[] = {
    {0x00AB, 0x00, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd sensor_streamon_regs[] = {
    {0x00AB, 0x01, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd stream_on_with_mipi_reset_first[] = {
    {0x00AE, 0x10, 0},
    {0x00AB, 0x01, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd stream_on_first_and_then_reset_mipi[] = {
    {0x00AB, 0x01, 0},
    {0x00AE, 0x10, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd sensor_init_regs[] = {
    {0xA8, 0x30, 0},
    {0xD4, 0x32, 0},
    {0xD5, 0xFA/SYS_CLK_FACTOR, 0}, // 250/125M sys clock

    #if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x66, 0},
        {0x7E, 0x07, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x02, 0},
        {0x8E, 0x02, 0},
    #elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x65, 0},
        {0x7E, 0x0B, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x03, 0},
        {0x8E, 0x03, 0},
    #elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x62, 0},
        {0x7E, 0x0F, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x05, 0},
        {0x8E, 0x05, 0},
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x78, 0},
        {0xE9, 0x42, 0},
        {0x7E, 0x0F, 0},
        {0x81, 0x80, 0},
        {0xA5, 0x11, 0},
        {0x88, 0x07, 0},
        {0x8E, 0x07, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xE6, 0x00, 0},
        #if !defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER) // // recommended config, mipi speed 1000 Mbps
        {0xE7, 0x7D, 0},
        {0xE9, 0x61, 0},
        #else // optional config, mipi speed 1008 Mbps, original low power setting use this configure.
        {0xE7, 0x54, 0},
        {0xE9, 0x41, 0},
        #endif
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},
        {0x88, 0x09, 0},
        {0x8E, 0x09, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xE6, 0x00, 0},    // MIPIPLL_LPDH, bit0
        {0xE7, 0x64, 0},    // MIPIPLL_LPDL
        {0xE9, 0x41, 0},    // MIPIPLL_PPD, pre-divider and post-divider
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},    // SYSCLK_DIV
        {0x88, 0x0B, 0},    // ClkTxThstrailCnt
        {0x8E, 0x0B, 0},    // DataTxThstrailCnt
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xE6, 0x00, 0},
        {0xE7, 0x7D, 0},
        {0xE9, 0x41, 0},
        {0x7E, 0x03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0x81, 0xA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0xA5, 0x11, 0},
        {0x88, 0x0D, 0},
        {0x8E, 0x0D, 0},
    #endif

    {0xD3, 0x01, 0},
    {0xC6, 0x3F, 0},
    {0xAE, 0x40, 0},
    {0xD9, 0x1A, 0},
    {0xDA, 0x60, 0},
    {0xCB, 0x07, 0},

    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0x0A, 0x11, 0},   // enable clock lane and data lane0
    #endif

    #if defined(NON_CONTINUOUS_MIPI_CLK)
        {0x04, 0x04, 0},
        {0x05, 0x18, 0},     //TCLW
        {0x06, 0x18, 0},     //TCLT
        {0x07, 0x78, 0},     //TDLW
        #if defined(ENABLE_SYS_CLK_125M)
        {0x50, 0xF0, 0},
        #endif
    #else
        {0x04, 0x0C, 0},
        #if defined(ENABLE_SYS_CLK_125M)
        {0x50, 0xF0, 0},
        #endif
    #endif

    {0x08, 0xFA, 0},
    {0x0C, 0x05, 0},
    //{0xB5, 0x0F, 0},	// Masking SPAD0 Configuration (X1, X4, X10, X100 enabled)
    #if defined(ENABLE_SYS_CLK_125M)
        {0xA6, 0x0F, 0},  // 30 fps for 125M sys clock
    #else
        {0xA6, 0x0B, 0},  // 30 fps for 250M sys clock
    #endif
    {0xAA, 0x01, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd sensor_pcm_regs[] = {
    {0xBA, 0x18, 0},
    {0xA4, 0x01, 0},
    {0xAF, 0x20, 0},
    {0xBC, (BIT(7) | PCM_VCSEL_LASER_PERIOD), 0},                    // depend on hw desgin
    {0xBE, PCM_PROX_VCSEL_LASER_PULSE_WIDTH, 0},
    {0xC3, 0x0D, 0},
    {0xC4, 0x0A, 0},
    {0xC5, 0x0A, 0},
    {0xC2, PCM_EXPOSURE_TIME, 0},
    #if (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xA9, DEFAULT_PKT_DELAY_4_1G_MIPI, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xA9, 0x0, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif
    {0x50, 0xC0, 0},
    {0x18, 0x00, 0},
    {0x19, 0x0A, 0},
    {0xB6, 0x01, 0},
    {REG16_NULL, 0x00, 0}
};

static const struct setting_r16vd sensor_fhr_regs[] = {
    {0xBA, 0x18, 0},
    {0xB2, 0x01, 0},
    {0xB3, 0x32, 0},
    {0xB4, 0x16, 0},
#if defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401) || defined(ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401)
    {0xA4, 0x00, 0},
#else
    {0xA4, 0x01, 0},
#endif
    {0xAF, 0x00, 0},
    {0xBC, (BIT(7) | PTM_VCSEL_LASER_PERIOD), 0},                    // depend on hw desgin
    {0xBD, PTM_VCSEL_LASER_PULSE_WIDTH, 0},
    {0xBE, PCM_PROX_VCSEL_LASER_PULSE_WIDTH, 0},
    {0xBF, COARSE_EXPOSURE_TIME, 0},
    {0xC0, FINE_EXPOSURE_TIME/SYS_CLK_FACTOR, 0},
    {0xC1, PRXMT_EXPOSURE_TIME, 0},
    {0xB0, 0x21, 0},
    {0xB1, 0x21, 0},
    {0xC3, 0x0C, 0},
    {0xC4, 0x08, 0},
    {0xC5, 0x10, 0},
    {0xB5, 0x0F, 0},  // Masking SPAD0 Configuration (X1,X4,X10,X100 Enabled)
    {0xBB, 0x06, 0},
    {0xB7, 0xF9, 0},
    {0xB8, 0x43, 0},
    {0xB9, 0x08, 0},
    #if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0xA9, 0x32, 0},
    #elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0xA9, 0x1D, 0},
    #elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20/SYS_CLK_FACTOR, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15/SYS_CLK_FACTOR, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        #if (SENSOR_DATA_LANE_COUNT == 1)
            {0xA9, 0x20, 0},
        #else
            {0xA9, DEFAULT_PKT_DELAY_4_1G_MIPI/SYS_CLK_FACTOR, 0},
        #endif
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
#if (SENSOR_DATA_LANE_COUNT == 1)
        {0xA9, 0x0C, 0},
#else
        {0xA9, 0x0, 0},
#endif
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif

#if defined(ENABLE_SYS_CLK_125M)
    {0x50, 0xF0, 0},
#else
    {0x50, 0xC0, 0},
#endif
    {0x18, 0x08, 0},
    {0x19, 0x10, 0},
    {0xB6, 0x26, 0}, // TDC LSB accuracy: 0x26 for 125 ps, 0x22 for 62.5 ps
    {REG16_NULL, 0x00, 0}
};

static const struct setting_r16vd sensor_phr_regs[] = {
    {0xBA, 0x0C, 0},
    {0xB2, 0x01, 0},
    {0xB3, 0x32, 0},
    {0xB4, 0x16, 0},
#if defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401) || defined(ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401)
    {0xA4, 0x00, 0},
#else
    {0xA4, 0x01, 0},
#endif
    {0xAF, 0x00, 0},
    {0xBC, (BIT(7) | PTM_VCSEL_LASER_PERIOD), 0},                    // depend on hw desgin
    {0xBD, PTM_VCSEL_LASER_PULSE_WIDTH, 0},
    {0xBE, PCM_PROX_VCSEL_LASER_PULSE_WIDTH, 0},
    {0xBF, 0x13, 0},    // 0x13
    {0xC0, 0x26, 0},      // 0x26
    {0xB0, 0x21, 0},
    {0xB1, 0x21, 0},
    {0xC3, 0x0C, 0},
    {0xC4, 0x08, 0},
    {0xC5, 0x10, 0},
    {0xB5, 0x0F, 0},
    {0xBB, 0x06, 0},
    {0xB7, 0xF9, 0},
    {0xB8, 0x43, 0},
    {0xB9, 0x08, 0},
    #if (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0xA9, 0x20, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
    #elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0xA9, 0x15, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0xA9, 0x10, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0xA9, 0x0, 0},
    #elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0xA9, 0x0, 0},
    #endif
    {0x50, 0x20, 0}, // vc0 fifo THRESHOLD
    {0x18, 0x08, 0},
    {0x19, 0x04, 0},
    {0xB6, 0x06, 0},
    {REG16_NULL, 0x00, 0}
};

static const s64 sensor_link_freq_items[] =
{
    SENSOR_LINK_FREQ
};

static const char *work_mode_name[]={
    SENSOR_MODE_NAME_PHR,
    SENSOR_MODE_NAME_GRAY,
    SENSOR_MODE_NAME_FHR,
};

static const char *environment_type_name[]={
    "Unknown",
    "Indoor",
    "Outdoor",
};

static const char *measurement_range_name[]={
    "Unknown",
    "Normal",
    "Short",
    "Full-distance",
};

static const char *power_mode_names[] =
{
    "Unknown",
    "Div1",
    "Div2",
    "Div3",
};

static struct rkmodule_csi_dphy_param rk3588_dcphy_param = {
    .vendor = PHY_VENDOR_SAMSUNG,
    .lp_vol_ref = 3,
    .lp_hys_sw = {3, 0, 0, 0},
    .lp_escclk_pol_sel = {1, 0, 0, 0},
    .skew_data_cal_clk = {0, 3, 3, 3},
    .clk_hs_term_sel = 2,
    .data_hs_term_sel = {2, 2, 2, 2},
    .reserved = {0},
};


static int calc_frequency(struct sensor *sensor, char *out_buf, int max_length);

static int sensor_framerate_setting(struct sensor * sensor);
static int sensor_write_tdc_delay_setting(struct sensor * sensor);
static int sensor_update_setting(
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsMeasurementType mtype,
    AdapsVcselZoneCountType vcselzonecount_type,
    AdapsVcselMode vmode);
static int sensor_read_module_static_data(struct sensor *sensor);
static int eeprom_data_valid_check(u8 *eeprom_buf, bool is_bigdata_compressed, u32 called_line);
static int sensor_read_otp_data(struct sensor *sensor);

/* pixel rate = link frequency * 2 * lanes / BITS_PER_SAMPLE */
static u64 __maybe_unused to_pixel_rate(int data_lane_cnt)
{
    u64 pixel_rate = SENSOR_LINK_FREQ * 2LL * data_lane_cnt;

    do_div(pixel_rate, SENSOR_BITS_PER_SAMPLE);

    return pixel_rate;
}

static int __maybe_unused printk_2_cur_console(const char *msg, bool append_lfrt) {
    struct tty_struct *my_tty;

    my_tty = get_current_tty();

    if (my_tty != NULL) {
        (my_tty->driver->ops->write) (my_tty, msg, strlen(msg));

        if (append_lfrt)
            (my_tty->driver->ops->write) (my_tty, "\015\012", 2); // \r\n
    }

    return 0;
}

static void __maybe_unused printk2target(enum log_output_target_e out_target, const char *fmt, ...)
{
#define MAX_LINE_LENGTH_4_CUSTOM_PRINTK 512

    char buf[MAX_LINE_LENGTH_4_CUSTOM_PRINTK];
    va_list ap;
    int n;
    struct tty_struct *my_tty;

    my_tty = get_current_tty();

    if (my_tty != NULL) {
        struct tty_driver *driver = my_tty->driver;

        if (OT_BOTH == out_target && strstr(driver->name, TTY_DRIVERNAME_4_UART))  // if the tty is UART(printk), try to avoid duplicated log output
        {
            //printk(KERN_ERR "The device is a UART serial port, driver->name:%s.\n", driver->name);
            // already output the log with 'printk(KERN_ERR'
        } else {
            //printk(KERN_ERR "The device is not a UART serial port, driver->name:%s.\n", driver->name);
            va_start(ap, fmt);
            n = vscnprintf(buf, sizeof(buf), fmt, ap);
            va_end(ap);

            printk_2_cur_console(buf, true);
        }

    }
    return;
}

static void __maybe_unused printk2console(const char *fmt, ...)
{
#define MAX_LINE_LENGTH_4_CUSTOM_PRINTK 512

    char buf[MAX_LINE_LENGTH_4_CUSTOM_PRINTK];
    va_list ap;
    int n;

    va_start(ap, fmt);
    n = vscnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    printk_2_cur_console(buf, true);

    return;
}

static void __maybe_unused print2console_nolfrt(const char *fmt, ...)
{
#define MAX_LINE_LENGTH_4_CUSTOM_PRINTK 512
    
        char buf[MAX_LINE_LENGTH_4_CUSTOM_PRINTK];
        va_list ap;
        int n;
    
        va_start(ap, fmt);
        n = vscnprintf(buf, sizeof(buf), fmt, ap);
        va_end(ap);
    
        printk_2_cur_console(buf, false);
    
        return;
}

static void printout_2_select_target(char *buf, bool out_2_console)
{
    if (out_2_console)
    {
        printk2console("%s", buf);
    }
    else {
        DBG_PRINTK("%s", buf);
    }
}

static void printk_multilines(char *buffer, int length)
{
    int len;
    char *start = buffer;
    char *end = buffer;
    char temp[128];  // Temporary buffer. Assume a line has at most 128 characters. Adjust the size according to the actual situation.

    while (end - buffer < length) {
        // Find the end position of a line
        while (*end!= '\n' && end - buffer < length) {
            end++;
        }

        // Copy the current line to the temporary buffer and add '\0'
        len = end - start;
        if (len > sizeof(temp) - 1) {
            len = sizeof(temp) - 1;
        }
        memcpy(temp, start, len);
        temp[len] = '\0';

        // Output the current line
        printk(KERN_ERR "%s\n", temp);

        // Move to the start of the next line
        if (end - buffer < length) {
            end++;
            start = end;
        }
    }
}

static bool IsASCII(const unsigned char c)
{
    bool ret = false;

    if (c >= 32 && c < 128)
        ret = true;

    return ret;
}

static void __maybe_unused hex8_dump(const unsigned char *buf, int buf_len, const char *title, bool out_2_console)
{
    int             i, j, k;
    const int       NoPerLine = 16;
    char            line_buf[100];
    int             line_len;

    if (NULL == buf) {
        DBG_ERROR("Null pointer");
        return;
    }

    if (NULL != title) {
        if (out_2_console)
        {
            LOG2T_NOTICE(OT_BOTH, "-------%s--------", title);
        }
        else {
            LOG2T_NOTICE(OT_KERNEL, "-------%s--------", title);
        }
    }

    for (i = 0; i <= buf_len / NoPerLine; i++) {
        memset(line_buf, 0, sizeof(line_buf));
        line_len = 0;

        for (j = 0; j < NoPerLine; j++) {
            k = i * NoPerLine + j;

            if (k >= buf_len)
                break;

            line_len += sprintf(line_buf + line_len, "%02x,", buf[k]);
        }

        line_len += sprintf(line_buf + line_len, "%s", "    ");

        for (j = 0; j < NoPerLine; j++) {
            k = i * NoPerLine + j;

            if (k >= buf_len)
                break;

            if (IsASCII(buf[k]))
            {
                line_len += sprintf(line_buf + line_len, "%c", buf[k]);
            }
            else {
                line_len += sprintf(line_buf + line_len, "%c", '.');
            }
        }

        if (out_2_console)
        {
            LOG2T_NOTICE(OT_BOTH, "[%04X] %s", i * NoPerLine, line_buf);
        }
        else {
            LOG2T_NOTICE(OT_KERNEL, "[%04X] %s", i * NoPerLine, line_buf);
        }
    }
}


static int zlib_direct_decompress(const char *src, unsigned int src_len, char *dest, unsigned int *dest_len)
{
    z_stream d_stream;
    int ret;

    memset(&d_stream, 0, sizeof(d_stream));
    d_stream.workspace = vmalloc(zlib_deflate_workspacesize(ZLIB_WINDOW_BITS, ZLIB_MEM_LEVEL));
    if (!d_stream.workspace) {
        return -ENOMEM;
    }

    ret = zlib_inflateInit(&d_stream);
    if (ret != Z_OK) {
        pr_err("Failed to initialize ZLIB decompression: %d\n", ret);
        vfree(d_stream.workspace);
        return -EIO;
    }

    d_stream.next_in = (void *)src;
    d_stream.avail_in = src_len;
    d_stream.next_out = (void *)dest;
    d_stream.avail_out = *dest_len;

    ret = zlib_inflate(&d_stream, Z_FINISH);
    if (ret != Z_STREAM_END) {
        pr_err("ZLIB decompression failed: %d\n", ret);
        zlib_inflateEnd(&d_stream);
        vfree(d_stream.workspace);
        return -EIO;
    }

    *dest_len = d_stream.total_out;
    zlib_inflateEnd(&d_stream);
    vfree(d_stream.workspace);

    return 0;
}

static ssize_t load_file_to_buffer(const char *filename, char **buffer, size_t *loaded_size, bool buf_pre_alloced, size_t expect_size) {
    struct file *filp = NULL;
    loff_t size;
    ssize_t result = 0;
    loff_t pos;

    if (!filename)
        return -EINVAL;

    filp = filp_open(filename, O_RDONLY, 0);
    if (IS_ERR(filp)) {
        LOG2T_ERROR(OT_BOTH, "Failed to open %s\n", filename);
        return PTR_ERR(filp);
    }

    size = filp->f_path.dentry->d_inode->i_size;
    if (!size) {
        LOG2T_ERROR(OT_BOTH, "Failed to get file size for %s\n", filename);
        filp_close(filp, NULL);
        return -EIO;
    }

    if ((0 != expect_size) && (size != expect_size))
    {
        DBG_ERROR("The actual size %lld of file <%s> mismatch with expected size: %ld!!!\n", size, filename, expect_size);
        filp_close(filp, NULL);
        return -EIO;
    }

    if (false == buf_pre_alloced)
    {
        *buffer = kmalloc(size, GFP_KERNEL);
        if (!*buffer) {
            LOG2T_ERROR(OT_BOTH, "Failed to allocate memory for %s\n", filename);
            filp_close(filp, NULL);
            return -ENOMEM;
        }
    }

    pos = 0;
    result = kernel_read(filp, *buffer, size, &pos);

    if (result >= 0) {
        LOG2T_NOTICE(OT_BOTH, "Read %ld bytes from %s\n", result, filename);
        *loaded_size = result;
    } else {
        LOG2T_ERROR(OT_BOTH, "Failed to read %s\n", filename);
        if (false == buf_pre_alloced)
        {
            kfree(*buffer);
            *buffer = NULL;
        }
        *loaded_size = 0;
    }

    filp_close(filp, NULL);

    return result;
}

#if !defined(CALIB_DATA_READY_IN_EEPROM_CHIP) && defined(CALIB_DATA_FROM_EEPROM_BIN_FILE)
static int __maybe_unused eeprom_read_from_file(struct sensor *priv, unsigned int offset, size_t bytes, char *outbuf)
{
    int ret = 0;
    char filename[128] = EEPROM_DATA_FILE_PATH;
    size_t file_size = 0;

    ret = load_file_to_buffer(filename, &outbuf, &file_size, true, bytes);
    if (ret < 0) {
        DBG_ERROR("Failed to load file %s\n", filename);
    }

    ret = eeprom_data_valid_check(outbuf, false, __LINE__);
    if (ret < 0) {
        DBG_ERROR("eeprom_data_valid_check() failure: %d\n", ret);
    }

    return ret;
}
#endif


static int create_blob_file_4_eeprom_data(struct sensor *sensor, struct dentry *parent, unsigned char *buf_to_map, int size_to_map, char *blob_filename)
{
    sensor->dbgfs_blob_4_calib_data.data = buf_to_map;
    sensor->dbgfs_blob_4_calib_data.size = size_to_map;

    sensor->dbgfs_dentry_4_calib_data = debugfs_create_blob(blob_filename, 0644, parent, &sensor->dbgfs_blob_4_calib_data);
    if (!sensor->dbgfs_dentry_4_calib_data) {
        DBG_ERROR("Fail to create_debug_blob_file:%s...", blob_filename);
        return -EIO;
    }

    return 0;
}

static int create_blob_file_4_roisram_data(struct sensor *sensor, struct dentry *parent, unsigned char *buf_to_map, int size_to_map, char *blob_filename)
{
    if (sensor->dbgfs_dentry_4_roisram_data) // delete the old one if exist already
    {
        debugfs_remove(sensor->dbgfs_dentry_4_roisram_data);
        sensor->dbgfs_dentry_4_roisram_data = NULL;
    }

    sensor->dbgfs_blob_4_roisram_data.data = buf_to_map;
    sensor->dbgfs_blob_4_roisram_data.size = size_to_map;

    sensor->dbgfs_dentry_4_roisram_data = debugfs_create_blob(blob_filename, 0644, parent, &sensor->dbgfs_blob_4_roisram_data);
    if (!sensor->dbgfs_dentry_4_roisram_data) {
        DBG_ERROR("Fail to create_debug_blob_file:%s...", blob_filename);
        return -EIO;
    }

    return 0;
}

static void __maybe_unused delay_ns(u32 ns)
{
    if (ns < 10) //(!ns)
        return;

    if (ns <= 1000) {
        ndelay(ns);
    } else {
        u32 us = DIV_ROUND_UP(ns, 1000);

        if (us <= 10)
            udelay(us);
        else
            usleep_range(us, us + DIV_ROUND_UP(us, 10));
    }
}

static u32 crc32_calculate(const u8* buf, size_t len)
{
    u32 crc = 0 ^ 0xFFFFFFFF;
#if 1
    crc = crc32_le(crc, buf, len);
    crc = crc ^ 0xFFFFFFFF;
#else
    char path[128];
    struct timespec64 ts;
    struct tm tm_res;
    ktime_get_real_ts64(&ts);
    time64_to_tm(ts.tv_sec, 0, &tm_res);

    crc = crc32_le(crc, buf, len);
    crc = crc ^ 0xFFFFFFFF;

    sprintf(path, "/root/buf_size_%ld_crc32_0x%x_at_%4ld-%02d-%02d_%02d_%02d_%02d.bin", len, crc, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday, tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec);
    save_buffer_to_file(buf, len, path);
#endif
    return crc;
}


// sensor_reg_write_hook is used to save a register value, or change a register value at last second before real register write for some special requirement!
static int sensor_reg_write_hook(struct sensor *sensor, u16 reg_addr, u8 org_cfg, u8 *final_cfg)
{
    int rc = 0;

    switch (reg_addr)
    {
        default:   // for most registers, no change!
            *final_cfg = org_cfg;
            break;

        case 0x00BC:
            *final_cfg = org_cfg;
            sensor->cur_laser_exposure_period = org_cfg;
            break;

        case 0x00BF:
            *final_cfg = org_cfg;
            sensor->cur_coarse_exposure_val = org_cfg;
            break;

        case 0x00C0:
            *final_cfg = org_cfg;
            sensor->cur_fine_exposure_val = org_cfg;
            break;

        case 0x00C2:
            *final_cfg = org_cfg;
            sensor->cur_gray_exposure_val = org_cfg;
            break;

    }

    return rc;
}

static u8 mcu_calc_checksum(u8 buff[], int len)
{
    int i;
    u8 ret = MCU_CHECKSUM_SALT;

    for (i = 0; i < len; i++)
    {
        ret ^= buff[i];
    }

    return ret;
}

static bool IsIgnorableErrLog(u8 sub_dev_id, u16 reg, int ret_value)
{
    bool ret = false;

//    if ((SUB_DEV_ID_MCU_SELF == sub_dev_id) && (STATUS_REG_SUB_DEV_OP_STATE == reg) && (-ENXIO == ret_value))
    if (-ENXIO == ret_value)
    {
        ret = true;
    }

    return ret;
}

static int mcu_read_reg_raw(struct sensor *sensor, u8 sub_dev_id, u16 reg, u8 *val)
{
    int ret;
    u8 calc_checksum;
    u8 tx_buf[sizeof(sub_dev_id) + sizeof(reg) + MCU_CHECKSUM_BYTES];
    uint8_t rx_buf[sizeof(*val) + MCU_CHECKSUM_BYTES] = {0};
    struct i2c_client *client = sensor->mcu_i2c_client;

    MUTEX_LOCK(&sensor->mcu_comm_mutex);

    tx_buf[0] = sub_dev_id;
    tx_buf[1] = (reg >> 8) & 0xFF;
    tx_buf[2] = reg & 0xFF;
    tx_buf[3] = mcu_calc_checksum(tx_buf, sizeof(sub_dev_id) + sizeof(reg));

    ret = i2c_master_send(client, tx_buf, sizeof(sub_dev_id) + sizeof(reg) + MCU_CHECKSUM_BYTES);
    if (ret < 0) {
        if (false == IsIgnorableErrLog(sub_dev_id, reg, ret)) DBG_ERROR("mcu read reg:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        goto out;
    }

    delay_ns(sensor->mcu_comm_extra_delay * 1000);

    ret = i2c_master_recv(client, rx_buf, sizeof(*val) + MCU_CHECKSUM_BYTES);
    if (ret < 0) {
        DBG_ERROR("mcu read reg:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        goto out;
    }

    calc_checksum = mcu_calc_checksum(rx_buf, sizeof(*val));
    if (calc_checksum == rx_buf[sizeof(*val)])
    {
        //DBG_NOTICE("mcu read reg:0x%04x for sub_dev 0x%x SUCCESS, return value: 0x%02x", reg, sub_dev_id, rx_buf[0]);
        *val = rx_buf[0];
        ret = 0;
    }
    else {
        sensor->chksum_fail_times++;
        DBG_ERROR("mcu read reg:0x%02x%04x FAILED, since checksum mismatch, rx[0]: 0x%02x, rx[1]: 0x%02x, calc_checksum: 0x%02x",
            sub_dev_id, reg, rx_buf[0], rx_buf[1], calc_checksum);
        ret = -EIO;
        goto out;
    }

    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_READ)
    {
        TRACE_REG_RW("<REGS_READ> mcu read reg:0x%02x%04x, return data 0x%02x...", sub_dev_id, reg, *val);
    }

out:
    MUTEX_UNLOCK(&sensor->mcu_comm_mutex);
    return ret;
}

static int mcu_write_reg_raw(struct sensor *sensor, u8 sub_dev_id, u16 reg, u8 val)
{
    int ret = 0;
    u8 tx_buf[sizeof(sub_dev_id) + sizeof(reg) + sizeof(val) + MCU_CHECKSUM_BYTES];
    struct i2c_msg msg;
    struct i2c_client *client = sensor->mcu_i2c_client;
    char *sub_dev_type_names[] =
    {
        "MCU",
        "ADS6401",
        "EEPROM",
    };

    if (NULL == client) {
        DBG_ERROR("Null pointer for client");
        return -EINVAL;
    }

    MUTEX_LOCK(&sensor->mcu_comm_mutex);

    tx_buf[0] = sub_dev_id;
    tx_buf[1] = (reg >> 8) & 0xFF;
    tx_buf[2] = reg & 0xFF;
    if (SUB_DEV_ID_ADS6401_DTOF == sub_dev_id)
    {
        sensor_reg_write_hook(sensor, reg, val, &tx_buf[3]);
    }
    else {
        tx_buf[3] = val;
    }
    tx_buf[4] = mcu_calc_checksum(tx_buf, sizeof(sub_dev_id) + sizeof(reg) + sizeof(val));

    msg.addr            = client->addr;
    msg.flags           = I2C_M_WR;
    msg.buf             = tx_buf;
    msg.len             = sizeof(sub_dev_id) + sizeof(reg) + sizeof(val) + MCU_CHECKSUM_BYTES;

    ret = i2c_transfer(client->adapter, &msg, 1);
    if (ret < 0) {
        DBG_ERROR("mcu write reg:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        goto out;
    }
    delay_ns(sensor->mcu_comm_extra_delay * 1000);

    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
    {
//        TRACE_REG_RW("<REGS_WRITE> mcu write reg:0x%02X%04X to 0x%02X...", sub_dev_id, reg, val);
        TRACE_REG_RW("<REGS_WRITE> mcu_write_%s_reg:0x%04X to 0x%02X...", sub_dev_type_names[sub_dev_id >> 4], reg, val);
    }

    ret = 0;
out:
    MUTEX_UNLOCK(&sensor->mcu_comm_mutex);
    return ret;
}

// 本寄存器仅用于SoC <=> MCU 之间数据块传输, 数据需提前从其他内部子设备预读好
static int mcu_burst_read_raw(struct sensor *sensor, u16 reg, u8 *buf, int len)
{
    uint8_t calc_checksum = 0;
    u8 sub_dev_id = SUB_DEV_ID_MCU_SELF;
    int ret = -EINVAL;
    u8 tx_buf[sizeof(sub_dev_id) + sizeof(reg) + MCU_CHECKSUM_BYTES];
    u8 *rx_buf;
    struct i2c_client *client = sensor->mcu_i2c_client;

    if ((sensor->max_transfer_size_per_burst > 0) && (len > sensor->max_transfer_size_per_burst)) {
        DBG_ERROR("length (%d) out of the range, please use for loop to handle it", len);
        return -EINVAL;
    }

    rx_buf = kmalloc(len + MCU_CHECKSUM_BYTES, GFP_KERNEL);
    if (!rx_buf)
        return -ENOMEM;

    tx_buf[0] = sub_dev_id;
    tx_buf[1] = (reg >> 8) & 0xFF;
    tx_buf[2] = reg & 0xFF;
    tx_buf[3] = mcu_calc_checksum(tx_buf, sizeof(sub_dev_id) + sizeof(reg));

    ret = i2c_master_send(client, tx_buf, sizeof(sub_dev_id) + sizeof(reg) + MCU_CHECKSUM_BYTES);
    if (ret < 0) {
        if (false == IsIgnorableErrLog(sub_dev_id, reg, ret)) DBG_ERROR("mcu_burst_read:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        kfree(rx_buf);
        return ret;
    }

    delay_ns(sensor->mcu_comm_extra_delay * 1000);

    ret = i2c_master_recv(client, rx_buf, len + MCU_CHECKSUM_BYTES);
    if (ret < 0) {
        DBG_ERROR("mcu_burst_read:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        kfree(rx_buf);
        return ret;
    }

    calc_checksum = mcu_calc_checksum(rx_buf, len);
    if (calc_checksum == rx_buf[len])
    {
        memcpy(buf, rx_buf, len);
        ret = 0;
    }
    else {
        DBG_ERROR("mcu_burst_read:0x%02x%04x failed since checksum mismatch", sub_dev_id, reg);
        sensor->chksum_fail_times++;
        kfree(rx_buf);
        return -EIO;
    }
    kfree(rx_buf);

    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_READ)
    {
        TRACE_REG_RW("<REGS_READ> mcu burst read reg:0x%02x%04x, data length:%d, ret:%d...", sub_dev_id, reg, len, ret);
    }

    return ret;
}

// 本寄存器仅用于SoC <=> MCU 之间数据块传输, 
// 对其他内部子设备的写操作(如有), 将延后执行, 不属于本函数的功能范围
static int mcu_burst_write_raw(struct sensor *sensor, u16 reg, char *buf, int len)
{
    int ret = 0;
    u8 sub_dev_id = SUB_DEV_ID_MCU_SELF;
    u8 *tx_buf;
    struct i2c_msg msg;
    struct i2c_client *client = sensor->mcu_i2c_client;

    if ((sensor->max_transfer_size_per_burst > 0) && (len > sensor->max_transfer_size_per_burst)) {
        DBG_ERROR("length (%d) out of the range, please use for loop to handle it", len);
        return -EINVAL;
    }

    tx_buf = kmalloc(sizeof(sub_dev_id) + sizeof(reg) + len + MCU_CHECKSUM_BYTES, GFP_KERNEL);
    if (!tx_buf)
        return -ENOMEM;

    tx_buf[0] = sub_dev_id;
    tx_buf[1] = (reg >> 8) & 0xFF;
    tx_buf[2] = reg & 0xFF;

    memcpy(&tx_buf[3], buf, len);
    tx_buf[len+3] = mcu_calc_checksum(tx_buf, sizeof(sub_dev_id) + sizeof(reg) + len);

    msg.addr            = client->addr;
    msg.flags           = I2C_M_WR;
    msg.buf             = tx_buf;
    msg.len             = sizeof(sub_dev_id) + sizeof(reg) + len + MCU_CHECKSUM_BYTES;

#if defined(I2C_BURST_WRITE_SPEED_OPTIMIZE_4_ROISRAM) // for i2c_rk3x.c of rockchip platform, the polling mode costs less time than the default interrupt mode, you may need change here if port to other SoC platform.
    if ((NULL != client->adapter->algo->master_xfer_atomic)
        && (len >= 64)
        && (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_ROI_WRITE_POLL_MD)))
    {
        i2c_lock_bus(client->adapter, I2C_LOCK_SEGMENT);
        ret = client->adapter->algo->master_xfer_atomic(client->adapter, &msg, 1);
        i2c_unlock_bus(client->adapter, I2C_LOCK_SEGMENT);
    }
    else 
#endif
    {
        ret = i2c_transfer(client->adapter, &msg, 1);
    }
    if (ret < 0) {
        DBG_ERROR("mcu_burst_write:0x%02x%04x failed, ret:%d", sub_dev_id, reg, ret);
        kfree(tx_buf);
        return ret;
    }
    delay_ns(sensor->mcu_comm_extra_delay * 1000);

    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
    {
        TRACE_REG_RW("<REGS_WRITE> mcu burst write reg:0x%02x%04x data length:%d %s...", sub_dev_id, reg, len, 1 == ret ? "SUCCESS": "FAILURE");
    }
    kfree(tx_buf);

    return 0;
}

static int mcu_burst_read_reg(struct sensor *sensor, u16 reg, u8 *buf, int len)
{
    int i;
    int ret = 0;
    int read_size = 0;

    if (sensor->max_transfer_size_per_burst <= 0) {
        DBG_ERROR("max_transfer_size_per_burst is illegal, please read register STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST to assign a correct value firstly. ");
        return -EINVAL;
    }

    /* Hold across all chunks so MCU ringlog_dump_offset / TX buffer stay consistent. */
    MUTEX_LOCK(&sensor->mcu_comm_mutex);

    if (len > sensor->max_transfer_size_per_burst) {
        for (i = 0; i < len / sensor->max_transfer_size_per_burst; i++)
        {
            ret = mcu_burst_read_raw(sensor, reg, buf + (sensor->max_transfer_size_per_burst * i), sensor->max_transfer_size_per_burst);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_burst_read_raw 0x%x, ret:%d, i: %d, len: %d", reg, ret, i, len);
                goto out;
            }
            read_size += sensor->max_transfer_size_per_burst;
        }

        if (read_size < len) {
            ret = mcu_burst_read_raw(sensor, reg, buf + read_size, len - read_size);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_burst_read_raw 0x%x, ret:%d, len: %d", reg, ret, len - read_size);
                goto out;
            }
        }
    }
    else {
        ret = mcu_burst_read_raw(sensor, reg, buf, len);
    }

out:
    MUTEX_UNLOCK(&sensor->mcu_comm_mutex);
    return ret;
}

static int mcu_burst_write_reg(struct sensor *sensor, u16 reg, char *buf, int len)
{
    int i;
    int ret = 0;
    int written_size = 0;

    if (sensor->max_transfer_size_per_burst <= 0) {
        DBG_ERROR("max_transfer_size_per_burst is illegal, please read register STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST to assign a correct value firstly. ");
        return -EINVAL;
    }

    MUTEX_LOCK(&sensor->mcu_comm_mutex);

    if (len > sensor->max_transfer_size_per_burst) {
        for (i = 0; i < len / sensor->max_transfer_size_per_burst; i++)
        {
            ret = mcu_burst_write_raw(sensor, reg, buf + (sensor->max_transfer_size_per_burst * i), sensor->max_transfer_size_per_burst);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_burst_write_raw 0x%x, ret:%d, i: %d, len: %d", reg, ret, i, len);
                goto out;
            }
            written_size += sensor->max_transfer_size_per_burst;
        }

        if (written_size < len) {
            ret = mcu_burst_write_raw(sensor, reg, buf + written_size, len - written_size);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_burst_write_raw 0x%x, ret:%d, len: %d", reg, ret, len - written_size);
                goto out;
            }
        }
    }
    else {
        ret = mcu_burst_write_raw(sensor, reg, buf, len);
    }

out:
    MUTEX_UNLOCK(&sensor->mcu_comm_mutex);
    return ret;
}

static int mcu_read_self_reg(struct sensor *sensor, u16 reg, u8 *val)
{
    int ret;

    ret = mcu_read_reg_raw(sensor, SUB_DEV_ID_MCU_SELF, reg, val);
    if (ret < 0) {
        if (false == IsIgnorableErrLog(SUB_DEV_ID_MCU_SELF, reg, ret)) DBG_ERROR("Fail to mcu_read_self_reg 0x%04x, ret:%d", reg, ret);
    }

    return ret;
}

static int mcu_write_self_reg(struct sensor *sensor, u16 reg, u8 val)
{
    int ret = 0;

    ret = mcu_write_reg_raw(sensor, SUB_DEV_ID_MCU_SELF, reg, val);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_write_self_reg 0x%x, ret:%d", reg, ret);
        return ret;
    }

    return 0;
}

static int mcu_waiting_4_state(struct sensor *sensor, u16 wait_reg, u8 wait_state1, u8 wait_state2, u32 wait_timeout_us, int callline)
{
    int ret;
    ktime_t start;
    s64 us_delta;
    u8 val8 = 0;
    int polled_times = 0;

    start = ktime_get();
    do {
        ret = mcu_read_self_reg(sensor, wait_reg, &val8);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (ret < 0) {
            DBG_INFO("Fail to read status register 0x%x of the sensor, ret: %d.\n", wait_reg, ret);
        }
        else {
            if ((wait_state1 == val8) || (wait_state2 == val8))
            {
                ret = 0;
                DBG_INFO("mcu waiting state %d is ready now, polled_times: %d, waited %lld us.\n", val8, polled_times, us_delta);
                break;
            }
#if 0
            else {
                DBG_NOTICE("mcu is still in %d state now, polled_times: %d, waited %lld us.\n", val8, polled_times, us_delta);
            }
#endif
        }

        if (wait_timeout_us < us_delta)
        {
            DBG_ERROR("Timeout to wait to mcu to %d/%d state (but: %d) for reg: 0x%04x, already waited %lld us (> %d us), polled_times: %d, called from Line: %d.\n",
                wait_state1, wait_state2, val8, wait_reg, us_delta, wait_timeout_us, polled_times, callline);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(1000, 1200);
        polled_times++;
    } while (1);

    return ret;
}


static int mcu_write_dtof_reg(struct sensor *sensor, u16 reg, u8 val)
{
    int ret = 0;
    u8 wait_state = OP_STATE_IDLE;
    u32 wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;

    ret = mcu_waiting_4_state(sensor, STATUS_REG_SUB_DEV_OP_STATE, wait_state, DTOF_WRITE_OP_SUCCESS, wait_timeout_us, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
        return ret;
    }

    ret = mcu_write_reg_raw(sensor, SUB_DEV_ID_ADS6401_DTOF, reg, val);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_write_dtof_reg 0x%x, ret:%d", reg, ret);
        return ret;
    }

    wait_state = DTOF_WRITE_OP_SUCCESS;
    wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;

    ret = mcu_waiting_4_state(sensor, STATUS_REG_SUB_DEV_OP_STATE, wait_state, wait_state, wait_timeout_us, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
        return ret;
    }

    return 0;
}


static int mcu_read_dtof_reg(struct sensor *sensor, u16 reg, u8 *val)
{
    int ret;

    ret = mcu_read_reg_raw(sensor, SUB_DEV_ID_ADS6401_DTOF, reg, val);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_dtof_reg 0x%x, ret:%d", reg, ret);
    }

    return ret;
}

static int mcu_read_eeprom_data(struct sensor *sensor, uint16_t start_offset, uint8_t *data, uint32_t length)
{
    int ret;
    uint8_t state = 0;
    uint16_t cur_op_len = 0;
    uint32_t read_len = 0;
    uint8_t *rx_buffer = NULL;
    ktime_t start;
    uint32_t remaining_len = length;
    uint16_t reg;
    uint8_t val8;
    uint16_t cur_offset = start_offset;

    reg = CTRL_REG_EEPROM_OP_TYPE;  // 0 – read, 1 - write
    val8 = 0;
    ret = mcu_write_self_reg(sensor, reg, val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_write_reg 0x%x, ret:%d", reg, ret);
        return ret;
    }

    rx_buffer = kmalloc(sensor->max_eeprom_op_size_per_time + MCU_CHECKSUM_BYTES, GFP_KERNEL);
    if (!rx_buffer)
    {
        DBG_ERROR("Fail to kmalloc memory.\n");
        return -ENOMEM;
    }

    //DBG_NOTICE("Start to read %d bytes from eeprom, max_eeprom_op_size_per_time: %d\n", remaining_len, max_eeprom_op_size_per_time);
    while(remaining_len > 0)
    {
        cur_op_len = remaining_len > sensor->max_eeprom_op_size_per_time ? sensor->max_eeprom_op_size_per_time : remaining_len;

        reg = CTRL_REG_EEPROM_OP_START_OFFSET_L;
        ret = mcu_write_self_reg(sensor, reg, cur_offset & 0xFF);
        if (ret < 0) {
            if (rx_buffer)
            {
                kfree(rx_buffer);
            }
            DBG_ERROR("Fail to mcu_write_reg 0x%x, ret:%d", reg, ret);
            return ret;
        }

        reg = CTRL_REG_EEPROM_OP_START_OFFSET_H;
        ret = mcu_write_self_reg(sensor, reg, cur_offset >> 8);
        if (ret < 0) {
            if (rx_buffer)
            {
                kfree(rx_buffer);
            }
            DBG_ERROR("Fail to mcu_write_reg 0x%x, ret:%d", reg, ret);
            return ret;
        }
        
        //DBG_NOTICE("Try to read %d bytes from eeprom, read_len: %d\n", cur_op_len, read_len);
        ret = mcu_write_self_reg(sensor, CTRL_REG_EEPROM_CUR_OP_SIZE, cur_op_len);
        if(ret < 0){
            DBG_ERROR("write EEPROM_CUR_OP_SIZE reg failed. ret: %d\n", ret);
            if (rx_buffer)
            {
                kfree(rx_buffer);
            }
            return -EIO;
        }

        start = ktime_get();
        while(1){
            if(ktime_us_delta(ktime_get(), start) > EEPROM_READ_TIMEOUT)
            {
                DBG_ERROR("mcu_read_eeprom_data time out.\n");
                if (rx_buffer)
                {
                    kfree(rx_buffer);
                }
                return -ETIME;
            }

            usleep_range(500, 1000);
            ret = mcu_read_self_reg(sensor, STATUS_REG_SUB_DEV_OP_STATE, &state);
            if(ret < 0){
                DBG_ERROR("read STATUS_REG_SUB_DEV_OP_STATE reg failed. ret: %d\n", ret);
                if (rx_buffer)
                {
                    kfree(rx_buffer);
                }
                return -EIO;
            }
            if (state == EEPROM_READ_DATA_READY) {
                break;
            }
            if (state == EEPROM_READ_DATA_FAILURE) {
                DBG_ERROR("mcu_read_eeprom_data mcu reported failure, offset:%u len:%u\n",
                    cur_offset, cur_op_len);
                if (rx_buffer) {
                    kfree(rx_buffer);
                }
                return -EIO;
            }
        }

        ret = mcu_burst_read_reg(sensor, DT_REG_EEPROM_DATA_TRANSFER, rx_buffer, cur_op_len);
        if(ret < 0){
            DBG_ERROR("mcu_burst_read_reg failed. ret: %d, to_read_len: %d, read_len: %d, cur_op_len: %d, remaining_len: %d\n", ret, length, read_len, cur_op_len, remaining_len);
            if (rx_buffer)
            {
                kfree(rx_buffer);
            }
            return ret;
        }

        memcpy(data, rx_buffer, cur_op_len);

        remaining_len -= cur_op_len;
        data += cur_op_len;
        read_len += cur_op_len;
        cur_offset += cur_op_len;

    }

    if (rx_buffer)
    {
        kfree(rx_buffer);
    }
    return 0;
}


// When any error occurs, the function will return a negative number.
static int mcu_write_dtof_reg_array(struct sensor *sensor, const struct setting_r16vd *reglist, int callline)
{
    u32     i;
    int     ret = 0;

    if (NULL == reglist) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    for (i = 0; reglist[i].reg != REG16_NULL; i++) {
        ret = mcu_write_dtof_reg(sensor, reglist[i].reg, reglist[i].val);
        if (ret < 0) {
            DBG_ERROR("mcu_write_dtof_reg failed, ret:%d when write reg[%d]:0x%04x to 0x%02X for dToF sensor", ret, i, reglist[i].reg, reglist[i].val);
            return ret;
        }

        if (reglist[i].delayUs)
        {
            usleep_range(reglist[i].delayUs, reglist[i].delayUs + DIV_ROUND_UP(reglist[i].delayUs, 10));
            if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
            {
                TRACE_REG_RW("Delay %d us after Write No:%d reg(0x%04X) to 0x%02X for dToF sensor...", reglist[i].delayUs, i, reglist[i].reg, reglist[i].val);
            }
        }
    }

    return 0;
}

static int mcu_read_fixed_settings(struct sensor *sensor)
{
    int ret;
    u16 reg;
    u8 val8;

    reg = STATUS_REG_MAX_EEPROM_OP_SIZE_PER_TIME_L;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->max_eeprom_op_size_per_time = val8;

    reg = STATUS_REG_MAX_EEPROM_OP_SIZE_PER_TIME_H;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->max_eeprom_op_size_per_time |= val8 << 8;

    reg = STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_L;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->block_size_4_flash_write = val8;

    reg = STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_H;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->block_size_4_flash_write |= val8 << 8;

    reg = STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST_L;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->max_transfer_size_per_burst = val8;

    reg = STATUS_REG_MAX_TRANSFER_SIZE_PER_BURST_H;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
    }
    sensor->max_transfer_size_per_burst |= val8 << 8;

    return ret;
}

static int mcu_read_runtime_simple_status(struct sensor *sensor)
{
    int ret;
    u16 reg;
    u8 buf[6];
    ktime_t start;
    s64 us_delta;

    reg = DT_REG_RT_TEMPERATURE_VOLTAGE;
    start = ktime_get();
    ret = mcu_burst_read_reg(sensor, reg, buf, 6);
    if(ret < 0){
        if (false == IsIgnorableErrLog(SUB_DEV_ID_MCU_SELF, reg, ret)) DBG_ERROR("mcu_burst_read_reg 0x%x failed. ret: %d\n", reg, ret);
        return ret;
    }

    sensor->mcu_cur_pvdd_x100 = buf[STATUS_REG_CUR_PVDD_VOL_L - STATUS_REG_CUR_PVDD_VOL_L];
    sensor->mcu_cur_pvdd_x100 |= buf[STATUS_REG_CUR_PVDD_VOL_H - STATUS_REG_CUR_PVDD_VOL_L] << 8;

    sensor->mcu_cur_vop_abs_x100 = buf[STATUS_REG_CUR_VOP_VOL_ABS_L - STATUS_REG_CUR_PVDD_VOL_L];
    sensor->mcu_cur_vop_abs_x100 |= buf[STATUS_REG_CUR_VOP_VOL_ABS_H - STATUS_REG_CUR_PVDD_VOL_L] << 8;

    sensor->mcu_cur_temperature_x100 = buf[STATUS_REG_CUR_TEMPERATURE_L - STATUS_REG_CUR_PVDD_VOL_L];
    sensor->mcu_cur_temperature_x100 |= buf[STATUS_REG_CUR_TEMPERATURE_H - STATUS_REG_CUR_PVDD_VOL_L] << 8;

    us_delta = ktime_us_delta(ktime_get(), start);
//    DBG_NOTICE("%s costs %lld us.\n", __FUNCTION__, us_delta);

    return ret;
}

static int mcu_read_runtime_full_status(struct sensor *sensor)
{
    int ret;
    ktime_t start;
    s64 us_delta;
    u8 *val_buf;
    u16 reg = DT_REG_MCU_REG_DUMP;
    u16 reg_count = MCU_BASIC_REG_SIZE;

    start = ktime_get();
    val_buf = kzalloc(reg_count, GFP_KERNEL);
    if (NULL == val_buf)
    {
        DBG_ERROR("malloc failure for <%s>", __func__);
        return -ENOMEM;
    }

    ret = mcu_burst_read_reg(sensor, reg, val_buf, reg_count);
    if(ret < 0){
        kfree(val_buf);
        DBG_ERROR("mcu_burst_read_reg 0x%x failed. ret: %d\n", reg, ret);
        return ret;
    }
    //hex8_dump(val_buf, reg_count, "MCU_REG_VALUES", true);

    sensor->mcu_cur_pvdd_x100 = val_buf[STATUS_REG_CUR_PVDD_VOL_L];
    sensor->mcu_cur_pvdd_x100 |= val_buf[STATUS_REG_CUR_PVDD_VOL_H] << 8;

    sensor->mcu_cur_vop_abs_x100 = val_buf[STATUS_REG_CUR_VOP_VOL_ABS_L];
    sensor->mcu_cur_vop_abs_x100 |= val_buf[STATUS_REG_CUR_VOP_VOL_ABS_H] << 8;

    sensor->mcu_cur_temperature_x100 = val_buf[STATUS_REG_CUR_TEMPERATURE_L];
    sensor->mcu_cur_temperature_x100 |= val_buf[STATUS_REG_CUR_TEMPERATURE_H] << 8;

    sensor->mcu_fw_version.fw_version = val_buf[STATUS_REG_RUNNING_FW_VERSION_L];
    sensor->mcu_fw_version.fw_version |= val_buf[STATUS_REG_RUNNING_FW_VERSION_H] << 8;

    sensor->mcu_error_status = val_buf[CTRL_REG_ERROR_STATUS_L];
    sensor->mcu_error_status |= val_buf[CTRL_REG_ERROR_STATUS_H] << 8;

    sensor->mcu_warning_status = val_buf[CTRL_REG_WARNING_STATUS_L];
    sensor->mcu_warning_status |= val_buf[CTRL_REG_WARNING_STATUS_H] << 8;

    sensor->mcu_roisram_data_size = val_buf[CTRL_REG_ROISRAM_DATA_SIZE_L];
    sensor->mcu_roisram_data_size |= val_buf[CTRL_REG_ROISRAM_DATA_SIZE_H] << 8;

    sensor->mcu_power_on = val_buf[STATUS_REG_MODULE_POWER_STATE];

    sensor->mcu_fw_type = val_buf[STATUS_REG_RUNNING_FW_TYPE];

    sensor->mcu_vop_algo_version = val_buf[STATUS_REG_VOP_ALGO_VERSION];

    sensor->mcu_fsm = val_buf[STATUS_REG_MODULE_FSM];

    sensor->mcu_vop_ctrl_policy = val_buf[CTRL_REG_VOP_CTRL_POLICY];

    sensor->mcu_vop_adjust_interval = val_buf[CTRL_REG_VOP_ADJUST_INTERVAL];

    sensor->mcu_roisram_rolling = val_buf[CTRL_REG_ROISRAM_ROLLING_ENABLE];

    sensor->mcu_roisram_data_group_cnt = val_buf[CTRL_REG_ROISRAM_DATA_GROUP_COUNT];

    sensor->mcu_cur_roisram_group_index = val_buf[STATUS_REG_CUR_ROISRAM_DATA_GROUP_INDEX];

    kfree(val_buf);
    us_delta = ktime_us_delta(ktime_get(), start);
    DBG_NOTICE("%s costs %lld us.\n", __FUNCTION__, us_delta);

    return ret;
}

static int mcu_send_roisram_data_to_mcu(struct sensor *sensor)
{
    int ret;
    u16 reg;
    u8 wait_state = ROISRAM_DATA_CRC_VERIFY_PASS;
    u32 wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;
    u8 *roi_sram;
    u32 roi_sram_size;
    u32 crc32 = 0;

    if (0 != sensor->loaded_roi_sram_size)
    {
        roi_sram = sensor->loaded_roi_sram;
        roi_sram_size = sensor->loaded_roi_sram_size;
    }
    else {
        roi_sram = (u8 *) sensor->eeprom_data->sramData;
        roi_sram_size = sensor->eeprom_data->real_spot_zone_count * PER_CALIB_SRAM_ZONE_SIZE;
    }

    crc32 = crc32_calculate(roi_sram, roi_sram_size);
    DBG_NOTICE("roisram crc32:0x%x", crc32);

    reg = CTRL_REG_ROISRAM_DATA_SIZE_L;
    ret = mcu_write_self_reg(sensor, reg, (u8) (roi_sram_size & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_SIZE_H;
    ret = mcu_write_self_reg(sensor, reg, (u8) ((roi_sram_size >> 8) & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_CRC32_BYTE0;
    ret = mcu_write_self_reg(sensor, reg, (u8) (crc32 & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_CRC32_BYTE1;
    ret = mcu_write_self_reg(sensor, reg, (u8) ((crc32 >> 8) & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_CRC32_BYTE2;
    ret = mcu_write_self_reg(sensor, reg, (u8) ((crc32 >> 16) & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_CRC32_BYTE3;
    ret = mcu_write_self_reg(sensor, reg, (u8) ((crc32 >> 24) & 0xFF));
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = DT_REG_ROISRAM_DATA_TRANSFER;
    ret = mcu_burst_write_reg(sensor, reg, roi_sram, roi_sram_size);
    if(ret < 0) {
        DBG_ERROR("mcu_burst_write_reg 0x%x failed. ret: %d\n", reg, ret);
        return ret;
    }

    reg = CTRL_REG_ROISRAM_DATA_CRC_VERIFY;
    ret = mcu_write_self_reg(sensor, reg, 1);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    ret = mcu_waiting_4_state(sensor, STATUS_REG_ROISRAM_DATA_CRC_VERIFY_RESULT, wait_state, wait_state, wait_timeout_us, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
        return ret;
    }

    return ret;
}

static int reg_format_dump(struct sensor *sensor, u32 base_address, int reg_count, const char *reg_type_name, const u8 *val_buf, bool out_2_console)
{
#define LENGTH_PER_LINE             128

    u16             reg, startAddr = base_address;
    u16             endAddr = base_address + reg_count - 1;
    int             i, j;
    int             buf_len = 0;
    char *          buf;
    int             index;

    buf = kzalloc(LENGTH_PER_LINE, GFP_KERNEL);
    if (NULL == buf)
    {
        DBG_ERROR("malloc failure for <%s>", __func__);
        return -ENOMEM;
    }

    buf_len += sprintf(buf, "===========%s Register Dump ===========", reg_type_name);
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    buf_len += sprintf(buf + buf_len, "-------");

    for (i = 0; i < 0x10; i++) {
        buf_len += sprintf(buf + buf_len, "----%x", i);
    }

    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    for (i = 0; i < reg_count/0x10; i++) {
        buf_len += sprintf(buf + buf_len, "%06x:", (i << 4) +base_address);

        for (j = 0; j < 0x10; j++) {
            index = ((i << 4) | j);
            reg = index +base_address;

            if ((startAddr <= reg && endAddr >= reg)) {
                buf_len += sprintf(buf + buf_len, "   %02X", val_buf[index]);
            }
            else {
                buf_len += sprintf(buf + buf_len, "   --");
            }
        }

        printout_2_select_target(buf, out_2_console);
        buf_len = 0;
    }

    buf_len += sprintf(buf + buf_len, "=====================================================================================\n");
    printout_2_select_target(buf, out_2_console);

    kfree(buf);
    buf = NULL;
    return buf_len;
}

static int mcu_reg_dump(struct sensor *sensor, u32 base_address, int reg_count, const char *callfunc, int callline, bool out_2_console)
{
    int ret = 0;
    uint16_t reg;
    u8 sub_dev_id;
    u8 *val_buf;
    char *reg_type_name;

    sub_dev_id = (base_address >> 16) & 0xFF;
    if ((SUB_DEV_ID_MCU_SELF != sub_dev_id) && (SUB_DEV_ID_ADS6401_DTOF != sub_dev_id))
    {
        DBG_ERROR("Invalid sub device id for <%s>", __func__);
        return -EIO;
    }

    switch (sub_dev_id)
    {
        case SUB_DEV_ID_MCU_SELF:
            reg = DT_REG_MCU_REG_DUMP;
            reg_type_name = "Module Status & Ctrl";
            break;

        case SUB_DEV_ID_ADS6401_DTOF:
            reg = DT_REG_ADS6401_REG_DUMP;
            reg_type_name = "Ads6401 Basic";
            break;

        default:
            DBG_ERROR("Invalid reg_addr 0x%x for <%s>", base_address, __func__);
            break;
    }

    val_buf = kzalloc(reg_count, GFP_KERNEL);
    if (NULL == val_buf)
    {
        DBG_ERROR("malloc failure for <%s>", __func__);
        return -ENOMEM;
    }

    ret = mcu_burst_read_reg(sensor, reg, val_buf, reg_count);
    if(ret < 0){
        kfree(val_buf);
        DBG_ERROR("mcu_burst_read_reg 0x%x failed. ret: %d\n", reg, ret);
        return ret;
    }

    ret = reg_format_dump(sensor, base_address, reg_count, reg_type_name, val_buf, out_2_console);
    kfree(val_buf);

    return ret;
}

// When any error occurs, the function will return a negative number.
static int __maybe_unused eeprom_read(struct sensor *priv, unsigned int offset, size_t count, u8 *outbuf)
{
    int ret = 0;

    if (offset >= priv->eeprom_capacity) {
        DBG_ERROR("offset >= priv->eeprom_capacity...");
        return -EINVAL;
    }

    if ((offset + count) > priv->eeprom_capacity) {
        DBG_ERROR("(offset:%d + count:%ld) > priv->eeprom_capacity:%d...", offset, count, priv->eeprom_capacity);
        return -EINVAL;
    }

    ret = mcu_read_eeprom_data(priv, offset, outbuf, count);

    return ret;
}

static int eeprom_data_valid_check(u8 *eeprom_buf, bool is_bigdata_compressed, u32 called_line)
{
    u32 calc_crc32 = 0;
    u32 compressed_data_length = 0; // uncompressed_basic_data_size + compressed_bigdata_size
    swift_eeprom_v2_data_t* eeprom_data = (swift_eeprom_v2_data_t*) eeprom_buf;

    if (NULL == eeprom_buf) {
        DBG_ERROR("Null pointer for eeprom_buf...");
        return -EINVAL;
    }

    if (BIG_FOV_EEPROM_MAGIC != eeprom_data->magic_id)
    {
        LOG2T_ERROR(OT_BOTH, "Invalid eeprom magic_id: 0x%x, called from Line: %d\n", eeprom_data->magic_id, called_line);
        return -EINVAL;
    }

    if (BIG_FOV_EEPROM_DATA_STRUCT_VERSION != eeprom_data->data_structure_version)
    {
        LOG2T_ERROR(OT_BOTH, "Invalid eeprom data_structure_version: 0x%x, called from Line: %d\n", eeprom_data->data_structure_version, called_line);
        return -EINVAL;
    }

    if ((eeprom_data->real_spot_zone_count > BIG_FOV_MAX_SPOT_ZONE_COUNT)
        || (eeprom_data->real_spot_zone_count < 4)
        || (0 != (eeprom_data->real_spot_zone_count % 4))
       )
    {
        LOG2T_ERROR(OT_BOTH, "Invalid real_spot_zone_count: %d, BIG_FOV_MAX_SPOT_ZONE_COUNT: %d, called from Line: %d\n", eeprom_data->real_spot_zone_count, BIG_FOV_MAX_SPOT_ZONE_COUNT, called_line);
        return -EINVAL;
    }

    if (0x0 == eeprom_data->tdcDelay[0] || 0x1F < eeprom_data->tdcDelay[0])
    {
        LOG2T_ERROR(OT_BOTH, "Invalid tdc_delay_major: 0x%x, called from Line: %d\n", eeprom_data->tdcDelay[0], called_line);
        return -EINVAL;
    }

    if (0x0 == eeprom_data->tdcDelay[1] || 0xF < eeprom_data->tdcDelay[1])
    {
        LOG2T_ERROR(OT_BOTH, "Invalid tdc_delay_minor: 0x%x, called from Line: %d\n", eeprom_data->tdcDelay[1], called_line);
        return -EINVAL;
    }

    if (is_bigdata_compressed)
    {
        compressed_data_length = eeprom_data->compressed_data_length;

        //if ((BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE + compressed_bigdata_size) != eeprom_data->compressed_data_length)
        if (0 == eeprom_data->compressed_data_length || eeprom_data->compressed_data_length < BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE)
        {
            LOG2T_ERROR(OT_BOTH, "Invalid eeprom compressed_data_length: %d, called from Line: %d\n", eeprom_data->compressed_data_length, called_line);
            return -EINVAL;
        }

        calc_crc32 = crc32_calculate((unsigned char*)eeprom_buf + BIG_FOV_MODULE_EEPROM_BASICDATA_OFFSET, compressed_data_length);
        if (calc_crc32 != eeprom_data->compressed_data_crc32)
        {
            LOG2T_ERROR(OT_BOTH, "Invalid eeprom compressed_data_crc32: 0x%x, calc_crc32: 0x%x, called from Line: %d\n", eeprom_data->compressed_data_crc32, calc_crc32, called_line);
            return -EINVAL;
        }
    }
    else {
        if ((BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE + BIG_FOV_MODULE_EEPROM_BIGDATA_MAX_SIZE) != eeprom_data->data_length)
        {
            LOG2T_ERROR(OT_BOTH, "Invalid eeprom data_length: %d, expected: %ld, called from Line: %d\n", 
                eeprom_data->data_length, BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE + BIG_FOV_MODULE_EEPROM_BIGDATA_MAX_SIZE, called_line);
            return -EINVAL;
        }

        calc_crc32 = crc32_calculate((unsigned char*)eeprom_buf + BIG_FOV_MODULE_EEPROM_BASICDATA_OFFSET, BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE + BIG_FOV_MODULE_EEPROM_BIGDATA_MAX_SIZE);
        if (calc_crc32 != eeprom_data->data_crc32)
        {
            LOG2T_ERROR(OT_BOTH, "Invalid eeprom data_crc32: 0x%x, calc_crc32: 0x%x, called from Line: %d\n", eeprom_data->data_crc32, calc_crc32, called_line);
            return -EINVAL;
        }
    }

    return 0;
}


static int __maybe_unused eeprom_data_read(struct sensor *priv, unsigned int offset, size_t length, u8 *outbuf)
{
    int ret = 0;

    unsigned int size_4_head_and_basicdata = 0;
    u32 compressed_bigdata_size = 0;
    char *eeprom_buf = NULL;
    swift_eeprom_v2_data_t* eeprom_data = NULL;
    unsigned int decomp_len;
    char *decomp_buf;

    if (NULL == outbuf) {
        DBG_ERROR("Null pointer for outbuf...");
        return -EINVAL;
    }

    eeprom_buf = kzalloc(priv->eeprom_capacity * sizeof(u8), GFP_KERNEL);
    if (!eeprom_buf)
    {
        return -ENOMEM;
    }

    ret = eeprom_read(priv, offset, priv->eeprom_capacity, eeprom_buf);
    if (ret < 0) {
        LOG2T_ERROR(OT_BOTH, "eeprom_read() failure: %d\n", ret);
        goto err_exit;
    }


    ret = eeprom_data_valid_check(eeprom_buf, true, __LINE__);
    if (ret < 0) {
        LOG2T_ERROR(OT_BOTH, "eeprom_data_valid_check() failure: %d\n", ret);
        goto err_exit;
    }

    decomp_buf = vmalloc(length);
    if (!decomp_buf) {
        ret = -ENOMEM;
        goto err_exit;
    }

    size_4_head_and_basicdata = BIG_FOV_MODULE_EEPROM_ROISRAM_DATA_OFFSET;
    eeprom_data = (swift_eeprom_v2_data_t*) eeprom_buf;
    compressed_bigdata_size = eeprom_data->compressed_data_length - BIG_FOV_MODULE_EEPROM_BASICDATA_SIZE;

    // copy HEAD and BASIC_DATA
    memcpy(outbuf, eeprom_buf, size_4_head_and_basicdata);

    // decompress BIG_DATA
    decomp_len = length;
    LOG2T_ERROR(OT_BOTH, "size_4_head_and_basicdata: %d, compressed_bigdata_size: %d, length: %ld, offset: %d, eeprom_capacity: %d\n", 
        size_4_head_and_basicdata, compressed_bigdata_size, length, offset, priv->eeprom_capacity);
    ret = zlib_direct_decompress(&eeprom_buf[size_4_head_and_basicdata], compressed_bigdata_size, decomp_buf, &decomp_len);
    LOG2T_ERROR(OT_BOTH, "zlib_direct_decompress() return: %d, decomp_len: %d\n", ret, decomp_len);
    if (ret < 0) {
        LOG2T_ERROR(OT_BOTH, "zlib_direct_decompress() failure: %d\n", ret);
        vfree(decomp_buf);
        goto err_exit;
    }

    memcpy(&outbuf[size_4_head_and_basicdata], decomp_buf, decomp_len);
    vfree(decomp_buf);

    // check decompressed EEPROM buffer once more, to check eeprom_data->data_length/data_crc32 matched or not?
    ret = eeprom_data_valid_check(outbuf, false, __LINE__);
    if (ret < 0) {
        LOG2T_ERROR(OT_BOTH, "eeprom_data_valid_check() failure: %d\n", ret);
        goto err_exit;
    }

err_exit:
    kfree(eeprom_buf);

    return ret;
}

static int mcu_set_sensor_config_stage(struct sensor *sensor, u8 stage)
{
    int ret = 0;
    u16 reg_addr16;

    reg_addr16 = CTRL_REG_DTOF_CONFIG_STAGE;
    ret = mcu_write_self_reg(sensor, reg_addr16, stage);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}

static int mcu_set_vop_adjust_policy(struct sensor *sensor, u8 policy)
{
    int ret = 0;
    u16 reg_addr16;

    reg_addr16 = CTRL_REG_VOP_CTRL_POLICY;
    ret = mcu_write_self_reg(sensor, reg_addr16, policy);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}

static int mcu_set_vop_adjust_interval(struct sensor *sensor, u16 interval_ms)
{
    int ret = 0;
    u16 reg_addr16;

    reg_addr16 = CTRL_REG_VOP_ADJUST_INTERVAL;
    ret = mcu_write_self_reg(sensor, reg_addr16, interval_ms/100);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}

static int mcu_set_pvdd_voltage(struct sensor *sensor, u16 pvdd_mv, int callline)
{
    int ret=0;
    u16 reg_addr16;
    u16 set_pvdd_x100;

    // if sensor->force_pvdd_voltage is set (not 0), I always use it for current pvdd voltage setting, for test purpose.
    if (0 != sensor->force_pvdd_voltage)   // volt's unit is mv
    {
        pvdd_mv = sensor->force_pvdd_voltage;
    }
    else {
        if (pvdd_mv < PVDD_VOLTAGE_4_INDOOR_MODE || pvdd_mv > PVDD_VOLTAGE_4_OUTDOOR_MODE)   // volt's unit is mv
        {
            DBG_ERROR("Invalid pvdd voltage %d mv",pvdd_mv);
            return -EINVAL;
        }
    }
    set_pvdd_x100 = pvdd_mv/10;

    reg_addr16 = CTRL_REG_SET_PVDD_VOL_L;
    ret = mcu_write_self_reg(sensor, reg_addr16, set_pvdd_x100 & 0xFF);
    if (ret < 0) {
        DBG_ERROR("Fail to set pvdd voltage to %d.%03d v.", pvdd_mv/1000, pvdd_mv % 1000);
        return ret;
    }

    reg_addr16 = CTRL_REG_SET_PVDD_VOL_H;
    ret = mcu_write_self_reg(sensor, reg_addr16, (set_pvdd_x100 >> 8) & 0xFF);
    if (ret < 0) {
        DBG_ERROR("Fail to set pvdd voltage to %d.%03d v.", pvdd_mv/1000, pvdd_mv % 1000);
        return ret;
    }
    else {
        sensor->mcu_cur_pvdd_x100 = set_pvdd_x100;
        LOG2T_NOTICE(OT_BOTH, "set pvdd voltage to %d.%03d v, requested from line: %d.", pvdd_mv/1000, pvdd_mv % 1000, callline);
    }

    return ret;
}

static int mcu_set_fsync_param(struct sensor *sensor, u8 source, u8 pulse_width, u8 frequency)
{
    int ret = 0;
    u16 reg_addr16;

    reg_addr16 = CTRL_REG_FSYNC_SOURCE;
    ret = mcu_write_self_reg(sensor, reg_addr16, source);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    reg_addr16 = CTRL_REG_FSYNC_PULSE_WIDTH;
    ret = mcu_write_self_reg(sensor, reg_addr16, pulse_width);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    reg_addr16 = CTRL_REG_FSYNC_FREQUENCY;
    ret = mcu_write_self_reg(sensor, reg_addr16, frequency);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}

static int mcu_set_roisram_parameters(struct sensor *sensor, u8 roisram_data_set_count, bool roisram_rolling)
{
    int ret = 0;
    u16 reg_addr16;

    if (ADAPS_PCM_MODE == sensor->cur_wkmode)
    {
        reg_addr16 = CTRL_REG_ROISRAM_DATA_GROUP_COUNT;
        ret = mcu_write_self_reg(sensor, reg_addr16, 0);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
            return ret;
        }

        reg_addr16 = CTRL_REG_ROISRAM_ROLLING_ENABLE;
        ret = mcu_write_self_reg(sensor, reg_addr16, false);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
            return ret;
        }
    }
    else {
        reg_addr16 = CTRL_REG_ROISRAM_DATA_GROUP_COUNT;
        ret = mcu_write_self_reg(sensor, reg_addr16, roisram_data_set_count);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
            return ret;
        }

        reg_addr16 = CTRL_REG_ROISRAM_ROLLING_ENABLE;
        ret = mcu_write_self_reg(sensor, reg_addr16, roisram_rolling);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
            return ret;
        }
    }

    return ret;
}

static int mcu_let_mcu_write_initial_roisram_data(struct sensor *sensor)
{
    int ret;
    u16 reg;
    u8 val8 = 0x01;
    u8 wait_state = 0x01;
    u32 wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;

    reg = CTRL_REG_WRITE_INIT_ROISRAM_DATA;
    ret = mcu_write_self_reg(sensor, reg, val8);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    ret = mcu_waiting_4_state(sensor, STATUS_REG_INIT_ROISRAM_WRITE_DONE, wait_state, wait_state, wait_timeout_us, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
        return ret;
    }

    return ret;
}

static int mcu_set_stream_state(struct sensor *sensor, bool stream_on)
{
    int ret = 0;
    u16 reg_addr16;

    reg_addr16 = CTRL_REG_DTOF_STREAMING_STATE;
    ret = mcu_write_self_reg(sensor, reg_addr16, stream_on);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}

static int mcu_read_chip_id(struct sensor *sensor)
{
    u16 id  = 0;
    u16 reg;
    u8 val8;
    int ret;

    reg = STATUS_REG_MCU_CHIP_ID_L;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_INFO("Fail to read register 0x%x, ret: %d.\n", reg, ret);
        return ret;
    }
    id = val8 << 8;

    reg = STATUS_REG_MCU_CHIP_ID_H;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_INFO("Fail to read register 0x%x, ret: %d.\n", reg, ret);
        return ret;
    }
    id = val8 | id;

    if (id != MCU_CHIP_ID_PY32L090E1BY7) {
        DBG_ERROR("Unexpected mcu id(0x%x) on i2c address: 0x%x, ret(%d)\n", id, sensor->mcu_i2c_client->addr, ret);
        return -ENODEV;
    }

    DBG_NOTICE("Detected MCU, chipid: 0x%x on i2c address 0x%x!\n", id, sensor->mcu_i2c_client->addr);
    sensor->mcu_chipid = id;

    return 0;
}

static int mcu_ready_check(struct sensor *sensor)
{
    int ret = 0;
    s64 us_delta;
    u32 delay_us;
    ktime_t start;

    delay_us = MCU_READY_CHECK_BASE_DELAY;
    usleep_range(delay_us, delay_us+100);
    DBG_INFO("<%s> start to read chip id.\n", __FUNCTION__);
    start = ktime_get();

    delay_us = MCU_READY_CHECK_INRERVAL;
    do {
        ret = mcu_read_chip_id(sensor);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (0 == ret) {
            DBG_NOTICE("mcu is ready, already wait %lld us, chip id: 0x%x\n", us_delta, sensor->mcu_chipid);
            ret = 0;
            break;
        }

        if (MCU_READY_CHECK_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to mcu ready, already wait %lld us.\n", us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(delay_us, delay_us+100);
    } while (1);

    return ret;
}

static int sensor_read_chip_id(struct sensor *sensor)
{
    u16 id  = 0;
    u16 reg;
    u8 val8;
    int ret;

    reg = 0x00A0;
    ret = mcu_read_dtof_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n", reg, ret);
        return ret;
    }
    id = val8 << 8;

    reg = 0x00A1;
    ret = mcu_read_dtof_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n", reg, ret);
        return ret;
    }
    id = val8 | id;

    if (id != SENSOR_CHIP_ID) {
        DBG_ERROR("Unexpected sensor id(0x%x) on i2c address: 0x%x, ret(%d)\n", id, sensor->mcu_i2c_client->addr, ret);
        return -ENODEV;
    }

    DBG_NOTICE("Detected %s sensor, chipid: 0x%x on i2c address 0x%x!\n", SENSOR_NAME, id, sensor->mcu_i2c_client->addr);
    sensor->sensor_chipid = id;

    return 0;
}

static int sensor_ready_check(struct sensor *sensor)
{
    int ret = 0;
    s64 us_delta;
    u32 delay_us;
    ktime_t start;

    delay_us = SENSOR_READY_CHECK_BASE_DELAY;
    usleep_range(delay_us, delay_us+100);
    DBG_INFO("<%s> start to read chip id.\n", __FUNCTION__);
    start = ktime_get();

    delay_us = SENSOR_READY_CHECK_INRERVAL;
    do {
        ret = sensor_read_chip_id(sensor);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (0 == ret) {
            DBG_NOTICE("sensor is ready, already wait %lld us, chip id: 0x%x\n", us_delta, sensor->sensor_chipid);
            ret = 0;
            break;
        }

        if (SENSOR_READY_CHECK_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to sensor ready, already wait %lld us.\n", us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(delay_us, delay_us+100);
    } while (1);

    return ret;
}

static int sensor_modify_reg(struct setting_r16vd *register_lst, u16 reg_addr, u8 new_val)
{
    int i;
    int ret = -1;

    if (NULL == register_lst) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    for (i = 0; register_lst[i].reg != REG16_NULL; i++) {
        if (reg_addr == register_lst[i].reg)
        {
            ret = 0;
            break;
        }
    }

    if (0 == ret)
        register_lst[i].val = new_val;

    return ret;
}


// refer to AD-819: https://www.teambition.com/project/5f643ef2ab08650044e81637/tasks/view/6486c42c3dd88d510ed0a13c/task/64c9ad6ddb11f84bbc6408b4
// the output raw data for test pattern may be different according the different system clock setting.
static int sensor_testpattern_enable(struct sensor *sensor)
{
    int ret = 0;
    u16 reg;
    u8 val;

    if (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)
    {
        reg = 0x00DF;
        ret = mcu_read_dtof_reg(sensor, reg, &val);
        if (ret < 0) {
            DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n", reg, ret);
            return ret;
        }
        val = val | 0x08;
        ret = mcu_write_dtof_reg(sensor, reg, val);
        if (ret < 0) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
        sensor->test_pattern_enabled = true;
    }

    return ret;
}

static const struct sensor_mode sensor_wkmode[] =
{
    // PHR mode 1032x32
    {
        .width              = 1032,
        .height             = 32,
        .max_fps            = {
            .numerator          = 10000,
            .denominator        = 300000,
        },
        .exp_def            = 0x3c,
        .wkmode_reg_cfg_list           = sensor_phr_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_phr_regs),
    },
    // PCM mode 2560x32
    {
        .width              = 2560,
        .height             = 32,
        .max_fps            = {
            .numerator          = 100000,
            .denominator        = 300000,
        },
        .exp_def            = 0xFF,
        .wkmode_reg_cfg_list           = sensor_pcm_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_pcm_regs),
    },
    // FHR mode 4104x32
    {
        .width              = 4104,
        .height             = 32,
        .max_fps            = {
            .numerator          = 10000,
            .denominator        = 300000,
        },
        .exp_def            = 0x3c,
        .wkmode_reg_cfg_list           = sensor_fhr_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_fhr_regs),
    },
};

static int sensor_match_work_mode(struct v4l2_subdev_format * fmt)
{
    struct v4l2_mbus_framefmt * framefmt = &fmt->format;
    int             cur_best_fit = -1;
    int             i;

    for (i = 0; i < ARRAY_SIZE(sensor_wkmode); i++) {
        if (sensor_wkmode[i].width == framefmt->width && sensor_wkmode[i].height == framefmt->height) {
            cur_best_fit        = i;
            break;
        }
    }

    return cur_best_fit;
}

static int sensor_spot_maskcfg_force_update(struct sensor *sensor, struct setting_r16vd *regs)
{
    u8 CoarseMaskCfg;
    u8 FineMaskCfg;

    CoarseMaskCfg = DEFAULT_COARSE_MASK_CONFIG;
    FineMaskCfg = DEFAULT_FINE_MASK_CONFIG;

    if (NO_FORCE_MASK_CONFIG != sensor->force_coarse_mask_cfg)
    {
        CoarseMaskCfg = sensor->force_coarse_mask_cfg;
    }

    if (NO_FORCE_MASK_CONFIG != sensor->force_fine_mask_cfg)
    {
        FineMaskCfg = sensor->force_fine_mask_cfg;
    }

    sensor_modify_reg(regs, 0xB0, CoarseMaskCfg);
    sensor_modify_reg(regs, 0xB1, FineMaskCfg);

    return 0;
}

static int sensor_config_4_work_mode(struct sensor *sensor)
{
    int ret = 0;

    if (FALSE == sensor->load_script)
    {
        struct setting_r16vd *p_sensor_workmode_setting = NULL;

        // create a copy of sensor_wkmode_cfg_regs before modifing some registers's configure to avoid the original sensor_work mode settings is changed.
        p_sensor_workmode_setting = kmalloc((sizeof(struct setting_r16vd) *sensor->cur_sensor_mode->wkmode_reg_cfg_count), GFP_KERNEL);
        if (!p_sensor_workmode_setting)
        {
            DBG_ERROR("kmalloc failure");
            return  -ENOMEM;
        }
        memcpy(p_sensor_workmode_setting, sensor->cur_sensor_mode->wkmode_reg_cfg_list, sizeof(struct setting_r16vd) *sensor->cur_sensor_mode->wkmode_reg_cfg_count);

        if (0 != sensor->force_mipi_tx_delay)
        {
            DBG_INFO("Update mipi tx delay to 0x%02x...\n", sensor->force_mipi_tx_delay);
            sensor_modify_reg(p_sensor_workmode_setting, 0x00A9, sensor->force_mipi_tx_delay);
        }

        if (0 != sensor->force_vcsel_laser_period)
        {
            DBG_INFO("Update force_vcsel_laser_period to 0x%02x...\n", sensor->force_vcsel_laser_period);
            sensor_modify_reg(p_sensor_workmode_setting, 0xBC, sensor->force_vcsel_laser_period);
        }

        if (0 != sensor->force_vcsel_laser_pulse_width)
        {
            DBG_INFO("Update force_vcsel_laser_pulse_width to 0x%02x...\n", sensor->force_vcsel_laser_pulse_width);
            sensor_modify_reg(p_sensor_workmode_setting, 0xBD, sensor->force_vcsel_laser_pulse_width);
            sensor_modify_reg(p_sensor_workmode_setting, 0xBE, sensor->force_vcsel_laser_pulse_width);
        }

        if (0 != sensor->force_fine_exposure_time)
        {
            DBG_INFO("Update force_fine_exposure_time to 0x%02x...\n", sensor->force_fine_exposure_time);
            sensor_modify_reg(p_sensor_workmode_setting, 0xC0, sensor->force_fine_exposure_time);
        }

        if (0 != sensor->force_pcm_exposure_time)
        {
            DBG_INFO("Update force_pcm_exposure_time to 0x%02x...\n", sensor->force_pcm_exposure_time);
            sensor_modify_reg(p_sensor_workmode_setting, 0xC2, sensor->force_pcm_exposure_time);
        }

        if (0 != sensor->force_tdc_delay_time_h)
        {
            DBG_INFO("Update force_tdc_delay_time_h to 0x%02x...\n", sensor->force_tdc_delay_time_h);
            sensor_modify_reg(p_sensor_workmode_setting, 0xC3, sensor->force_tdc_delay_time_h);
        }

        if (0 != sensor->force_tdc_delay_time_l)
        {
            DBG_INFO("Update force_tdc_delay_time_l to 0x%02x...\n", sensor->force_tdc_delay_time_l);
            sensor_modify_reg(p_sensor_workmode_setting, 0xC4, sensor->force_tdc_delay_time_l);
        }


        if (ADAPS_PCM_MODE != sensor->cur_wkmode)
        {
#if defined(ENABLE_RUNTIME_REGISTER_UPDATE)
            // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
            if ((0 == (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)) && (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_RUNTIME_UPDATE)))
            {
                sensor_spot_maskcfg_force_update(sensor, p_sensor_workmode_setting);
            }
#endif
        }

        ret = mcu_set_sensor_config_stage(sensor, DTOF_CONFIG_STAGE_WORKMODE);
        if (ret < 0) {
            DBG_ERROR("could not set sensor_config_stage\n");
        }

        ret = mcu_write_dtof_reg_array(sensor, p_sensor_workmode_setting, __LINE__);
        kfree(p_sensor_workmode_setting);
        if (ret < 0) {
            DBG_ERROR("fail to write mode config registers");
            return ret;
        }

        if (ADAPS_PCM_MODE != sensor->cur_wkmode)
        {
            // notice MCU to write roisram register.
        }

#if defined(ENABLE_RUNTIME_REGISTER_UPDATE)
        // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
        if ((0 == (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)) && (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_RUNTIME_UPDATE)))
        {
            sensor_update_setting(sensor,
                sensor->cur_etype,
                sensor->cur_mtype,
                sensor->cur_v_zone_cnt,
                sensor->cur_vmode);
            sensor_framerate_setting(sensor);
        }
#endif
        if (sensor->force_tdc_delay_time_h == 0 && sensor->force_tdc_delay_time_l == 0)
        {
            sensor_write_tdc_delay_setting(sensor);
        }
    }

    return ret;
}

/**
 * sensor_init_setting - Initialize sensor with default register settings
 * @sensor: Pointer to sensor structure
 *
 * Return: 0 on success, negative error code on failure
 *
 * This function writes the initial register settings to the sensor.
 * It creates a copy of the default settings, applies power mode and
 * MIPI speed adjustments if needed, then writes them to the sensor.
 */
static int sensor_init_setting(struct sensor * sensor)
{
    int ret = 0;
    struct setting_r16vd *p_sensor_init_setting = NULL;

    // create a copy of sensor_init_regs before modifing some registers's configure to avoid the original sensor_init_regs settings is changed.
    p_sensor_init_setting = kmalloc((sizeof(struct setting_r16vd) *ARRAY_LEN(sensor_init_regs) ), GFP_KERNEL);
    if (!p_sensor_init_setting)
    {
        DBG_ERROR("kmalloc failure");
        return  -ENOMEM;
    }
    memcpy(p_sensor_init_setting, sensor_init_regs, sizeof(struct setting_r16vd) *ARRAY_LEN(sensor_init_regs));
    // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)

    ret = mcu_set_sensor_config_stage(sensor, DTOF_CONFIG_STAGE_INIT);
    if (ret < 0) {
        DBG_ERROR("could not set sensor_config_stage\n");
    }

    ret = mcu_write_dtof_reg_array(sensor, p_sensor_init_setting, __LINE__);
    kfree(p_sensor_init_setting);
    if (ret < 0) {
        DBG_ERROR("could not set init registers\n");
    }

    return ret;
}

static int sensor_initilize(struct sensor * sensor)
{
    int ret = 0;

    if (FALSE == sensor->load_script)
    {
        ret = sensor_init_setting(sensor);
        if (ret < 0) {
            DBG_ERROR("Fail to set sensor init registers, ret: %d\n", ret);
            return ret;
        }

        sensor_testpattern_enable(sensor);

    }

    return ret;
}

static int sensor_config(struct sensor *sensor, int callline)
{
    int ret;

    DBG_NOTICE("env_type=%d, measure_type=%d, work_mode=%d, framerate_type:%d, cur_pmode: %d, called from Line: %d...",
        sensor->cur_etype, sensor->cur_mtype, sensor->cur_wkmode, sensor->cur_frtype, sensor->cur_pmode, callline);

    __v4l2_ctrl_s_ctrl(sensor->ctrl_linkfreqency, 0);
    __v4l2_ctrl_s_ctrl_int64(sensor->ctrl_pixelrate, to_pixel_rate(sensor->mipi_data_lanes));

    ret = sensor_initilize(sensor);
    if (ret < 0) {
        DBG_ERROR("Fail to sensor_initilize(), ret: %d\n", ret);
        return ret;
    }

    sensor_config_4_work_mode(sensor);
    sensor->sensor_cfg_done = true;

    return 0;
}

/**
 * sensor_set_fmt - Set the image format for the sensor
 * @sd: V4L2 subdevice pointer
 * @sd_state: V4L2 subdevice state
 * @fmt: Format structure containing requested format
 *
 * Return: 0 on success, negative error code on failure
 *
 * This V4L2 callback sets the sensor's image format (resolution, pixel format).
 * It finds the matching work mode based on requested width/height and
 * configures the sensor accordingly.
 */
static int sensor_set_fmt(struct v4l2_subdev * sd, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    struct v4l2_subdev_state *sd_state,
#else
    struct v4l2_subdev_pad_config *cfg,
#endif
    struct v4l2_subdev_format * fmt)
{
    int ret = 0;
    struct sensor *sensor = to_sensor(sd);
    int wkmode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);
    mutex_lock(&sensor->sensor_mutex);

    //DBG_INFO("fmt->which:0x%x,V4L2_SUBDEV_FORMAT_TRY:0x%x, fmt->width:%d, fmt->height:%d", 
    //  fmt->which, V4L2_SUBDEV_FORMAT_TRY, fmt->format.width, fmt->format.height);
    wkmode = sensor_match_work_mode(fmt);
    if (wkmode < 0)
    {
        DBG_ERROR("find_best_fit_work_mode failed wkmode:%d\n", wkmode);
        ret = -EINVAL;
    }
    else {
        sensor->cur_wkmode    = wkmode;
        sensor->cur_sensor_mode        = &sensor_wkmode[wkmode];

        fmt->format.code        = SENSOR_MEDIA_BUS_FMT;
        fmt->format.width       = sensor->cur_sensor_mode->width;
        fmt->format.height      = sensor->cur_sensor_mode->height;
        fmt->format.field       = V4L2_FIELD_NONE;
        DBG_NOTICE("fmt->which:0x%x, wkmode:%d mode->width:%d, mode->height:%d, probe_success: %d, load_script: %d, dbg_ctrl: 0x%x, client: %s...",
            fmt->which, wkmode, sensor->cur_sensor_mode->width, sensor->cur_sensor_mode->height, sensor->probe_success, sensor->load_script, sensor->dbg_ctrl, current->comm);

#if defined(DISABLE_SENSOR_CFG_AT_BOOT_STAGE)
        if ((sensor->probe_success) // on rk3588, set_fmt() will be called when excute to v4l2_async_register_subdev_sensor_common() of probe().
             && (0 == strncmp(current->comm, DTOF_APP_NAME, strlen(DTOF_APP_NAME))))
#else
        if (sensor->probe_success) // on rk3588, set_fmt() will be called when excute to v4l2_async_register_subdev_sensor_common() of probe().
#endif
        {
            ret = sensor_config(sensor, __LINE__);
        }
    }

    mutex_unlock(&sensor->sensor_mutex);

    return ret;
}


static int sensor_get_fmt(struct v4l2_subdev * sd, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    struct v4l2_subdev_state *sd_state,
#else
    struct v4l2_subdev_pad_config *cfg,
#endif
    struct v4l2_subdev_format * fmt)
{
    int ret = 0;
    struct sensor * sensor = to_sensor(sd);
    const struct sensor_mode * mode = sensor->cur_sensor_mode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s, which:0x%x,V4L2_SUBDEV_FORMAT_TRY:0x%x", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name, fmt->which, V4L2_SUBDEV_FORMAT_TRY);
    mutex_lock(&sensor->sensor_mutex);

    if (fmt->which == V4L2_SUBDEV_FORMAT_TRY) {
        fmt->format = *v4l2_subdev_get_try_format(sd,
#   if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
            sd_state,
#   else
            cfg,
#   endif
            fmt->pad);
    }
    else {
        fmt->format.width   = mode->width;
        fmt->format.height  = mode->height;
        fmt->format.code    = SENSOR_MEDIA_BUS_FMT;
        fmt->format.field   = V4L2_FIELD_NONE;
    }

    mutex_unlock(&sensor->sensor_mutex);

    return ret;
}


static int sensor_enum_mbus_code(struct v4l2_subdev * sd, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    struct v4l2_subdev_state *sd_state,
#else
    struct v4l2_subdev_pad_config *cfg,
#endif
    struct v4l2_subdev_mbus_code_enum * code)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    if (code->index != 0)
        return - EINVAL;

    code->code = SENSOR_MEDIA_BUS_FMT;

    return 0;
}

static int sensor_enum_frame_sizes(struct v4l2_subdev * sd, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    struct v4l2_subdev_state *sd_state,
#else
    struct v4l2_subdev_pad_config *cfg,
#endif
    struct v4l2_subdev_frame_size_enum * fse)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    if (fse->index >= ARRAY_SIZE(sensor_wkmode))
        return - EINVAL;

    if (fse->code != SENSOR_MEDIA_BUS_FMT)
        return - EINVAL;

    DBG_INFO("fse->index:%d", fse->index);
    fse->min_width      = sensor_wkmode[fse->index].width;
    fse->max_width      = sensor_wkmode[fse->index].width;
    fse->max_height     = sensor_wkmode[fse->index].height;
    fse->min_height     = sensor_wkmode[fse->index].height;

    return 0;
}

#if LINUX_VERSION_CODE <= KERNEL_VERSION(6,7,0)
static int sensor_g_frame_interval(struct v4l2_subdev * sd, 
    struct v4l2_subdev_frame_interval * fi)
{
    struct sensor * sensor = to_sensor(sd);
    const struct sensor_mode * mode = sensor->cur_sensor_mode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    mutex_lock(&sensor->sensor_mutex);
    fi->interval = mode->max_fps;
    mutex_unlock(&sensor->sensor_mutex);

    return 0;
}
#endif

static int sensor_update_setting(
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsMeasurementType mtype,
    AdapsVcselZoneCountType vcselzonecount_type,
    AdapsVcselMode vmode)
{
    int ret = 0;
    u16 reg;
    u8 val;
    u8 mode_bit = 0;

    if (NULL == sensor)
    {
        DBG_ERROR("sensor is NULL");
        return -EINVAL;
    }

    // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
    if (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)
    {
        DBG_INFO("Use the basic register settings for test pattern data output...");
        return ret;
    }

    // for this kind of module, always use OUTDOOR PVDD voltage!
    mcu_set_pvdd_voltage(sensor, PVDD_VOLTAGE_4_OUTDOOR_MODE, __LINE__);

    if (ADAPS_PCM_MODE == sensor->cur_wkmode)
    {
        // apply the user configured exposure values from SpadisApp if any.
        if (0 != sensor->grayExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, grayExposureCfg: 0x%x", sensor->grayExposureCfg);

            reg = 0xC2;
            val = sensor->grayExposureCfg;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->laserExposurePeriodCfg)
        {
            DBG_NOTICE("apply the user configured laserExposurePeriodCfg value, laserExposurePeriodCfg: 0x%x", sensor->laserExposurePeriodCfg);

            reg = 0xBC;
            val = BIT(7) | sensor->laserExposurePeriodCfg;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        return ret;
    }
    else {
        if (etype < AdapsEnvTypeIndoor || etype > AdapsEnvTypeOutdoor)
        {
            DBG_ERROR("Invalid EnvironmentType, etype:%d",etype);
            return -EINVAL;
        }
    
        if (mtype < AdapsMeasurementTypeNormal || mtype > AdapsMeasurementTypeFull)
        {
            DBG_ERROR("Invalid MeasurementType, etype:%d",mtype);
            return -EINVAL;
        }
    
        if (ADAPS_PTM_FHR_MODE == sensor->cur_wkmode)
        {
            mode_bit = 0x20;
        }
        else {
            mode_bit = 0x00;
        }

#if defined(ENABLE_SPECIAL_SETTING_4_AMZ_PER_HUAIYI)
        val = 0x22;
#else
        if (AdapsEnvTypeIndoor == etype)
        {
            switch (mtype) {
                case AdapsMeasurementTypeFull:
                    mode_bit = 0x20; // Full-distance force use FHR mode
                    val = mode_bit | 0x6;
                    break;
    
                case AdapsMeasurementTypeShort:
                    val = mode_bit | 0x6;
                    break;
    
                default:
                    val = mode_bit | 0x4;
                    break;
            }
        }
        else {
            switch (mtype) {
                case AdapsMeasurementTypeFull:
                    mode_bit = 0x20; // Full-distance force use FHR mode
                    val = mode_bit | 0x6;
                    break;

                case AdapsMeasurementTypeShort:
                    mode_bit = 0x20; // Outdoor force use FHR mode
                    val = mode_bit | 0x2;
                    break;
    
                default:
                    mode_bit = 0x20; // Outdoor force use FHR mode
                    val = mode_bit | 0x0;
                    break;
            }
        }
#endif

        DBG_INFO("------etype:%d, mtype:%d, val for B6: 0x%02x, current workmode: %d",etype, mtype, val, sensor->cur_wkmode);
        reg = 0xB6;
        ret = mcu_write_dtof_reg(sensor, reg, val);
        if (ret < 0) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }

        if (AdapsMeasurementTypeFull == mtype)
        {
            reg = 0xBC;
            val = BIT(7) | PTM_VCSEL_LASER_PERIOD;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }

            reg = 0xBF;
            val = COARSE_EXPOSURE_TIME;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }

            reg = 0xC0;
            val = FINE_EXPOSURE_TIME;  // 0x26
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
    
        }
    
        // apply the user configured exposure values from SpadisApp if any.
        if (0 != sensor->coarseExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, coarseExposureCfg: 0x%x", sensor->coarseExposureCfg);

            reg = 0xBF;
            val = sensor->coarseExposureCfg;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->fineExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, fineExposureCfg: 0x%x", sensor->fineExposureCfg);

            reg = 0xC0;
            val = sensor->fineExposureCfg;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->laserExposurePeriodCfg)
        {
            DBG_NOTICE("apply the user configured laserExposurePeriodCfg value, laserExposurePeriodCfg: 0x%x", sensor->laserExposurePeriodCfg);
        
            reg = 0xBC;
            val = BIT(7) | sensor->laserExposurePeriodCfg;
            ret = mcu_write_dtof_reg(sensor, reg, val);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }
    }

    return ret;
}

static int sensor_framerate_setting(struct sensor * sensor)
{
    int ret = 0;
    u16 reg;
    u8 val;

    if (sensor->cur_frtype >= AdapsFramerateType15FPS && sensor->cur_frtype <= AdapsFramerateType60FPS)
    {
        reg = 0x00A6;
        ret = mcu_read_dtof_reg(sensor, reg, &val);
        if (ret < 0) {
            DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n",reg, ret);
            return ret;
        }
        val = val & 0x03; //get the bit1-bit0 value

        val |= (sensor->cur_frtype - 1) << 2;
        ret = mcu_write_dtof_reg(sensor, reg, val);
        if (ret < 0) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
    }

    return ret;
}

static void sensor_get_module_inf(struct sensor * sensor, 
    struct rkmodule_inf * inf)
{
    memset(inf, 0, sizeof(*inf));
    strscpy(inf->base.sensor, SENSOR_NAME, sizeof(inf->base.sensor));
    strscpy(inf->base.module, sensor->module_name, sizeof(inf->base.module));
    strscpy(inf->base.lens, sensor->len_name, sizeof(inf->base.lens));
}

static long sensor_ioctl(struct v4l2_subdev * sd, unsigned int cmd, void *arg)
{
    struct rkmodule_bus_config *bus_config;
    struct sensor *sensor = to_sensor(sd);
    long ret = 0;
    ktime_t kt_req = ktime_get();
	struct rkmodule_csi_dphy_param *dphy_param;

    TRACE_IOCTL("----- Sensor_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, RKMODULE_GET_MODULE_INFO:0x%lx", 
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), RKMODULE_GET_MODULE_INFO
        );

    switch (cmd)
    {
        case RKMODULE_GET_MODULE_INFO:
            sensor_get_module_inf(sensor, (struct rkmodule_inf *) arg);
            TRACE_IOCTL("current sensor_ioctl_cmd: %x (RKMODULE_GET_MODULE_INFO)", cmd);
            break;

        case RKMODULE_GET_CSI_DSI_INFO:
            *(int *)arg = RKMODULE_CSI_INPUT;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x (RKMODULE_GET_CSI_DSI_INFO)", cmd);
            break;

        case RKMODULE_GET_BUS_CONFIG:
            bus_config = (struct rkmodule_bus_config *)arg;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,20,0)
            bus_config->bus.bus_type = V4L2_MBUS_CSI2_DPHY;
#else
            bus_config->bus.bus_type = V4L2_MBUS_CSI2;   // kernel 4.19
#endif
            bus_config->bus.lanes = sensor->mipi_data_lanes;
            /*
             * for rk356x: dphy0 is used just for full mode,
             *             dphy1 is used just for split mode,uses lane0_1,
             *             dphy2 is used just for split mode,uses lane2_3
             *
             * csi2_dphy0: used for csi2 dphy full mode,
                       is mutually exclusive with
                       csi2_dphy1 and csi2_dphy2
             * csi2_dphy1: used for csi2 dphy split mode,
                       physical lanes use lane0 and lane1,
                       can be used with csi2_dphy2  parallel
             * csi2_dphy2: used for csi2 dphy split mode,
                       physical lanes use lane2 and lane3,
                       can be used with csi2_dphy1  parallel
             *
             */

            // PAY ATTENTION: This configuration should be consistent with the value of the data-lanes attribute in the csi2_dphyX node of the DTS file.
            bus_config->bus.phy_mode = PHY_SPLIT_01;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x (RKMODULE_GET_BUS_CONFIG)", cmd);
            //DBG_INFO("phy_mode %d, lanes %d\n", bus_config->bus.phy_mode, bus_config->bus.lanes);
            break;

        case RKMODULE_GET_CSI_DPHY_PARAM:
            dphy_param = (struct rkmodule_csi_dphy_param *)arg;
            TRACE_IOCTL("current sensor_ioctl_cmd: %x, arg: %p, sensor get dphy param, vendor: %d, clk_hs_term_sel: %d", cmd, arg, dphy_param->vendor, rk3588_dcphy_param.clk_hs_term_sel);
            //if (dphy_param->vendor == rk3588_dcphy_param.vendor)
            {
                *dphy_param = rk3588_dcphy_param;
            }
            break;

#if 0
        case RKMODULE_GET_HDR_CFG:
            hdr = (struct rkmodule_hdr_cfg *)arg;
            hdr->esp.mode = HDR_NORMAL_VC;
            hdr->hdr_mode = NO_HDR;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            //DBG_INFO("cmd:0x%x,RKMODULE_GET_HDR_CFG:0x%lx", cmd, RKMODULE_GET_HDR_CFG);
            break;

        case RKMODULE_GET_CHANNEL_INFO:
            ch_info = (struct rkmodule_channel_info *)arg;
            ch_info->vc = V4L2_MBUS_CSI2_CHANNEL_0;
            ch_info->width = sensor->cur_sensor_mode->width;
            ch_info->height = sensor->cur_sensor_mode->height;
            ch_info->bus_fmt = SENSOR_MEDIA_BUS_FMT;
            ch_info->data_type = SENSOR_RAW_DATA_TYPE;
            ch_info->data_bit = 8;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            break;

        case RKMODULE_GET_START_STREAM_SEQ:
#endif
        default:
            ret = -ENOIOCTLCMD;
            TRACE_IOCTL("cmd:0x%x,RKMODULE_GET_MODULE_INFO:0x%lx,RKMODULE_GET_CHANNEL_INFO:0x%lx", cmd, RKMODULE_GET_MODULE_INFO,RKMODULE_GET_CHANNEL_INFO);
            break;
    }

    TRACE_IOCTL("=END= Sensor_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ret: %ld", 
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        ret
        );

    if (0 != ret && -ENOIOCTLCMD != ret)
    {
        DBG_ERROR("client: %s (%d), cmd: 0x%x,ENOIOCTLCMD: 0x%x ret: %ld", current->comm, current->pid, cmd, ENOIOCTLCMD, ret);
    }

    return ret;
}

static int sensor_write_tdc_delay_setting(struct sensor * sensor)
{
    int ret = 0;
    u16 reg;
    u8 tdc_delay_major = sensor->tdc_delay_major;
    u8 tdc_delay_minor = sensor->tdc_delay_minor;

    if (0x0 == tdc_delay_major || 0x1F < tdc_delay_major)
    {
        tdc_delay_major = TDC_DELAY_H_DEFAULT;
    }

    if (0x0 == tdc_delay_minor || 0xF < tdc_delay_minor)
    {
        tdc_delay_minor = TDC_DELAY_L_DEFAULT;
    }

    reg = 0xc3;
    ret = mcu_write_dtof_reg(sensor, reg, tdc_delay_major);
    if (ret < 0) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = 0xc4;
    ret = mcu_write_dtof_reg(sensor, reg, tdc_delay_minor);
    if (ret < 0) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    return ret;
}

static int sensor_waiting_4_state(struct sensor *sensor, u8 wait_state)
{
    int ret;
    ktime_t start;
    s64 us_delta;
    u8 val8 = 0;
    int polled_times = 0;

    start = ktime_get();
    do {
        ret = mcu_read_dtof_reg(sensor, SENSOR_REG_SYSC_FSM, &val8);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (ret < 0) {
            DBG_INFO("Fail to read status register of the sensor, ret: %d.\n", ret);
        }
        else {
            if (wait_state == (val8 & 0xF))
            {
                ret = 0;
                DBG_INFO("Sensor state %d is ready now, polled_times: %d, waited %lld us.\n", wait_state, polled_times, us_delta);
                break;
            }
            else {
                DBG_NOTICE("Sensor is still in %d state now, polled_times: %d, waited %lld us.\n", (val8 & 0xF), polled_times, us_delta);
            }
        }

        if (SENSOR_FSM_WAIT_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to sensor to %d state, already waited %lld us.\n", wait_state, us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(1000, 1200);
        polled_times++;
    } while (1);

    return ret;
}

static int sensor_start_stream(struct sensor * sensor)
{
    int ret;
    u8 wait_state;
    u32 wait_timeout_us;

    // restore the initial values before start a new streaming...
#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    sensor->min_fsync_gap = 500000; // set a enough big (> the min value of all work mode) value as initially, so that it must be re-assgined value.
    sensor->max_fsync_gap = 0;
    sensor->fsync_times = 0;
    sensor->last_fsync_time = 0;
#endif

    if (false == sensor->load_script && false == sensor->sensor_cfg_done)
    {
        ret = sensor_config(sensor, __LINE__);
        if (ret < 0) {
            DBG_ERROR("Fail to sensor_config\n");
            return ret;
        }
    }

    /* In case these controls are set before streaming */
    mutex_unlock(&sensor->sensor_mutex);
    ret = v4l2_ctrl_handler_setup(&sensor->ctrl_handler);
    mutex_lock(&sensor->sensor_mutex);
    if (ret) {
        DBG_ERROR("fail to v4l2_ctrl_handler_setup");
        return ret;
    }

    if (true == sensor->load_script)
    {
        // for script load mode, need sensor initialize firstly for spot module, 
        if (NULL != sensor->loaded_sensor_reg_setting && 0 != sensor->loaded_sensor_reg_setting_cnt)
        {
            ret = mcu_set_sensor_config_stage(sensor, DTOF_CONFIG_STAGE_LOADED_SCRIPT);
            if (ret < 0) {
                DBG_ERROR("could not set sensor_config_stage\n");
            }

            ret = mcu_write_dtof_reg_array(sensor, (const struct setting_r16vd *) sensor->loaded_sensor_reg_setting, __LINE__);
            if (ret < 0) {
                DBG_ERROR("fail to write sensor setting registers\n");
                return ret;
            }
        }
        else {
            DBG_ERROR("Invalid loaded_sensor_reg_setting, %p, %d", sensor->loaded_sensor_reg_setting, sensor->loaded_sensor_reg_setting_cnt);
            return -EINVAL;
        }

    }

    if (ADAPS_PCM_MODE != sensor->cur_wkmode)
    {
        ret = mcu_send_roisram_data_to_mcu(sensor);
        if (ret < 0) {
            DBG_ERROR("fail to mcu_send_roisram_data_to_mcu\n");
            return ret;
        }

        ret = mcu_let_mcu_write_initial_roisram_data(sensor);
        if (ret < 0) {
            DBG_ERROR("fail to mcu_let_mcu_write_initial_roisram_data\n");
            return ret;
        }

        ret = mcu_set_stream_state(sensor, true);
        if (ret < 0) {
            DBG_ERROR("fail to mcu_set_stream_state(true)\n");
            return ret;
        }
    }

    ret = mcu_set_sensor_config_stage(sensor, DTOF_CONFIG_STAGE_STREAMING_ON);
    if (ret < 0) {
        DBG_ERROR("could not set sensor_config_stage\n");
    }

    delay_ns(MODULE_SENSOR_REG_UPDATE_WAIT_MS * 1000000);

    wait_state = TRUE;
    wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;
    ret = mcu_waiting_4_state(sensor, STATUS_REG_DTOF_STREAM_ON_READY, wait_state, wait_state, wait_timeout_us, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
        return ret;
    }

    // It is suggested we write ROI sram before stream-on, so I already ignore the stream-on register in script, I'm compensating it here.
    switch (sensor->reset_mipi_4_streamon)
    {
        case STREAM_ON_WITH_MIPI_IP_RESET_FIRST:
            ret = mcu_write_dtof_reg_array(sensor, stream_on_with_mipi_reset_first, __LINE__);
            break;

        case STREAM_ON_FIRST_AND_THEN_RESET_MIPI_IP:
            ret = mcu_write_dtof_reg_array(sensor, stream_on_first_and_then_reset_mipi, __LINE__);
            break;

        default:
            ret = mcu_write_dtof_reg_array(sensor, sensor_streamon_regs, __LINE__);
            break;
    }
    if (ret < 0) {
        DBG_ERROR("fail to write stream on registers\n");
        return ret;
    }

    if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
        int rc;
        char *temp_buf;

        temp_buf = kzalloc(PAGE_SIZE, GFP_KERNEL);

        if (!temp_buf) {
            return -ENOMEM;
        }

        rc = calc_frequency(sensor, temp_buf, PAGE_SIZE);
        if (rc >= 0)
        {
            printk_multilines(temp_buf, rc);
        }
        kfree(temp_buf);

        mcu_reg_dump(sensor, MCU_CSD_REG_BASE, MCU_BASIC_REG_SIZE, __func__, __LINE__, false);
        mcu_reg_dump(sensor, MCU_DTOF_REG_BASE, MCU_DTOF_REG_SIZE, __func__, __LINE__, false);
    }

    //sensor_vop_adjust_per_temperature(sensor, true); // get the temperature and set the first vop voltage as soon after stream-on, since the inside temperature may be high already (may worked a long time before now).

    return ret;
}

static int sensor_stop_stream(struct sensor * sensor)
{
    int ret;

    ret = mcu_set_sensor_config_stage(sensor, DTOF_CONFIG_STAGE_STREAMING_OFF);
    if (ret < 0) {
        DBG_ERROR("could not set sensor_config_stage\n");
    }

    ret = mcu_write_dtof_reg_array(sensor, sensor_streamoff_regs, __LINE__);
    if (ret < 0) {
        DBG_ERROR("fail to write stream off registers\n");
    }

    ret = sensor_waiting_4_state(sensor, SENSOR_FSM_IDLE_STATE);
    if (ret < 0) {
        DBG_ERROR("fail to wait for IDLE state.\n");
    }

    return ret;
}

static int sensor_s_stream(struct v4l2_subdev * sd, int enable)
{
    struct sensor * sensor = to_sensor(sd);
    int ret = 0;
    const char * const wkmode_names[] = {
            [ADAPS_PTM_PHR_MODE] = "PHR-Mode",
            [ADAPS_PCM_MODE] = "PCM-Mode",
            [ADAPS_PTM_FHR_MODE] = "FHR-Mode",
    };

    DBG_NOTICE("---dbg_ctrl: 0x%x, enable:%d, streaming: %d, load_script: %d, roi_sram_rolling: %d, wkmode:%d (%s), mtype:%d, etype:%d, power mode:%d, frtype:%d, vcsel mode:%d, v_zone_cnt:%d, linkFreq:%d, drv_version: %s---", 
        sensor->dbg_ctrl, 
        enable,
        sensor->streaming,
        sensor->load_script,
        sensor->roi_sram_rolling,
        sensor->cur_wkmode,
        wkmode_names[sensor->cur_wkmode],
        sensor->cur_mtype,
        sensor->cur_etype,
        sensor->cur_pmode,
        sensor->cur_frtype,
        sensor->cur_vmode,
        sensor->cur_v_zone_cnt,
        SENSOR_LINK_FREQ,
        FULL_VERSION_STRING
        );
    mutex_lock(&sensor->sensor_mutex);
    enable = !!enable;
    if (enable == sensor->streaming)
        goto unlock_and_return;

    if (enable) {
        mcu_set_vop_adjust_policy(sensor, VOP_PER_TEMPERATURE);
        mcu_set_vop_adjust_interval(sensor, sensor->vop_adjust_interval);
        mcu_set_fsync_param(sensor, DEFAULT_FSYNC_SRC, DEFAULT_FSYNC_PULSE_WIDTH, sensor->slave_fps_config);
        mcu_set_roisram_parameters(sensor, sensor->max_calib_sram_data_group_cnt, sensor->roi_sram_rolling);

        ret = sensor_start_stream(sensor);
        if (ret) {
            DBG_ERROR("start stream failed ret:%d\n", ret);
            goto unlock_and_return;
        }

        sensor->stream_start = ktime_get();
    } else {
        sensor->stream_start = 0;
        sensor_stop_stream(sensor);
        mcu_set_vop_adjust_policy(sensor, VOP_OFF);
        mcu_set_stream_state(sensor, false);
    }

    sensor->streaming = enable;

unlock_and_return:
    mutex_unlock(&sensor->sensor_mutex);

    return ret;
}

static int sensor_set_power_on(struct sensor *sensor, u32 powerOnReason, int callline)
{
    int ret = 0;
    u8 wait_state;

    if (POWER_REASON_LINUX_DRIVER_PROBE == powerOnReason) // only first time
    {
        if (!IS_ERR(sensor->mcu_reset_gpio))
        {
            gpiod_set_value_cansleep(sensor->mcu_reset_gpio, SENSOR_RESET_ENABLED);
        }

        if (!IS_ERR(sensor->iovcc_en_gpio)) {
            gpiod_set_value_cansleep(sensor->iovcc_en_gpio, FUNCTION_ENABLE);
        }

        if (!IS_ERR(sensor->avcc_en_gpio)) {
            gpiod_set_value_cansleep(sensor->avcc_en_gpio, FUNCTION_ENABLE);
        }
    }

    // if power on is for reading calib eeprom, then we don't power on the drv VCC, since it is not necessary and we just want to save some time for faster reading.
    if (POWER_REASON_WRITE_CALIB_EEPROM != powerOnReason && POWER_REASON_READ_CALIB_EEPROM != powerOnReason) {
        if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
            gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_ENABLE);
        }
    }

    usleep_range(500, 1000);

    if (POWER_REASON_LINUX_DRIVER_PROBE == powerOnReason) // only first time
    {
        if (!IS_ERR(sensor->mcu_reset_gpio)) {
            gpiod_set_value_cansleep(sensor->mcu_reset_gpio, SENSOR_RESET_DISABLED);
        }

        usleep_range(500, 1000);
    }

    ret = mcu_ready_check(sensor);
    if (ret < 0) {
        DBG_ERROR("Fail to wait to mcu ready, ret: %d\n", ret);
        return ret;
    }

    mcu_read_fixed_settings(sensor);
    mcu_read_runtime_full_status(sensor);

    if (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type)
    {
        // pvdd voltage
        // for this kind of module, always use OUTDOOR PVDD voltage!
        mcu_set_pvdd_voltage(sensor, PVDD_VOLTAGE_4_OUTDOOR_MODE, __LINE__);
    
        mcu_set_vop_adjust_policy(sensor, VOP_INITIAL_VOLTAGE);

        ret = mcu_write_self_reg(sensor, CTRL_REG_MODULE_POWER_CTRL, true);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", CTRL_REG_MODULE_POWER_CTRL, ret);
            return ret;
        }

        delay_ns(MODULE_POWER_ON_WAIT_MS * 1000000);

        wait_state = MOD_POWER_ON;
        ret = mcu_waiting_4_state(sensor, STATUS_REG_MODULE_POWER_STATE, wait_state, wait_state, MCU_STATUS_WAIT_TIMEOUT_US, __LINE__);
        if (ret < 0) {
            DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
            return ret;
        }

        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_SKIP_SENSOR_READY_CHECK))
        {
            ret = sensor_ready_check(sensor);
            if (ret < 0) {
                DBG_ERROR("Fail to wait to sensor ready, ret: %d\n", ret);
                return ret;
            }
            else {
                sensor->power_on = true;

                if ((sensor->probe_success) && (false == sensor->static_data_ready) && (powerOnReason > POWER_REASON_LINUX_DRIVER_PROBE)) // if fail to read module_static_data at probe(), try to re-read it once more
                {
                    ret = sensor_read_module_static_data(sensor);
                    if (ret < 0) {
                        DBG_ERROR( "Fail to read module static data, ret: %d.", ret);
                        ret = 0; // since EEPROM has no data, so I let ret = 0 now; @2026/5/14
                    }
                }
            }
        }
        else 
        {
            sensor->power_on = true;
        }
    }
    else {
        sensor->power_on = true;
    }

    sensor->power_on_times++;

    TRACE_POWER_CTRL("<%s> is called from %d, ret: %d\n", __func__, callline, ret);

    return ret;
}

static int sensor_set_power_off(struct sensor *sensor, u32 powerOnReason, int callline)
{
    if (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type)
    {
        int ret = 0;
        u8 wait_state;

        ret = mcu_write_self_reg(sensor, CTRL_REG_MODULE_POWER_CTRL, false);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", CTRL_REG_MODULE_POWER_CTRL, ret);
            return ret;
        }

        wait_state = MOD_POWER_OFF;
        ret = mcu_waiting_4_state(sensor, STATUS_REG_MODULE_POWER_STATE, wait_state, wait_state, MCU_STATUS_WAIT_TIMEOUT_US, __LINE__);
        if (ret < 0) {
            DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%d", wait_state, ret);
            return ret;
        }
    }

    if (POWER_REASON_WRITE_CALIB_EEPROM != powerOnReason && POWER_REASON_READ_CALIB_EEPROM != powerOnReason) {
        if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
            gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_DISABLE);
        }
    }

    TRACE_POWER_CTRL("<%s> is called from %d\n", __func__, callline);
    sensor->power_on = false;

    return 0;
}

static int sensor_s_power(struct v4l2_subdev * sd, int on)
{
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;

    mutex_lock(&sensor->sensor_mutex);

    TRACE_POWER_CTRL("--on: %d, power_on:%d, from process <%s> %d...", 
        on, sensor->power_on,
        current->comm, current->pid);

    /* If the power state is not modified - no work to do. */
    if (sensor->power_on == !!on)
        goto unlock_and_return;

    if (strcmp(current->comm, "v4l_id") == 0) // this is special for rockchip SoC Linux platform
    {
        // Ignore the real power on/off for v4l_id's requests.
        //
        // during the system startup, /usr/lib/udev/v4l_id will try to identify the v4l device, this driver does not need real power on, only return 0 should be enough,
        goto unlock_and_return;
    }

    if (on) {
#if defined(PM_RUNTIME_ENABLE)
        ret = pm_runtime_get_sync(sensor->dev);
        TRACE_PM_RUNTIME("------TRACE_PM_RUNTIME--<%s> Line:%d--power_on:%d, ret: %d---", __FUNCTION__, __LINE__, sensor->power_on, ret);
        if (ret < 0) {
            DBG_ERROR("Fail to pm_runtime_get_sync, ret:%d\n", ret);
            pm_runtime_put_noidle(sensor->dev);
            goto unlock_and_return;
        }
#else
        ret = sensor_set_power_on(sensor, POWER_REASON_V4L2_S_POWER_CB, __LINE__);
        if (ret < 0) {
            DBG_ERROR("Fail to sensor_set_power_on(), ret: %d\n", ret);
            goto unlock_and_return;
        }
#endif


        sensor->test_pattern_enabled = false;

#if defined(DUMP_POWERON_REGISTER_ENABLE)
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            sensor_reg_dump(sensor, false, __func__, __LINE__);
        }
#endif

    } else {
        // when power off, clear all loaded data (user must re-load it next time if need).
        sensor->roi_sram_rolling = false;
        // clear all possible loaded data for loaded_sensor_reg_setting, loaded_vcsel_reg_setting, loaded_roi_sram
        memset(sensor->loaded_sensor_reg_setting, 0, REG_SETTING_BUF_MAX_SIZE_PER_SEG*2 + (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP * MAX_CALIB_SRAM_ROLLING_GROUP_CNT));
        sensor->loaded_roi_sram_size = 0;
        sensor->loaded_sensor_reg_setting_cnt = 0;
        sensor->loaded_vcsel_reg_setting_cnt = 0;

#if defined(PM_RUNTIME_ENABLE)
        pm_runtime_put_sync(sensor->dev);
#else
        sensor_set_power_off(sensor, POWER_REASON_V4L2_S_POWER_CB, __LINE__);
 #endif
        sensor->sensor_cfg_done = false;
    }

unlock_and_return:
    mutex_unlock(&sensor->sensor_mutex);

    return ret;
}

static int sensor_close(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh)
{
    u32 closing_from_client = CURRENT_CLIENT;
    struct sensor *sensor = to_sensor(sd);

    mutex_lock(&sensor->sensor_mutex);

    TRACE_V4L2_CB("---- S_CLOSE  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );
    //dump_stack();

    if (CLIENT_TO_PID(sensor->client_id_4_sensor) != CLIENT_TO_PID(closing_from_client))
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: opened id: (%d:%d), closing id: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_sensor), CLIENT_TO_TID(sensor->client_id_4_sensor),
            CLIENT_TO_PID(closing_from_client), CLIENT_TO_TID(closing_from_client)
            );
    }

    sensor->client_id_4_sensor = 0;
    sensor->client_task_4_sensor = NULL;
    mutex_unlock(&sensor->sensor_mutex);

    return 0;
}

static int sensor_open(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh)
{
    int             ret = 0;
    struct sensor *sensor = to_sensor(sd);
    u32 opening_from_client = CURRENT_CLIENT;

    mutex_lock(&sensor->sensor_mutex);

    TRACE_V4L2_CB("---- S_OPEN  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
    if (0 != sensor->client_id_4_sensor)
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: Sensor was opened already\nOpened client: (%d:%d), re-opening client: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_sensor), CLIENT_TO_TID(sensor->client_id_4_sensor),
            CLIENT_TO_PID(opening_from_client), CLIENT_TO_TID(opening_from_client)
            );
        ret = -EIO;
        goto unlock_and_return;
    }
#endif

    sensor->client_id_4_sensor = opening_from_client;
    sensor->client_task_4_sensor = current;

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
unlock_and_return:
#endif

    mutex_unlock(&sensor->sensor_mutex);

    return ret;
}

static int sensor_enum_frame_interval(struct v4l2_subdev *sd, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    struct v4l2_subdev_state *sd_state,
#else
    struct v4l2_subdev_pad_config *cfg,
#endif
    struct v4l2_subdev_frame_interval_enum *fie)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, fie->index:%d, fie->code: 0x%x, SENSOR_MEDIA_BUS_FMT: 0x%x", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        fie->index, fie->code, SENSOR_MEDIA_BUS_FMT);

    if (fie->index >= ARRAY_SIZE(sensor_wkmode))
        return - EINVAL;

#if 0 // on Rockchip Linux 6.1, if not disable this, some error will happen, the reason is unknown now.
    /*
        [ 4591.622397] rkcif-mipi-lvds3: stream[0] start streaming
        [ 4591.622417] rkcif rkcif-mipi-lvds3: rkcif_alloc_buffer failed ret:-22
        [ 4591.622426] rkcif-mipi-lvds3: Failed to allocate the memory for dummy buffer, size 0
        [ 4591.622430] rkcif-mipi-lvds3: Failed to create dummy_buf, -12
    */
    if (fie->code != SENSOR_MEDIA_BUS_FMT)
        return - EINVAL;
#endif

    DBG_INFO("fie->index:%d", fie->index);
    fie->width          = sensor_wkmode[fie->index].width;
    fie->height         = sensor_wkmode[fie->index].height;
    fie->interval       = sensor_wkmode[fie->index].max_fps;

    return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
static int sensor_g_mbus_config(struct v4l2_subdev *sd, unsigned int pad_id, 
    struct v4l2_mbus_config *config)
{
    struct sensor *sensor = to_sensor(sd);
    u32 val = 0;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, pad_id:%d", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        pad_id);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    val                 = 1 << (sensor->mipi_data_lanes - 1);
    config->type        = V4L2_MBUS_CSI2_DPHY;
    config->bus.mipi_csi2.num_data_lanes = sensor->mipi_data_lanes;
    config->bus.mipi_csi2.flags       = val;
#else
    val                 = 1 << (sensor->mipi_data_lanes - 1) | V4L2_MBUS_CSI2_CHANNEL_0 | V4L2_MBUS_CSI2_CONTINUOUS_CLOCK;
    config->type        = V4L2_MBUS_CSI2_DPHY;
    config->flags       = val;
#endif

    return 0;
}
#endif

static const struct v4l2_subdev_internal_ops sensor_internal_ops =
{
    .open = sensor_open, 
    .close = sensor_close,
};

static const struct v4l2_subdev_core_ops sensor_core_ops =
{
    .s_power            = sensor_s_power, 
    .ioctl              = sensor_ioctl, 
};


static const struct v4l2_subdev_video_ops sensor_video_ops =
{
    .s_stream           = sensor_s_stream, 
#if LINUX_VERSION_CODE <= KERNEL_VERSION(6,7,0)
    .g_frame_interval   = sensor_g_frame_interval, 
#endif
};


/**
 * struct v4l2_subdev_pad_ops - v4l2-subdev pad level operations
 *
 * @enum_mbus_code: callback for VIDIOC_SUBDEV_ENUM_MBUS_CODE() ioctl handler
 *          code.
 * @enum_frame_size: callback for VIDIOC_SUBDEV_ENUM_FRAME_SIZE() ioctl handler
 *           code.
 *
 * @enum_frame_interval: callback for VIDIOC_SUBDEV_ENUM_FRAME_INTERVAL() ioctl
 *           handler code.
 *
 * @get_fmt: callback for VIDIOC_SUBDEV_G_FMT() ioctl handler code.
 *
 * @set_fmt: callback for VIDIOC_SUBDEV_S_FMT() ioctl handler code.
 *
 * @get_mbus_config: get the media bus configuration of a remote sub-device.
 *           The media bus configuration is usually retrieved from the
 *           firmware interface at sub-device probe time, immediately
 *           applied to the hardware and eventually adjusted by the
 *           driver. Remote sub-devices (usually video receivers) shall
 *           use this operation to query the transmitting end bus
 *           configuration in order to adjust their own one accordingly.
 *           Callers should make sure they get the most up-to-date as
 *           possible configuration from the remote end, likely calling
 *           this operation as close as possible to stream on time. The
 *           operation shall fail if the pad index it has been called on
 *           is not valid or in case of unrecoverable failures. The
 *           config argument has been memset to 0 just before calling
 *           the op.
 */
static const struct v4l2_subdev_pad_ops sensor_pad_ops =
{
    .enum_mbus_code     = sensor_enum_mbus_code, 
    .enum_frame_size    = sensor_enum_frame_sizes, 
    .enum_frame_interval = sensor_enum_frame_interval, 
    .get_fmt            = sensor_get_fmt, 
    .set_fmt            = sensor_set_fmt, 
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,10,0)
    .get_mbus_config    = sensor_g_mbus_config,
#endif
};


static const struct v4l2_subdev_ops sensor_subdev_ops =
{
    .core               = &sensor_core_ops, 
    .video              = &sensor_video_ops, 
    .pad                = &sensor_pad_ops, 
};


static int sensor_set_ctrl(struct v4l2_ctrl * ctrl)
{
    int ret = 0;
#if defined(ENABLE_V4L2_CID_EXPOSURE)
    u8 reg, val;
#endif
    struct sensor *sensor = container_of(ctrl->handler, struct sensor, ctrl_handler);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, ctrl->id: 0x%x, ctrl->val: %d, V4L2_CID_EXPOSURE: 0x%x",
        current->comm, current->tgid, current->pid,
        smp_processor_id(),
        ctrl->id, ctrl->val, V4L2_CID_EXPOSURE);

#if defined(PM_RUNTIME_ENABLE)
    /*
     * Applying V4L2 control value only happens
     * when power is up for streaming
     */
    if (!pm_runtime_get_if_in_use(sensor->dev))
    {
        DBG_ERROR("Not power up yet!!!\n");
        return 0;
    }
#endif

    switch (ctrl->id)
    {
        case V4L2_CID_EXPOSURE:
#if defined(ENABLE_V4L2_CID_EXPOSURE)
            val = ctrl->val & 0xFF;
            if (ADAPS_PCM_MODE == sensor->cur_wkmode)
            {
                reg = 0xC2;
            }
            else {
                reg = 0xC0;
            }
            DBG_NOTICE("---dbg_ctrl: 0x%02x, power_on:%d, streaming: %d, wkmode:%d, mtype:%d, etype:%d, power mode:%d, ctrl->val:0x%x, reg:0x%x, val:0x%x---", 
                sensor->dbg_ctrl, 
                sensor->power_on,
                sensor->streaming,
                sensor->cur_wkmode, 
                sensor->cur_mtype,
                sensor->cur_etype,
                sensor->cur_pmode,
                ctrl->val,
                reg,
                val
                );
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
#endif
            break;

        default:
            DBG_INFO("%s Unhandled id:0x%x, val:0x%x\n", 
                __func__, ctrl->id, ctrl->val);
            break;
    }

#if defined(PM_RUNTIME_ENABLE)
    pm_runtime_put(sensor->dev);
#endif

    return ret;
}


static const struct v4l2_ctrl_ops sensor_ctrl_ops =
{
    .s_ctrl = sensor_set_ctrl, 
};

static int sensor_initialize_controls(struct sensor * sensor)
{
    const struct sensor_mode *mode;
    struct v4l2_ctrl_handler *handler;
    int             ret;
    s64 pixel_rate;

    handler             = &sensor->ctrl_handler;
    mode                = sensor->cur_sensor_mode;
    ret                 = v4l2_ctrl_handler_init(handler, 8);

    if (ret)
        return ret;

    handler->lock       = &sensor->sensor_mutex;

    sensor->ctrl_linkfreqency = v4l2_ctrl_new_int_menu(handler, &sensor_ctrl_ops, V4L2_CID_LINK_FREQ,
        0, 0, sensor_link_freq_items);

    pixel_rate = to_pixel_rate(sensor->mipi_data_lanes);
    sensor->ctrl_pixelrate = v4l2_ctrl_new_std(handler, &sensor_ctrl_ops, V4L2_CID_PIXEL_RATE,
        0, pixel_rate, 1, pixel_rate);

#if defined(ENABLE_V4L2_CID_EXPOSURE)
    sensor->ctrl_exposure    = v4l2_ctrl_new_std(handler, &sensor_ctrl_ops,
        V4L2_CID_EXPOSURE, SENSOR_EXPOSURE_MIN,
        SENSOR_EXPOSURE_MAX, SENSOR_EXPOSURE_STEP, mode->exp_def);
#endif

    if (handler->error) {
        ret = handler->error;
        DBG_ERROR("Failed to init controls(%d)\n", ret);
        goto err_free_handler;
    }

    sensor->subdev.ctrl_handler = handler;

    return 0;

err_free_handler:
    v4l2_ctrl_handler_free(handler);

    return ret;
}

static int sensor_get_i2c_bus_frequency(struct sensor *sensor)
{
    int ret;
    struct platform_device *pdev_4_i2c_bus;

    pdev_4_i2c_bus = to_platform_device(sensor->mcu_i2c_client->adapter->dev.parent);
    if (pdev_4_i2c_bus == NULL) {
        DBG_ERROR("pdev_4_i2c_bus is NULL...");
        return -EIO;
    }

    ret = device_property_read_u32(&pdev_4_i2c_bus->dev, "clock-frequency", &sensor->i2c_bus_freq_hz);
    return ret;
}

static void get_sensor_role(struct sensor *sensor, char *buf)
{
    int ret;

    if (0 == sensor->stream_start)
    {
        sprintf(buf, "%s", "NA");
    }
    else {
        u8 val = 0;

        ret = mcu_read_dtof_reg(sensor, 0x00A4, &val);
        if (ret < 0)
        {
            sprintf(buf, "%s", "NA");
        }
        else {
            if (1 == (val & 0x01))
            {
                sprintf(buf, "%s", "Master");
            }
            else {
                sprintf(buf, "%s", "Slave");
            }
        }
    }

    return ;
}

static void get_module_type(struct sensor *sensor, u32 *ret_type)
{
    *ret_type = SWIFT_MODULE_TYPE;

    return ;
}

static ssize_t register_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    ktime_t start;
    s64 us_delta1, us_delta2;

    start = ktime_get();
    mcu_reg_dump(sensor, MCU_CSD_REG_BASE, MCU_BASIC_REG_SIZE, __func__, __LINE__, true);
    us_delta1 = ktime_us_delta(ktime_get(), start);
    if (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type)
    {
        mcu_reg_dump(sensor, MCU_DTOF_REG_BASE, MCU_DTOF_REG_SIZE, __func__, __LINE__, true);
        us_delta2 = ktime_us_delta(ktime_get(), start);
    }
    DBG_NOTICE("dump_mcu_reg costs %lld us, dump_dToF_reg costs %lld us.\n", us_delta1, us_delta2);

    return 0;
}

static ssize_t register_store(struct device * dev,
                struct device_attribute * attr,
                const char * buf,
                size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    u8  val;
    u32 reg;
    int ret;
    u16 length = 0;
    uint8_t *rx_buffer = NULL;

    ret = sscanf(buf, "write %06x %02hhx", &reg, &val);
    if (ret == 2) {
        if (0 != (reg & 0xFF000000))
        {
            printk2console("Invalid register address: 0x%x\n", reg);
            return -EINVAL;
        }

        ret = mcu_write_reg_raw(sensor, (reg >> 16) & 0xFF, reg & 0xFFFF, val);
        printk2console("Write reg[0x%06x] to 0x%02x, ret: %d...", reg, val, ret);

        return count;
    }

    ret = sscanf(buf, "read %06x", &reg);
    if (ret == 1) {
        if (0 != (reg & 0xFF000000))
        {
            printk2console("Invalid register address: 0x%x\n", reg);
            return -EINVAL;
        }

        ret = mcu_read_reg_raw(sensor, (reg >> 16) & 0xFF, reg & 0xFFFF, &val);
        printk2console("read reg[0x%06x]=0x%02x, ret:%d\n", reg, val, ret);
        return count;
    }

    ret = sscanf(buf, "burst_read %02x %hd", &reg, &length);
    if (ret == 2) {
        if (reg > DT_REG_END || reg < DT_REG_EEPROM_DATA_TRANSFER)
        {
            printk2console("Invalid register address: 0x%x for burst read\n", reg);
            return -EINVAL;
        }

        if (length > 128)
        {
            printk2console("too long: %d for burst read\n", length);
            return -EINVAL;
        }

        rx_buffer = kmalloc(length, GFP_KERNEL);
        if (!rx_buffer)
        {
            DBG_ERROR("Fail to kmalloc memory.\n");
            return -ENOMEM;
        }

        ret = mcu_burst_read_reg(sensor, reg, rx_buffer, length);
        if(ret < 0){
            DBG_ERROR("mcu_burst_read_reg failed. ret: %d, to_read_len: %d\n", ret, length);
            if (rx_buffer)
            {
                kfree(rx_buffer);
            }
            return ret;
        }
        hex8_dump(rx_buffer, length, "burst_read_data", true);
        if (rx_buffer)
        {
            kfree(rx_buffer);
        }

        return count;
    }
    else {
        return -EINVAL;
    }
}

static DEVICE_ATTR_RW(register);

static void generate_stream_duration(struct sensor *sensor, char *buf)
{
    if (0 == sensor->stream_start)
    {
        buf[0] = '\0';
    }
    else {
        s64 us_delta = ktime_us_delta(ktime_get(), sensor->stream_start);
        u32 stream_seconds = us_delta / 1000000;

        sprintf(buf, " (%d:%02d:%02d)", stream_seconds/3600, (stream_seconds % 3600)/60, stream_seconds % 60);
    }

    return ;
}

static char * get_kernel_buildtime(void)
{
    static char *p = COMPILE_DATE;

    return p;
}

static ssize_t info_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE,
        "%s\n"
        "Version:                       %s\n"
        "Matched Compatible string:     %s\n"
        "Last Build Time:               %s\n"
        "I2C Bus Num:                   %d\n"
        "I2C bus configured frequency:  %d Hz\n"
        "I2C address for ads6401:       0x%x\n"
        "Current TTY:                   %s\n"
        "tdc_delay_major:               0x%x\n"
        "tdc_delay_minor:               0x%x\n\n",

        DRIVER_NAME,
        FULL_VERSION_STRING,
        sensor->matched_dev_id->compatible,
        get_kernel_buildtime(),
        client->adapter->nr,
        sensor->i2c_bus_freq_hz,
        client->addr,
        get_current_tty()->name,
        sensor->tdc_delay_major,
        sensor->tdc_delay_minor
        );
}
static DEVICE_ATTR_RO(info);

static int calc_freq_hz(ktime_t evt_start, ktime_t evt_end, int evt_times)
{
    s64 us_delta;
    int times_per_second = 0;

    us_delta = ktime_us_delta(evt_end, evt_start);
    times_per_second = (evt_times) / (us_delta / 1000000);

    return times_per_second;
}


static ssize_t status_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    u32 eeprom_roisram_size = 0;
    u32 module_type;
    char stream_duration[32];
    char sensor_role[16];
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    char *reset_mipi_4_streamon_names[] =
    {
        "No reset",
        "Before",
        "After",
    };

    char *gpio_level_names[] =
    {
        "Low",
        "High",
    };

    char *framerate_type_names[] =
    {
        "Uninitialized",
        "15",
        "25",
        "30",
        "60",
    };

    eeprom_roisram_size = sensor->eeprom_data->real_spot_zone_count * PER_CALIB_SRAM_ZONE_SIZE;

    generate_stream_duration(sensor, stream_duration);
    get_sensor_role(sensor, sensor_role);
    get_module_type(sensor, &module_type);
    mcu_read_runtime_full_status(sensor);

    return scnprintf(buf, PAGE_SIZE, 
        "probe success:                 %s\n"
        "static_data_ready:             %s\n"
        "eeprom_crc_matched:            %s\n"
        "dbg_ctrl:                      0x%x\n\n"

        "Sensor OTP read:               %s\n"
        "Sensor OTP blank:              %s\n"
        "Sensor Chip id:                0x%x\n"
        "Sensor Role:                   %s\n"
        "Ads6401 module type:           %X\n"
        "mcu_reset_gpio raw level:      %s\n"

        "Module Firmware type:          %s (0x%x)\n"
        "Module Firmware version:       %d.%d.%d (0x%x)\n"
        "Module Chip id:                0x%x\n"
        "Module Error Status:           0x%x\n"
        "Module Warning Status:         0x%x\n"
        "Module FSM:                    0x%x\n"
        "max_transfer_size_per_burst:   %d\n"
        "Module roisram_rolling:        %s\n"
        "roisram_data_group_cnt:        %d\n"
        "cur_roisram_group_idx:         %d\n\n"

        "Module Power_on:               %s\n"
        "current temperature:           %d.%02d degree\n"
        "current expected Vop:          -%d.%02d V\n"
        "vop conversion algo version:   V%d\n"
        "current force_pvdd_voltage:    %d.%03d V\n"
        "current expected pvdd voltage: %d.%02d V\n\n"

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        "frame_sync_irq:                %d\n"
#endif
        "frame_sync_times:              %d (%d Hz)\n"
        "frame_sync_gap:                (%lld -- %lld) us\n"

        "Power_on:                      %s (%d)\n"
        "Load_script:                   %s\n"
        "Streaming:                     %s%s\n"
        "test_pattern_output_enabled:   %s\n"
        "Curr workmode:                 %s\n"
        "Curr measurement type:         %s\n"
        "Curr enviroment type:          %s\n"
        "Curr power mode:               %s\n"
        "Curr image-frame-rate setting: %s fps (Master mode)\n"
        "anchor_x:                      %d\n"
        "anchor_y:                      %d\n"
        "rowSearchingRange:             %d\n"
        "colSearchingRange:             %d\n"
        "mipi data lanes:               %d\n"
        "roi_sram_rolling:              %s\n"
        "loaded_roi_sram_size:          %d\n"
        "eeprom_roi_sram_size:          %d\n"
        "Reset MIPI mode for stream_on: %s\n\n"

        "Communication statistics:\n"
        "mcu_err_irq_times:     %d\n"
        "read fail times:       %d\n"
        "write fail times:      %d\n"
        "checksum fail times:   %d\n\n",

        false == sensor->probe_success ? "No" : "Yes",
        false == sensor->static_data_ready ? "No" : "Yes",
        false == sensor->eeprom_data_crc_matched ? "No" : "Yes",
        sensor->dbg_ctrl,

        false == sensor->otp_read ? "No" : "Yes",
        false == sensor->otp_blank ? "No" : "Yes",
        sensor->sensor_chipid,
        sensor_role,
        module_type,
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->mcu_reset_gpio)],

        MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type ? "bootloader" : (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type ? "Application" : "Unknown"),
        sensor->mcu_fw_type,
        sensor->mcu_fw_version.field.version_major,
        sensor->mcu_fw_version.field.version_minor,
        sensor->mcu_fw_version.field.version_revision,
        sensor->mcu_fw_version.fw_version,
        sensor->mcu_chipid,
        sensor->mcu_error_status,
        sensor->mcu_warning_status,
        sensor->mcu_fsm,
        sensor->max_transfer_size_per_burst,
        false == sensor->mcu_roisram_rolling ? "No" : "Yes",
        sensor->mcu_roisram_data_group_cnt,
        sensor->mcu_cur_roisram_group_index,

        false == sensor->mcu_power_on ? "No" : "Yes",
        sensor->mcu_cur_temperature_x100 / 100,
        sensor->mcu_cur_temperature_x100 % 100,
        sensor->mcu_cur_vop_abs_x100 / 100,
        sensor->mcu_cur_vop_abs_x100 % 100,
        sensor->mcu_vop_algo_version,
        sensor->force_pvdd_voltage / 1000,
        sensor->force_pvdd_voltage % 1000,
        sensor->mcu_cur_pvdd_x100 / 100,
        sensor->mcu_cur_pvdd_x100 % 100,

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        sensor->fsync_irq,
#endif
        sensor->fsync_times,
        calc_freq_hz(sensor->first_fsync_time, sensor->last_fsync_time, sensor->fsync_times),
        sensor->min_fsync_gap, sensor->max_fsync_gap,

        false == sensor->power_on ? "No" : "Yes",
        sensor->power_on_times,
        false == sensor->load_script ? "No" : "Yes",
        false == sensor->streaming ? "No" : "Yes",
        stream_duration,
        false == sensor->test_pattern_enabled ? "No" : "Yes",
        work_mode_name[sensor->cur_wkmode],
        measurement_range_name[sensor->cur_mtype],
        environment_type_name[sensor->cur_etype],
        power_mode_names[sensor->cur_pmode],
        framerate_type_names[sensor->cur_frtype],
        sensor->anchor_x,
        sensor->anchor_y,
        sensor->rowSearchingRange,
        sensor->colSearchingRange,
        sensor->mipi_data_lanes,
        false == sensor->roi_sram_rolling ? "No" : "Yes",
        sensor->loaded_roi_sram_size,
        eeprom_roisram_size,
        reset_mipi_4_streamon_names[sensor->reset_mipi_4_streamon],
        sensor->mcu_err_irq_times, sensor->read_fail_times, sensor->write_fail_times, sensor->chksum_fail_times
        );
}
static DEVICE_ATTR_RO(status);

static ssize_t config_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    // do some build options valid check here
#if ADS6401_MODULE_BIG_FOV_FLOOD_SMART != SWIFT_MODULE_TYPE
    #error "Ads6401s.c only support BigFoV Smart module (ADS6401_MODULE_BIG_FOV_FLOOD_SMART)."
#endif

#if MIPI_SPEED > MIPISPEED_200M_BPS && defined(ENABLE_SYS_CLK_125M)
    #error "ENABLE_SYS_CLK_125M only is available for mipi speed <= 200M bps."
#endif

#if PCM_VCSEL_LASER_PERIOD > 127
    #error "PCM_VCSEL_LASER_PERIOD should <= 127 ns."
#endif

#if PTM_VCSEL_LASER_PERIOD > 127
    #error "PTM_VCSEL_LASER_PERIOD should <= 127 ns."
#endif

    return scnprintf(buf, PAGE_SIZE, 
        "Build switch options:\n"
        "---------------------------------------------------------\n"
        "MINI_DEMO_BOX:                                     %s\n"
        "ADS6401_MODULE_TYPE:                               %s\n"
        "ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401:          %s\n"
        "ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401:     %s\n"
        "ENABLE_MCU_ERROR_IRQ:                              %s\n"
        "ENABLE_MCU_FIRMWARE_UPGRADE:                       %s\n"

        "CALIB_DATA_READY_IN_EEPROM_CHIP:                   %s\n"
        "CALIB_DATA_FROM_EEPROM_BIN_FILE:                   %s\n"
        "ENABLE_DEEP_MLP_WALKERROR:                         %s\n"
        "IGNORE_PROBE_FAILURE:                              %s\n"
        "ENABLE_SYSFREQ_ADJUST_4_LOW_POWER:                 %s\n"
        "ENABLE_RUNTIME_REGISTER_UPDATE:                    %s\n"
        "ENABLE_SYS_CLK_125M:                               %s\n"
        "USE_DIV1_FOR_1G_MIPISPEED:                         %s\n"

        "PM_RUNTIME_ENABLE:                                 %s\n"
        "ENABLE_UP_TO_80_SUBFRAMES_ROIROLLING_4_SWIFT:      %s\n"
        "MAX_CALIB_SRAM_ROLLING_GROUP_CNT:                  %d\n"
        "NON_CONTINUOUS_MIPI_CLK:                           %s\n"
        "MIPI_DATA_LANE_COUNT:                              %d\n"
        "MIPI_SPEED:                                        %d Mbps\n"
        "SOC_MIPI_RX_CLOCK_FREQ:                            %d MHz\n"
        "EEPROM_CHIP_CAPACITY:                              %d bytes\n"
        "ADAPS_DBG_ONCE:                                    0x%x\n\n",

#if defined(MINI_DEMO_BOX)
        "Yes",
#else
        "No",
#endif

        ADS6401_MODULE_TYPE_NAME,

#if defined(ENABLE_MCU_OUTPUT_FSYNC_TO_SLAVE_ADS6401)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_EXTERNAL_FSYNC_SIGNAL_TO_SLAVE_ADS6401)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_MCU_ERROR_IRQ)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_MCU_FIRMWARE_UPGRADE)
        "Yes",
#else
        "No",
#endif

#if defined(CALIB_DATA_READY_IN_EEPROM_CHIP)
        "Yes",
#else
        "No",
#endif

#if defined(CALIB_DATA_FROM_EEPROM_BIN_FILE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_DEEP_MLP_WALKERROR)
        "Yes",
#else
        "No",
#endif

#if defined(IGNORE_PROBE_FAILURE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_RUNTIME_REGISTER_UPDATE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SYS_CLK_125M)
        "Yes",
#else
        "No",
#endif

#if defined(USE_DIV1_FOR_1G_MIPISPEED)
        "Yes",
#else
        "No",
#endif

#if defined(PM_RUNTIME_ENABLE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_UP_TO_80_SUBFRAMES_ROIROLLING_4_SWIFT)
        "Yes",
#else
        "No",
#endif

        MAX_CALIB_SRAM_ROLLING_GROUP_CNT,

#if defined(NON_CONTINUOUS_MIPI_CLK)
        "Yes",
#else
        "No",
#endif

        SENSOR_DATA_LANE_COUNT,
        MIPI_SPEED,
        SOC_MIPI_RX_CLOCK_FREQ,
        EEPROM_REAL_CAPACITY_SIZE,
        ADAPS_DBG_ONCE
        );
}
static DEVICE_ATTR_RO(config);

static ssize_t i2c_address_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, 
        "I2C address for smart module:        0x%x\n",
        sensor->mcu_i2c_client->addr
        );
}

// if we are not sure which i2c address (0x4a,0x5e,...) is right, we can change the i2c address to some values to try to dump the sensor register;
// echo 0x5e > i2c_address
static ssize_t i2c_address_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    u8 val;
    int ret;

    ret = kstrtou8(buf, 0, &val);
    if (ret)
        return ret;

    if (val > 0x00 && val < 0x80)
    {
        client->addr = val;
    }
    else {
        return -EINVAL;
    }

    return count;
}

static DEVICE_ATTR_RW(i2c_address);

static int calc_frequency(struct sensor *sensor, char *out_buf, int max_length)
{
    #define X10     10
    u16 reg;
    uint32_t data;
    int rc = 0;
    u8 val8 = 0;
    u8 xclk = SENSOR_XVCLK_FREQ_M;

    uint32_t syspll_Fvco = 0;
    uint32_t mipipll_Fvco = 0;
    uint32_t syspll_clk = 0;    // mclk, mesh clock
    uint32_t mipi_clk_X10 = 0; // Linux kernel doesn't support float type, so X 10 here.
    char mipi_clk_string[16];
    uint32_t mipi_TxEscClk = 0;
    uint32_t mipi_speed_per_lane = 0;
    uint32_t sys_clk = 0;
    uint32_t tdc_clk = 0;

    u8 sysclk_div_m = 0;
    u8 sysclk_div_n = 0;
    u8 syspll_id = 0;       // input divider
    u8 syspll_od = 0;       // output divider
    u8 syspll_fb = 0;       // feedback divider
    u8 syspll_ld = 0;       // laser divider

    u16 mipipll_div_ns = 0;
    u8 mipipll_div_ms = 0;
    u8 mipipll_div_ps = 0;
    u8 mipi_dphy_tx_frange_cfg = 0;
    u8 mipi_dphy_tx_freq_range = 0;
    u8 mipi_tx_delay_cfg = 0;

    if (false == sensor->power_on)
    {
        printk2console("System frequency can't be caculated without power on.");
        return -EPERM;
    }

    reg = 0xA9;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    mipi_tx_delay_cfg = val8;

    reg = 0xA5;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    sysclk_div_n = (val8 & 0x0F);
    sysclk_div_m = ((val8 >> 4) & 0x0F);

    reg = 0xD4;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    syspll_id = ((val8 >> 4) & 0x07);
    syspll_od = (1 << ((val8 & 0x03) + 1));

    reg = 0xD5;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    syspll_fb = val8;

    reg = 0xD6;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    syspll_ld = (1 << (val8 & 0x03));

    reg = 0xE6;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    mipipll_div_ns = ((val8 << 8) & 0x100);
    reg = 0xE7;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    mipipll_div_ns |= val8;

    reg = 0xE9;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    mipipll_div_ps = (val8 & 0x1F);
    mipipll_div_ms = ((val8 >> 5) & 0x07);

    reg = 0x81;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    mipi_dphy_tx_frange_cfg = ((val8 >> 3) & 0x4);
    DBG_INFO("data: 0x%x, val8: 0x%x, mipi_dphy_tx_frange_cfg: 0x%x", data, val8, mipi_dphy_tx_frange_cfg);
    reg = 0x7E;
    rc = mcu_read_dtof_reg(sensor, reg, &val8);
    val8 = (val8 >> 2) & 0x3;
    mipi_dphy_tx_frange_cfg |= val8;
    DBG_INFO("data: 0x%x, val8: 0x%x, mipi_dphy_tx_frange_cfg: 0x%x", data, val8, mipi_dphy_tx_frange_cfg);

    mipi_dphy_tx_freq_range = 6 * (1 << mipi_dphy_tx_frange_cfg);

    if (0 == syspll_id)
    {
        DBG_ERROR("syspll_id can not be 0.");
        return -EINVAL;
    }

    if (0 == mipipll_div_ms)
    {
        DBG_ERROR("mipipll_div_ms can not be 0.");
        return -EINVAL;
    }

    if (0 == mipipll_div_ps)
    {
        DBG_ERROR("mipipll_div_ps can not be 0.");
        return -EINVAL;
    }

    syspll_Fvco = (xclk * syspll_fb) / syspll_id;
    tdc_clk = syspll_Fvco * 8;
    syspll_clk = syspll_Fvco / syspll_od;
    mipi_TxEscClk = syspll_clk / 15;
    if (0 == sysclk_div_m || 0 == sysclk_div_n)
    {
        sys_clk = syspll_clk;
    }
    else {
        sys_clk = (syspll_clk * sysclk_div_m) / sysclk_div_n;
    }

    mipipll_Fvco = (xclk * mipipll_div_ns) / mipipll_div_ms;
    mipi_clk_X10 = mipipll_Fvco * X10 / (mipipll_div_ps * 8);
    mipi_speed_per_lane = mipi_clk_X10 * 8 / X10;

    if (0 != (mipi_clk_X10 % X10))
    {
        sprintf(mipi_clk_string, "%d.%d", mipi_clk_X10 / 10, mipi_clk_X10 % 10);
    }
    else {
        sprintf(mipi_clk_string, "%d", mipi_clk_X10 / 10);
    }

    rc = scnprintf(out_buf, max_length,
        "System frequency list:\n"
        "FORCE_MIPI_TX_DELAY:           0x%02x\n"

        "sysclk_div_m:                  %d\n"
        "sysclk_div_n:                  %d\n"
        "syspll_id:                     %d\n"
        "syspll_od:                     %d\n"
        "syspll_fb:                     %d\n"
        "syspll_ld:                     %d\n"
        "mipi_tx_delay_cfg:             %d\n"
        "mipi_dphy_tx_pll_frange_config:%d\n"
        "mipipll_div_ns:                %d\n"
        "mipipll_div_ms:                %d\n"
        "mipipll_div_ps:                %d\n\n"

        "xclk:                          %d MHz\n"
        "syspll_Fvco (1G - 2G Hz):      %d MHz\n"
        "syspll_clk:                    %d MHz\n"
        "sys_clk (>= 3*XCLK):           %d MHz\n"
        "tdc_clk:                       %d MHz\n\n"

        "mipipll_Fvco (1G - 2G Hz):     %d MHz\n"
        "mipi_clk:                      %s MHz\n"
        "mipi_dphy_tx_pll_freq_range:   %d ~ %d MHz\n"
        "mipi_TxEscClk:                 %d MHz\n"
        "mipi_frame_end_delay:          %d us\n"
        "mipi_packet_delay:             %d us\n"
        "mipi_speed (per_lane):         %d Mbps\n"
        "SOC_MIPI_RX_CLOCK_FREQ:        %d MHz\n\n",

        sensor->force_mipi_tx_delay,

        sysclk_div_m,
        sysclk_div_n,
        syspll_id,
        syspll_od,
        syspll_fb,
        syspll_ld,
        mipi_tx_delay_cfg,
        mipi_dphy_tx_frange_cfg,
        mipipll_div_ns,
        mipipll_div_ms,
        mipipll_div_ps,

        xclk,
        syspll_Fvco,
        syspll_clk,
        sys_clk,
        tdc_clk,

        mipipll_Fvco,
        mipi_clk_string,
        mipi_dphy_tx_freq_range, mipi_dphy_tx_freq_range*2,
        mipi_TxEscClk,
        4 * (1 << ((mipi_tx_delay_cfg >> 6) & 0x3)),
        mipi_tx_delay_cfg & 0x3F,
        mipi_speed_per_lane,
        SOC_MIPI_RX_CLOCK_FREQ
        );

    return rc;
}

static ssize_t frequency_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int rc = 0;

    rc = calc_frequency(sensor, buf, PAGE_SIZE);

    if (0 > rc)
    {
        return -EINVAL;
    }

    return rc;
}
static DEVICE_ATTR_RO(frequency);

static ssize_t manual_powerctl_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;
    char cmd[20];

    ret = sscanf(buf, "%s", cmd);
    if (ret == 1) {
        if (3 == count) {
            ret = memcmp(cmd,"On",3);
            if (0 == ret)
            {
                ret = sensor_set_power_on(sensor, POWER_REASON_MANUAL, __LINE__);
                printk2console("manual power on %s, ret: %d\n", 0 == ret ? "successfully" : "failure", ret);
                ret = 0; // avoid "write error: Operation not permitted"
            }
            else {
                printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
                return -EINVAL;
            }
        }
        else if (4 == count) {
            ret = memcmp(cmd,"Off",3);
            if (0 == ret)
            {
                //u32 bk_dbg_ctrl = sensor->dbg_ctrl;
                //sensor->dbg_ctrl = ADAPS_DBG_DISABLE_VCSEL_DRIVER;
                sensor_set_power_off(sensor, POWER_REASON_MANUAL, __LINE__);
                //sensor->dbg_ctrl = bk_dbg_ctrl;
                printk2console("manual power off successfully");
                ret = 0; // avoid "write error: Operation not permitted"
            }
            else {
                printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
                return -EINVAL;
            }
        }
    }
    else {
        printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
        return -EINVAL;
    }

    return ret ? -1 : count;
}

static DEVICE_ATTR_WO(manual_powerctl);

static ssize_t vop_adjust_interval_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "%d ms\n", sensor->vop_adjust_interval);
}

static ssize_t vop_adjust_interval_store(struct device *dev,
                 struct device_attribute *attr,
                 const char *buf, size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    unsigned long val;
    int err;

    err = kstrtoul(buf, 0, &val);
    if (err)
        return -err;

    sensor->vop_adjust_interval = val;

    return count;
}
static DEVICE_ATTR_RW(vop_adjust_interval);

static ssize_t mcu_comm_extra_delay_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "mcu_comm_extra_delay: %d us\n\n", sensor->mcu_comm_extra_delay);
}

static ssize_t mcu_comm_extra_delay_store(struct device * dev,
                                    struct device_attribute * attr,
                                    const char * buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    unsigned long val;
    int ret;

    ret = kstrtoul(buf, 0, &val);
    if (ret)
        return ret;

    sensor->mcu_comm_extra_delay = (u32) val;

    return count;
}

static DEVICE_ATTR_RW(mcu_comm_extra_delay);

static ssize_t dbg_ctrl_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "dbg_ctrl: 0x%x\n", sensor->dbg_ctrl);
}

static ssize_t dbg_ctrl_store(struct device * dev,
                struct device_attribute * attr,
                const char * buf,
                size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    int val;
    int ret;

    ret = kstrtoint(buf, 0, &val);
    if (ret)
        return ret;

    sensor->dbg_ctrl = val;

    return count;
}

static DEVICE_ATTR_RW(dbg_ctrl);


static struct attribute *dev_drv_attrs[] = {
    &dev_attr_dbg_ctrl.attr,
    &dev_attr_register.attr,
    &dev_attr_info.attr,
    &dev_attr_status.attr,
    &dev_attr_config.attr,
    &dev_attr_i2c_address.attr,
    &dev_attr_frequency.attr,
    &dev_attr_vop_adjust_interval.attr,
    &dev_attr_manual_powerctl.attr,
    &dev_attr_mcu_comm_extra_delay.attr,


    NULL,
};

static const struct attribute_group dev_drv_attrs_group = {
    .attrs = dev_drv_attrs,
};

static int cam_sensor_register_attrib_group(struct sensor *sensor, struct device *dev)
{
    int ret = 0;
    ret = sysfs_create_group(&dev->kobj, &dev_drv_attrs_group);

    sensor->link_kobj = kobject_create_and_add(VENDOR_NAME, kernel_kobj);
    if (!sensor->link_kobj) {
        DBG_ERROR("create kobj failed\n");
        return -EIO;
    }

    // create a symbolic link with a fixed path /sys/kernel/adaps/ads6401
    ret = sysfs_create_link(sensor->link_kobj, &dev->kobj, SENSOR_NAME);
    if (ret) {
        DBG_ERROR("Failed to create sysfs link: %d\n", ret);
        kobject_put(sensor->link_kobj);
        return ret;
    }

    return 0;
}

static int cam_sensor_adaps_dbg_set(void *data, u64 val)
{
    struct sensor *sensor = (struct sensor *)data;

    //DBG_INFO(CAM_SENSOR, "val:0x%x, adaps_debug:0x%x, streaming:%d...\r\n",val,sensor->dbg_ctrl, sensor->streaming);

    //when ADAPS_DBG_ONCE bit is set, we can dump some data for specified registers.
    if (val > ADAPS_DBG_ONCE)
    {
        // CMD: adb root
        // CMD: adb remount
        // CMD: adb shell "echo 0x90 > /sys/kernel/debug/adaps/dbg_ctrl"

        // only when stream ON state, the followng dump is available
        if (sensor->streaming) {
            if (val & ADAPS_DBG_DUMP_REGS) {
                mcu_reg_dump(sensor, MCU_CSD_REG_BASE, MCU_BASIC_REG_SIZE, __func__, __LINE__, true);
                mcu_reg_dump(sensor, MCU_DTOF_REG_BASE, MCU_DTOF_REG_SIZE, __func__, __LINE__, true);
            }
            // CMD: adb shell "echo 0xC0 > /sys/kernel/debug/adaps/dbg_ctrl"
            else if (val & ADAPS_DBG_DUMP_SRAM_REG) {
                // todo
            }
        }
        return 0;
    }

    sensor->dbg_ctrl = (val & 0xffffffff);

    return 0;
}

static int cam_sensor_adaps_dbg_get(void *data, u64 *val)
{
    struct sensor *sensor = (struct sensor *)data;

    *val = sensor->dbg_ctrl;

    return 0;
}

DEFINE_SIMPLE_ATTRIBUTE(cam_sensor_adaps_dbg_control,
    cam_sensor_adaps_dbg_get, cam_sensor_adaps_dbg_set, "0x%0llx\n\n");

static irqreturn_t sensor_fsync_irq(int irq, void *privateData)
{
    struct sensor *sensor = (struct sensor *)privateData;
    ktime_t fsync_irq_time;
    s64 us_delta;
    unsigned long flags;

    spin_lock_irqsave(&sensor->fsync_spinlock, flags);
    fsync_irq_time = ktime_get();
    sensor->fsync_times++;

    if (true != sensor->probe_success)
    {
        goto exit_irq;
    }

    if (1 == sensor->fsync_times)
    {
        sensor->first_fsync_time = ktime_get();
    }
    else {
        us_delta = ktime_us_delta(ktime_get(), sensor->last_fsync_time);
        if (0 != sensor->last_fsync_time)
        {
            if (us_delta > sensor->max_fsync_gap) sensor->max_fsync_gap = us_delta;
            if (us_delta < sensor->min_fsync_gap) sensor->min_fsync_gap = us_delta;
        }
    }

    sensor->last_fsync_time = fsync_irq_time;

exit_irq:
    spin_unlock_irqrestore(&sensor->fsync_spinlock, flags);

    return IRQ_HANDLED;
}

#if defined(ENABLE_MCU_ERROR_IRQ)
static irqreturn_t sensor_mcu_error_irq(int irq, void *privateData)
{
    struct sensor *sensor = (struct sensor *)privateData;

    if (NULL == sensor)
        return IRQ_NONE;

    if (true != sensor->probe_success)
        return IRQ_HANDLED;

    sensor->mcu_err_irq_times++;
    return IRQ_HANDLED;
}
#endif

static int sensor_get_vop_algo_version(struct sensor *sensor)
{
    #define OTP_TEMPERATURE_HIGH_4_V3               7000
    #define V2_LOT_ID_CNT_4_V2                      2
    #define OTP_LOT_ID_LENGTH                       6
    int i;
    int ret = 0;
    const u8 vop_v2_productId[V2_LOT_ID_CNT_4_V2][OTP_LOT_ID_LENGTH] = {
        {0x50, 0x50, 0x54, 0x32, 0x34, 0x32},     // PPT242
        {0x50, 0x54, 0x32, 0x31, 0x33, 0x31}      // PT2131
    };

    sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_1;    // set to V1 by default

    if (OTP_TEMPERATURE_HIGH_4_V3 == sensor->otp_T_high)
    {
        sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_3;
    }
    else {
        for (i = 0; i < V2_LOT_ID_CNT_4_V2; i++)
        {
            if (0 == memcmp(vop_v2_productId[i], sensor->otp_product_id, OTP_LOT_ID_LENGTH))
            {
                sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_2;
                break;
            }
        }
    }

    return ret;
}

static int sensor_read_otp_data(struct sensor *sensor)
{
    #define OTP_PRODUCT_ID_OFFSET            0x0C
    uint16_t i;
    int ret = 0;
    u16 reg;
    u8 val8;

    if (sensor->otp_read) // already read otp data before.
        return 0;

    reg = STATUS_REG_DTOF_OTP_DATA_READY;
    ret = mcu_read_self_reg(sensor, reg, &val8);
    if (ret < 0) {
        DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%d", reg, ret);
        return ret;
    }

    if (1 != val8) {
        DBG_ERROR("It seems otp data is not ready yet on MCU side!");
        return -EIO;
    }

    reg = DT_REG_OTP_DATA_TRANSFER;
    ret = mcu_burst_read_reg(sensor, reg, (u8 *) sensor->otp_raw_data, SENSOR_OTP_DATA_SIZE * sizeof(u16));
    if(ret < 0){
        DBG_ERROR("mcu_burst_read_reg 0x%x failed. ret: %d\n", reg, ret);
        return ret;
    }

    sensor->otp_blank = true;  // Assume that the OTP has not programmed any data yet, firstly.
    for (i = 0; i < SENSOR_OTP_DATA_SIZE; i++)
    {
        if (0 != sensor->otp_raw_data[i])
        {
            sensor->otp_blank = false;
        }
    }

    sensor->otp_read = true;
    if (sensor->otp_blank)
    {
        DBG_ERROR("All otp data seems NOT BE SAVED YET on this test chip!\n");
        return ret;
    }
    else {
        sensor->otp_T_low = OTP_TEMPERATURE_LOW;

        sensor->otp_adc_vref = sensor->otp_raw_data[0x05];

        sensor->otp_vbe25 = sensor->otp_raw_data[0x0A];

        sensor->otp_vbd_low = sensor->otp_raw_data[0x0B];
        DBG_INFO("sensor->otp_vbd_low: %d\n", sensor->otp_vbd_low);

        sensor->otp_vbd_high = sensor->otp_raw_data[0x1B];

        sensor->otp_T_high = (sensor->otp_raw_data[0x1C] & 0xFF) * 100;  // X 100 to keep same unit as current temperature.

        sensor->otp_K_high = (sensor->otp_raw_data[0x1D] & 0xFF);
        sensor->otp_K_low = ((sensor->otp_raw_data[0x1D] >> 8) & 0xFF);

        for (i = 0; i < SWIFT_PRODUCT_ID_SIZE / 2; i++) {
            sensor->otp_product_id[i * 2] = (sensor->otp_raw_data[OTP_PRODUCT_ID_OFFSET + i] >> 8) & 0xFF;
            sensor->otp_product_id[i * 2 + 1] = sensor->otp_raw_data[OTP_PRODUCT_ID_OFFSET + i]  & 0xFF;
        }
        sensor_get_vop_algo_version(sensor);
    }

    return ret;
}

static int sensor_read_module_static_data(struct sensor *sensor)
{
    int ret = 0;
    u8 *p_tdcDelay=NULL;

    ret = sensor_read_otp_data(sensor);
    if (ret < 0) {
        DBG_ERROR( "Fail to sensor_read_otp_data, ret: %d.", ret);
        return ret;
    }

    sensor->static_data_ready = false;

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_SKIP_EEPROM_DATA_READ))
    {
        DBG_INFO("eeprom_data_size=%d", sensor->eeprom_data_size);

#if !defined(CALIB_DATA_READY_IN_EEPROM_CHIP) && defined(CALIB_DATA_FROM_EEPROM_BIN_FILE)
        ret = eeprom_read_from_file(sensor, 0, sensor->eeprom_data_size, (char *) sensor->eeprom_data);
        if (ret < 0) {
            DBG_ERROR( "Fail to eeprom_read_from_file, ret: %d.", ret);
            return ret;
        }
        sensor->static_data_ready = true;
#else
        ret = eeprom_data_read(sensor, 0, sensor->eeprom_data_size, (u8 *) sensor->eeprom_data);
        if (ret < 0) {
            DBG_ERROR( "Fail to read eeprom data, ret: %d.", ret);
            return ret;
        }
        sensor->static_data_ready = true;

        if (ret < 0)
        {
            sensor->eeprom_data_crc_matched = false;
            create_blob_file_4_eeprom_data(sensor, sensor->dbgfs_dentry_4_root, (u8 *) sensor->eeprom_data, sensor->eeprom_data_size, "ads6401_eeprom_data_crc_mismatched");
        }
        else {
            sensor->eeprom_data_crc_matched = true;
            create_blob_file_4_eeprom_data(sensor, sensor->dbgfs_dentry_4_root, (u8 *) sensor->eeprom_data, sensor->eeprom_data_size, "ads6401_eeprom_data");
        }
#endif
    }

    p_tdcDelay = (uint8_t *) sensor->eeprom_data->tdcDelay;
    sensor->tdc_delay_major = *p_tdcDelay;
    p_tdcDelay += sizeof(uint8_t);
    sensor->tdc_delay_minor = *p_tdcDelay;

    return ret;
}

static int sensor_get_module_static_data(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_module_static_data temp;
    void __user *uarg = (void __user *)arg;

    if (NULL == sensor->eeprom_data)
    {
        DBG_ERROR("eeprom data is not available yet!");
        return -EFAULT;
    }

    memset(&temp, 0, sizeof(temp));
    get_module_type(sensor, &temp.module_type);
    temp.eeprom_capacity = sensor->eeprom_capacity;
    temp.otp_vbe25 = sensor->otp_vbe25;
    temp.otp_vbd = sensor->otp_vbd_low;
    temp.otp_adc_vref = sensor->otp_adc_vref;
    memcpy(temp.chip_product_id, sensor->otp_product_id, SWIFT_PRODUCT_ID_SIZE);
    sprintf(temp.sensor_drv_version, "%d.%d.%d", VERSION_MAJOR, VERSION_MINOR, VERSION_REVISION);
    temp.ready = sensor->static_data_ready;
    temp.eeprom_crc_matched = sensor->eeprom_data_crc_matched;

    if (copy_to_user((struct adaps_dtof_module_static_data *)uarg, &temp, sizeof(struct adaps_dtof_module_static_data)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_get_dtof_runtime_status_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_runtime_status_param temp;
    void __user *uarg = (void __user *)arg;

    mcu_read_runtime_simple_status(sensor);
    temp.test_pattern_enabled = sensor->test_pattern_enabled;
    temp.inside_temperature_x100 = sensor->mcu_cur_temperature_x100;
    temp.expected_vop_abs_x100 = sensor->mcu_cur_vop_abs_x100;
    temp.expected_pvdd_x100 = sensor->mcu_cur_pvdd_x100;
    if (sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE)
    {
        DBG_NOTICE("***temperature_x100: %u, expected_vop_abs_x100: %d, pvdd_x100: %d***",
            sensor->mcu_cur_temperature_x100, sensor->mcu_cur_vop_abs_x100, sensor->mcu_cur_pvdd_x100);
    }


    if (copy_to_user((struct adaps_dtof_runtime_status_param *)uarg, &temp, sizeof(struct adaps_dtof_runtime_status_param)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_get_exposure_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_exposure_param temp;
    void __user *uarg = (void __user *)arg;

    temp.exposure_period = sensor->cur_laser_exposure_period & 0x7F;    // the value of reg[0xBC], but need mask bit7, which is exposure enable bit.
    temp.ptm_coarse_exposure_value = sensor->cur_coarse_exposure_val;   // the value of reg[0xBF]
    temp.ptm_fine_exposure_value = sensor->cur_fine_exposure_val;       // the value of reg[0xC0]
    temp.pcm_gray_exposure_value = sensor->cur_gray_exposure_val;       // the value of reg[0xC2]

    if (copy_to_user((struct adaps_dtof_exposure_param *)uarg, &temp, sizeof(struct adaps_dtof_exposure_param)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_set_dtof_intial_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    void __user *uarg = (void __user *)arg;
    struct adaps_dtof_intial_param temp;
    struct adaps_dtof_intial_param *param;
    u32 eeprom_roisram_size = 0;

    if (copy_from_user(&temp, (struct adaps_dtof_intial_param *)uarg, sizeof(struct adaps_dtof_intial_param)))
    {
        ret = -EFAULT;
        return ret;
    }

    param = &temp;

    if (param->env_type < AdapsEnvTypeIndoor || param->env_type > AdapsEnvTypeOutdoor)
    {
        DBG_ERROR("Invalid env_type=%d",
            param->env_type);
        return -EINVAL;
    }

    if (param->measure_type < AdapsMeasurementTypeNormal || param->measure_type > AdapsMeasurementTypeFull)
    {
        DBG_ERROR("Invalid measure_type=%d",
            param->measure_type);
        return -EINVAL;
    }

    if (param->framerate_type < AdapsFramerateType15FPS || param->framerate_type > AdapsFramerateType60FPS)
    {
        DBG_ERROR("Invalid framerate_type=%d",
            param->framerate_type);
        return -EINVAL;
    }

    if (param->vcselzonecount_type < AdapsVcselZoneCount1 || param->vcselzonecount_type > AdapsVcselZoneCount4)
    {
        DBG_ERROR("Invalid vcselzonecount_type=%d",
            param->vcselzonecount_type);
        return -EINVAL;
    }

    if (param->power_mode < AdapsPowerModeNormal || param->power_mode > AdapsPowerModeDiv3)
    {
        DBG_ERROR("Invalid power_mode=%d",
            param->power_mode);
        return -EINVAL;
    }

    DBG_NOTICE("roi_sram_rolling: %d, env_type=%d, measure_type=%d, framerate_type=%d, grayExposure:%d, fineExposure:%d, coarseExposure: %d",
        param->roi_sram_rolling, param->env_type,param->measure_type,param->framerate_type, param->grayExposure, param->fineExposure, param->coarseExposure);
    sensor->cur_etype = param->env_type;
    sensor->cur_mtype = param->measure_type;
    sensor->cur_frtype = param->framerate_type;
    sensor->cur_v_zone_cnt = param->vcselzonecount_type;
    sensor->cur_pmode = param->power_mode;
    sensor->anchor_x = param->colOffset;
    sensor->anchor_y = param->rowOffset;
    sensor->rowSearchingRange = param->rowSearchingRange;
    sensor->colSearchingRange = param->colSearchingRange;

    sensor->coarseExposureCfg = param->coarseExposure;
    sensor->fineExposureCfg = param->fineExposure;
    sensor->grayExposureCfg = param->grayExposure;
    sensor->laserExposurePeriodCfg = param->laserExposurePeriod;

    sensor->roi_sram_rolling = param->roi_sram_rolling;
    if (sensor->roi_sram_rolling)
    {
        eeprom_roisram_size = sensor->eeprom_data->real_spot_zone_count * PER_CALIB_SRAM_ZONE_SIZE;
        if (0 == sensor->loaded_roi_sram_size) // if loaded roisram, use loaded roisram firstly
        {
            sensor->max_calib_sram_data_group_cnt = eeprom_roisram_size / PER_ROISRAM_GROUP_SIZE;
        }
    }

    return 0;
}

static int loaded_script_valid_check(struct sensor *sensor, external_config_script_param_t *cfg_script_param)
{
    int i;
    u16 addr;
    u8 value;
    u8 req_work_mode = ADAPS_MODE_MAX;
    const struct setting_r16vd *pRegList = NULL;

    if (0 == cfg_script_param->sensor_reg_setting_cnt)
    {
        DBG_ERROR("sensor_reg_setting_cnt can not be 0");
        return -EINVAL;
    }

    if (0 == cfg_script_param->vcsel_reg_setting_cnt)
    {
        DBG_ERROR("vcsel_reg_setting_cnt can not be 0");
        return -EINVAL;
    }

    req_work_mode = cfg_script_param->work_mode;
    pRegList = (const struct setting_r16vd *) sensor->loaded_sensor_reg_setting;

    for (i = 0; i < cfg_script_param->sensor_reg_setting_cnt; i++) {
        addr = pRegList[i].reg;
        value = pRegList[i].val;

        switch (addr)
        {
            case 0xB6:
                if (ADAPS_PCM_MODE == req_work_mode)
                {
                    if (0 == (value & BIT(0))) // for PCM mode, the bit0 should be 1
                    {
                        DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                        return -EINVAL;
                    }
                }
                else {
                    if (0 != (value & BIT(0))) // for non-PCM mode, the bit0 should be 0
                    {
                        DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                        return -EINVAL;
                    }

                    if (ADAPS_PTM_PHR_MODE == req_work_mode)
                    {
                        if (0 != (value & BIT(5))) // for PHR mode, the bit5 should be 0
                        {
                            DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                            return -EINVAL;
                        }
                    }
                    else {
                        if (0 == (value & BIT(5))) // for FHR mode, the bit5 should be 1
                        {
                            DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                            return -EINVAL;
                        }
                    }
                }
                break;


            default:
                break;
        }
    }

    return 0;
}

static int misc_device_open(struct inode *inode, struct file *file)
{
    int ret = 0;
    struct mm_struct *mm = current->mm;
    u32 opening_from_client = CURRENT_CLIENT;
    struct miscdevice *miscdev = file->private_data;

    struct sensor *sensor = container_of(miscdev, struct sensor, misc_device);
    file->private_data = sensor;

    MUTEX_LOCK(&sensor->misc_mutex);

    if (NULL == sensor->mmap_buffer_base)
    {
        DBG_ERROR("Null pointer for mmap_buffer_base, need alloc buffer firstly.");
        ret = -ENODATA;
        goto unlock_and_return;
    }

    TRACE_IOCTL("---- M_OPEN  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
    if (0 != sensor->client_id_4_misc)
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: Misc device was opened already\nOpened client: (%d:%d), re-opening client: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_misc), CLIENT_TO_TID(sensor->client_id_4_misc),
            CLIENT_TO_PID(opening_from_client), CLIENT_TO_TID(opening_from_client)
            );
        ret = -EIO;
        goto unlock_and_return;
    }
#endif

    sensor->client_id_4_misc = opening_from_client;
    sensor->client_task_4_misc = current;

    DBG_INFO("sensor->mmap_buffer_base: %p, 0x%lx", sensor->mmap_buffer_base, (unsigned long)sensor->mmap_buffer_base);
    DBG_INFO("client: %s (%d)", current->comm, current->pid);
    DBG_INFO("code  section: [0x%lx   0x%lx]", mm->start_code, mm->end_code);
    DBG_INFO("data  section: [0x%lx   0x%lx]", mm->start_data, mm->end_data);
    DBG_INFO("brk   section: s: 0x%lx, c: 0x%lx", mm->start_brk, mm->brk);
    DBG_INFO("mmap  section: s: 0x%lx", mm->mmap_base);
    DBG_INFO("stack section: s: 0x%lx", mm->start_stack);
    DBG_INFO("arg   section: [0x%lx   0x%lx]", mm->arg_start, mm->arg_end);
    DBG_INFO("env   section: [0x%lx   0x%lx]\n", mm->env_start, mm->env_end);

    // restore the default values
    sensor->load_script = false;
    sensor->loaded_roi_sram_size = 0;

unlock_and_return:
    MUTEX_UNLOCK(&sensor->misc_mutex);

    return ret;
}

static int misc_device_release(struct inode *inode, struct file *file)
{
    u32 closing_from_client = CURRENT_CLIENT;
    struct sensor *sensor = (struct sensor *) file->private_data;

    if (NULL != sensor)
    {
        MUTEX_LOCK(&sensor->misc_mutex);

        TRACE_IOCTL("---- M_RELEASE  from %s (%d:%d) on CPU %d",
            current->comm, current->tgid, current->pid,
            smp_processor_id()
            );

        if (CLIENT_TO_PID(sensor->client_id_4_misc) != CLIENT_TO_PID(closing_from_client))
        {
            DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: opened id: (%d:%d), closing id: (%d:%d)",
                CLIENT_TO_PID(sensor->client_id_4_misc), CLIENT_TO_TID(sensor->client_id_4_misc),
                CLIENT_TO_PID(closing_from_client), CLIENT_TO_TID(closing_from_client)
                );
        }

        sensor->client_id_4_misc = 0;
        sensor->client_task_4_misc = NULL;
        file->private_data = NULL;

        MUTEX_UNLOCK(&sensor->misc_mutex);
    }

    return 0;
}

static int misc_device_mmap(struct file *file, struct vm_area_struct *vma)
{
    unsigned long offset;
    unsigned long pfn_start;
    unsigned long virt_start;
    unsigned long size;
    int ret = 0;
    struct sensor *sensor;

    if (NULL == vma || NULL == file->private_data)
    {
        DBG_ERROR("Null pointer, vma: %p, file->private_data: %p", vma, file->private_data);
        return -EINVAL;
    }

    sensor = (struct sensor *) file->private_data;

    MUTEX_LOCK(&sensor->misc_mutex);

    if (NULL == sensor->mmap_buffer_base)
    {
        DBG_ERROR("Null pointer for mmap_buffer_base, need alloc buffer firstly.");
        ret = -ENODATA;
        goto unlock_and_return;
    }

    if (0 == sensor->mmap_buffer_max_size)
    {
        DBG_ERROR("Uninitilized mmap buffer max size.");
        ret = -EINVAL;
        goto unlock_and_return;
    }

    size = vma->vm_end - vma->vm_start;
    offset = vma->vm_pgoff << PAGE_SHIFT;
    pfn_start = (virt_to_phys(sensor->mmap_buffer_base) >> PAGE_SHIFT) + vma->vm_pgoff;
    virt_start = (unsigned long)sensor->mmap_buffer_base + offset;

    DBG_INFO("phy: 0x%lx, offset: 0x%lx, size: 0x%lx, vm_flags: 0x%lx, vm_page_prot: 0x%llx\n",
        pfn_start << PAGE_SHIFT, offset, size, vma->vm_flags, vma->vm_page_prot.pgprot);

    if (!(vma->vm_flags & (VM_WRITE | VM_READ)))
    //if (vma->vm_flags & VM_WRITE) // for read-only maping
    {
        DBG_ERROR("Invalid reuqest flag: 0x%lx, PROT_READ | PROT_WRITE: 0x%x, VM_WRITE | VM_READ: 0x%x",
            vma->vm_flags, PROT_READ | PROT_WRITE, VM_WRITE | VM_READ);
        ret = -EACCES;
        goto unlock_and_return;
    }

    if (vma->vm_flags & VM_EXEC)
    {
        DBG_ERROR("No execute is allowed, vm_flags: 0x%lx",
            vma->vm_flags);
        ret = -EACCES;
        goto unlock_and_return;
    }

    if (size > sensor->mmap_buffer_max_size)
    {
        DBG_ERROR("Invalid Request mmap size:%ld(> %d)", size, sensor->mmap_buffer_max_size);
        ret = -EINVAL;
        goto unlock_and_return;
    }

    ret = remap_pfn_range(vma, vma->vm_start, pfn_start, size, vma->vm_page_prot);
    if (ret)
    {
        DBG_INFO("remap_pfn_range failed at [0x%lx  0x%lx], ret: %d\n", vma->vm_start, vma->vm_end, ret);
    }
    else {
        DBG_INFO("map 0x%lx to 0x%lx (userspace address), size: 0x%lx, TASK_SIZE:  0x%lx\n", virt_start, vma->vm_start, size, TASK_SIZE);
    }

unlock_and_return:
    MUTEX_UNLOCK(&sensor->misc_mutex);

    return ret;
}

static long __maybe_unused misc_device_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    register_op_data_t register_op_data;
    u16 reg16 = 0;
    u32 reg24 = 0;
    u8 sub_dev_id = 0;
    u8 val8 = 0;
    u16 val16 = 0;
    u32 val32 = 0;
    struct sensor *sensor = (struct sensor*) file->private_data;
    void __user *uarg = (void __user *)arg;
    long ret = 0;
    external_config_script_param_t ex_cfg_script_param;
    external_roisram_data_size_t ex_roisram_data_param;
    ktime_t kt_req = ktime_get();

    TRACE_IOCTL("----- M_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ADAPS_GET_DTOF_MODULE_STATIC_DATA:0x%lx, eeprom_data_size: %d",
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid,
        smp_processor_id(), ADAPS_GET_DTOF_MODULE_STATIC_DATA, sensor->eeprom_data_size
        );

    switch (cmd)
    {
        case ADAPS_GET_DTOF_MODULE_STATIC_DATA:
             ret = sensor_get_module_static_data(sensor, arg);
             break;

        case ADAPS_SET_DTOF_INITIAL_PARAM:
             ret = sensor_set_dtof_intial_param(sensor, arg);
             break;

        case ADAPS_GET_DTOF_EXPOSURE_PARAM:
             ret = sensor_get_exposure_param(sensor, arg);
             break;

        case ADAPS_GET_DTOF_RUNTIME_STATUS_PARAM:
             ret = sensor_get_dtof_runtime_status_param(sensor, arg);
             break;

        case ADTOF_SET_DEVICE_REGISTER:
            if (copy_from_user(&register_op_data, (register_op_data_t *)uarg, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }

            reg24 = register_op_data.reg_addr & 0xFFFFFF;
            sub_dev_id = (reg24 >> 16) & 0xFF;
            reg16 = reg24 & 0xFFFF;
            val8 = register_op_data.reg_val & 0xFF;
            ret = mcu_write_reg_raw(sensor, sub_dev_id, reg16, val8);
            break;

        case ADTOF_GET_DEVICE_REGISTER:
            if (copy_from_user(&register_op_data, (register_op_data_t *)uarg, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }

            reg24 = register_op_data.reg_addr & 0xFFFFFF;
            sub_dev_id = (reg24 >> 16) & 0xFF;
            reg16 = reg24 & 0xFFFF;
            ret = mcu_read_reg_raw(sensor, sub_dev_id, reg16, &val8);
            if (ret < 0) {
                break;
            }
            register_op_data.reg_val = val8;

            if (copy_to_user((register_op_data_t *)uarg, &register_op_data, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }
            break;

        case ADTOF_SET_EXTERNAL_CONFIG_SCRIPT:
            if (copy_from_user(&ex_cfg_script_param, (external_config_script_param_t *)uarg, sizeof(external_config_script_param_t)))
            {
                ret = -EFAULT;
                break;
            }

            if (ex_cfg_script_param.sensor_reg_setting_cnt)
            {
                ret = loaded_script_valid_check(sensor, &ex_cfg_script_param);
                if (0 != ret)
                {
                    // if there is any error in loaded script, return failure to user space.
                    break;
                }

                if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_LOAD_SCRIPT))
                {
                    sensor->load_script = true;
                }
                sensor->loaded_sensor_reg_setting_cnt = ex_cfg_script_param.sensor_reg_setting_cnt;
                sensor->loaded_vcsel_reg_setting_cnt = ex_cfg_script_param.vcsel_reg_setting_cnt;
            }

            sensor->cur_wkmode            = ex_cfg_script_param.work_mode;

            DBG_NOTICE("script start dbg_ctrl: 0x%x, workMode: %d (%s), reg sensor_reg_setting_cnt: %u, reg vcsel_reg_setting_cnt: %u, load_script: %d."
                , sensor->dbg_ctrl
                , sensor->cur_wkmode, work_mode_name[sensor->cur_wkmode], sensor->loaded_sensor_reg_setting_cnt
                , sensor->loaded_vcsel_reg_setting_cnt, sensor->load_script);
            break;

        case ADTOF_SET_EXTERNAL_ROISRAM_DATA_SIZE:
            if (copy_from_user(&ex_roisram_data_param, (external_roisram_data_size_t *)uarg, sizeof(external_roisram_data_size_t)))
            {
                ret = -EFAULT;
                break;
            }
            sensor->loaded_roi_sram_size = ex_roisram_data_param.roi_sram_size;

            if (sensor->loaded_roi_sram_size > 0)
            {
                if (0 != (sensor->loaded_roi_sram_size % PER_ROISRAM_GROUP_SIZE))
                {
                    ret = -EINVAL;
                    break;
                }

                if (sensor->loaded_roi_sram_size > PER_ROISRAM_GROUP_SIZE)
                {
                    sensor->max_calib_sram_data_group_cnt = sensor->loaded_roi_sram_size / PER_ROISRAM_GROUP_SIZE;
                }
                else {
                    sensor->roi_sram_rolling = false;
                }

                create_blob_file_4_roisram_data(sensor, sensor->dbgfs_dentry_4_root, sensor->loaded_roi_sram, sensor->loaded_roi_sram_size, "loaded_roisram_data");
            }

            DBG_NOTICE("Load_roi_sram_size: %u, roi_sram_rolling: %d, ", sensor->loaded_roi_sram_size, sensor->roi_sram_rolling);
            break;


        case ADTOF_GET_MCU_RUNNING_FW_TYPE:
            reg16 = STATUS_REG_RUNNING_FW_TYPE;
            ret = mcu_read_self_reg(sensor, reg16, &val8);
            if (ret < 0) {
                DBG_INFO("Fail to read register 0x%x, ret: %ld.\n", reg16, ret);
                break;
            }
            val16 = val8;
            if (copy_to_user((u16 *)uarg, &val16, sizeof(u16)))
            {
                ret = -EFAULT;
                break;
            }
            sensor->mcu_fw_type = val8;
            break;

        case ADTOF_GET_MCUFIRMWARE_VERSION:
            reg16= STATUS_REG_RUNNING_FW_VERSION_L;
            ret = mcu_read_self_reg(sensor, reg16, &val8);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
            }
            val16 = val8;

            reg16 = STATUS_REG_RUNNING_FW_VERSION_H;
            ret = mcu_read_self_reg(sensor, reg16, &val8);
            if (ret < 0) {
                DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
            }
            val16 |= val8 << 8;
            if (copy_to_user((u16 *)uarg, &val16, sizeof(u16)))
            {
                ret = -EFAULT;
                break;
            }
            sensor->mcu_fw_version.fw_version = val16;
            break;

#if defined(ENABLE_MCU_FIRMWARE_UPGRADE)
        case ADTOF_LET_MCU_ENTER_BOOTLOADER:
            if (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type)
            {
                val8 = MCU_FW_TYPE_BOOTLOADER;
                reg16 = CTRL_REG_LET_MCU_ENTER_BOOTLOADER;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                }
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_SET_MCU_FW_LENGTH:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                if (copy_from_user(&val32, uarg, sizeof(val32)))
                {
                    ret = -EFAULT;
                    break;
                }

                if (val32 > MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA)
                {
                    ret = -EPERM;
                    DBG_ERROR("Invalid MCU firmware size: %d\n", val32);
                    break;
                }

                val8 = (u8) (val32 & 0xFF);
                reg16 = CTRL_REG_MCU_FW_SIZE_BYTE0;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                val8 = (u8) ((val32 >> 8) & 0xFF);
                reg16 = CTRL_REG_MCU_FW_SIZE_BYTE1;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                val8 = (u8) ((val32 >> 16) & 0xFF);
                reg16 = CTRL_REG_MCU_FW_SIZE_BYTE2;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }

                sensor->new_fw_total_length = val32;
                sensor->new_fw_transfered_offset = 0;
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_SET_MCU_FW_CRC32:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                u32 wait_timeout_us = MCU_STATUS_WAIT_TIMEOUT_US;
                u8 wait_state = MFS_WRITE_DONE;

                if (copy_from_user(&val32, uarg, sizeof(u32)))
                {
                    ret = -EFAULT;
                    break;
                }
                val8 = (u8) (val32 & 0xFF);
                reg16 = CTRL_REG_MCU_FW_CRC32_BYTE0;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                val8 = (u8) ((val32 >> 8) & 0xFF);
                reg16 = CTRL_REG_MCU_FW_CRC32_BYTE1;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                val8 = (u8) ((val32 >> 16) & 0xFF);
                reg16 = CTRL_REG_MCU_FW_CRC32_BYTE2;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                val8 = (u8) ((val32 >> 24) & 0xFF);
                reg16 = CTRL_REG_MCU_FW_CRC32_BYTE3;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }

                val8 = MFS_TO_WRITE;
                reg16 = CTRL_REG_WRITE_UPGRADE_INFO_TO_FLASH;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }

                ret = mcu_waiting_4_state(sensor, reg16 , wait_state, wait_state, wait_timeout_us, __LINE__);
                if (ret < 0) {
                    DBG_ERROR("Fail to mcu_waiting_4_state %d, ret:%ld", wait_state, ret);
                    return ret;
                }
                sensor->new_fw_total_crc32 = val32;
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_GET_BLOCK_SIZE_4_FLASH_WRITE:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                reg16 = STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_L;
                ret = mcu_read_self_reg(sensor, reg16, &val8);
                if (ret < 0) {
                    DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
                }
                val16 = val8;
                
                reg16 = STATUS_REG_BLOCK_SIZE_4_FLASH_WRITE_H;
                ret = mcu_read_self_reg(sensor, reg16, &val8);
                if (ret < 0) {
                    DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
                }
                val16 |= val8 << 8;

                if (copy_to_user((u16 *)uarg, &val16, sizeof(val16)))
                {
                    ret = -EFAULT;
                    DBG_ERROR("client: %s (%d), cmd: 0x%x, ret: %ld", current->comm, current->pid, cmd, ret);
                    break;
                }
                sensor->block_size_4_flash_write = val16;
            }
            else {
                DBG_ERROR("client: %s (%d), cmd: 0x%x, ret: %ld", current->comm, current->pid, cmd, ret);
                ret = -EPERM;
            }
            break;

        case ADTOF_TRANSFER_DATA_WITH_OFFSET:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type
                && sensor->new_fw_transfered_offset < sensor->new_fw_total_length)
            {
                u8 *pBuf_to_be_sent;
                int cur_tx_len = 0;

                if (copy_from_user(&val32, uarg, sizeof(u32)))
                {
                    ret = -EFAULT;
                    break;
                }

                if (val32 > sensor->new_fw_total_length || val32 > MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA)
                {
                    ret = -EPERM;
                    DBG_ERROR("Invalid fw transfer offset: %d\n", val32);
                    break;
                }

                sensor->new_fw_transfered_offset = val32;

                pBuf_to_be_sent = sensor->mmap_buffer_base + sensor->new_fw_transfered_offset;
                reg16 = DT_REG_MCU_FW_TRANSFER;
                if ((sensor->new_fw_transfered_offset + sensor->block_size_4_flash_write) <= sensor->new_fw_total_length)
                {
                    cur_tx_len = sensor->block_size_4_flash_write;
                }
                else {
                    cur_tx_len = sensor->new_fw_total_length - sensor->new_fw_transfered_offset;
                }
                ret = mcu_burst_write_reg(sensor, reg16, pBuf_to_be_sent, cur_tx_len);
                if(ret < 0) {
                    DBG_ERROR("mcu_burst_write_reg 0x%x failed. ret: %ld\n", reg16, ret);
                    return ret;
                }

            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_SET_FLASH_WRITE_STATUS:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                if (copy_from_user(&val8, uarg, sizeof(u8)))
                {
                    ret = -EFAULT;
                    break;
                }

                reg16 = CTRL_REG_MCU_FW_DATA_WRITE_STATUS;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
                sensor->flashwrite_status = val8;
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_GET_FLASH_WRITE_STATUS:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                reg16 = CTRL_REG_MCU_FW_DATA_WRITE_STATUS;
                ret = mcu_read_self_reg(sensor, reg16, &val8);
                if (ret < 0) {
                    DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
                    break;
                }
                if (copy_to_user((u8 *)uarg, &val8, sizeof(u8)))
                {
                    ret = -EFAULT;
                    break;
                }
                sensor->flashwrite_status = val8;
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_GET_MCU_FW_UPGRADE_STATUS:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                reg16 = STATUS_REG_FW_UPGRADE_STATUS;
                ret = mcu_read_self_reg(sensor, reg16, &val8);
                if (ret < 0) {
                    DBG_ERROR("Fail to mcu_read_self_reg 0x%x, ret:%ld", reg16, ret);
                    break;
                }
                if (copy_to_user((u8 *)uarg, &val8, sizeof(u8)))
                {
                    ret = -EFAULT;
                    break;
                }
                sensor->upgrade_status = val8;
            }
            else {
                ret = -EPERM;
            }
            break;

        case ADTOF_LET_MCU_REBOOT:
            if (MCU_FW_TYPE_BOOTLOADER == sensor->mcu_fw_type)
            {
                val8 = 0x01;
                reg16 = CTRL_REG_LET_MCU_REBOOT;
                ret = mcu_write_self_reg(sensor, reg16, val8);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%ld\n", reg16, ret);
                    break;
                }
            }
            else {
                ret = -EPERM;
            }
            break;
#endif

        default:
            ret = -ENOIOCTLCMD;
            DBG_NOTICE("Unhandled cmd:0x%x", cmd);
            break;
    }

    if (0 != ret && -ENOIOCTLCMD != ret)
    {
        DBG_ERROR("client: %s (process_id:thread_id=%d:%d) is running on CPU %d, userId: %d cmd: 0x%x, ret: %ld",
            current->comm, current->tgid, current->pid,
            smp_processor_id(),
            __kuid_val(current->cred->uid),
            cmd, ret);
    }

    TRACE_IOCTL("=END= M_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ret: %ld",
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid,
        smp_processor_id(),
        ret
        );

    return ret;
}

static const struct file_operations misc_device_fops = {
    .owner = THIS_MODULE,
    .open = misc_device_open,
    .mmap = misc_device_mmap,
    .unlocked_ioctl = misc_device_ioctl,
    .release = misc_device_release,
};

#if defined(PM_RUNTIME_ENABLE)
static int sensor_runtime_resume(struct device *dev)
{
    int             ret;
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    TRACE_PM_RUNTIME("------TRACE_PM_RUNTIME--Begin of <%s> Line:%d--power_on:%d---", __FUNCTION__, __LINE__, sensor->power_on);
    ret = sensor_set_power_on(sensor, POWER_REASON_RUMTIME_PM, __LINE__);
    if (ret < 0) {
        DBG_ERROR("Fail to __sensor_power_on(), ret: %d\n", ret);
    }
    TRACE_PM_RUNTIME("------TRACE_PM_RUNTIME--End of <%s> Line:%d--power_on:%d---", __FUNCTION__, __LINE__, sensor->power_on);

    return ret;
}


static int sensor_runtime_suspend(struct device *dev)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    TRACE_PM_RUNTIME("------TRACE_PM_RUNTIME--Begin of <%s> Line:%d--power_on:%d---", __FUNCTION__, __LINE__, sensor->power_on);
    sensor_set_power_off(sensor, POWER_REASON_RUMTIME_PM, __LINE__);
    TRACE_PM_RUNTIME("------TRACE_PM_RUNTIME--End of <%s> Line:%d--power_on:%d---", __FUNCTION__, __LINE__, sensor->power_on);

    return 0;
}

static const struct dev_pm_ops sensor_pm_ops =
{
    SET_RUNTIME_PM_OPS(sensor_runtime_suspend,
        sensor_runtime_resume, NULL)
};
#endif

#if IS_ENABLED(CONFIG_OF)
static const struct of_device_id sensor_of_match[] =
{
    { .compatible = DEV_COMPATIBLE_STRING },
    {},
};

MODULE_DEVICE_TABLE(of, sensor_of_match);
#endif

static const struct i2c_device_id sensor_match_id[] =
{
    { DEV_COMPATIBLE_STRING, 0 },
    { },
};

static int sensor_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    struct device *dev = &client->dev;
    struct v4l2_subdev *sd;
    struct device_node *node = dev->of_node;
    char            facing[2];
    struct sensor   *sensor;
    int             ret;
    unsigned long virt_addr;

    DBG_NOTICE("-Start probe(), ads6401_module_type: %s, driver_version: %s, Build Time: %s---", 
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        get_kernel_buildtime()
        );

    if ((sizeof(swift_spot_module_eeprom_data_t) > MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA)
        || (sizeof(swift_flood_module_eeprom_data_t) > MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA)
        || (sizeof(swift_eeprom_v2_data_t) > MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA)
        )
    {
        DBG_ERROR("Oops, swift_eeprom_*_data_t size exceeds buffer limit (MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA: %lu)!\n", MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA);
        DBG_ERROR("sizeof(swift_eeprom_v2_data_t): %lu!\n", sizeof(swift_eeprom_v2_data_t));
        DBG_ERROR("sizeof(swift_flood_module_eeprom_data_t): %lu!\n", sizeof(swift_flood_module_eeprom_data_t));
        DBG_ERROR("sizeof(swift_spot_module_eeprom_data_t): %lu!\n", sizeof(swift_spot_module_eeprom_data_t));
        return -EINVAL;
    }

    //console_loglevel = LOGLEVEL_DEBUG; // enable printk output to the console (uart tty)
    sensor = devm_kzalloc(dev, sizeof(*sensor), GFP_KERNEL);
    if (!sensor)
        return - ENOMEM;

    i2c_set_clientdata(client, sensor);
    sensor->mcu_i2c_client = client;
    sensor->dev         = &client->dev;
    dev_set_drvdata(sensor->dev, sensor);

    ret = of_property_read_u32(node, RKMODULE_CAMERA_MODULE_INDEX, 
        &sensor->module_index);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_FACING, 
        &sensor->module_facing);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_NAME, 
        &sensor->module_name);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_LENS_NAME, 
        &sensor->len_name);

    if (ret) {
        DBG_ERROR("could not get module information!\n");
        return - EINVAL;
    }

    sensor->matched_dev_id = i2c_of_match_device(sensor_of_match, client);
    if (NULL == sensor->matched_dev_id) {
        // Matching failed, handle error
        DBG_ERROR("Matching failed\n");
        return -EINVAL;
    }

    sensor->dbg_ctrl = DEFAULT_DBG_CTRL;
    sensor->version_code = VERSION_CODE;
    sensor->cur_wkmode = DEFAULT_WORK_MODE;
    sensor->cur_sensor_mode    = &sensor_wkmode[sensor->cur_wkmode];
    sensor->cur_etype = AdapsEnvTypeUninitilized;
    sensor->cur_mtype = AdapsMeasurementTypeUninitilized;
    sensor->cur_frtype = AdapsFramerateTypeUninitilized;
    sensor->cur_pmode = AdapsPowerModeDiv3;
    sensor->cur_v_zone_cnt = AdapsVcselZoneCount4;
    sensor->cur_vmode = AdapsVcselModeOn;
    sensor->anchor_x = 0;
    sensor->anchor_y = 0;
    sensor->reset_mipi_4_streamon = MIPI_RESET_DEFAULT_CFG;
    sensor->mipi_data_lanes = SENSOR_DATA_LANE_COUNT;
    sensor->probe_success = false;
    sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_UNKNOWN;
    sensor->static_data_ready = false;
//    sensor->force_vop_voltage_abs = 24270;
    sensor->mcu_comm_extra_delay = MCU_I2C_OP_EXTRA_DELAY;
    sensor->chksum_fail_times = 0;
    sensor->read_fail_times = 0;
    sensor->write_fail_times = 0;
    sensor->slave_fps_config = DEFAULT_FSYNC_FREQUENCY;
    sensor->force_coarse_mask_cfg = NO_FORCE_MASK_CONFIG;
    sensor->force_fine_mask_cfg = NO_FORCE_MASK_CONFIG;

#if defined(ENABLE_MCU_ERROR_IRQ)
    sensor->mcu_err_irq = -1;
    sensor->mcu_err_irq_times = 0;
#endif

    sensor->eeprom_capacity = EEPROM_REAL_CAPACITY_SIZE;
    sensor->eeprom_page_size = BIG_FOV_MODULE_EEPROM_PAGE_SIZE;
    sensor->eeprom_data_size = sizeof(swift_eeprom_v2_data_t);

    sensor->mcu_reset_gpio = devm_gpiod_get(dev, "reset", GPIOD_OUT_HIGH);
    if (IS_ERR(sensor->mcu_reset_gpio)) {
        DBG_ERROR("Failed to get reset-gpio\n");
    }

    sensor->iovcc_en_gpio = devm_gpiod_get(dev, "iovcc_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->iovcc_en_gpio)) {
        DBG_ERROR("Failed to get iovcc_en-gpio\n");
    }

    sensor->avcc_en_gpio = devm_gpiod_get(dev, "avcc_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->avcc_en_gpio)) {
        DBG_ERROR("Failed to get avcc_en-gpio\n");
    }

    sensor->drv_vcc_en_gpio = devm_gpiod_get(dev, "drv_vcc_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->drv_vcc_en_gpio)) {
        DBG_ERROR("Failed to get drv_vcc_en-gpio\n");
    }

    ret = sensor_set_power_on(sensor, POWER_REASON_LINUX_DRIVER_PROBE, __LINE__);
    if (ret < 0)
    {
        DBG_ERROR("sensor_power_on failed\n");
#if !defined(IGNORE_PROBE_FAILURE) 
        goto err_power_off;
#endif
    }

    spin_lock_init(&sensor->fsync_spinlock);
    mutex_init(&sensor->sensor_mutex);
    mutex_init(&sensor->mcu_comm_mutex);
    mutex_init(&sensor->fsync_mutex);

    sd = &sensor->subdev;
    v4l2_i2c_subdev_init(sd, sensor->mcu_i2c_client, &sensor_subdev_ops);
    ret = sensor_initialize_controls(sensor);
    if (ret)
    {
        DBG_ERROR("sensor_initialize_controls failed\n");
        goto err_destroy_mutex;
    }

    sd->internal_ops    = &sensor_internal_ops;
    sd->flags           |= V4L2_SUBDEV_FL_HAS_DEVNODE | V4L2_SUBDEV_FL_HAS_EVENTS;

    sensor->pad.flags   = MEDIA_PAD_FL_SOURCE;
    sd->entity.function = MEDIA_ENT_F_CAM_SENSOR;
    ret = media_entity_pads_init(&sd->entity, 1, &sensor->pad);
    if (ret < 0)
    {
        DBG_ERROR("media_entity_pads_init failed\n");
        goto err_free_handler;
    }

    memset(facing, 0, sizeof(facing));

    if (strcmp(sensor->module_facing, "back") == 0)
        facing[0] = 'b';
    else 
        facing[0] = 'f';

    snprintf(sd->name, sizeof(sd->name), "m%02d_%s_%s %s",
         sensor->module_index, facing,
         SENSOR_NAME, dev_name(sd->dev));

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,14,0)
    ret = v4l2_async_register_subdev_sensor(sd);
#else
    ret = v4l2_async_register_subdev_sensor_common(sd);
#endif
    if (ret) {
        DBG_ERROR("v4l2 async register subdev failed\n");
        goto err_clean_entity;
    }

    sensor->vop_adjust_interval = VOP_ADJUST_INTERVAL;

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    sensor->fsync_irq = of_irq_get(client->dev.of_node, 0);
    if (sensor->fsync_irq < 0) {
        DBG_ERROR("Failed to get frame sync interrupt number\n");
        goto err_clean_entity;
    }
    DBG_INFO("fsync_irq:%d!\n", sensor->fsync_irq);

    if (sensor->fsync_irq > 0) {
        ret = devm_request_threaded_irq(dev, sensor->fsync_irq,
                        NULL, sensor_fsync_irq,
                        IRQF_TRIGGER_FALLING | IRQF_ONESHOT,
                        SENSOR_NAME "_frame_sync", sensor);
        if (ret < 0) {
            DBG_ERROR("irq %d request failed, %d\n",
                sensor->fsync_irq, ret);
            goto err_clean_entity;
        }

    }
#endif

#if defined(ENABLE_MCU_ERROR_IRQ)
    sensor->mcu_err_irq = of_irq_get(client->dev.of_node, 1);
    if (sensor->mcu_err_irq < 0) {
        DBG_ERROR("Failed to get MCU error interrupt number\n");
        goto err_clean_entity;
    }
    DBG_INFO("mcu_err_irq:%d!\n", sensor->mcu_err_irq);

    if (sensor->mcu_err_irq > 0) {
        ret = devm_request_threaded_irq(dev, sensor->mcu_err_irq,
                        NULL, sensor_mcu_error_irq,
                        IRQF_TRIGGER_FALLING | IRQF_ONESHOT,
                        SENSOR_NAME "_mcu_error", sensor);
        if (ret < 0) {
            DBG_ERROR("irq %d request failed, %d\n",
                sensor->mcu_err_irq, ret);
            goto err_clean_entity;
        }
        DBG_INFO("irq %d request succeeded, %d\n",
                sensor->mcu_err_irq, ret);
    }
#endif

    sensor->misc_device.minor = MISC_DYNAMIC_MINOR;
    //sensor->misc_device.name = SENSOR_NAME "_misc";
    sensor->misc_device.name = "ads6401_misc";
    sensor->misc_device.fops = &misc_device_fops;
    sensor->misc_device.parent = sensor->dev;

    ret = misc_register(&sensor->misc_device);
    if (ret) {
        DBG_ERROR("Failed to register msic device");
        goto err_clean_entity3;
	}

    mutex_init(&sensor->misc_mutex);

    sensor->mmap_buffer_max_size = MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA
        + REG_SETTING_BUF_MAX_SIZE_PER_SEG
        + REG_SETTING_BUF_MAX_SIZE_PER_SEG
        + (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP * MAX_CALIB_SRAM_ROLLING_GROUP_CNT);

    // NOTE: mmap buffer size (the third parameter of remap_pfn_range()) must be an integer multiple of PAGE_SIZE
    if (0 != sensor->mmap_buffer_max_size % PAGE_SIZE)
    {
        sensor->mmap_buffer_max_size = ((sensor->mmap_buffer_max_size/PAGE_SIZE) +1) * PAGE_SIZE;
    }

    sensor->mmap_buffer_base = kzalloc((sensor->mmap_buffer_max_size * sizeof(u8)), GFP_KERNEL);
    if (NULL == sensor->mmap_buffer_base) {
        DBG_ERROR("Fail to alloc mmap buffer");
        ret = -ENOMEM;
        goto err_clean_entity3;
    }

    sensor->eeprom_data       = (swift_eeprom_v2_data_t *) sensor->mmap_buffer_base;
    sensor->loaded_sensor_reg_setting = sensor->mmap_buffer_base + MMAP_BUFFER_MAX_SIZE_4_WHOLE_EEPROM_DATA;
    sensor->loaded_vcsel_reg_setting = sensor->loaded_sensor_reg_setting + REG_SETTING_BUF_MAX_SIZE_PER_SEG;
    sensor->loaded_roi_sram = sensor->loaded_vcsel_reg_setting + REG_SETTING_BUF_MAX_SIZE_PER_SEG;
    sensor->loaded_roi_sram_size = 0;

    /*reserve kmalloc memory as pages to make them remapable*/
    for (virt_addr = (unsigned long)sensor->mmap_buffer_base;
            virt_addr < (unsigned long)sensor->mmap_buffer_base + sensor->mmap_buffer_max_size;
            virt_addr += PAGE_SIZE) {
        SetPageReserved(virt_to_page((virt_addr)));
    }

    sensor->dbgfs_dentry_4_root = debugfs_create_dir(VENDOR_NAME, NULL);
    if (!sensor->dbgfs_dentry_4_root)
    {
        DBG_ERROR("Fail to debugfs_create_dir:adaps...");
        goto err_clean_entity3;
    }

    if (!debugfs_create_file("dbg_ctrl", 0644, sensor->dbgfs_dentry_4_root, sensor, &cam_sensor_adaps_dbg_control))
    {
        DBG_ERROR("Fail to debugfs_create_file:dbg_ctrl...");
        goto err_clean_entity3;
    }

    if ((sensor->power_on) && (MCU_FW_TYPE_APPLICATION == sensor->mcu_fw_type))
    {
        ret = sensor_read_module_static_data(sensor);
        if (ret < 0) {
            DBG_ERROR( "Fail to read calibrate data, ret: %d.", ret);
#if !defined(IGNORE_PROBE_FAILURE) 
            goto err_clean_entity3;
#endif
        }
    }

    sensor_set_power_off(sensor, POWER_REASON_LINUX_DRIVER_PROBE, __LINE__);

    sensor_get_i2c_bus_frequency(sensor);

    ret = cam_sensor_register_attrib_group(sensor, dev);
    if (ret) {
        DBG_ERROR( "Error creating sysfs attribute group.");
        goto err_clean_entity3;
    }

#if defined(PM_RUNTIME_ENABLE)
    /* Enable runtime PM and turn off the device */
    pm_runtime_set_active(dev);
    pm_runtime_enable(dev);
    pm_runtime_idle(dev);
#endif

    sensor->probe_success = true;
    DBG_NOTICE("---done, dbg_ctrl: 0x%x, eeprom_data_size:%d, mcu_comm_extra_delay:%d, ads6401_module_type: %s, driver_version: %s, matched_dev: %s---", 
        sensor->dbg_ctrl,
        sensor->eeprom_data_size,
        sensor->mcu_comm_extra_delay,
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        sensor->matched_dev_id->compatible
        );
    return 0;

err_clean_entity3:
    if (sensor->mmap_buffer_base) {
        unsigned long virt_addr;
        for (virt_addr = (unsigned long)sensor->mmap_buffer_base;
             virt_addr < (unsigned long)sensor->mmap_buffer_base + sensor->mmap_buffer_max_size;
             virt_addr += PAGE_SIZE) {
            ClearPageReserved(virt_to_page((virt_addr)));
        }

        kfree(sensor->mmap_buffer_base);
    }

err_clean_entity:
    media_entity_cleanup(&sd->entity);

err_free_handler:
    v4l2_ctrl_handler_free(&sensor->ctrl_handler);

err_destroy_mutex:
    mutex_destroy(&sensor->sensor_mutex);
    mutex_destroy(&sensor->mcu_comm_mutex);
    mutex_destroy(&sensor->misc_mutex);

#if !defined(IGNORE_PROBE_FAILURE) 
err_power_off:
#endif
    sensor_set_power_off(sensor, POWER_REASON_LINUX_DRIVER_PROBE, __LINE__);
    DBG_ERROR("---failure, ret:%d, ads6401_module_type: %s, driver_version: %s, console_loglevel: %d---", 
        ret,
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        console_loglevel
        );

    return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,1,0)
static void sensor_remove(struct i2c_client * client)
#else
static int sensor_remove(struct i2c_client * client)
#endif
{
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

#if defined(PM_RUNTIME_ENABLE)
    pm_runtime_disable(sd->dev);
    if (!pm_runtime_status_suspended(sd->dev))
    {
        sensor_set_power_off(sensor, POWER_REASON_LINUX_DRIVER_REMOVE, __LINE__);
    }
    pm_runtime_set_suspended(sd->dev);
#endif

    if (sensor->dbgfs_dentry_4_root)
    {
        debugfs_remove_recursive(sensor->dbgfs_dentry_4_root);
    }

    if (sensor->link_kobj) {
        sysfs_remove_link(sensor->link_kobj, SENSOR_NAME);
        kobject_put(sensor->link_kobj);
        sensor->link_kobj = NULL;
    }

    sysfs_remove_group(&sensor->dev->kobj, &dev_drv_attrs_group);

    mutex_destroy(&sensor->sensor_mutex);
    mutex_destroy(&sensor->mcu_comm_mutex);
    mutex_destroy(&sensor->misc_mutex);
    mutex_destroy(&sensor->fsync_mutex);

    misc_deregister(&sensor->misc_device);

    if (sensor->mmap_buffer_base) {
        unsigned long virt_addr;
        for (virt_addr = (unsigned long)sensor->mmap_buffer_base;
             virt_addr < (unsigned long)sensor->mmap_buffer_base + sensor->mmap_buffer_max_size;
             virt_addr += PAGE_SIZE) {
            ClearPageReserved(virt_to_page((virt_addr)));
        }

        kfree(sensor->mmap_buffer_base);
    }

    v4l2_async_unregister_subdev(sd);

    media_entity_cleanup(&sd->entity);

    v4l2_ctrl_handler_free(&sensor->ctrl_handler);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,1,0)
    return;
#else
    return 0;
#endif
}

static struct i2c_driver cam_sensor_i2c_driver = {
    .driver = {
        .name = SENSOR_NAME,
#if defined(PM_RUNTIME_ENABLE)
        .pm = &sensor_pm_ops,
#endif
        .of_match_table = of_match_ptr(sensor_of_match),
    },
    .probe      = &sensor_probe,
    .remove     = &sensor_remove,
    .id_table   = sensor_match_id,
};

static int __init sensor_mod_init(void)
{
    int32_t rc = 0;

    rc = i2c_add_driver(&cam_sensor_i2c_driver);
    if (rc < 0)
        DBG_ERROR( "i2c_add_driver failed rc = %d", rc);

    return rc;
}

static void __exit sensor_mod_exit(void)
{
    i2c_del_driver(&cam_sensor_i2c_driver);
}

device_initcall_sync(sensor_mod_init);
module_exit(sensor_mod_exit);

MODULE_DESCRIPTION(DRIVER_NAME);
MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("David.Chen@adaps-ph.com");
MODULE_VERSION(FULL_VERSION_STRING);

