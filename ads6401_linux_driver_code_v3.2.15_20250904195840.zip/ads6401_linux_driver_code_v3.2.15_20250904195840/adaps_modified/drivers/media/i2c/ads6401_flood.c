#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)

#define SETTING_SYNC_FROM_SPADISAPP

#define VBAT_VOLTAGE_DEFAULT                3300 //unit is mv
#define VBAT_VOLTAGE_ADJUST_STEPS           1000
#define PWM_MIN_DUTY_VBAT_VOLTAGE           4000    // VBAT_PWM_50% ---> 4V, unit is mv
#define PWM_MAX_DUTY_VBAT_VOLTAGE           3000    // VBAT_PWM_100% ---> 3V, unit is mv
#define PWM_DUTY_4_VBAT_DISABLE             0       // 0 % duty cycle is to disable vbat output

#define COARSE_EXPOSURE_TIME            0x01    // unit is 80us, for register 0xBF
#define PRXMT_EXPOSURE_TIME             0x01    // unit is 80us, for register 0xC1
#define PCM_EXPOSURE_TIME               0xFF    // unit is 80us, for register 0xC2

#if defined(FRAMERATE_TEST_4_60FPS)
#define FINE_EXPOSURE_TIME              0x12    // unit is 80us, for register 0xC0
#else
#define FINE_EXPOSURE_TIME              0x58    // unit is 80us, for register 0xC0
#endif

#define DELAY_4_VOP_POWER_UP                (5)  // >=5ms, unit is milli secound
#define DELAY_4_DRV_VCC_POWER_UP            (10) // >=10ms, unit is milli secound
#define DELAY_4_VBAT_POWER_UP               (20) // >=20ms, unit is milli secound

#define DELAY_4_VBAT_POWER_DOWN             (500) // >=500ms, unit is milli secound
#define DELAY_4_LDVCC_POWER_DOWN            (600) // >=600ms, unit is milli secound

#define MCUCTRL_READY_CHECK_BASE_DELAY      5000     // unit is us
#define MCUCTRL_READY_CHECK_INRERVAL        1000     // unit is us
#define MCUCTRL_READY_CHECK_TIMEOUT         500000     // unit is us
#define MCUCTRL_REG_BASE                    0x8000
#define MCUCTRL_FW_MAJOR_VERSION_OFFSET     0x14
#define MCUCTRL_REG_COUNT                   0x6A

#define PhotonIC5015_REG_BASE               0x0000
#define PhotonIC5015_REG_COUNT              0x150

//for vcsel err 
//0X014B
#define  EMI_HIGH_ERR_MASK       (1<<0)     //Power Error(high)
#define  EMI_LOW_ERR_MSAK        (1<<1)      //Power Error (low)
#define  HIGH_LVDCC_ERR_MSAK     (1<<2)      //LDVCC High
#define  LOW_LVDCC_ERR_MSAK      (1<<3)      //LDVCC low
#define  OVER_CURRENT_ERR_MSAK   (1<<4)      //Over Current
#define  REG_0X14B_BIT_NUMS       5

//0X014C
#define  MAXS_PULSE_NUM_ERR_MSAK  (1<<0)    //Pulse Number
#define  PULSE_18US_NUM_ERR_MSAK  (1<<1)    //Pulse Number in 18us
#define  LVDS_HIZ_ERR_MSAK        (1<<2)    //LVDS Impedance 
#define  LDOUT_SHORT_ERR_MSAK     (1<<3)   //LDOUT to Ground Short
#define  CLK_HIZ_ERR_MSAK         (1<<4)    //CLK Impedance
#define  ITO_DETACH_ERR_MSAK      (1<<5)   //ITO Error
#define  VDD18_ERR_MSAK           (1<<6)
#define  VDD33_ERR_MSAK           (1<<7)
#define  REG_0X14C_BIT_NUMS       8


//0X014D
#define  PULSE_WIDTH_ERR_MSAK      (1<<0)   //Pulse Width Flag signal of pulse width larger than threshold
#define  HIGH_TEMP_ERR_MSAK        (1<<1)   //High Temp
#define  NON_EMI_ERR_MSAK          (1<<2)  //Abnormal Emission(detect with ADC) or (detect without ADC)
#define  PD_CHECK_HIGH_ERR_MSAK    (1<<3)   //Skin Protection Error
#define  PD_CHECK_LOW_ERR_MSAK     (1<<4)    //Diffuser Removal Error
#define  REG_0X14D_BIT_NUMS         5

#define MAX_VCSEL_POWERDN_RETRIES   3

enum Vcsel_Error_Code{
    EMI_HIGH_ERR_CODE=0,
    EMI_LOW_ERR_CODE,
    HIGH_LVDCC_ERR_CODE,
    LOW_LVDCC_ERR_CODE,
    OVER_CURRENT_ERR_CODE,

    MAXS_PULSE_NUM_ERR_CODE=5,
    PULSE_18US_NUM_ERR_CODE,
    LVDS_HIZ_ERR_CODE  ,
    LDOUT_SHORT_ERR_CODE,
    CLK_HIZ_ERR_CODE,
    ITO_DETACH_ERR_CODE,
    VDD18_ERR_CODE,
    VDD33_ERR_CODE,

    PULSE_WIDTH_ERR_CODE=13,
    HIGH_TEMP_ERR_CODE,
    NON_EMI_ERR_CODE,
    PD_CHECK_HIGH_ERR_CODE,
    PD_CHECK_LOW_ERR_CODE,

    VCSEL_ERR_CODE_MAX
}Vcsel_Error_Code_t;

static const char *vcsel_err_codes[]={
    "Power Error(high)",
    "Power Error (low)",
    "LDVCC High",
    "LDVCC low",

    "Over  Current",
    "Pulse Number err",
    "Pulse Number in 18us",
    "LVDS Impedance ",

    "LDOUT to Ground Short",
    "CLK Impedance",
    "ITO Error",
    "VDD18_Error",

    "VDD33_Error",
    "Pulse Width Flag signal of pulse width larger than threshold",
    "High Temp",
    "Abnormal Emission(detect with ADC) or (detect without ADC)",

    "Skin Protection Error",
    "Diffuser Removal Error",
};


static const struct setting_r16vd mcuctrl_init_regs[] = {
    {0x8031, 0x01, 0}, // enable spi driver, ie. vcsel driver controler.
#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
    {0x8032, 0x01, 0}, // enable PWM function to adjust the power voltage
#else
    {0x8032, 0x00, 0},
#endif
    {0x8033, 0x00, 0}, // dToF work mode for vsync signal handle, generally, rgb as master, dToF as slave
    {0x8034, 0x00, 0}, // disable sleep function (low power)
    {0x8035, 0x00, 0}, // vcsel switch (0: vcsel disable, 1: vcsel enable)

    {0x8023, 0x01, 0}, // mcu read temperature from vcsel driver periodically (generally once per second)
#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
                       // PWM Adjustment Control By: 0: Host Computer, 1: MCU
    {0x8024, 0x01, 0}, // mcu change PWM duty cycle to adjust the output voltage automatically
#else
    {0x8024, 0x00, 0},
#endif
    {0x8000, 0x12, 0},
    {0x8001, 0xc0, 0},
    {0x8002, 0x07, 0},
    {0x8003, 0x80, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_r16vd vcseldriver_init_regs[] = { // for PHX3D 5015
    //Reset chip 
    {0x0081, 0x06, 0},
    {0x0081, 0x04, 0},
    {0x0081, 0x00, 0},
    {0x0081, 0x01, 0},
    {0x0081, 0x03, 0},
    {0x0081, 0x07, 500},

#ifdef VCSEL_ERR_DETECT_ENABLE
    //Mask all the errors
    {0x00A2, 0xc7, 0},// ,open bit7:power low bit6:power high err bit5:ldvcc low,bit4:lvdcc high bit3:high temp //0xff t0 0x07
    {0x00A3, 0xbF, 0}, //bit6:ana over current,//0xff t0 0xbf
    {0x00A4, 0x10, 0},   //bit0:LDOUT to Ground Short bit3:over current  bit2:vdd33 bit1:vdd18  0x19 to 0x10
#else
    {0x00A2, 0xff, 0},// ,open bit7:power low bit6:power high err bit5:ldvcc low,bit4:lvdcc hight bit3:high temp //0xff t0 0x07
    {0x00A3, 0xfF, 0}, //bit6:over current,//0xff t0 0xbf
    {0x00A4, 0x19, 0},   //bit0:LDOUT to Ground Short  bit2:vdd33 bit1:vdd18  0x19 to 0x10
#endif
    //Emission settings
    {0x0084, 0x00, 0},
    {0x0082, 0x24, 0},
    //PD_RES=100kΩ
    {0x0020, 0x0B, 0},
    {0x0088, 0x02, 0},
    {0x0089, 0x03, 0},

    //FWHM Code
    //You can change 0x83~0x84 to change the FWHM value
    {0x0083, 0xC8, 0},
    {0x0084, 0x00, 0},
    {0x001D, 0xE3, 0},
    {0x008E, 0x65, 0},
    {0x0093, 0xFF, 0},
    {0x0094, 0x01, 0},
    {0x00F2, 0xFF, 0},
    {0x00F3, 0x01, 0},
    {0x0096, 0x50, 0},
    {0x0097, 0xE0, 0},
    {0x0098, 0x01, 0},
    {0x00A0, 0x0A, 0},
    {0x00E3, 0x66, 0},
    {0x00E3, 0x64, 0},
    {0x00E3, 0x24, 0},
    {0x00E5, 0x30, 0},
#ifdef VCSEL_ERR_DETECT_ENABLE
    {0x00EE, 0xcb, 0}, // change vcsel temperature limit to 65 degree
    {0x00EF, 0x04, 0}, // change vcsel temperature limit to 65 degree
#else
    {0x00EE, 0xFF, 0},
    {0x00EF, 0x05, 0},
#endif
    {0x00F0, 0xFF, 0},
    {0x00F9, 0x96, 0},
    {0x00FA, 0x07, 0},
    {0x00FB, 0x96, 0},
    {0x00FD, 0x02, 0},
    {0x00E6, 0x80, 0},
    {0x0087, 0x33, 0},
    {0x0085, 0xFF, 0},
    {0x0087, 0x33, 0},
    {0x0086, 0xFF, 0},

    //Boost settings
    //You can change 0x8A~0x8D to change the LDVCC voltage
    {0x008A, 0x84, 0},
    {0x008B, 0x03, 0},
    {0x008C, 0x84, 0},
    {0x008D, 0x03, 0},
    {0x0043, 0x0C, 0},
    {0x0062, 0x08, 0},
    {0x0082, 0x20, 0},
    {0x0044, 0x09, 0},
    {0x0044, 0x03, 0},
    {0x0082, 0xA4, 10},

    {0x0080, 0x01, 0},
    {0x0042, 0xFF, 0},
    {0x003E, 0x05, 0},
    {REG16_NULL, 0x00, 0},
};

static const struct setting_rvd sensor_init_regs[] = {
    // the following registers setting are synced from duxin's PC software. david@2023/11/17
    {0XA8, 0X30, 0},
    {0XD4, 0X32, 0},
    {0XD5, 0XFA/SYS_CLK_FACTOR, 0}, // 250/125M sys clock

#if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X66, 0},
        {0X7E, 0X07, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X02, 0},
        {0X8E, 0X02, 0},
#elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X65, 0},
        {0X7E, 0X0B, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X03, 0},
        {0X8E, 0X03, 0},
#elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X62, 0},
        {0X7E, 0X0F, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X05, 0},
        {0X8E, 0X05, 0},
#elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0XE6, 0X00, 0},
        {0XE7, 0X78, 0},
        {0XE9, 0X42, 0},
        {0X7E, 0X0F, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X07, 0},
        {0X8E, 0X07, 0},
#elif (MIPI_SPEED == MIPISPEED_1G_BPS)
        {0XE6, 0X00, 0},
    #if defined(USE_DIV1_FOR_1G_MIPISPEED)
        {0XE7, 0X7D, 0},
        {0XE9, 0X61, 0},
        {0X7E, 0X03, 0},
        {0X81, 0XA0, 0},
        {0XA5, 0X11, 0},
    #else
        {0XE7, 0X54, 0},
        {0XE9, 0X43, 0},
        {0X7E, 0X0B, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X13, 0},
    #endif
        {0X88, 0X09, 0},
        {0X8E, 0X09, 0},
#elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0XE6, 0X00, 0},    // MIPIPLL_LPDH, bit0
        {0XE7, 0X64, 0},    // MIPIPLL_LPDL
        {0XE9, 0X41, 0},    // MIPIPLL_PPD, pre-divider and post-divider
        {0X7E, 0X03, 0}, //bit3-bit2: mipi DPHY tx freq range Low 2 bits
        {0X81, 0XA0, 0}, //bit5: mipi DPHY tx freq range High 1 bit
        {0XA5, 0X11, 0},    // SYSCLK_DIV
        {0X88, 0X0B, 0},    // ClkTxThstrailCnt
        {0X8E, 0X0B, 0},    // DataTxThstrailCnt
#elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X41, 0},
        {0X7E, 0X03, 0},
        {0X81, 0XA0, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X0D, 0},
        {0X8E, 0X0D, 0},
#endif
    {0XB0, 0X21, 0},
    {0XB1, 0X21, 0},
    {0XAC, 0X01, 0},
    {0XD3, 0X41, 0},
    {0XC6, 0X3F, 0},
    {0XAE, 0X40, 0},
#if defined(ENABLE_SYS_CLK_125M)
    {0XA6, 0X0F, 0},  // 30 fps for 125M sys clock
#else
    {0XA6, 0X0B, 0},  // 30 fps for 250M sys clock
#endif
    {0XD9, 0X1A, 0},
    {0XDA, 0X60, 0},

#if (SENSOR_DATA_LANE_COUNT == 1)
    {0X0A, 0x11, 0},   // enable clock lane and data lane0
#endif


#if defined(NON_CONTINUOUS_MIPI_CLK)
        {0X04, 0x04, 0},
        {0X05, 0X18, 0},     //TCLW
        {0X06, 0X18, 0},     //TCLT
        {0X07, 0X78, 0},     //TDLW
    #if defined(ENABLE_SYS_CLK_125M)
        {0X50, 0xF0, 0},
    #endif
#else
        {0X04, 0x0C, 0},
    #if defined(ENABLE_SYS_CLK_125M)
        {0X50, 0xF0, 0},
    #endif
#endif

#if (MIPI_SPEED == MIPISPEED_166M64_BPS)
        {0XA9, 0X32, 0},
#elif (MIPI_SPEED == MIPISPEED_200M_BPS)
        {0XA9, 0x1D, 0},
#elif (MIPI_SPEED == MIPISPEED_500M_BPS)
        {0XA9, 0X20/SYS_CLK_FACTOR, 0}, // MIPI_TXDELAY: 1G: 0x10, 720M: 0x15  500M: 0x20
#elif (MIPI_SPEED == MIPISPEED_720M_BPS)
        {0XA9, 0X15/SYS_CLK_FACTOR, 0},
#elif (MIPI_SPEED == MIPISPEED_1G_BPS)
    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0XA9, 0X20, 0},
    #else
        {0XA9, 0X10/SYS_CLK_FACTOR, 0},
    #endif
#elif (MIPI_SPEED == MIPISPEED_1G2_BPS)
        {0XA9, 0X0, 0},
#elif (MIPI_SPEED == MIPISPEED_1G5_BPS)
        {0XA9, 0X0, 0},
#endif
    {0X08, 0XFA, 0},
    {0X0C, 0X05, 0},
    {0XBA, 0X18, 0},
    {0XAA, 0X01, 0},
    {0XDF, 0X00, 0},

    {REG_NULL, 0x00, 0},
};

static const struct setting_rvd sensor_phr_regs[] = {
    {0XBA, 0X0C, 0},
    {0XB2, 0X01, 0},
    {0XB3, 0X32, 0},
    {0XB4, 0X16, 0},
    {0XA4, 0X01, 0},  // disable proximity
    {0XAF, 0X00, 0},
    {0XBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},
    {0XBF, 0X13, 0},
    {0XC0, 0X26, 0},
    {0XB0, 0X21, 0},
    {0XB1, 0X21, 0},
    {0XBD, 0X66, 0},
    {0XBE, 0X66, 0},
    {0XC3, 0X0C, 0},
    {0XC4, 0X08, 0},
    {0XC5, 0X10, 0},
    {0XB5, 0X0F, 0},
    {0XBB, 0X06, 0},
    {0XB7, 0XF9, 0},
    {0XB8, 0X43, 0},
    {0XB9, 0X08, 0},
    {0X18, 0X08, 0},
    {0X19, 0X04, 0},
    {0XB6, 0X06, 0},
    {REG_NULL, 0x00, 0}
};

static const struct setting_rvd sensor_pcm_regs[] = {
    {0XA4, 0X01, 0},
    {0XB6, 0X01, 0},
    {0XBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},
    {0XCB, 0X04, 0}, // wangfeng think 0x04 should have enough driver strength for PCM mode, which is same as FHR mode.
    {0X18, 0X00, 0},
    {0X19, 0X0A, 0},
    {0XC3, 0X0B, 0},
    {0XC4, 0X08, 0},
    {0XC5, 0X0A, 0},
    {0XC2, 0X20, 0}, // PCM expore time change to 2560us.
    {0XAF, 0X20, 0},

#if defined(SETTING_SYNC_FROM_SPADISAPP)
    // the following registers setting are synced from duxin's PC software (DothinkDevice::Start() of swift_device.cpp). david@2023/11/20
    {0XC5, 0X10, 0},
    {0XB7, 0Xf9, 0},
    {0XB2, 0X01, 0},
    {0XB3, 0X32, 0},
    {0XB4, 0X16, 0},
#endif

    {REG_NULL, 0x00, 0}
};

static const struct setting_rvd sensor_fhr_regs[] = {
    {0XA4, 0X00, 0},   //bit0: 1 as master, 0 as slave, bit1: enable/disable proximity
    {0XB6, 0X26, 0},
    {0XBC, (BIT(7) | VCSEL_LASER_PERIOD), 0},
    {0XCB, 0X04, 0},
    {0X18, 0X08, 0},
    {0X19, 0X10, 0},
    {0XAF, 0X00, 0},
    {0XBF, 0X01, 0},
    {0XC0, 0X3C/SYS_CLK_FACTOR, 0},
    {0XC1, 0X01, 0},
    {0XBD, 0X66, 0},
    {0XBE, 0X66, 0},
    {0XC3, 0X06, 0},
    {0XC4, 0X08, 0},
    {0XC5, 0X06, 0},
    {0XB0, 0X21, 0},
    {0XB1, 0X83, 0},
    {0XB5, 0X0F, 0},
    {0XBB, 0X06, 0},
    {0XB7, 0XF9, 0},
    {0XB8, 0X43, 0},
    {0XB9, 0X08, 0},
    {0XAA, 0X01, 0},
    {0XD9, 0X1F, 0},

#if defined(SETTING_SYNC_FROM_SPADISAPP)
    // the following registers setting are synced from duxin's PC software (DothinkDevice::Start() of swift_device.cpp). david@2023/11/20
    {0XC5, 0X10, 0},
    {0XB2, 0X01, 0},
    {0XB3, 0X32, 0},
    {0XB4, 0X16, 0},
#endif

    {REG_NULL, 0x00, 0}
};

static uint32_t g_crc32_table[CRC32_TABLE_BUF_LEN] = { 0 };

static void generate_crc32_table(void) {
    u32 i = 0;
    u32 j = 0;
    u32 crc = 0;

    for (i = 0; i < 256; i++) {
        crc = i;
        for (j = 8; j > 0; j--) {
            if (crc & 1) {
                crc = (crc >> 1) ^ POLYNOMIAL;
            } else {
                crc >>= 1;
            }
        }

        g_crc32_table[i] = crc;
    }
}

static u32 crc32_calculate(u32 initial, const u8* buf, size_t len) {
    u32 c = initial ^ 0xFFFFFFFF;
    size_t i = 0;

    for (i = 0; i < len; i++) {
        c = g_crc32_table[(c ^ buf[i]) & 0xFF] ^ (c >> 8);
    }

    return c ^ 0xFFFFFFFF;
}

// When any error occurs, the function will return a negative number.
static int __maybe_unused i2c_dev_burst_write_reg16(struct sensor *sensor, struct i2c_client * client, u16 reg, const u8 *data, const u32 len)
{
    int             ret;
    u8 *            buf;
    struct i2c_msg msg;

    if (NULL == client) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg, len);
        return -EINVAL;
    }

    if (NULL == data) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg, len);
        return -EINVAL;
    }

    buf                 = kmalloc((sizeof(unsigned char) * (len + 2)), GFP_KERNEL);
    if (!buf) {
        DBG_ERROR("kmalloc failure");
        return -ENOMEM;
    }

    buf[0] = (reg >> 8) & 0xff;
    buf[1] = reg & 0xff;
    memcpy(&buf[2], data, len);

    msg.addr            = client->addr;
    msg.flags           = I2C_M_WR;
    msg.buf             = buf;
    msg.len             = len + 2;

    ret = i2c_transfer(client->adapter, &msg, 1);
    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
    {
        if (1 == len)
        {
            TRACE_REG_RW("Write reg:0x%04x to 0x%02x for i2c device(0x%x) %s...", reg, *data, client->addr, 1 == ret ? "SUCCESS": "FAILURE");
        }
        else {
            TRACE_REG_RW("Burst write reg:0x%04x data length:%d for i2c device(0x%x) %s...", reg, len, client->addr, 1 == ret ? "SUCCESS": "FAILURE");
        }
    }

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret != 1) {
        DBG_ERROR("i2c_transfer failed, ret:%d when write buffer to i2c device:0x%x reg:0x%0x", 
            ret,
            client->addr,
            reg);
        kfree(buf);
        return -EIO;
    }
#endif

    kfree(buf);

    return 0;
}

static int __maybe_unused mcuctrl_reg_read(struct sensor *priv, u16 reg, u8 *val)
{
    return i2c_dev_burst_read_reg16(priv, priv->mcuctrl_i2c, reg, val, 1);
}

static int mcuctrl_write_reg(struct sensor *sensor, u16 reg, const u8 *data, const u32 len)
{
    return i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, reg, data, len);
}

static int mcuctrl_ready_check(struct sensor *sensor)
{
    int ret = 0;
    uint8_t version[4];
    s64 us_delta;
    u32 delay_us;
    ktime_t start;

    delay_us = MCUCTRL_READY_CHECK_BASE_DELAY;
    usleep_range(delay_us, delay_us+100);
    DBG_INFO("<%s> start to read mcu firmware version.\n", __FUNCTION__);
    start = ktime_get();

    delay_us = MCUCTRL_READY_CHECK_INRERVAL;
    do {
        ret = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c,
            MCUCTRL_REG_BASE + MCUCTRL_FW_MAJOR_VERSION_OFFSET,
            version, 4);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (ret >= 0) {
            DBG_NOTICE("MCU is ready, already wait %lld us, ret: %d, mcu fw version: %d.%d.%d.%d!\n", us_delta, ret, version[0], version[1], version[2], version[3]);
            sensor->mcuctrl_fw_version = (version[0] << 24) | (version[1] <<16) | (version[2] << 8) | version[3];
            ret = 0;
            break;
        }

        if (MCUCTRL_READY_CHECK_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to MCU ready, already wait %lld us.\n", us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(delay_us, delay_us+100);
    } while (1);

    return ret;
}

static int mcuctrl_reg16_dump(struct sensor *sensor, 
    u16 base_address, int reg_count, const char * callfunc, int callline, bool out_2_console)
{
#define LENGTH_PER_LINE             128

    u8              value;
    u16             reg, startAddr = base_address;
    u16             endAddr = base_address + reg_count;
    int             i, j;
    int             buf_len = 0;
    char *          buf;
    int             rc  = 0;

    if (NULL == sensor || NULL == callfunc) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    buf = kzalloc(LENGTH_PER_LINE, GFP_KERNEL);
    if (NULL == buf)
    {
        DBG_ERROR("malloc failure for <%s>", __func__);
        return -ENOMEM;
    }

    buf_len += sprintf(buf, "===========McuCtrl Register Dump from <%s> Line: %d===========",
         callfunc, callline);
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    buf_len += sprintf(buf + buf_len, "-----");

    for (i = 0; i < 0x10; i++) {
        buf_len += sprintf(buf + buf_len, "----%x", i);
    }

    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    for (i = 0; i < reg_count/0x10; i++) {
        buf_len += sprintf(buf + buf_len, "%04x:", (i << 4) +base_address);

        for (j = 0; j < 0x10; j++) {
            reg = ((i << 4) | j) +base_address;

            if ((startAddr <= reg && endAddr >= reg)) {
                rc = mcuctrl_reg_read(sensor, reg, &value);
                if (rc < 0) {
                    DBG_ERROR("read register 0x%x failed ret:%d\n", reg, rc);
                    goto error_exit;
                }

                buf_len += sprintf(buf + buf_len, "   %02X", value);
            }
            else {
                buf_len += sprintf(buf + buf_len, "   --");
            }
        }

        printout_2_select_target(buf, out_2_console);
        buf_len = 0;
    }

    buf_len += sprintf(buf + buf_len, "=====================================================================================\n");
    printout_2_select_target(buf, out_2_console);

error_exit:
    kfree(buf);
    buf = NULL;
    return buf_len;
}


static int mcuctrl_initreg_update(struct sensor *sensor, struct setting_r16vd *regs, u8 work_mode)
{
    int i;
    u8 force_role = FORCE_SENSOR_ROLE_NONE;

    if (sensor->force_sensor_role == FORCE_SENSOR_ROLE_AS_MASTER || sensor->force_sensor_role == FORCE_SENSOR_ROLE_AS_SLAVE)
    {
        force_role = sensor->force_sensor_role;
    }
    else {
        if (ADAPS_PCM_MODE == work_mode)
        {
            force_role = FORCE_SENSOR_ROLE_AS_MASTER;
        }
        else {
            force_role = FORCE_SENSOR_ROLE_AS_SLAVE;
        }
    }

    if (FORCE_SENSOR_ROLE_NONE != force_role) {
        for (i = 0; regs[i].reg != REG16_NULL; i++) {
            if (regs[i].reg == 0x8033)
            {
                //0 as slave, 1 as master
                if (FORCE_SENSOR_ROLE_AS_MASTER == force_role)
                {
                    regs[i].val = 0x01;
                    DBG_INFO("----update No:%d reg(0x%04x) to 0x%02x for sensor role: Master",
                        i, regs[i].reg, regs[i].val);
                }
                else if (FORCE_SENSOR_ROLE_AS_SLAVE == force_role)
                {
                    regs[i].val = 0x00;
                    DBG_INFO("----update No:%d reg(0x%04x) to 0x%02x for sensor role: Slave",
                        i, regs[i].reg, regs[i].val);
                }
            }

            if (regs[i].reg == 0x8035)
            {
                if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
                {
                    //0: vcsel disable, 1: vcsel enable
                    if (FORCE_SENSOR_ROLE_AS_MASTER == force_role)
                    {
                        if (true == sensor->force_enable_vcsel_4_pcm_mode)
                        {
                            regs[i].val = 0x01; // only enable vcsel if environment variable 'adaps_enable_vcsel_4_gray' is set.
                            DBG_INFO("----update No:%d reg(0x%04x) to 0x%02x for sensor role: Master",
                                i, regs[i].reg, regs[i].val);
                        }
                        else {
                            regs[i].val = 0x00; // vcsel disable for gray mode by default
                            DBG_INFO("----update No:%d reg(0x%04x) to 0x%02x for sensor role: Master, but vcsel is disabled.",
                                i, regs[i].reg, regs[i].val);
                        }
                    }
                    else if (FORCE_SENSOR_ROLE_AS_SLAVE == force_role)
                    {
                        regs[i].val = 0x01;
                        DBG_INFO("----update No:%d reg(0x%04x) to 0x%02x for sensor role: Slave",
                            i, regs[i].reg, regs[i].val);
                    }
                }
                else {
                    regs[i].val = 0x00; // vcsel disable
                }
            }
        }
    }

    return 0;
}

#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
static int mcuctrl_vop_adjust_enable(struct sensor *sensor, bool on) // from ads6401_vop_adjust_switch()
{
    int ret = 0;

    u16 reg_addr16;
    uint8_t val = 0;

    if (on)
    {
        int i;
        uint8_t version[4];
        uint8_t ng_version[4] = {1,0,0,2};
        reg_addr16 = 0x8014;
        ret = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, version, 4);
        if (ret < 0) {
            return ret;
        }

        for (i = 0; i < 4; i++) {
            if (version[i] > ng_version[i]) {
                val = 1;
                break;
            }
        }

        DBG_INFO("-- on: %d, curr mcu fw version: %d.%d.%d.%d",
            on, version[0], version[1], version[2], version[3]);
    }

    reg_addr16 = 0x8032;
    ret = i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &val, 1);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }

    return ret;
}
#endif

static int mcuctrl_swd_enable(struct sensor *sensor, bool enable)
{
    int ret = 0;
    u16 reg_addr16;
    uint8_t val = enable ? 1:0;

    reg_addr16 = 0x8021;
    ret = i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &val, 1);
    if (ret < 0) {
        DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
        return ret;
    }
    sensor->swd_enable = enable;

    return ret;
}

static int mcuctrl_setting_init(struct sensor *sensor, u8 work_mode)
{
    int i;
    int ret = 0;
    struct setting_r16vd *regs = NULL;

    regs = kzalloc(sizeof(struct setting_r16vd) *ARRAY_LEN(mcuctrl_init_regs), GFP_KERNEL);
    if (NULL == regs)
    {
        DBG_ERROR("malloc failure for <%s>", __func__);
        return -ENOMEM;
    }
    memcpy(regs, mcuctrl_init_regs, sizeof(struct setting_r16vd) *ARRAY_LEN(mcuctrl_init_regs));
    mcuctrl_initreg_update(sensor, regs, work_mode);

    for (i = 0; regs[i].reg != REG16_NULL; i++) {
        ret = i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, regs[i].reg, &regs[i].val, 1);
        if (ret < 0) {
            DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", regs[i].reg, ret);
            break;
        }

        if (regs[i].delayUs)
        {
            common_delay(regs[i].delayUs * 1000);
        }
    }
    kfree(regs);

    return ret;
}

static int sensor_get_inside_temperature(struct sensor *sensor, u32 *temperature_x_100)
{
    int rc = 0;
    u16 reg_addr16;
    uint8_t tempH = 0;
    uint8_t tempL = 0;

#if 1 // get the real temperature from MCU
    reg_addr16 = 0x8010;
    rc = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &tempH, 1);
    if (rc < 0) {
        return rc;
    }

    reg_addr16 = 0x8011;
    rc = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &tempL, 1);
    if (rc < 0) {
        return rc;
    }

    *temperature_x_100 = (tempH << 8) | tempL;
#else
    //float temperature;
    reg_addr16 = 0x8012;
    rc = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &tempH, 1);
    if (rc < 0) {
        return rc;
    }

    reg_addr16 = 0x8013;
    rc = i2c_dev_burst_read_reg16(sensor, sensor->mcuctrl_i2c, reg_addr16, &tempL, 1);
    if (rc < 0) {
        return rc;
    }

    temp_value = (tempH << 8) | tempL;
    /// temperature = (float)(temp_value - 1024) / 5.8f + 30;  // °C
    /// *temperature_x_100 = (u32)(temperature*100);

    // Convert floating-point operations to integer operations.
    // temperature *100 = ((float)(temp_value - 1024) / 5.8f + 30) * 100;
    // temperature *100 = (temp_value - 1024) *17 + 30 * 100;
    // *temperature_x_100 = (temp_value - 1024) *17 + 30 * 100;;
    // *temperature_x_100 = temp_value*17 - 1024 *17 + 30 * 100;;
    // *temperature_x_100 = temp_value*17 - 14408;

    *temperature_x_100 = temp_value*17 - 14408;
#endif

    return rc;
}

static int vcseldrv_setting_update(
    struct setting_r16vd *regs,
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsMeasurementType mtype)
{
    int ret = 0;
    int i;

    if (NULL == sensor)
    {
        DBG_ERROR("sensor is NULL");
        return -EINVAL;
    }

    if (ADAPS_PCM_MODE == sensor->cur_wkmode)
    {
        return ret;
    }

    if (etype < AdapsEnvTypeIndoor || etype > AdapsEnvTypeOutdoor)
    {
        DBG_ERROR("Invalid EnvironmentType, etype:%d",etype);
        return -EINVAL;
    }

    if (mtype < AdapsMeasurementTypeNormal || mtype > AdapsMeasurementTypeFull)
    {
        DBG_ERROR("Invalid MeasurementType, etype:%d",mtype);
        return -EINVAL;
    }

    for (i = 0; regs[i].reg != REG16_NULL; i++) {
        if ((0x008a == regs[i].reg) || (0x008c == regs[i].reg))
        {
            if (AdapsEnvTypeIndoor == etype)
            {
                regs[i].val = 0x84;
            }
            else {
                if (0 == (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_OD_9V_CONFIG))
                {
                    regs[i].val = 0x00;
                }
                else{
                    regs[i].val = 0x5F;  //ourdoor 9v config
                }
            }
            continue;
        }

        if ((0x008b == regs[i].reg) || (0x008d == regs[i].reg))
        {
            if (AdapsEnvTypeIndoor == etype)
            {
                regs[i].val = 0x03;
            }
            else {
                if (0 == (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_OD_9V_CONFIG))
                {
                    regs[i].val = 0x02;
                }
                else{
                    regs[i].val = 0x01;  //ourdoor 9v config
                }
            }
            continue;
        }

        if (0x0083 == regs[i].reg)
        {
            if (AdapsEnvTypeIndoor == etype)
            {
                regs[i].val = 0xc8;
            }
            else {
                regs[i].val = 0x44;
            }
            continue;
        }

        if (0x0084 == regs[i].reg)
        {
            if (AdapsEnvTypeIndoor == etype)
            {
                regs[i].val = 0x00;
            }
            else {
                regs[i].val = 0x01;
            }
            continue;
        }
    }

    return ret;
}

static int vcseldrv_setting_init(struct sensor *sensor)
{
    int i;
    int ret = 0;
    struct setting_r16vd *regs = NULL;

    // when test pattern enabled, don't need enable vcsel driver
    if (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)
    {
        DBG_INFO("Use the basic register settings for test pattern data output...");
        return 0;
    }

    if (FALSE == sensor->load_script)
    {
        regs = kzalloc(sizeof(struct setting_r16vd) *ARRAY_LEN(vcseldriver_init_regs), GFP_KERNEL);
        if (NULL == regs)
        {
            DBG_ERROR("malloc failure for <%s>", __func__);
            return -ENOMEM;
        }
        memcpy(regs, vcseldriver_init_regs, sizeof(struct setting_r16vd) *ARRAY_LEN(vcseldriver_init_regs));
        vcseldrv_setting_update(regs, sensor, sensor->cur_etype, sensor->cur_mtype);

        for (i = 0; regs[i].reg != REG16_NULL; i++) {
            ret = i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, regs[i].reg, &regs[i].val, 1);
            if (ret < 0) {
                DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", regs[i].reg, ret);
                break;
            }

            if (regs[i].delayUs)
            {
                common_delay(regs[i].delayUs * 1000);
                if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
                {
                    TRACE_REG_RW("Delay %d us after Write reg(0x%04X) to 0x%02X for i2c device:0x%x...", regs[i].delayUs, regs[i].reg, regs[i].val, sensor->mcuctrl_i2c->addr);
                }
            }
        }
        kfree(regs);
    }
    else {
        if (NULL != sensor->loaded_vcsel_reg_setting && 0 != sensor->loaded_vcsel_reg_setting_cnt)
        {
            regs =  (struct setting_r16vd *) sensor->loaded_vcsel_reg_setting;
            for (i = 0; regs[i].reg != REG16_NULL; i++) {
                ret = i2c_dev_burst_write_reg16(sensor, sensor->mcuctrl_i2c, regs[i].reg, &regs[i].val, 1);
                if (ret < 0) {
                    DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", regs[i].reg, ret);
                    break;
                }
            
                if (regs[i].delayUs)
                {
                    common_delay(regs[i].delayUs * 1000);
                    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
                    {
                        TRACE_REG_RW("Delay %d us after Write reg(0x%04X) to 0x%02X for i2c device:0x%x...", regs[i].delayUs, regs[i].reg, regs[i].val, sensor->mcuctrl_i2c->addr);
                    }
                }
            }
        }
        else {
            DBG_ERROR("Invalid loaded_sensor_reg_setting, %p, %d", sensor->loaded_vcsel_reg_setting, sensor->loaded_vcsel_reg_setting_cnt);
            return -EINVAL;
        }
    }

    if (ret >= 0)
    {
        sensor->vcsel_inited = true;
    }
    return ret;
}

static void sensor_show_vcsel_errcode(unsigned int v_err_code)
{
    int i =0;
    DBG_ERROR("\n--------------------------- VCSEL Alert Code: 0x%x ----------------------------------", v_err_code);
    for(i=0;i<(VCSEL_ERR_CODE_MAX);i++)
    {
        if(v_err_code & (1<<i))
            DBG_ERROR("%s \n",vcsel_err_codes[i]);
    }
    DBG_ERROR("-------------------------------------------------------------------------------------\n");
}

//current do  not handle these err. may be use later,so save here
//MAXS_PULSE_NUM_ERR_CODE
//PULSE_18US_NUM_ERR_CODE
//LVDS_HIZ_ERR_CODE
//CLK_HIZ_ERR_CODE
//ITO_DETACH_ERR_CODE
//PULSE_WIDTH_ERR_CODE
//NON_EMI_ERR_CODE
//PD_CHECK_HIGH_ERR_CODE
//PD_CHECK_LOW_ERR_CODE
static int sensor_get_vcsel_errcode(struct sensor *sensor, unsigned int *vcsel_err_code)
{
    int rc=0;
    u16 reg_addr16;
    unsigned char val_014b=0,val_014c=0,val_014d=0;

    reg_addr16 = 0x014b;
    rc = mcuctrl_reg_read(sensor, reg_addr16, &val_014b);
    if (rc < 0) {
        DBG_ERROR("fail to read mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, rc);
        return rc;
    }

    reg_addr16 = 0x014c;
    rc = mcuctrl_reg_read(sensor, reg_addr16, &val_014c);
    if (rc < 0) {
        DBG_ERROR("fail to read mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, rc);
        return rc;
    }

    reg_addr16 = 0x014d;
    rc = mcuctrl_reg_read(sensor, reg_addr16, &val_014d);
    if (rc < 0) {
        DBG_ERROR("fail to read mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, rc);
        return rc;
    }
    
    //ignore these error.
    val_014c &= ~MAXS_PULSE_NUM_ERR_MSAK;
    val_014c &= ~PULSE_18US_NUM_ERR_MSAK;
    val_014c &= ~LVDS_HIZ_ERR_MSAK;
    val_014c &= ~CLK_HIZ_ERR_MSAK;
    val_014c &= ~ITO_DETACH_ERR_MSAK;

    val_014d &= ~PULSE_WIDTH_ERR_MSAK;
    val_014d &= ~NON_EMI_ERR_MSAK;
    val_014d &= ~PD_CHECK_HIGH_ERR_MSAK;
    val_014d &= ~PD_CHECK_LOW_ERR_MSAK;

    *vcsel_err_code=(val_014d<<(REG_0X14C_BIT_NUMS+REG_0X14B_BIT_NUMS)) | (val_014c<<REG_0X14B_BIT_NUMS) | val_014b;

    return rc;
}

static irqreturn_t vcsel_err_handle_handler(int irq, void *privateData)
{
    struct sensor *sensor = privateData;
    unsigned int vcsel_err_code;

    sensor->vcsel_drv_err_irq_times++;

    if (sensor->streaming)
    {
        sensor_get_vcsel_errcode(sensor, &vcsel_err_code);

        if ((0 != vcsel_err_code) && (((1<<HIGH_TEMP_ERR_CODE)  & vcsel_err_code) ||
            ((1<<VDD18_ERR_CODE) & vcsel_err_code)||
            ((1<<VDD33_ERR_CODE) & vcsel_err_code)))
        {
            sensor_show_vcsel_errcode(vcsel_err_code);
            if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_ERR_IRQ_HANDLE)) {
                if (NULL != sensor->client_task_4_sensor)
                {
                    // send a user signal 1 to let the userspace App stop the streaming
                    send_sig(SIGUSR1, sensor->client_task_4_sensor, 1);
                }
            }
            else {
                DBG_NOTICE("VCSEL error (0x%x) happened, but stop-streaming is disabled now.\n", vcsel_err_code);
            }
        }
    }

    return IRQ_HANDLED;
}

static int sensor_role_force_update(struct sensor *sensor, struct setting_rvd *regs, u8 work_mode)
{
    int i;
    u8 force_role = FORCE_SENSOR_ROLE_NONE;

    if (sensor->force_sensor_role == FORCE_SENSOR_ROLE_AS_MASTER || sensor->force_sensor_role == FORCE_SENSOR_ROLE_AS_SLAVE)
    {
        force_role = sensor->force_sensor_role;
    }
    else {
        if (ADAPS_PCM_MODE == work_mode)
        {
            force_role = FORCE_SENSOR_ROLE_AS_MASTER;
        }
        else {
            force_role = FORCE_SENSOR_ROLE_AS_SLAVE;
        }
    }

    if (FORCE_SENSOR_ROLE_NONE != force_role) {
        for (i = 0; regs[i].reg != REG_NULL; i++) {
            if (regs[i].reg == 0Xa4)
            {
                //--bit0: 0 as slave, 1 as master
                if (FORCE_SENSOR_ROLE_AS_MASTER == force_role)
                {
                    regs[i].val = regs[i].val | 0x01;
                    DBG_INFO("----update No:%d reg(0x%02x) to 0x%02x for sensor role: Master",
                        i, regs[i].reg, regs[i].val);
                }
                else if (FORCE_SENSOR_ROLE_AS_SLAVE == force_role)
                {
                    regs[i].val = regs[i].val & 0xFE;
                    DBG_INFO("----update No:%d reg(0x%02x) to 0x%02x for sensor role: Slave",
                        i, regs[i].reg, regs[i].val);
                }
            }
        }
    }

    return 0;
}

/*
    ---swift rk3568转接板vbat电压控制PWM计算方法---

    PWM频率10KHz，占空比0.1%可调
    占空比可调范围50%~100%

    VBAT_PWM_50% ---> 4V
    VBAT_PWM_100% ---> 3V
*/
static int sensor_vbat_pwm_convert_voltage_to_duty(struct sensor *sensor, u16 vbat_mv)
{
    int duty_ns = 0;
    int expected_duty_permillage;
    int duty_delta_permillage;
    int duty_permillage_min = 500;
    int duty_permillage_max = 1000; //pwm adjust step is 1/1000

    u16 vbat_voltage_min_duty = PWM_MIN_DUTY_VBAT_VOLTAGE;  // when the duty of PWM is 50.0%, the vbat output voltage, unit is mv
    u16 vbat_voltage_max_duty = PWM_MAX_DUTY_VBAT_VOLTAGE;  // when the duty of PWM is 100.0%, the vbat output voltage, unit is mv

    duty_delta_permillage = ((vbat_voltage_max_duty - vbat_mv) * (duty_permillage_max - duty_permillage_min)) / (vbat_voltage_max_duty - vbat_voltage_min_duty);
    expected_duty_permillage = duty_permillage_max - duty_delta_permillage;

    duty_ns = (expected_duty_permillage * sensor->pwm_4_vbat.current_period_ns) / duty_permillage_max;

    DBG_INFO("Vbat volt: %d mv duty_delta_permillage: %d expected_duty_permillage: %d, duty_ns: %d ns.", vbat_mv, duty_delta_permillage, expected_duty_permillage, duty_ns);

    return duty_ns;
}

static int sensor_vbat_pwm_set_duty(struct sensor *sensor, int duty_ns)
{
    int ret;

    if (duty_ns < 0 || duty_ns > sensor->pwm_4_vbat.current_period_ns)
    {
        DBG_ERROR("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_vbat.current_duty_ns);
        return -EINVAL;
    }

    ret = pwm_config(sensor->pwm_4_vbat.pwm_dev, duty_ns, sensor->pwm_4_vbat.current_period_ns);
    if (ret) {
        DBG_ERROR("Failed to configure PWM, duty: %d ns, period: %d ns", duty_ns, sensor->pwm_4_vbat.current_period_ns);
        return ret;
    }
    sensor->pwm_4_vbat.current_duty_ns = duty_ns;

    return ret;
}

static void sensor_vbat_pwm_enable(struct sensor *sensor)
{

    pwm_config(sensor->pwm_4_vbat.pwm_dev, sensor->pwm_4_vbat.current_duty_ns, sensor->pwm_4_vbat.current_period_ns);
    pwm_enable(sensor->pwm_4_vbat.pwm_dev);
}

static void sensor_vbat_pwm_disable(struct sensor *sensor)
{
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_vbat.pwm_dev, &state);
    if (!state.enabled)
        return;

    pwm_config(sensor->pwm_4_vbat.pwm_dev, PWM_INITDUTYCYCLE_4_VBAT, sensor->pwm_4_vbat.current_period_ns);
    pwm_disable(sensor->pwm_4_vbat.pwm_dev);
}

static int sensor_set_vbat_voltage(struct sensor *sensor, u16 vbat_mv)
{
    int duty_ns;
    int ret=0;

    if (vbat_mv < PWM_MAX_DUTY_VBAT_VOLTAGE || vbat_mv > PWM_MIN_DUTY_VBAT_VOLTAGE)   // vbat_mv's unit is mv
    {
        DBG_ERROR("Invalid vbat voltage, volt: %d mv",vbat_mv);
        return -EINVAL;
    }

    duty_ns = sensor_vbat_pwm_convert_voltage_to_duty(sensor, vbat_mv);
    ret = sensor_vbat_pwm_set_duty(sensor, duty_ns);
    if (ret < 0) {
        DBG_ERROR("Fail to set Vbat voltage to %d.%d v.", vbat_mv/1000, vbat_mv % 1000);
    }
    else {
        sensor->pwm_4_vbat.current_set_voltage = vbat_mv;
    }

    return ret;
}

static ssize_t vbat_pwm_test_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_vbat.pwm_dev, &state);

    return scnprintf(buf, PAGE_SIZE, 
        "period_ns:             %d ns\n"
        "duty_ns:               %d ns\n"
        "current set voltage:   %d\n"
        "current status:        %s\n\n",

        sensor->pwm_4_vbat.current_period_ns,
        sensor->pwm_4_vbat.current_duty_ns,
        sensor->pwm_4_vbat.current_set_voltage,
        true == state.enabled ? "Enabled" : "Disabled"
    );
}

static ssize_t vbat_pwm_test_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;
    int test_case;
    int param2;
    int duty_ns;

    ret = sscanf(buf, "%d %d", &test_case, &param2);
    if (2 == ret) {
        if (2 == test_case) // test_case:2 set PWM duty by voltage (unit is mv)
        {
            u16 vbat_mv = 0;
            if (param2 < PWM_MAX_DUTY_VBAT_VOLTAGE || param2 > PWM_MIN_DUTY_VBAT_VOLTAGE)
            {
                printk2console("Invalid vbat voltage: %d.%d V\n", param2/1000, param2%1000);
                return -EINVAL;
            }

            vbat_mv = param2;
            duty_ns = sensor_vbat_pwm_convert_voltage_to_duty(sensor, vbat_mv);
            ret = sensor_vbat_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("Vbat voltage is adjusted to %d.%d V\n", param2/1000, param2%1000);
            }
        }
        else if (3 == test_case) // test_case:3 set PWM duty by duty (ns)
        {
            duty_ns = param2;
            if (duty_ns < 0 || duty_ns > sensor->pwm_4_vbat.current_period_ns)
            {
                printk2console("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_vbat.current_duty_ns);
                return -EINVAL;
            }

            ret = sensor_vbat_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else if (4 == test_case) // test_case:4 set PWM duty by permillage 
        {
            int permillage = param2;
            if (permillage < 500 || permillage > PWM_VOLTAGE_ADJUST_STEPS)
            {
                printk2console("Invalid permillage: %d\n", permillage);
                return -EINVAL;
            }

            duty_ns = (sensor->pwm_4_vbat.current_period_ns * permillage) / PWM_VOLTAGE_ADJUST_STEPS;
            ret = sensor_vbat_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else {
            return -EINVAL;
        }
    }
    else if (1 == ret) {
        if (0 == test_case) // test_case:0  disable PWM
        {
            sensor_vbat_pwm_disable(sensor);
            printk2console("Vbat PWM is disabled\n");
        }
        else if (1 == test_case) // test_case:1  enable PWM
        {
            sensor_vbat_pwm_enable(sensor);
            printk2console("Vbat PWM is enabled\n");
        }
        else {
            return -EINVAL;
        }
    }
    else {
        return -EINVAL;
    }

    return count;
}

static DEVICE_ATTR_RW(vbat_pwm_test);

static ssize_t force_enable_vcsel_4_pcm_mode_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "%d\n", sensor->force_enable_vcsel_4_pcm_mode);
}

static ssize_t force_enable_vcsel_4_pcm_mode_store(struct device *dev,
                 struct device_attribute *attr,
                 const char *buf, size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int val;
    int err;

    err = kstrtoint(buf, 0, &val);
    if (err)
        return -err;

    if (val >= 0 && val <= 1)
    {
        sensor->force_enable_vcsel_4_pcm_mode = val;
    }
    else {
        return -EINVAL;
    }

    return count;
}
static DEVICE_ATTR_RW(force_enable_vcsel_4_pcm_mode);

static int sensor_set_power_on(struct sensor *sensor, int callline)
{
    int ret;
    //struct device *dev = &sensor->sensor_i2c->dev;

    if (!IS_ERR(sensor->reset_gpio))
    {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_ENABLED);
    }

    if (!IS_ERR(sensor->dvcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->dvcc_en_gpio, FUNCTION_ENABLE);
        usleep_range(TPS62864_ENABLE_DELAY_TIME, TPS62864_ENABLE_DELAY_TIME+100);
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            tps62864_reg_dump(sensor, false);
        }
        sensor_set_dvcc_voltage(sensor);
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            tps62864_reg_dump(sensor, false);
        }
    }

    if (!IS_ERR(sensor->iovcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->iovcc_en_gpio, FUNCTION_ENABLE);
    }

#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->avcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->avcc_en_gpio, FUNCTION_ENABLE);
    }

    if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_ENABLE);
    }
#endif

#if !defined(VOP_ADJUST_BY_BUILT_IN_MCU) && defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    set_vop_voltage(sensor, DEFAULT_VOP_VOLTAGE);
    sensor_vop_pwm_enable(sensor);
#endif

    // vbat voltage
    sensor_set_vbat_voltage(sensor, VBAT_VOLTAGE_DEFAULT);
    sensor_vbat_pwm_enable(sensor);
#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->vbat_en_gpio)) {
        gpiod_set_value_cansleep(sensor->vbat_en_gpio, FUNCTION_ENABLE);
    }
#endif

    usleep_range(500, 1000);

#if defined(SENSOR_XCLK_FROM_SOC)
    ret = clk_prepare_enable(sensor->xvclk);
    if (ret < 0) {
        DBG_ERROR("Failed to enable xvclk\n");
        return ret;
    }
#endif

    if (!IS_ERR(sensor->reset_gpio)) {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_DISABLED);
    }

#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->work_state_led_gpio)) {
        gpiod_set_value_cansleep(sensor->work_state_led_gpio, FUNCTION_ENABLE);
    }
#endif

    usleep_range(500, 1000);

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_SKIP_SENSOR_READY_CHECK))
    {
        ret = mcuctrl_ready_check(sensor);
        if (ret < 0) {
            DBG_ERROR("Fail to wait to mcu ready, ret: %d\n", ret);
            return ret;
        }
        else {
            ret = sensor_ready_check(sensor);
            if (ret < 0) {
                DBG_ERROR("Fail to wait to sensor ready, ret: %d\n", ret);
                return ret;
            }
            else {
                sensor->power_on = true;
        
                if ((sensor->probe_success) && (false == sensor->static_data_ready)) // if fail to read module_static_data at probe(), try to re-read it once more
                {
                    ret = sensor_read_module_static_data(sensor);
                    if (ret < 0) {
                        DBG_ERROR( "Fail to read module static data, ret: %d.", ret);
                    }
                }
            }
        
        }
    }
    else {
        sensor->power_on = true;
    }

    sensor->power_on_times++;

    TRACE_POWER_CTRL("<%s> is called from %d, ret: %d\n", __func__, callline, ret);

    return ret;
}

static void sensor_set_power_off(struct sensor *sensor, int callline)
{
    u16 reg_addr16;
    uint8_t val = 0;
    int tries = 0;
    int ret = -1;
    //struct device *dev = &sensor->sensor_i2c->dev;

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
    {
        do {
            reg_addr16 = 0x0081;
            val = 0x0;
            DBG_INFO("Start LDVCC power down by write 0x0080 register");
            ret = mcuctrl_write_reg(sensor, reg_addr16, &val, 1);
            if (0 > ret) {
                DBG_ERROR("fail to write mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
                return;
            }
            common_delay(DELAY_4_LDVCC_POWER_DOWN * MS_TO_NS);
        
            reg_addr16 = 0x0081;
            ret = mcuctrl_reg_read(sensor, reg_addr16, &val);
            if (ret < 0) {
                DBG_ERROR("fail to read mcu ctrl register: 0x%x, ret:%d\n", reg_addr16, ret);
                return;
            }
        
            if (0 == val)
            {
                break;
            }
        
            tries++;
            if (tries > MAX_VCSEL_POWERDN_RETRIES)
            {
                DBG_ERROR("fail to turn off LDVCC, val:0x%x, tries:%d\n", val, tries);
                return;
            }
        } while (1);
    }

    ret = sensor_vbat_pwm_set_duty(sensor, PWM_DUTY_4_VBAT_DISABLE);
    if (ret < 0) {
        DBG_ERROR("Fail to set Vbat voltage disable.");
    }
    else {
        //sensor->mcu_ctrl.set_vbat_voltage = volt;
    }
    sensor_vbat_pwm_disable(sensor); // TODO: to be confirmed
#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->vbat_en_gpio)) {
        gpiod_set_value_cansleep(sensor->vbat_en_gpio, FUNCTION_DISABLE);
    }
#endif
    common_delay(DELAY_4_VBAT_POWER_DOWN * MS_TO_NS);

#if !defined(VOP_ADJUST_BY_BUILT_IN_MCU) && defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    sensor_vop_pwm_disable(sensor);
    common_delay(DELAY_4_VOP_POWER_DOWN * MS_TO_NS);
#endif

#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->drv_vcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->drv_vcc_en_gpio, FUNCTION_DISABLE);
    }

    if (!IS_ERR(sensor->avcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->avcc_en_gpio, FUNCTION_DISABLE);
    }
#endif

    if (!IS_ERR(sensor->iovcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->iovcc_en_gpio, FUNCTION_DISABLE);
    }

    if (!IS_ERR(sensor->dvcc_en_gpio)) {
        gpiod_set_value_cansleep(sensor->dvcc_en_gpio, FUNCTION_DISABLE);
    }

#if defined(SENSOR_XCLK_FROM_SOC)
    clk_disable_unprepare(sensor->xvclk);
#endif
    if (!IS_ERR(sensor->reset_gpio)) {
        gpiod_set_value_cansleep(sensor->reset_gpio, SENSOR_RESET_ENABLED);
    }

#if defined(MINI_DEMO_BOX)
    if (!IS_ERR(sensor->work_state_led_gpio)) {
        gpiod_set_value_cansleep(sensor->work_state_led_gpio, FUNCTION_DISABLE);
    }
#endif

    TRACE_POWER_CTRL("<%s> is called from %d\n", __func__, callline);
    sensor->power_on = false;
    sensor->vcsel_inited = false;

}

static int sensor_check_eeprom_crc(struct sensor *sensor)
{
    int i = 0,ret=0;
    uint32_t read_crc32 = 0;
    uint32_t calc_crc32 = 0;

    //do page 0 crc
    calc_crc32 = crc32_calculate(0, (const unsigned char *) sensor->eeprom_data, FLOOD_EEPROM_VERSION_INFO_SIZE + FLOOD_EEPROM_SN_INFO_SIZE);
    if(sensor->eeprom_data->Crc32Pg0 == calc_crc32)
    {
        DBG_INFO("EEPROM Crc32Pg0 matched!!! sizeof(swift_flood_module_eeprom_data_t)=%ld, calc_crc32:0x%x",
                sizeof(swift_flood_module_eeprom_data_t),
                calc_crc32);
        //hex_data_dump((const u8 *) sensor->eeprom_data, 64, "eeprom data head");
    }
    else {
        DBG_ERROR("EEPROM Crc32Pg0 MISMATCHED!!! sizeof(swift_flood_module_eeprom_data_t)=%ld, calc_crc32:0x%x,read Crc32Pg0:0x%x",
                sizeof(swift_flood_module_eeprom_data_t),
                calc_crc32,
                sensor->eeprom_data->Crc32Pg0);
        //hex_data_dump((const u8 *) sensor->eeprom_data, 64, "eeprom data head");
        ret = -1;
        //goto check_exit;
    }

    //do page 1 crc
    calc_crc32 = crc32_calculate(0, (unsigned char*)(sensor->eeprom_data) + FLOOD_EEPROM_MODULE_INFO_OFFSET, FLOOD_EEPROM_MODULE_INFO_SIZE);

    if(sensor->eeprom_data->Crc32Pg1 == calc_crc32)
    {
        DBG_INFO("EEPROM Crc32Pg1 matched!!! calc_crc32:0x%x",
                calc_crc32);
        //hex_data_dump((const u8 *) sensor->eeprom_data, 64, "eeprom data head");
    }
    else {
        DBG_ERROR("EEPROM Crc32Pg1 MISMATCHED!!! calc_crc32:0x%x,read Crc32Pg1:0x%x",
                calc_crc32,
                sensor->eeprom_data->Crc32Pg1);
        ret = -1;
        //goto check_exit;
    }



    calc_crc32 = crc32_calculate(0, (unsigned char*)(sensor->eeprom_data) + FLOOD_EEPROM_TDCDELAY_OFFSET, 
        FLOOD_EEPROM_TDCDELAY_SIZE + FLOOD_EEPROM_INTRINSIC_SIZE + FLOOD_EEPROM_INDOOR_CALIBTEMPERATURE_SIZE
        + FLOOD_EEPROM_OUTDOOR_CALIBTEMPERATURE_SIZE + FLOOD_EEPROM_INDOOR_CALIBREFDISTANCE_SIZE+FLOOD_EEPROM_OUTDOOR_CALIBREFDISTANCE_SIZE);
    if(sensor->eeprom_data->Crc32Pg2 == calc_crc32)
    {
        DBG_INFO("EEPROM Crc32Pg2 matched!!! calc_crc32:0x%x",
                calc_crc32);
        //hex_data_dump((const u8 *) sensor->eeprom_data, 64, "eeprom data head");
    }
    else {
        DBG_ERROR("EEPROM Crc32Pg2 MISMATCHED!!! calc_crc32:0x%x,read Crc32Pg2:0x%x",
                calc_crc32,
                sensor->eeprom_data->Crc32Pg2);
        ret = -1;
        //goto check_exit;
    }

    //do sram data crc for every zone
    for ( i = 0; i < ZONE_COUNT_PER_SRAM_GROUP * CALIB_SRAM_GROUP_COUNT; ++i)
    {
        calc_crc32 = crc32_calculate(0, sensor->eeprom_data->sramData + i*FLOOD_MODULE_SRAM_ZONE_OCUPPY_SPACE, FLOOD_MODULE_SRAM_ZONE_VALID_DATA_LENGTH);
        read_crc32 = *(uint32_t*)(sensor->eeprom_data->sramData + i*FLOOD_MODULE_SRAM_ZONE_OCUPPY_SPACE + FLOOD_MODULE_SRAM_ZONE_VALID_DATA_LENGTH);
        if (calc_crc32 != read_crc32)
        {
            DBG_ERROR("SRAM %d CRC checksum MISMATCHED, calc_crc32=0x%x   read_crc32=0x%x\n", i, calc_crc32, read_crc32);
            ret = -1;
            //goto check_exit;
        }
        else
        {
            DBG_INFO("SRAM %d CRC checksum matched!!! sizeof(swift_flood_module_eeprom_data_t)=%ld, calc_crc32:0x%x",
                i,
                sizeof(swift_flood_module_eeprom_data_t),
                calc_crc32);
        }

        //reset the crc in the eeprom to 0,because the algo will use these data
        //*(uint32_t*)(sensor->eeprom_data->sramData+i*SRAM_ZONE_OCUPPY_SPACE + SRAM_ZONE_VALID_DATA_LENGTH)=0;
    }

    //do offset crc 
    for ( i = 0; i < 8; ++i)
    {
        calc_crc32 = crc32_calculate(0, (unsigned char*)(sensor->eeprom_data->spotOffset) + i * FLOOD_MODULE_OFFSET_VALID_DATA_LENGTH, FLOOD_MODULE_OFFSET_VALID_DATA_LENGTH);
        if (calc_crc32 != sensor->eeprom_data->Crc32Offset[i])
        {
            DBG_ERROR("offset %d CRC checksum MISMATCHED, read_crc=0x%x, calc_crc32:0x%x\n", i, sensor->eeprom_data->Crc32Offset[i], calc_crc32);
            ret = -1;
            //goto check_exit;
        }
        else
        {
            DBG_INFO("offset %d CRC checksum matched!!! calc_crc32:0x%x", i, calc_crc32);
        }
    }

//check_exit:
    return ret;
}





#endif
