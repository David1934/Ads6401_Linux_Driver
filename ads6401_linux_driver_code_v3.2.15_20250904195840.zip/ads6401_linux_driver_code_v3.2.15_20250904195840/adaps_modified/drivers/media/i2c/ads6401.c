// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (C) 2023- Adaps Photonics Inc.
 */

#include <linux/clk.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/i2c.h>
#include <linux/module.h>
#include <linux/regulator/consumer.h>
#include <linux/sysfs.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/tty.h>
#include <linux/debugfs.h>
#include <media/media-entity.h>
#include <media/v4l2-async.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-subdev.h>
#include <linux/pwm.h>
#include <linux/of_irq.h>
#include <linux/miscdevice.h>
#include <linux/mman.h>
#include <generated/compile.h>

#include <linux/rk-camera-module.h>

#define VERSION_MAJOR                   3
#define VERSION_MINOR                   2
#define VERSION_REVISION                15
#define LAST_MODIFIED_TIME              "20250904A"


#define DEFAULT_DBG_CTRL                0 //(ADAPS_DBG_DUMP_REGS | ADAPS_DBG_TRACE_REGS_WRITE)

#define SWIFT_MODULE_TYPE               ADS6401_MODULE_BIG_FOV_FLOOD  // (ADS6401_MODULE_SPOT / ADS6401_MODULE_FLOOD / ADS6401_MODULE_BIG_FOV_FLOOD)

#if defined(CONFIG_SWIFT_MINI_DEMO_BOX)
    #define MINI_DEMO_BOX
#endif

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
    #if (ADS6401_MODULE_BIG_FOV_FLOOD == SWIFT_MODULE_TYPE)
        #define ADS6401_MODULE_TYPE_NAME                        "Big_FoV_Flood"
    #else
        #define ADS6401_MODULE_TYPE_NAME                        "Classic_Spot"
    #endif

    #define VCSEL_LASER_PERIOD                              96  // 127          // <=127, laser repetition frequency period, unit is ns

    // for rk3568 + new adapter board: 2 PWM output from rk3568 for pvdd and vop voltage adjustment.
    #define ENABLE_SOC_PWM_4_PVDD_VOLTAGE
    #define ENABLE_SOC_PWM_4_VOP_VOLTAGE
    #define ENABLE_VCSEL_DRV_ERROR_IRQ

    #define TTY_DRIVERNAME_4_UART                           "ttyFIQ"
    #define CALIB_DATA_READY_IN_EEPROM_CHIP
    #define OPN7020_VCSEL_DRIVER_ENABLE
    #define MIPI_SPEED                                      MIPISPEED_1G_BPS
    #define NON_CONTINUOUS_MIPI_CLK

    #define MIPI_RESET_DEFAULT_CFG                          STREAM_ON_WITH_MIPI_IP_RESET_FIRST
    #define ROISRAM_ANCHOR_PREPROCCESS_ENABLE
    #define ENABLE_RUNTIME_REGISTER_UPDATE
    //#define ENABLE_SYSFREQ_ADJUST_4_LOW_POWER             // only apply to 1G mipi speed now.
    //#define FRAMERATE_TEST_4_60FPS

    #define SENSOR_XCLK_FROM_SOC
    #define DEVICE_CONCURRENCY_OPEN_CHECK
    #define ENABLE_SENSOR_FSYNC_IRQ
    #define ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ

    #define IGNORE_PROBE_FAILURE

#else
    //#error "ADS6401_MODULE_FLOOD is selected!"
    #define ADS6401_MODULE_TYPE_NAME                        "Small_Flood"

    #define ENABLE_SOC_PWM_4_VOP_VOLTAGE                    // VOP_ADJUST_BY_BUILT_IN_MCU
    #define TTY_DRIVERNAME_4_UART                           "ttyFIQ"
    #define CALIB_DATA_READY_IN_EEPROM_CHIP
    #define ENABLE_VCSEL_4_PCM_MODE_CFG                     true // enable vcsel for pcm mode of flood module
    #define VCSEL_LASER_PERIOD                              96          // <=127, laser repetition frequency period, unit is ns

    #define MIPI_SPEED                                      MIPISPEED_1G_BPS
    //#define USE_DIV1_FOR_1G_MIPISPEED
    #define NON_CONTINUOUS_MIPI_CLK

    #define MIPI_RESET_DEFAULT_CFG                          STREAM_ON_WITH_MIPI_IP_RESET_FIRST
    #define ENABLE_RUNTIME_REGISTER_UPDATE
    #define ENABLE_SYSFREQ_ADJUST_4_LOW_POWER               // only apply to 1G mipi speed now.
    #define ROISRAM_ANCHOR_PREPROCCESS_ENABLE

    #define SENSOR_XCLK_FROM_SOC
    #define DEVICE_CONCURRENCY_OPEN_CHECK
    #define ENABLE_SENSOR_FSYNC_IRQ
    #define ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ
    #define ENABLE_VCSEL_DRV_ERROR_IRQ
    #define VCSEL_ERR_DETECT_ENABLE
    #define IGNORE_PROBE_FAILURE

#endif

#if defined(FRAMERATE_TEST_4_60FPS)
    #undef MIPI_SPEED
    #define MIPI_SPEED                                      MIPISPEED_1G5_BPS
#endif


#if defined(NON_CONTINUOUS_MIPI_CLK)
    #undef MIPI_RESET_DEFAULT_CFG
    #define MIPI_RESET_DEFAULT_CFG          STREAM_ON_WITHOUT_MIPI_IP_RESET
#endif

#if defined(ENABLE_SYS_CLK_125M)
    #define SYS_CLK_FACTOR                  2
#else
    #define SYS_CLK_FACTOR                  1
#endif

//#define __weak                              __attribute__((weak))

#define MAX(a, b)                           ((a) > (b) ? (a) : (b))

#define VERSION_CODE                        (VERSION_MAJOR << 16 | VERSION_MINOR << 8 | VERSION_REVISION)
#define VERSION_STRING                      __stringify(VERSION_MAJOR) "."  \
        __stringify(VERSION_MINOR) "."  \
        __stringify(VERSION_REVISION)
#define FULL_VERSION_STRING                 VERSION_STRING "_LM" LAST_MODIFIED_TIME

#define MIPISPEED_1G5_BPS                   1500     // 1.5G
#define MIPISPEED_1G2_BPS                   1200
#define MIPISPEED_1G_BPS                    1000
#define MIPISPEED_720M_BPS                  720
#define MIPISPEED_500M_BPS                  500
//#define MIPISPEED_328M_BPS                328
//#define MIPISPEED_250M_BPS                250
#define MIPISPEED_200M_BPS                  200
#define MIPISPEED_166M64_BPS                166     // 166.64M


#define DRIVER_NAME                         "Adaps ads6401 dToF sensor driver"
#define SENSOR_NAME                         "ads6401"
#define DEV_COMPATIBLE_STRING               "adaps,ads6401"
#define MINI_BOX_COMPATIBLE_STRING          "adaps,ads6401-mbox"

#define LOG_TAG                             "<DRV_ADS6401> "
#define PWM_NAME_IN_DTS_FOR_VBAT_OR_PVDD    "pwm_vbat_or_pvdd"
#define PWM_NAME_IN_DTS_FOR_VOP             "pwm_vop"

#define SENSOR_MODE_NAME_GRAY               "PCM-Gray"
#define SENSOR_MODE_NAME_PHR                "PTM-PHR"
#define SENSOR_MODE_NAME_FHR                "PTM-FHR"

#define I2C_ADDRESS_4_EEPROM                0x50

// TPS62864 I2C slave address (assuming 1000 101 from datasheet)
#define TPS62864_I2C_ADDR                   0x45

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)

#define I2C_ADDR_4_VCSELDRV                 0x31

#else

#define I2C_ADDR_4_MCUCTRL                  0x60

#endif

#define REG_NULL                            0xFF
#define REG16_NULL                          0xFFFF

#define EEPROM_PAGESIZE                     64          // unit is bytes
#define MAX_BYTES_PER_EEPROM_READ           4096        // 8, unit is bytes

#define MEGA                                1000000

#define SENSOR_DATA_LANE_COUNT              2
#define SOC_MIPI_RX_CLOCK_FREQ              MAX(MIPI_SPEED/2, 500)     // The min is 500MHz, SoC MIPI RX clock frequency

#define SENSOR_BITS_PER_SAMPLE              8
#define SENSOR_LINK_FREQ                    (SOC_MIPI_RX_CLOCK_FREQ * MEGA)
/* pixel rate = link frequency * 2 * lanes / BITS_PER_SAMPLE */
//#define SENSOR_PIXEL_RATE                 ((SENSOR_LINK_FREQ / SENSOR_BITS_PER_SAMPLE) * 2 * SENSOR_DATA_LANE_COUNT)

#define SENSOR_XVCLK_FREQ_M                 24
#define SENSOR_XVCLK_FREQ                   (SENSOR_XVCLK_FREQ_M * MEGA)

#define SENSOR_MEDIA_BUS_FMT                MEDIA_BUS_FMT_SBGGR8_1X8
#define SENSOR_RAW_DATA_TYPE                0x2A        // RAW8

// ADDRESS RANGE: 0x00--0x5F   The registers of CSI TX controller
// ADDRESS RANGE: 0x60--0x9F   The registers of D-PHY controller
// ADDRESS RANGE: 0xA0--0xEF   The registers of CSRU (Control Status Register Unit).
#define CHIP_ID                             0x4101
#define CHIP_ID_VER2                        0x6401
#define SENSOR_REG_CHIP_ID                  0xA2

#define SENSOR_READY_CHECK_BASE_DELAY      1000     // unit is us
#define SENSOR_READY_CHECK_INRERVAL        1000     // unit is us
#define SENSOR_READY_CHECK_TIMEOUT         10000     // unit is us

#define SENSOR_EXPOSURE_MIN                 1
#define SENSOR_EXPOSURE_STEP                1
#define SENSOR_EXPOSURE_MAX                 255

#define I2C_M_WR                            0
#define I2C_MSG_MAX                         300
#define I2C_DATA_MAX                        (I2C_MSG_MAX * 3)

#define SENSOR_IDLE_WAIT_TIMEOUT            50000        // unit is us

#define PWM_INITDUTYCYCLE_4_VBAT            0       // unit is ns
#define PWM_POLARITY_4_VBAT                 PWM_POLARITY_NORMAL

#define PWM_INITDUTYCYCLE_4_VOP             0       // unit is ns
#define PWM_POLARITY_4_VOP                  PWM_POLARITY_NORMAL // PWM_POLARITY_INVERSED
#define PWM_VOLTAGE_ADJUST_STEPS            1000

#define DEFAULT_VOP_VOLTAGE                 (-2000)     // unit is 10mv
#define VOP_VOLTAGE_MAX                     (-2000)     // unit is 10mv, when 65.60% duty cycle
#define VOP_VOLTAGE_MIN                     (-3014)     // unit is 10mv, when 100.0% duty cycle

#define VOP_ADJUST_INTERVAL                 1000 //unit is ms

#define CHIP_TEMPERATURE_MIN_THRESHOLD      1500  // 15.0 x 100
#define CHIP_TEMPERATURE_MAX_THRESHOLD      9000  // 90.0 x 100
#define OTP_TEMPERATURE_LOW                 2500   // it is fixed to 25.00 degree

#define PWM_INITDUTYCYCLE_4_PVDD            0       // unit is ns
#define PWM_POLARITY_4_PVDD                 PWM_POLARITY_NORMAL

// Register addresses (as per datasheet)
#define TPS62864_REG_VOUT1                  0x01
#define TPS62864_REG_VOUT2                  0x02
#define TPS62864_REG_CONTROL                0x03
#define TPS62864_REG_STATUS                 0x05

#define TPS62864_REG_VOUT1_VAL              0x8C        // 1100mv
#define TPS62864_REG_VOUT2_VAL              0x8C        // 1100mv
#define TPS62864_ENABLE_DELAY_TIME          1000         // unit is us

#define MS_TO_NS                            1000000

#define DELAY_4_VOP_POWER_DOWN              (500) // >=500ms, unit is milli secound

#define POLYNOMIAL                          0xEDB88320
#define CRC32_TABLE_BUF_LEN                 (256)

#define ARRAY_LEN(arr)                      (sizeof(arr) / sizeof(arr[0]))

#define CURRENT_CLIENT                      (((current->tgid << 16) & 0xFFFF0000) | (current->pid & 0xFFFF))
#define CLIENT_TO_PID(CLIENT)               (((CLIENT) >> 16) & 0xFFFF)
#define CLIENT_TO_TID(CLIENT)               ((CLIENT) & 0xFFFF)

#define MUTEX_LOCK(mutex)                   mutex_lock((mutex))
#define MUTEX_UNLOCK(mutex)                 mutex_unlock((mutex))

#if !defined(DISABLE_DBG_MACRO_4_WARNING_CHECK)

inline const char* get_filename(const char* path) {
    const char* file = strrchr(path, '/');
    if (!file) {
        file = strrchr(path, '\\');
    }
    return file ? file + 1 : path;
}

#define CONSOLE_ERROR(fmt, args ...)                                                                        \
    do {                                                                                                    \
        printk2console("<%s> %s L%d <ERR> " fmt "\n",                                                       \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define CONSOLE_PRINT(fmt, args ...)                                                                        \
    do {                                                                                                    \
        printk2console("[%s L%d] " fmt "\n",                                                                  \
            get_filename(__FILE__), __LINE__, ##args);                                                      \
    }while(0)

#define DBG_PRINTK(fmt, args ...)                                                                           \
    do {                                                                                                    \
        printk(KERN_ERR "%s <%s> %s L%d " fmt "\n",                                                         \
            LOG_TAG, __func__, get_filename(__FILE__), __LINE__, ##args);                                   \
    }while(0)

#define DBG_ERROR(fmt, args ...)                                                                            \
    do {                                                                                                    \
        struct timespec64 ts;                                                                               \
        struct tm tm_res;                                                                                   \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                                \
        pr_err_ratelimited("%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <E> <%s> %s L%d " fmt "\n", \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                                 \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                                   \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define DBG_NOTICE(fmt, args ...)                                                                           \
    do {                                                                                                    \
        struct timespec64 ts;                                                                               \
        struct tm tm_res;                                                                                   \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &tm_res);                                                                \
        printk(KERN_ERR "%s[%4ld-%02d-%02d %02d:%02d:%02d.%03ld.%03ld.%03ld] <N> <%s> %s L%d " fmt "\n",    \
            LOG_TAG, tm_res.tm_year+1900L, tm_res.tm_mon+1, tm_res.tm_mday,                                 \
            tm_res.tm_hour, tm_res.tm_min, tm_res.tm_sec,                                                   \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }while(0)

#define DBG_INFO(fmt, args ...)                                                                             \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_DEBUG_INFO_ENABLE))                           \
    {                                                                                                       \
        struct timespec64 ts;                                                                               \
        struct tm t;                                                                                        \
        ktime_get_real_ts64(&ts);                                                                           \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                     \
                                                                                                            \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] <I> <%s> %s L%d " fmt "\n",   \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                            \
            t.tm_hour, t.tm_min, t.tm_sec,                                                                  \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                              \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }

#define TRACE_REG_RW(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & (ADAPS_DBG_TRACE_REGS_READ | ADAPS_DBG_TRACE_REGS_WRITE)))                       \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] <%s> %s L%d " fmt "\n",   \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
        __func__, get_filename(__FILE__), __LINE__, ##args);                                            \
    }

#define TRACE_IOCTL(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_IOCTL_CMD))                               \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        pr_err_ratelimited(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] ioctl <%s> %s L%d " fmt "\n",        \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#define TRACE_V4L2_CB(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_V4L2_CALLBACK))                           \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] v4l2_cb <%s> %s L%d:"fmt"\n", \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#define TRACE_POWER_CTRL(fmt, args ...)                                     \
    if ((NULL == sensor) || (sensor->dbg_ctrl & ADAPS_DBG_POWER_CTRL))                              \
    {                                                                                                   \
        struct timespec64 ts;                                                                           \
        struct tm t;                                                                                    \
        ktime_get_real_ts64(&ts);                                                                       \
        time64_to_tm(ts.tv_sec, 0, &t);                                                                 \
                                                                                                        \
        printk(KERN_ERR "%s[%04ld-%02d-%02d %02d:%02d:%02d %03ld.%03ld.%03ld] power_ctl <%s> %s L%d:"fmt"\n", \
            LOG_TAG, t.tm_year + 1900L, t.tm_mon + 1, t.tm_mday,                                        \
            t.tm_hour, t.tm_min, t.tm_sec,                                                              \
            ts.tv_nsec / 1000000, ts.tv_nsec / 1000 % 1000, ts.tv_nsec % 1000,                          \
            __func__, get_filename(__FILE__), __LINE__, ##args);                                        \
    }

#else
#define CONSOLE_ERROR                   printk2console
#define CONSOLE_PRINT                   printk2console
#define DBG_PRINTK                      printk
#define DBG_ERROR                       printk
#define DBG_NOTICE                      printk
#define DBG_INFO                        printk
#define TRACE_REG_RW                    printk
#define TRACE_IOCTL                     printk
#define TRACE_V4L2_CB                   printk
#define TRACE_POWER_CTRL                printk
#endif

#if !defined(BIT)
#define BIT(n)                      (1 << n)
#endif

enum adaps_dbg_type_t {
    ADAPS_DBG_TRACE_REGS_READ           = BIT(0),
    ADAPS_DBG_DUMP_REGS                 = BIT(1),
    ADAPS_DBG_TRACE_REGS_WRITE          = BIT(2),
    ADAPS_DBG_TESTPATTERN_ENABLE        = BIT(3),

    ADAPS_DBG_POWER_CTRL                = BIT(4),
    ADAPS_DBG_DEBUG_INFO_ENABLE         = BIT(5),
    ADAPS_DBG_DUMP_SRAM_REG             = BIT(6),
    ADAPS_DBG_PM_RUNTIME                = BIT(7),

    ADAPS_DBG_VOLTAGE_UPDATE            = BIT(8),
    ADAPS_DBG_DISABLE_VCSEL_DRVIER      = BIT(9),
    ADAPS_DBG_ROISRAM_RB_4_VERIFY       = BIT(10),
    ADAPS_DBG_IOCTL_CMD                 = BIT(11),

    ADAPS_DBG_V4L2_CALLBACK             = BIT(12),
    ADAPS_DBG_MUTEX_LOCK                = BIT(13),
    ADAPS_DBG_DISABLE_ROI_SWITCH        = BIT(14),
    ADAPS_DBG_DISABLE_ERR_IRQ_HANDLE    = BIT(15),

    ADAPS_DBG_ENABLE_OD_9V_CONFIG       = BIT(16),  // Disable 9V configure for outdoor mode for swift flood module, by default.
    ADAPS_DBG_TRACE_FSYNC_IRQ           = BIT(17),
    ADAPS_DBG_DISABLE_LOAD_SCRIPT       = BIT(18),
    ADAPS_DBG_TRACE_ROI_SWITCH          = BIT(19),

    ADAPS_DBG_SKIP_SENSOR_READY_CHECK   = BIT(20),
//    ADAPS_DBG_ENABLE_BIG_FOV_MODULE     = BIT(21),
    ADAPS_DBG_ENABLE_VCSEL_L_MODE       = BIT(22),

    ADAPS_DBG_ONCE                      = BIT(23)  // keep at LAST seat.
};

enum {
    FORCE_SENSOR_ROLE_NONE = 0,    // No force
    FORCE_SENSOR_ROLE_AS_MASTER,
    FORCE_SENSOR_ROLE_AS_SLAVE
};

enum {
    FUNCTION_DISABLE = 0,
    FUNCTION_ENABLE = 1
};

enum {
    SENSOR_RESET_DISABLED = 0,
    SENSOR_RESET_ENABLED = 1
};

enum {
    STREAM_ON_WITHOUT_MIPI_IP_RESET         = 0, // No reset
    STREAM_ON_WITH_MIPI_IP_RESET_FIRST      = 1, // reset mipi module before stream on
    STREAM_ON_FIRST_AND_THEN_RESET_MIPI_IP  = 2  // reset mipi module after stream on
};

enum {
    SWIFT_VOP_ALGO_VER_UNKNOWN = 0,
    SWIFT_VOP_ALGO_VER_1,
    SWIFT_VOP_ALGO_VER_2,
    SWIFT_VOP_ALGO_VER_3,
    SWIFT_VOP_ALGO_VER_CNT = SWIFT_VOP_ALGO_VER_3,
};

struct adaps_init_reg {
    u8 reg_addr;
    u8 reg_val[3]; // div1, div2, div3
};

struct sensor_mode {
    u32                 width;
    u32                 height;
    struct v4l2_fract   max_fps;
    u32                 exp_def;
    const struct setting_rvd  *wkmode_reg_cfg_list;
    const u32 wkmode_reg_cfg_count;
};

struct sensor_pwm {
    struct pwm_device               *pwm_dev;
    int                             current_period_ns;
    int                             current_duty_ns;

    // for Vop voltage, unit is 10mv, Eg. the value -2315 means -23.15v, 
    // for vbat voltage, unit is mv, Eg. the value 3400 means 3.4v
    // for pvdd voltage, unit is mv, Eg. the value 7600 means 7.6v
    int                             current_set_voltage;
};

struct sensor {
    u16                             chipid;
    u32                             version_code;
    struct i2c_client               *sensor_i2c;
    spinlock_t                      sensor_lock;
    uint16_t                        otp_vbe25;
    uint16_t                        otp_vbd_low;        // unit is 10mv/0.01v
    uint16_t                        otp_vbd_high;        // unit is 10mv/0.01v
    uint16_t                        otp_adc_vref;
    u8                              otp_product_id[SWIFT_PRODUCT_ID_SIZE];
    uint16_t                        otp_K_high;
    uint16_t                        otp_T_high;
    uint16_t                        otp_K_low;
    uint16_t                        otp_T_low;
    uint32_t                        t_point_x100[SWIFT_VOP_ALGO_VER_CNT];
    u8                              vop_algo_version;

    struct i2c_client               *dvcc_regulator_i2c;    // for TPS62864

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
    #if defined(OPN7020_VCSEL_DRIVER_ENABLE)
    struct i2c_client               *vcsel_i2c; // for OPN7020
    #endif
    swift_spot_module_eeprom_data_t* eeprom_data;

#else
    struct i2c_client               *mcuctrl_i2c;           // for HC32L110B6YA
    u32                             mcuctrl_fw_version;
    bool                            swd_enable;
    bool                            force_enable_vcsel_4_pcm_mode;
    swift_flood_module_eeprom_data_t* eeprom_data;
#endif
    u32                             eeprom_capacity;       // unit is byte
    u32                             eeprom_page_size;       // unit is byte
    u32                             eeprom_data_size;       // sizeof(swift_spot_module_eeprom_data_t) or sizeof(swift_flood_module_eeprom_data_t)
    bool                            eeprom_data_crc_matched;
    bool                            static_data_ready;

#if defined(CALIB_DATA_READY_IN_EEPROM_CHIP)
    struct i2c_client               *eeprom_i2c;
#endif
    struct mutex                    misc_mutex;                  // mutex protect for misc device related callback
    u32                             client_id_4_misc;           // high 16 bits for process id, low 16 bits for thread id.
    struct task_struct              *client_task_4_misc;
    u8                              *mmap_buffer_base;
    u32                             mmap_buffer_max_size;       // This value should be a multiple of PAGE_SIZE (4096)
    u8                              roi_sram_data_to_write[ALL_ROISRAM_GROUP_SIZE];
    s64                             min_costtime_4_roisram_write;
    s64                             max_costtime_4_roisram_write;

    struct device                   *dev;
    struct miscdevice               misc_device;
    bool                            load_script;
    u8                              *loaded_sensor_reg_setting;   // loaded register setting buffer(struct setting_rvd array[]) for sensor config
    u16                             loaded_sensor_reg_setting_cnt;    // loaded register setting count for sensor config
    u8                              *loaded_vcsel_reg_setting;   // loaded register setting buffer(struct setting_rvd/setting_rvd16 array[]) for vcsel driver config
    u16                             loaded_vcsel_reg_setting_cnt;    // loaded register setting count for vcsel driver config
    u8                              *loaded_roi_sram;
    u32                             loaded_roi_sram_size;
    u32                             i2c_bus_freq_hz;
    u32                             dbg_ctrl;
    u8                              reset_mipi_4_streamon;
    u8                              force_sensor_role;
    struct dentry                   *debugfs_root;
    struct debugfs_blob_wrapper     calib_data_blob;
    struct dentry                   *debugfs_calib_data_blob;
    struct debugfs_blob_wrapper     loaded_roisram_data_blob;
    struct dentry                   *debugfs_loaded_roisram_data_blob;
    u8                              mipi_data_lanes;

#if defined(SENSOR_XCLK_FROM_SOC)
    struct clk                      *xvclk;
#endif
    struct gpio_desc                *reset_gpio;
    struct gpio_desc                *iovcc_en_gpio;
    struct gpio_desc                *dvcc_en_gpio;
#if defined(MINI_DEMO_BOX)
    struct gpio_desc                *avcc_en_gpio;
    struct gpio_desc                *drv_vcc_en_gpio;
    struct gpio_desc                *vbat_en_gpio;
    struct gpio_desc                *hw_target_id1_gpio; // M_DOT
    struct gpio_desc                *hw_target_id2_gpio; // M_ARRAY
    struct gpio_desc                *work_state_led_gpio; // LED-0603-GREEN on the new adaptor-board
#endif
    struct gpio_desc                *fsync_irq_gpio;
    struct gpio_desc                *drverr_irq_gpio;
#if defined(REGULATOR_ENABLE)
    struct regulator_bulk_data      supplies[SENSOR_NUM_SUPPLIES];
#endif

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    struct sensor_pwm               pwm_4_vbat;
#else
#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    struct sensor_pwm               pwm_4_pvdd;
#endif
#endif

#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    struct sensor_pwm               pwm_4_vop;
#endif

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    int                             fsync_irq;                  // frame sync interrupt

    u32                             fsync_irq_times;
    ktime_t                         first_fsync_irq_time;
    ktime_t                         last_fsync_irq_time;
    s64                             min_fsync_irq_gap;
    s64                             max_fsync_irq_gap;

    #if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
    struct workqueue_struct         *sensor_roiswitch_wq;
    struct work_struct              sensor_roiswitch_work;
    u32                             fsync_roi_swt_delay_ms;
    bool                            allow_roi_switch;
    u32                             roi_switch_req_times;
    u8                              cur_calib_sram_blk_idx;
    u8                              cur_calib_sram_data_group_idx;
    u8                              max_calib_sram_data_group_cnt;
    bool                            roi_sram_rolling;
    #endif
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
    int                             vcsel_drv_err_irq;                  // vcsel error handle interrupt

    u32                             vcsel_drv_err_irq_times;
#endif

    struct v4l2_subdev              subdev;
    struct media_pad                pad;
    struct v4l2_ctrl_handler        ctrl_handler;
    struct v4l2_ctrl                *ctrl_linkfreqency;
    struct v4l2_ctrl                *ctrl_pixelrate;
    struct v4l2_ctrl                *ctrl_exposure;
    struct v4l2_rect                crop;

    struct mutex                    mutex;

    ktime_t                         vop_adjust_delay;

    struct hrtimer                  vop_adjust_timer;
    struct workqueue_struct         *vop_adjust_wq;
    struct work_struct              vop_adjust_work;

    bool                            probe_success;
    bool                            power_on;
    u32                             power_on_times;
    bool                            vcsel_inited;
    bool                            test_pattern_enabled;
    bool                            streaming;
    ktime_t                         stream_start;

    u32                             client_id_4_sensor;         // high 16 bits for process id, low 16 bits for thread id.
    struct task_struct              *client_task_4_sensor;

    u32                             module_index;
    const char                      *module_facing;
    const char                      *module_name;
    const char                      *len_name;

    const struct sensor_mode        *cur_sensor_mode;
    u8                              tdc_delay_major;
    u8                              tdc_delay_minor;
    u8                              anchor_x;
    u8                              anchor_y;
    u8                              rowSearchingRange;
    u8                              colSearchingRange;
    u8                              coarseExposureCfg;
    u8                              fineExposureCfg;
    u8                              grayExposureCfg;
    u8                              laserExposurePeriodCfg;

    int                             cur_wkmode;
    u8                              cur_mtype;                  // current measurement type
    u8                              cur_etype;                  // current enviroment type
    u8                              cur_pmode;                  // current power mode
    u8                              cur_frtype;                 // current frame rate type, refer to AdapsFramerateType
    u8                              cur_vmode;                  // current vcsel mode
    u8                              cur_v_zone_cnt;             // current vcsel zone count

    u8                              cur_coarse_exposure_val;
    u8                              cur_gray_exposure_val;
    u8                              cur_fine_exposure_val;     // to be notified to algo lib
    u8                              cur_laser_exposure_period;  // to be notified to algo lib
    u32                             cur_temperature_x100;      // Eg. the value 2715 means 27.15 degree
    u32                             cur_vop_abs_x100;           // it is vop absolute value X 100, since the real vop is negative. Eg. the value 2405 means 24.05v
    s16                             force_vop_offset;          // unit is 10mv/0.01v, may include a minus sign.
    u32                             cur_pvdd_x100;              // it is pvdd value X 100. Eg. the value 760 means 7.60v
    u8                              force_mipi_tx_delay;        //for register 0xA9
    u16                             force_mipi_speed;           // unit is M bps
};

#define to_sensor(sd)       container_of(sd, struct sensor, subdev)


static const struct setting_rvd sensor_streamoff_regs[] = {
    {0xAB, 0x00, 0},
    {REG_NULL, 0x00, 0},
};

static const struct setting_rvd sensor_streamon_regs[] = {
    {0xAB, 0x01, 0},
#if defined(DISABLE_MIPI_LANES_UNTIL_STREAM_ON)
    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0X0A, 0x11, 0},   // enable clock lane and data lane0
    #else
        {0x0A, 0x13, 0},
    #endif
#endif
    {REG_NULL, 0x00, 0},
};

static const struct setting_rvd stream_on_with_mipi_reset_first[] = {
    {0xAE, 0x10, 0},
    {0xAB, 0x01, 0},
#if defined(DISABLE_MIPI_LANES_UNTIL_STREAM_ON)
    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0X0A, 0x11, 0},   // enable clock lane and data lane0
    #else
        {0x0A, 0x13, 0},
    #endif
#endif
    {REG_NULL, 0x00, 0},
};

static const struct setting_rvd stream_on_first_and_then_reset_mipi[] = {
    {0xAB, 0x01, 0},
    {0xAE, 0x10, 0},
#if defined(DISABLE_MIPI_LANES_UNTIL_STREAM_ON)
    #if (SENSOR_DATA_LANE_COUNT == 1)
        {0X0A, 0x11, 0},   // enable clock lane and data lane0
    #else
        {0x0A, 0x13, 0},
    #endif
#endif
    {REG_NULL, 0x00, 0},
};

static const struct setting_rvd sensor_reset_mipi_regs[] = {
    {0xAE, 0x10, 0},
    {REG_NULL, 0x00, 0},
};

static const s64 sensor_link_freq_items[] =
{
    SENSOR_LINK_FREQ
};

#if defined(REGULATOR_ENABLE)
static const char * const sensor_supply_names[] =
{
    "avdd",                         /* Analog power */
    "dovdd",                        /* Digital I/O power */
    "dvdd",                         /* Digital core power */
};

#define SENSOR_NUM_SUPPLIES ARRAY_SIZE(sensor_supply_names)
#endif

static const char *work_mode_name[]={
    SENSOR_MODE_NAME_PHR,
    SENSOR_MODE_NAME_GRAY,
    SENSOR_MODE_NAME_FHR,
};

static const char *environment_type_name[]={
    "Unknown",
    "Indoor",
    "Outdoor",
};

static const char *measurement_range_name[]={
    "Unknown",
    "Normal",
    "Short",
    "Full-distance",
};

static const char *power_mode_names[] =
{
    "Unknown",
    "Div1",
    "Div2",
    "Div3",
};

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)

static int sensor_vbat_pwm_convert_voltage_to_duty(struct sensor *sensor, u16 vbat_mv);
static int sensor_vbat_pwm_set_duty(struct sensor *sensor, int duty_ns);
static void sensor_vbat_pwm_enable(struct sensor *sensor);
static void sensor_vbat_pwm_disable(struct sensor *sensor);
static int sensor_set_vbat_voltage(struct sensor *sensor, u16 vbat_mv);
#else

#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
static int sensor_pvdd_pwm_convert_voltage_to_duty(struct sensor *sensor, u16 pvdd_mv);
static int sensor_pvdd_pwm_set_duty(struct sensor *sensor, int duty_ns);
static void sensor_pvdd_pwm_enable(struct sensor *sensor);
static void sensor_pvdd_pwm_disable(struct sensor *sensor);
static int sensor_set_pvdd_voltage(struct sensor *sensor, u16 pvdd_mv);
#endif

#endif

#if !defined(VOP_ADJUST_BY_BUILT_IN_MCU)
#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
static int sensor_vop_pwm_convert_voltage_to_duty(struct sensor *sensor, s16 vop_volt_x100);
static int sensor_vop_pwm_set_duty(struct sensor *sensor, int duty_ns);
static void sensor_vop_pwm_enable(struct sensor *sensor);
static void sensor_vop_pwm_disable(struct sensor *sensor);
static int set_vop_voltage(struct sensor *sensor, s16 vop_volt_x100);
#endif
#endif
static int sensor_timer_adjust_vop(struct sensor *sensor, bool first_read);
static int calc_frequency(struct sensor *sensor, char *out_buf, int max_length);

#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
static int sensor_switch_roi_sram(struct sensor *sensor, bool firstWriteSRAM);
#endif
static int sensor_write_sramdata(struct sensor * sensor);
static int sensor_framerate_setting(struct sensor * sensor);
static int sensor_write_tdc_delay_setting(struct sensor * sensor);
static int sensor_update_setting(
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsMeasurementType mtype,
    AdapsVcselZoneCountType vcselzonecount_type,
    AdapsVcselMode vmode);
static int sensor_read_module_static_data(struct sensor *sensor);
static int sensor_write_sram_register(struct sensor * sensor, u8 reg, u32 length, u8 *buffer, int callline);

/* pixel rate = link frequency * 2 * lanes / BITS_PER_SAMPLE */
static u64 __maybe_unused to_pixel_rate(int data_lane_cnt)
{
    u64 pixel_rate = SENSOR_LINK_FREQ * 2LL * data_lane_cnt;

    do_div(pixel_rate, SENSOR_BITS_PER_SAMPLE);

    return pixel_rate;
}

static int __maybe_unused printk_2_cur_console(const char *msg, bool append_lfrt) {
    struct tty_struct *my_tty;

    my_tty = get_current_tty();

    if (my_tty != NULL) {
        (my_tty->driver->ops->write) (my_tty, msg, strlen(msg));

        if (append_lfrt)
            (my_tty->driver->ops->write) (my_tty, "\015\012", 2); // \r\n
    }

    return 0;
}

static void __maybe_unused printk2console(const char *fmt, ...)
{
#define MAX_LINE_LENGTH_4_CUSTOM_PRINTK 512

    char buf[MAX_LINE_LENGTH_4_CUSTOM_PRINTK];
    va_list ap;
    int n;

    va_start(ap, fmt);
    n = vscnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    printk_2_cur_console(buf, true);

    return;
}

static void __maybe_unused print2console_nolfrt(const char *fmt, ...)
{
#define MAX_LINE_LENGTH_4_CUSTOM_PRINTK 512
    
        char buf[MAX_LINE_LENGTH_4_CUSTOM_PRINTK];
        va_list ap;
        int n;
    
        va_start(ap, fmt);
        n = vscnprintf(buf, sizeof(buf), fmt, ap);
        va_end(ap);
    
        printk_2_cur_console(buf, false);
    
        return;
}

static void printk_multilines(char *buffer, int length)
{
    int len;
    char *start = buffer;
    char *end = buffer;
    char temp[128];  // Temporary buffer. Assume a line has at most 128 characters. Adjust the size according to the actual situation.

    while (end - buffer < length) {
        // Find the end position of a line
        while (*end!= '\n' && end - buffer < length) {
            end++;
        }

        // Copy the current line to the temporary buffer and add '\0'
        len = end - start;
        if (len > sizeof(temp) - 1) {
            len = sizeof(temp) - 1;
        }
        memcpy(temp, start, len);
        temp[len] = '\0';

        // Output the current line
        printk(KERN_ERR "%s\n", temp);

        // Move to the start of the next line
        if (end - buffer < length) {
            end++;
            start = end;
        }
    }
}

bool IsASCII(const unsigned char c)
{
    bool ret = false;

    if (c >= 32 && c < 128)
        ret = true;

    return ret;
}

void hexdump(const unsigned char * buf, int buf_len, const char * title)
{
    int             i, j, k;
    const int       NoPerLine = 16;
    char            line_buf[100];
    int             line_len;

    if (NULL == buf) {
        DBG_ERROR("Null pointer");
        return;
    }

    if (NULL != title) {
        DBG_PRINTK("-------%s--------\n", title);
    }

    for (i = 0; i <= buf_len / NoPerLine; i++) {
        memset(line_buf, 0, sizeof(line_buf));
        line_len = 0;

        for (j = 0; j < NoPerLine; j++) {
            k = i * NoPerLine + j;

            if (k >= buf_len)
                break;

            line_len += sprintf(line_buf + line_len, "%02x,", buf[k]);
        }

        line_len += sprintf(line_buf + line_len, "%s", "    ");

        for (j = 0; j < NoPerLine; j++) {
            k = i * NoPerLine + j;

            if (k >= buf_len)
                break;

            if (IsASCII(buf[k]))
            {
                line_len += sprintf(line_buf + line_len, "%c", buf[k]);
            }
            else {
                line_len += sprintf(line_buf + line_len, "%c", '.');
            }
        }

        DBG_PRINTK("[%4d] %s\n", i * NoPerLine, line_buf);
    }
}

static void __maybe_unused dump_a_gpio(struct gpio_desc *gpiodesc, char *gpio_func, int callline)
{
    u8 val;
    u8 raw_val;
    int dir;
    int activeLow;
    int gpio_no;
    int cansleep;
    char gpioFunc[][5] = {
        "Out",
        "In"
    };
    char activeLowType[][5] = {
        "No",
        "Yes"
    };

    if (NULL == gpiodesc)
        return;

    gpio_no = desc_to_gpio(gpiodesc);
    val = gpiod_get_value_cansleep(gpiodesc);
    raw_val = gpiod_get_raw_value_cansleep(gpiodesc);
    cansleep = gpiod_cansleep(gpiodesc);
    dir = gpiod_get_direction(gpiodesc); 
    activeLow = gpiod_is_active_low(gpiodesc); 
    printk2console("dump_a_gpio() requested from line:%d", callline);
    printk2console("GPIO num     Dir      Value      ActiveLow       Function(can sleep?)");
    printk2console("---------------------------------------------------------------------");
    printk2console(" %03d         %-3s        %d(%d)       %-3s            %s(%s)\n",
        gpio_no, 
        -ENOTSUPP == dir ? "NotSupp" : gpioFunc[dir],
        val, raw_val, activeLowType[activeLow], gpio_func,
        0 == cansleep ? "No" : "Yes"
        );
}

static int create_eeprom_blob_file(struct sensor *sensor, struct dentry *parent, unsigned char *buf_to_map, int size_to_map, char *blob_filename)
{
    sensor->calib_data_blob.data = buf_to_map;
    sensor->calib_data_blob.size = size_to_map;

    sensor->debugfs_calib_data_blob = debugfs_create_blob(blob_filename, 0644, parent, &sensor->calib_data_blob);
    if (!sensor->debugfs_calib_data_blob) {
        DBG_ERROR("Fail to create_debug_blob_file:%s...", blob_filename);
        return -EIO;
    }

    return 0;
}

static int create_loaded_roisram_blob_file(struct sensor *sensor, struct dentry *parent, unsigned char *buf_to_map, int size_to_map, char *blob_filename)
{
    if (sensor->debugfs_loaded_roisram_data_blob) // delete the old one if exist already
    {
        debugfs_remove(sensor->debugfs_loaded_roisram_data_blob);
        sensor->debugfs_loaded_roisram_data_blob = NULL;
    }

    sensor->loaded_roisram_data_blob.data = buf_to_map;
    sensor->loaded_roisram_data_blob.size = size_to_map;

    sensor->debugfs_loaded_roisram_data_blob = debugfs_create_blob(blob_filename, 0644, parent, &sensor->loaded_roisram_data_blob);
    if (!sensor->debugfs_loaded_roisram_data_blob) {
        DBG_ERROR("Fail to create_debug_blob_file:%s...", blob_filename);
        return -EIO;
    }

    return 0;
}

static void common_delay(u32 ns)
{
    if (ns < 10) //(!ns)
        return;

    if (ns <= 1000) {
        ndelay(ns);
    } else {
        u32 us = DIV_ROUND_UP(ns, 1000);

        if (us <= 10)
            udelay(us);
        else
            usleep_range(us, us + DIV_ROUND_UP(us, 10));
    }
}

#if defined(SAVE_ROISRAM_DATA_TO_FILE)
static ssize_t save_buffer_to_file(const unsigned char *buffer, size_t size, const char *path)
{
    struct file *fp;
    loff_t pos;
    ssize_t ret;

    fp = filp_open(path, O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        DBG_ERROR("Failed to create file %s", path);
        return PTR_ERR(fp);
    }

    pos = 0;
    // kernel_write() already include "set_fs(KERNEL_DS);"
    // please refer to fs\read_write.c
    ret = kernel_write(fp, buffer, size, &pos);
    filp_close(fp, NULL);

    return ret;
}
#endif

// When any error occurs, the function will return a negative number.
static int eeprom_read(struct sensor *priv, unsigned int offset, size_t bytes, u8 *outbuf)
{
    int ret = 0;

#if defined(CALIB_DATA_READY_IN_EEPROM_CHIP)
    struct i2c_client *client = priv->eeprom_i2c;
    u8 reg_addr[2];
    int i,times,cur_len;
    unsigned int cur_offset = offset;
    int remaining_len = bytes;
    const int max_bytes_per_time = MAX_BYTES_PER_EEPROM_READ; // On rk3588, both 4096 and 8 work well. david@2023/07/17
    struct i2c_msg msgs[] = {
        {
            .flags    = 0,
            .addr = client->addr,
            .len    = sizeof(reg_addr),
            .buf    = reg_addr
        },
        {
            .flags    = I2C_M_RD,
            .addr = client->addr,
        }
    };

    if ((offset+bytes) > priv->eeprom_capacity)
        return -EINVAL;

    times = (bytes + (max_bytes_per_time -1))/max_bytes_per_time;

    for (i = 0; i < times; i++) {
        reg_addr[0] = (cur_offset >> 8) & 0xff;
        reg_addr[1] = cur_offset & 0xff;

        if (remaining_len > max_bytes_per_time)
            cur_len = max_bytes_per_time;
        else
            cur_len = remaining_len;
        msgs[1].len = cur_len;
        msgs[1].buf = &outbuf[bytes-remaining_len];

        ret = i2c_transfer(client->adapter, msgs, ARRAY_SIZE(msgs));

#if !defined(IGNORE_REAL_COMMUNICATION)
        if (ret != ARRAY_SIZE(msgs))
        {
            DBG_ERROR( "i2c_transfer failed ret:%d when read eeprom, ,msgs[1].len:%d,bytes:%ld", ret,msgs[1].len,bytes);
            break;
        }
#endif

        remaining_len -= cur_len;
        cur_offset += cur_len;
    }

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret != ARRAY_SIZE(msgs)) {
        return ret < 0 ? ret : -EIO;
    }
#else
    ret = 0;
#endif

#else

    if (sizeof(sample_eeprom_data) < (offset + bytes))
    {
        DBG_ERROR("Your request is out of range of the sample eeprom.\n");
        return -EIO;
    }

    memcpy(outbuf, sample_eeprom_data + offset, bytes);
#endif

    return ret;
}

// sensor_reg_write_hook is used to save a register value, or change a register value at last second before real register write for some special requirement!
static int sensor_reg_write_hook(struct sensor *sensor, u8 reg_addr, u8 org_cfg, u8 *final_cfg)
{
    int rc = 0;

    switch (reg_addr)
    {
        default:   // for most registers, no change!
            *final_cfg = org_cfg;
            break;

        case 0xBC:
            *final_cfg = org_cfg;
            sensor->cur_laser_exposure_period = org_cfg;
            break;

        case 0xBF:
            *final_cfg = org_cfg;
            sensor->cur_coarse_exposure_val = org_cfg;
            break;

        case 0xC0:
            *final_cfg = org_cfg;
            sensor->cur_fine_exposure_val = org_cfg;
            break;

        case 0XC2:
            *final_cfg = org_cfg;
            sensor->cur_gray_exposure_val = org_cfg;
            break;

    }

    return rc;
}

// When any error occurs, the function will return a negative number.
static int i2c_dev_burst_write_reg(struct sensor *sensor, struct i2c_client *client, u8 reg_addr, const u8 *data, const u32 len)
{
    int             ret;
    u8 *            buf;
    struct i2c_msg msg;

    if (NULL == client) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg_addr, len);
        return -EINVAL;
    }

    if (NULL == data) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg_addr, len);
        return -EINVAL;
    }

    buf                 = kmalloc((sizeof(unsigned char) * (len + 1)), GFP_KERNEL);
    if (!buf) {
        DBG_ERROR("kmalloc failure");
        return -ENOMEM;
    }

    buf[0]              = reg_addr;
    if (1 == len && client == sensor->sensor_i2c)
    {
        sensor_reg_write_hook(sensor, reg_addr, *data, &buf[1]);
    }
    else {
        memcpy(&buf[1], data, len);
    }

    msg.addr            = client->addr;
    msg.flags           = I2C_M_WR;
    msg.buf             = buf;
    msg.len             = len + 1;

    ret = i2c_transfer(client->adapter, &msg, 1);
    if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
    {
        if (1 == len)
        {
            TRACE_REG_RW("Write reg:0x%02x to 0x%02x for i2c device(0x%x) %s...", reg_addr, *data, client->addr, 1 == ret ? "SUCCESS": "FAILURE");
        }
        else {
            TRACE_REG_RW("Burst write reg:0x%02x data length:%d for i2c device(0x%x) %s...", reg_addr, len, client->addr, 1 == ret ? "SUCCESS": "FAILURE");
        }
    }

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret != 1) {
        DBG_ERROR("i2c_transfer failed, ret:%d when write buffer to i2c device:0x%x reg:0x%0x", 
            ret,
            client->addr,
            reg_addr);
        kfree(buf);
        return -EIO;
    }
#endif

    kfree(buf);

    return 0;
}

// When any error occurs, the function will return a negative number.
static int i2c_dev_write_reg_list(struct sensor *sensor, struct i2c_client *client, const struct setting_rvd *reglist)
{
    u32     i;
    int     ret = 0;
    u8      data[2];
    struct  i2c_msg msg;

    if (NULL == client) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    if (NULL == reglist) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    msg.addr            = client->addr;
    msg.flags           = I2C_M_WR;
    msg.buf             = data;
    msg.len             = 2;

    for (i = 0; reglist[i].reg != REG_NULL; i++) {
        data[0]         = reglist[i].reg;

        if (client == sensor->sensor_i2c)
        {
            sensor_reg_write_hook(sensor, reglist[i].reg, reglist[i].val, &data[1]);
        }
        else {
            data[1] = reglist[i].val;
        }
        ret = i2c_transfer(client->adapter, &msg, 1);

#if !defined(IGNORE_REAL_COMMUNICATION)
        if (ret < 0) {
            DBG_ERROR("i2c_transfer failed, ret:%d when write reg[%d]:0x%04x for i2c device:0x%x", ret, i, reglist[i].reg, client->addr);
            return ret;
        }
#endif

        if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
        {
            TRACE_REG_RW("Write No:%d reg(0x%02X) to 0x%02X for i2c device:0x%X %s...", i, reglist[i].reg, reglist[i].val, client->addr, 1 == ret ? "SUCCESS": "FAILURE");
        }
        if (reglist[i].delayUs)
        {
            usleep_range(reglist[i].delayUs, reglist[i].delayUs + DIV_ROUND_UP(reglist[i].delayUs, 10));
            if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_WRITE)
            {
                TRACE_REG_RW("Delay %d us after Write No:%d reg(0x%02X) to 0x%02X for i2c device:0x%x...", reglist[i].delayUs, i, reglist[i].reg, reglist[i].val, client->addr);
            }
        }
    }

    return 0;
}

// When any error occurs, the function will return a negative number.
static int __maybe_unused i2c_dev_burst_read_reg(struct sensor *sensor, struct i2c_client * client, u8 reg, u8 *buf, int len)
{
    int ret = 0;
    char regAddr[1];
    struct i2c_msg msg[2] = {
        {
            .addr = client->addr,
            .flags = I2C_M_WR,
            .len = sizeof(reg),
            .buf = regAddr,
        },
        {
            .addr = client->addr,
            .flags = I2C_M_RD,
            .len = 0,
            .buf = NULL,
        }
    };

    if (NULL == client || NULL == buf) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    regAddr[0] = reg;
    msg[1].len = len;
    msg[1].buf = &buf[0];

    ret = i2c_transfer(client->adapter, msg, 2);

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret < 0) {
        DBG_ERROR("i2c_transfer failed, ret:%d when read i2c device:0x%x reg:0x%0x", 
            ret,
            client->addr,
            reg);
    }
    else 
#else
    ret = 0;
#endif
    {
        if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_READ)
        {
            if (1 == len)
            {
                TRACE_REG_RW("<REGS_READ> i2c read reg:0x%04x for i2c device:0x%x, return data 0x%02x, ret:%d...", reg, client->addr, *buf, ret);
            }
            else {
                TRACE_REG_RW("<REGS_READ> i2c burst read reg:0x%04x for i2c device:0x%x, data length:%d, ret:%d...", reg, client->addr, len, ret);
            }
        }
    }

    return ret;
}

// When any error occurs, the function will return a negative number.
static int __maybe_unused i2c_dev_burst_read_reg16(struct sensor *sensor, struct i2c_client * client, u16 reg, u8 *buf, int len)
{
    int ret = 0;
    u8 regbuf[2];
    struct i2c_msg msg[2] = {
        {
            .addr = client->addr,
            .flags = I2C_M_WR,
            .len = sizeof(regbuf),
            .buf = regbuf,
        },
        {
            .addr = client->addr,
            .flags = I2C_M_RD,
            .len = 0,
            .buf = NULL,
        }
    };

    if (NULL == client || NULL == buf) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    regbuf[0] = (reg >> 8) & 0xff;
    regbuf[1] = reg & 0xff;
    msg[1].len = len;
    msg[1].buf = &buf[0];

    ret = i2c_transfer(client->adapter, msg, 2);

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret < 0) {
        DBG_ERROR("i2c_transfer failed, ret:%d when read i2c device:0x%x reg:0x%0x", 
            ret,
            client->addr,
            reg);
    }
    else
#else
    ret = 0;
#endif
    {
        if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_READ)
        {
            if (1 == len)
            {
                TRACE_REG_RW("<REGS_READ> i2c read reg:0x%04x for i2c device:0x%x, return data 0x%02x, ret:%d...", reg, client->addr, *buf, ret);
            }
            else {
                TRACE_REG_RW("<REGS_READ> i2c burst read reg:0x%04x for i2c device:0x%x, data length:%d, ret:%d...", reg, client->addr, len, ret);
            }
        }
    }

    return ret;
}

/* Read registers up to 4 bytes at a time */
// When any error occurs, the function will return a negative number.
static int i2c_dev_read_reg(struct sensor *sensor, struct i2c_client * client, u8 reg, unsigned int len, u32 *val)
{
    struct i2c_msg msgs[2];
    u8              *data_be_p;
    __be32          data_be = 0;
    int             ret;

    if (NULL == sensor) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg, len);
        return -EINVAL;
    }

    if (NULL == client) {
        DBG_ERROR("Null pointer detected when try to write reg: 0x%x, len: %d...", reg, len);
        return -EINVAL;
    }

    if (len > 4 || !len)
    {
        DBG_ERROR("Invalid length, len:%d", len);
        return - EINVAL;
    }

    data_be_p           = (u8 *) &data_be;

    /* Write register address */
    msgs[0].addr        = client->addr;
    msgs[0].flags       = I2C_M_WR;
    msgs[0].len         = sizeof(reg);
    msgs[0].buf         = (u8 *) &reg;

    /* Read data from register */
    msgs[1].addr        = client->addr;
    msgs[1].flags       = I2C_M_RD;
    msgs[1].len         = len;
    msgs[1].buf         = &data_be_p[4 - len];

    ret = i2c_transfer(client->adapter, msgs, ARRAY_SIZE(msgs));

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (ret != ARRAY_SIZE(msgs))
    {
        DBG_ERROR("i2c_transfer failed, ret:%d when read i2c device:0x%x reg:0x%0x, len:%d", 
            ret,
            client->addr,
            reg,len);
        return -EIO;
    }
    else
#endif
    {
        *val = be32_to_cpu(data_be);

        if (sensor->dbg_ctrl & ADAPS_DBG_TRACE_REGS_READ)
        {
            TRACE_REG_RW("<REGS_READ> i2c burst read sensor reg:0x%04x read length:%d, returned data: 0x%x ret:%d...", reg, len, *val, ret);
        }
    }

    return 0;
}

static int sensor_read_reg(struct sensor *sensor, u16 reg, unsigned int len, u32 *val)
{
    return i2c_dev_read_reg(sensor, sensor->sensor_i2c, reg, len, val);
}

static int sensor_burst_write_reg(struct sensor *sensor, u16 reg, const u8 *data, const u32 len)
{
    return i2c_dev_burst_write_reg(sensor, sensor->sensor_i2c, reg, data, len);
}

static int sensor_write_reg_list(struct sensor *sensor, const struct setting_rvd *reglist, int callline)
{
    return i2c_dev_write_reg_list(sensor, sensor->sensor_i2c, reglist);
}

static int sensor_write_reg_8bit_value(struct sensor *sensor, u16 reg, const u8 val8)
{
    return i2c_dev_burst_write_reg(sensor, sensor->sensor_i2c, reg, &val8, 1);
}

static int sensor_burst_read_reg(struct sensor *sensor, u8 reg, char *buf, int len)
{
    return i2c_dev_burst_read_reg(sensor, sensor->sensor_i2c, reg, buf, len);
}

static int sensor_read_reg_8bit_value(struct sensor *sensor, u16 reg, u8 *val8)
{
    return i2c_dev_burst_read_reg(sensor, sensor->sensor_i2c, reg, val8, 1);
}

static int sensor_ready_check(struct sensor *sensor)
{
    int ret = 0;
    u32 id  = 0;
    s64 us_delta;
    u32 delay_us;
    ktime_t start;

    delay_us = SENSOR_READY_CHECK_BASE_DELAY;
    usleep_range(delay_us, delay_us+100);
    DBG_INFO("<%s> start to read chip id.\n", __FUNCTION__);
    start = ktime_get();

    delay_us = SENSOR_READY_CHECK_INRERVAL;
    do {
        ret = sensor_read_reg(sensor, SENSOR_REG_CHIP_ID, 2, &id);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (ret >= 0) {
            if (id != CHIP_ID && id != CHIP_ID_VER2) {
                DBG_ERROR("Unexpected sensor id(%06x), ret(%d)\n", id, ret);
                return -ENODEV;
            }
            DBG_NOTICE("sensor is ready, already wait %lld us, ret: %d, chip id: 0x%x\n", us_delta, ret, id);
            ret = 0;
            break;
        }

        if (SENSOR_READY_CHECK_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to sensor ready, already wait %lld us.\n", us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(delay_us, delay_us+100);
    } while (1);

    return ret;
}

static int sensor_set_dvcc_voltage(struct sensor *sensor)
{
    int ret=0;
    u8 reg, val;

    reg = TPS62864_REG_VOUT1;
    val = TPS62864_REG_VOUT1_VAL;
    ret = i2c_dev_burst_write_reg(sensor, sensor->dvcc_regulator_i2c, 
        reg,
        &val,
        1);
    if (ret < 0) {
        DBG_ERROR("fail to write dvcc_regulator register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = TPS62864_REG_VOUT2;
    val = TPS62864_REG_VOUT2_VAL;
    ret = i2c_dev_burst_write_reg(sensor, sensor->dvcc_regulator_i2c, 
        reg,
        &val,
        1);
    if (ret < 0) {
        DBG_ERROR("fail to write dvcc_regulator register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    return ret;
}

static int __maybe_unused sensor_read_otp_word(struct sensor *sensor, u8 offset, u16 *pusData)
{
#define SWIFT_OTP_ADDR_REG       0xEA
#define SWIFT_OTP_DATAH_REG      0xEB
#define SWIFT_OTP_DATAL_REG      0xEC
#define SWIFT_OTP_CTRL_REG       0xED

    int ret = 0;
    u8  val;
    uint16_t reg;
    uint16_t val16;

    if (false == sensor->power_on)
    {
        DBG_ERROR("Sensor register can't be read/writen when rx power off\n");
        return -EPERM;
    }

    reg = SWIFT_OTP_CTRL_REG;
    val = 0x40;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret < 0) {
        return ret;
    }

    reg = SWIFT_OTP_ADDR_REG;
    val = offset;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret < 0) {
        return ret;
    }

    reg = SWIFT_OTP_CTRL_REG;
    val = 0x41;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret < 0) {
        return ret;
    }
    msleep(1);

    ret = sensor_read_reg_8bit_value(sensor, SWIFT_OTP_DATAH_REG, &val);
    if (ret < 0) {
        return ret;
    }
    val16 = val << 8;

    ret = sensor_read_reg_8bit_value(sensor, SWIFT_OTP_DATAL_REG, &val);
    if (ret < 0) {
        return ret;
    }
    val16 = val16 | val;
    *pusData = val16;

    DBG_INFO("sensor otp data[%02x]: 0x%04x\n", offset, val16);

    return ret;
}

static int sensor_modify_reg(struct setting_rvd *register_lst, u8 reg_addr, u8 new_val)
{
    int i;
    int ret = -1;

    if (NULL == register_lst) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    for (i = 0; register_lst[i].reg != REG_NULL; i++) {
        if (reg_addr == register_lst[i].reg)
        {
            ret = 0;
            break;
        }
    }

    if (0 == ret)
        register_lst[i].val = new_val;

    return ret;
}

static bool sensor_reg_is_ignorable(u8 regAddr, bool noSkip)
{
//#define IGNORE_DONT_CARE_REG_DUMP

#if defined(IGNORE_DONT_CARE_REG_DUMP)
    int i;
    u8 reg2ignore[] = {
            0x02, 0x03, 0x0d, 0x0e, 0x0f,
            0x15,0x16,0x17, 0x1a,0x1b,0x1c,0x1d,0x1e,0x1f,
            0x22,0x23,0x24,0x25,0x26,0x27,  0x2a,0x2b,0x2c,0x2d,0x2e,0x2f,
            0x31, 0x36, 0x39,0x3a,0x3b,0x3d,
            0x54,0x55,0x56,0x57,0x58,0x59,0x5a,0x5b,0x5c,0x5d,0x5e,0x5f,
            0x9c,0x9d,0x9e,0x9f,

// some read-only registers
            0xad,
            0xc3,0xc4,
            0xe0,0xe1,0xee
        };

    if (true == noSkip)
        return false;

    for (i = 0; i < sizeof(reg2ignore); i++)
    {
        if (regAddr == reg2ignore[i])
            return true;
    }
#endif

    return false;
}

static void printout_2_select_target(char *buf, bool out_2_console)
{
    if (out_2_console)
    {
        printk2console("%s", buf);
    }
    else {
        DBG_PRINTK("%s", buf);
    }
}

static int sensor_output_tof_sensor_reg(struct sensor *sensor, char *buf, u8 regBuf[], bool noSkip, bool out_2_console, const char * callfunc, int callline)
{
    u8 reg,startAddr = 0;
    int i,j;
    int buf_len = 0;

    buf_len += sprintf(buf+buf_len, "===================================================================");
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;
    buf_len += sprintf(buf, "%s Register Dump, called from <%s> Line: %d", SENSOR_NAME, callfunc, callline);
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;
    buf_len += sprintf(buf+buf_len, "--MIPI CSI: 0x00--0x5F, MIPI D-PHY: 0x60--0x9F, CSRU: 0xA0--0xEF---");
    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    buf_len += sprintf(buf+buf_len, "---");

    for (i=0; i< 0x10; i++)
    {
        buf_len += sprintf(buf+buf_len, "---%x",i);
    }

    printout_2_select_target(buf, out_2_console);
    buf_len = 0;

    for (i=0; i< 0xf; i++)
    {
        buf_len += sprintf(buf+buf_len, "%x0:",i);
        for (j=0; j< 0x10; j++)
        {
            reg = (i << 4) | j;

            if ((startAddr <= reg && 0xef >= reg))
            {
                if (false == sensor_reg_is_ignorable(reg, noSkip))
                {
                    buf_len += sprintf(buf+buf_len, "  %02X",regBuf[reg]);
                }
                else {
                    buf_len += sprintf(buf+buf_len, "  XX");
                }
            }
            else {
                buf_len += sprintf(buf+buf_len, "  --");
            }
        }
        printout_2_select_target(buf, out_2_console);
        buf_len = 0;
    }
    buf_len = 0;
    buf_len += sprintf(buf+buf_len, "===================================================================");
    printout_2_select_target(buf, out_2_console);

    return buf_len;
}

static int sensor_reg_dump(struct sensor *sensor, bool noSkip, bool out_2_console, const char * callfunc, int callline)
{
    int i;
    char *buf;
    u8 reg;
    u8 val;
    int rc = 0;
    u8 regBuf[256] = {0};
    int buf_len = 0;

    buf = kzalloc(PAGE_SIZE, GFP_KERNEL);
    if (!buf)
    {
        return -ENOMEM;
    }

    // read all register in advance, since we may need output twice, one for printk, another for write file.
    for (i=0; i< 0xf0; i++)
    {
        reg = i;
        rc = sensor_read_reg_8bit_value(sensor, reg, &val);
        regBuf[i] = val;
    }

    buf_len = sensor_output_tof_sensor_reg(sensor,buf, regBuf, noSkip, out_2_console, callfunc, callline);

    kfree(buf);
    buf = NULL;
    return buf_len;
}

static int __maybe_unused tps62864_reg_dump(struct sensor *sensor, bool out_2_console)
{
    u16 reg;
    int rc = 0;
    uint8_t val_reg1 = 0;
    uint8_t val_reg2 = 0;
    uint8_t val_reg3 = 0;
    uint8_t val_reg5 = 0;
    char buf[64];

    reg = TPS62864_REG_VOUT1;
    rc = i2c_dev_burst_read_reg(sensor, sensor->dvcc_regulator_i2c, reg, &val_reg1, 1);
    if (rc < 0) {
        DBG_ERROR("Fail to read tps62864_reg: 0x%x, ret:%d", reg, rc);
    }

    reg = TPS62864_REG_VOUT2;
    rc = i2c_dev_burst_read_reg(sensor, sensor->dvcc_regulator_i2c, reg, &val_reg2, 1);
    if (rc < 0) {
        DBG_ERROR("Fail to read tps62864_reg: 0x%x, ret:%d", reg, rc);
    }

    reg = TPS62864_REG_CONTROL;
    rc = i2c_dev_burst_read_reg(sensor, sensor->dvcc_regulator_i2c, reg, &val_reg3, 1);
    if (rc < 0) {
        DBG_ERROR("Fail to read tps62864_reg: 0x%x, ret:%d", reg, rc);
    }

    reg = TPS62864_REG_STATUS;
    rc = i2c_dev_burst_read_reg(sensor, sensor->dvcc_regulator_i2c, reg, &val_reg5, 1);
    if (rc < 0) {
        DBG_ERROR("Fail to read tps62864_reg: 0x%x, ret:%d", reg, rc);
    }

    printout_2_select_target("========TPS62864 Register Dump===========", out_2_console);

    sprintf(buf, "  REG_VOUT1:    0x%02x", val_reg1);
    printout_2_select_target(buf, out_2_console);
    sprintf(buf, "  REG_VOUT2:    0x%02x", val_reg2);
    printout_2_select_target(buf, out_2_console);
    sprintf(buf, "  REG_CONTROL:  0x%02x", val_reg3);
    printout_2_select_target(buf, out_2_console);
    sprintf(buf, "  REG_STATUS:   0x%02x", val_reg5);
    printout_2_select_target(buf, out_2_console);

    printout_2_select_target("====================================", out_2_console);

    return 0;
}

// refer to AD-819: https://www.teambition.com/project/5f643ef2ab08650044e81637/tasks/view/6486c42c3dd88d510ed0a13c/task/64c9ad6ddb11f84bbc6408b4
// the output raw data for test pattern may be different according the different system clock setting.
static int sensor_testpattern_enable(struct sensor *sensor)
{
    int ret = 0;
    u8 reg, val;

    if (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)
    {
        reg = 0xDF;
        ret = sensor_read_reg_8bit_value(sensor, reg, &val);
        if (ret) {
            DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n",reg, ret);
            return ret;
        }
        val = val | 0x08;
        ret = sensor_write_reg_8bit_value(sensor, reg, val);
        if (ret) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
        sensor->test_pattern_enabled = true;
    }

    return ret;
}

#if defined(ROISRAM_ANCHOR_PREPROCCESS_ENABLE)
static void sensor_roisram_anchor_preproccess(struct sensor * sensor, u8 *roisram_buf, uint32_t roisram_buf_size)
{
    // Calculate the top-left corner of the spot.
    // if spod size is 8 * 3, then rowOffset = 1, colOffset = 5.
    u8 rowOffset = sensor->anchor_y;
    u8 colOffset = sensor->anchor_x;
    int i;

    if ((0 == rowOffset) && (0 == colOffset))
        return; // nothing to do

    for (i = 0; i < roisram_buf_size;) {
      if (roisram_buf[i] > rowOffset) {
        roisram_buf[i] -= rowOffset;
      }
      if (roisram_buf[i + 1] > colOffset) {
        roisram_buf[i + 1] -= colOffset;
      }
      i += 2;
    }
}
#endif

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    #include "ads6401_flood.c"
#else
    #include "ads6401_spot.c"
#endif

static const struct sensor_mode sensor_wkmode[] =
{
    // PHR mode 1032x32
    {
        .width              = 1032,
        .height             = 32,
        .max_fps            = {
            .numerator          = 10000,
            .denominator        = 300000,
        },
        .exp_def            = 0x3c,
        .wkmode_reg_cfg_list           = sensor_phr_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_phr_regs),
    },
    // PCM mode 2560x32
    {
        .width              = 2560,
        .height             = 32,
        .max_fps            = {
            .numerator          = 100000,
            .denominator        = 300000,
        },
        .exp_def            = 0xFF,
        .wkmode_reg_cfg_list           = sensor_pcm_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_pcm_regs),
    },
    // FHR mode 4104x32
    {
        .width              = 4104,
        .height             = 32,
        .max_fps            = {
            .numerator          = 10000,
            .denominator        = 300000,
        },
        .exp_def            = 0x3c,
        .wkmode_reg_cfg_list           = sensor_fhr_regs,
        .wkmode_reg_cfg_count      = ARRAY_SIZE(sensor_fhr_regs),
    },
};

#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
/*
    ---swift rk3568转接板适配Vop电压控制PWM计算方法---

    PWM频率10KHz，占空比0.1%可调，调节精度±30mV

    Vfb = Duty_pwm × 1.229 V
    Vop = -Vfb x ( Ra / Rb ) - 0.65 V

    Ra = 24K
    Rb = 1K

    Here, vop should be a negative float number with two decimal places, and the unit is volt.

    Vop = Duty_pwm × (-1.229V x ( 24 ) / 1) - 0.65
         = Duty_pwm x (-1.229V x 24) - 0.65V
         = Duty_pwm x (-29.496) - 0.65

    Duty_pwm = (Vop + 0.65)/-29.496
             = (Vop*100 +65)/-2950

    Duty-pwm% = (vop_volt_x100*100 +6500)/-2950

    expected_duty_permillage = (vop_volt_x100*100 +6500)/-295
*/
static int sensor_vop_pwm_convert_voltage_to_duty(struct sensor *sensor, s16 vop_volt_x100)
{
    int duty_ns = 0;
    int expected_duty_permillage;
    int duty_permillage_min = 0;
    int duty_permillage_max = PWM_VOLTAGE_ADJUST_STEPS; //pwm adjust step is 1/1000
    uint32_t vop_volt_x100_abs = abs(vop_volt_x100);

    expected_duty_permillage = (vop_volt_x100*100 +6500)/(-295);
    duty_ns = (expected_duty_permillage * sensor->pwm_4_vop.current_period_ns) / (duty_permillage_max - duty_permillage_min);

    DBG_INFO("VOP expected_duty_permillage %d/1000, duty_ns: %d ns for Vop voltage: -%d.%02d V.", 
        expected_duty_permillage,
        duty_ns, vop_volt_x100_abs / 100, vop_volt_x100_abs % 100
    );

    return duty_ns;
}

static int sensor_vop_pwm_set_duty(struct sensor *sensor, int duty_ns)
{
    int ret;

    if (duty_ns < 0 || duty_ns > sensor->pwm_4_vop.current_period_ns)
    {
        DBG_ERROR("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_vop.current_period_ns);
        return -EINVAL;
    }

    ret = pwm_config(sensor->pwm_4_vop.pwm_dev, duty_ns, sensor->pwm_4_vop.current_period_ns);
    if (ret) {
        DBG_ERROR("Failed to configure PWM, duty: %d ns, period: %d ns", duty_ns, sensor->pwm_4_vop.current_period_ns);
        return ret;
    }
    sensor->pwm_4_vop.current_duty_ns = duty_ns;

    return ret;
}

static void sensor_vop_pwm_enable(struct sensor *sensor)
{

    pwm_config(sensor->pwm_4_vop.pwm_dev, sensor->pwm_4_vop.current_duty_ns, sensor->pwm_4_vop.current_period_ns);
    pwm_enable(sensor->pwm_4_vop.pwm_dev);
}

static void sensor_vop_pwm_disable(struct sensor *sensor)
{
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_vop.pwm_dev, &state);
    if (!state.enabled)
        return;

    pwm_config(sensor->pwm_4_vop.pwm_dev, PWM_INITDUTYCYCLE_4_VOP, sensor->pwm_4_vop.current_period_ns);
    pwm_disable(sensor->pwm_4_vop.pwm_dev);
}

static int set_vop_voltage(struct sensor *sensor, s16 vop_volt_x100)
{
    int duty_ns;
    int ret=0;

    if (vop_volt_x100 < VOP_VOLTAGE_MIN || vop_volt_x100 > VOP_VOLTAGE_MAX)   // volt's unit is 10mv, VOP: -32v ~ -20v
    {
        DBG_ERROR("Invalid vop voltage, volt: %d.%02d v",vop_volt_x100/100, abs(vop_volt_x100 % 100));
        return -EINVAL;
    }

    duty_ns = sensor_vop_pwm_convert_voltage_to_duty(sensor, vop_volt_x100);
    ret = sensor_vop_pwm_set_duty(sensor, duty_ns);
    if (ret < 0) {
        DBG_ERROR("Fail to set VOP voltage to %d.%d v.", vop_volt_x100/100, abs(vop_volt_x100 % 100));
    }
    else {
        sensor->pwm_4_vop.current_set_voltage = vop_volt_x100;
    }

    return ret;
}
#endif

static int sensor_match_work_mode(struct v4l2_subdev_format * fmt)
{
    struct v4l2_mbus_framefmt * framefmt = &fmt->format;
    int             cur_best_fit = -1;
    int             i;

    for (i = 0; i < ARRAY_SIZE(sensor_wkmode); i++) {
        if (sensor_wkmode[i].width == framefmt->width && sensor_wkmode[i].height == framefmt->height) {
            cur_best_fit        = i;
            break;
        }
    }

    return cur_best_fit;
}

static int sensor_spot_maskcfg_force_update(struct sensor *sensor, struct setting_rvd *regs)
{
    u8 CoarseMaskCfg;
    u8 FineMaskCfg;

    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_VCSEL_L_MODE)) // the tranditional vcsel flood mode
    {
        #define MASKING_COL_SHIFT                5
        #define MASKING_FINE_COL_DEFAULT         1

        // Use spot searching range settings.
        CoarseMaskCfg = ((sensor->colSearchingRange - 1) << MASKING_COL_SHIFT)
            + (sensor->rowSearchingRange - 1);
        FineMaskCfg = (MASKING_FINE_COL_DEFAULT << MASKING_COL_SHIFT)
            + (sensor->rowSearchingRange - 1);

        DBG_INFO("rowSearchingRange=%d, colSearchingRange=%d, CoarseMaskCfg=0x%x, FineMaskCfg=0x%x",
            sensor->rowSearchingRange, sensor->colSearchingRange, CoarseMaskCfg, FineMaskCfg);
    }
    else {
        CoarseMaskCfg = 0x0;
        FineMaskCfg = 0x0;
    }

    sensor_modify_reg(regs, 0xB0, CoarseMaskCfg);
    sensor_modify_reg(regs, 0xB1, FineMaskCfg);

    return 0;
}

static int sensor_config_4_work_mode(struct sensor *sensor)
{
    int ret;

    struct setting_rvd *p_sensor_workmode_setting = NULL;

    // create a copy of sensor_wkmode_cfg_regs before modifing some registers's configure to avoid the original sensor_work mode settings is changed.
    p_sensor_workmode_setting = kmalloc((sizeof(struct setting_rvd) *sensor->cur_sensor_mode->wkmode_reg_cfg_count), GFP_KERNEL);
    if (!p_sensor_workmode_setting)
    {
        DBG_ERROR("kmalloc failure");
        return  -ENOMEM;
    }
    memcpy(p_sensor_workmode_setting, sensor->cur_sensor_mode->wkmode_reg_cfg_list, sizeof(struct setting_rvd) *sensor->cur_sensor_mode->wkmode_reg_cfg_count);

    if (FALSE == sensor->load_script)
    {
        if (0xFF != sensor->force_mipi_tx_delay)
        {
            DBG_INFO("Update mipi tx delay register to 0x%02x...\n", sensor->force_mipi_tx_delay);
            sensor_modify_reg(p_sensor_workmode_setting, 0xA9, sensor->force_mipi_tx_delay);
        }

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        sensor_role_force_update(sensor, p_sensor_workmode_setting, sensor->cur_wkmode);
#endif

        if (ADAPS_PCM_MODE != sensor->cur_wkmode)
        {
            sensor_spot_maskcfg_force_update(sensor, p_sensor_workmode_setting);
        }

        ret = sensor_write_reg_list(sensor, p_sensor_workmode_setting, __LINE__);
        kfree(p_sensor_workmode_setting);
        if (ret) {
            DBG_ERROR("fail to write mode config registers");
            return ret;
        }

        if (ADAPS_PCM_MODE != sensor->cur_wkmode)
        {
            if (sensor->roi_sram_rolling)
            {
                ret = sensor_switch_roi_sram(sensor, true);
                if (ret) {
                    DBG_ERROR("fail to write sramdata registers\n");
                    return ret;
                }
            }
            else {
                // firstly, try to write ROI sram from the loaded script
                if (0 != sensor->loaded_roi_sram_size)
                {
                    ret = sensor_write_sram_register(sensor, CALIB_SRAM_REG_BASE0, sensor->loaded_roi_sram_size, sensor->loaded_roi_sram, __LINE__);
                    if (ret < 0) {
                        DBG_ERROR("fail to write sramdata registers[0x%x].\n", CALIB_SRAM_REG_BASE0);
                        return ret;
                    }
                }
                else {
                    ret = sensor_write_sramdata(sensor);
                    if (ret) {
                        DBG_ERROR("fail to write sramdata registers\n");
                        return ret;
                    }
                }
            }
        }
    }

    if (FALSE == sensor->load_script)
    {
#if defined(ENABLE_RUNTIME_REGISTER_UPDATE)
        // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE))
        {
            sensor_update_setting(sensor,
                sensor->cur_etype,
                sensor->cur_mtype,
                sensor->cur_v_zone_cnt,
                sensor->cur_vmode);
        }
#endif
        sensor_framerate_setting(sensor);
        sensor_write_tdc_delay_setting(sensor);
    }

    return ret;
}

static bool sensor_update_initsetting_4_powermode(struct sensor *sensor, struct setting_rvd *regs, u8 PowerMode)
{
#if defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER) && (MIPI_SPEED == MIPISPEED_1G_BPS) // only support 1G bps now
    int i, j;
    struct adaps_init_reg to_update_regs[]={
        {0xA5, {0x11, 0x12, 0x13}},
        {0xE9, {0x41, 0x00, 0x43}},
        {0x7E, {0x03, 0x00, 0x0B}},
        {0x81, {0xA0, 0x00, 0x80}},
        {0xA9, {0x10, 0x00, 0x20}},
    };

    if (PowerMode > AdapsPowerModeDiv3 || PowerMode < AdapsPowerModeNormal)
    {
        DBG_ERROR("----do not select Power mode, dynamically update setting is skiped, PowerMode:%d", PowerMode);
        return FALSE; // user didn't setup the power mode from apk, DO NOT update the setting.
    }

    for (i = 0; regs[i].reg != REG_NULL; i++) {
        for (j = 0; j < sizeof(to_update_regs)/sizeof(to_update_regs[0]); j++)
        {
            if (regs[i].reg == to_update_regs[j].reg_addr)
            {
                regs[i].val = to_update_regs[j].reg_val[PowerMode-1];
                DBG_INFO("----update No:%d reg(0x%02x) to 0x%02x for power mode:%d",
                    i,to_update_regs[j].reg_addr,to_update_regs[j].reg_val[PowerMode-1], PowerMode);
            }
        }
    }
#endif

    return TRUE;
}

static bool sensor_update_initsetting_4_mipi_speed(struct sensor *sensor, struct setting_rvd *regs)
{
    int i, j;
    struct setting_rvd *p_to_update_reg_setting = NULL;
    u8 to_update_reg_cnt = 0;

    struct setting_rvd reg_setting_4_mipi_speed_500M_bps[] = {  // demo default/golden setting
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X62, 0},
        {0X7E, 0X0F, 0},
        {0X81, 0X80, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X05, 0},
        {0X8E, 0X05, 0},
    };

    struct setting_rvd reg_setting_4_mipi_speed_720M_bps[] = {
        {0XE6, 0X00, 0},
        {0XE7, 0X78, 0},
        {0XE9, 0X42, 0},
        {0X7E, 0X0C, 0},
        {0X81, 0X00, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X07, 0},
        {0X8E, 0X07, 0},
    };

    struct setting_rvd reg_setting_4_mipi_speed_1G_bps[] = {
        {0XE6, 0X00, 0},
#if !defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER) // // recommended config, mipi speed 1000 Mbps
        {0XE7, 0X7D, 0},
        {0XE9, 0X61, 0},
#else // optional config, mipi speed 1008 Mbps, original low power setting use this configure.
        {0XE7, 0X54, 0},
        {0XE9, 0X41, 0},
#endif
        {0X7E, 0X03, 0},
        {0X81, 0XA0, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X09, 0},
        {0X8E, 0X09, 0},
    };

    struct setting_rvd reg_setting_4_mipi_speed_1G2_bps[] = {
        {0XE6, 0X00, 0},    // MIPIPLL_LPDH, bit0
        {0XE7, 0X64, 0},    // MIPIPLL_LPDL
        {0XE9, 0X41, 0},    // MIPIPLL_PPD, pre-divider and post-divider
        {0X7E, 0X00, 0},    // mipi_dphy_tx_pll_frange_config
        {0X81, 0X20, 0},    // mipi_dphy_tx_pll_frange_config
        {0XA5, 0X11, 0},    // SYSCLK_DIV
        {0X88, 0X0B, 0},    // ClkTxThstrailCnt
        {0X8E, 0X0B, 0},    // DataTxThstrailCnt
    };

    struct setting_rvd reg_setting_4_mipi_speed_1G5_bps[] = {
        {0XE6, 0X00, 0},
        {0XE7, 0X7D, 0},
        {0XE9, 0X41, 0},
        {0X7E, 0X00, 0},
        {0X81, 0X20, 0},
        {0XA5, 0X11, 0},
        {0X88, 0X0D, 0},
        {0X8E, 0X0D, 0},
    };

    if (0 == sensor->force_mipi_speed)
    {
        DBG_INFO("Use the static register settings for mipi speed %d Mbps...", MIPI_SPEED);
        return TRUE;
    }

    switch (sensor->force_mipi_speed)
    {
        case 500:
            p_to_update_reg_setting = reg_setting_4_mipi_speed_500M_bps;
            to_update_reg_cnt = ARRAY_SIZE(reg_setting_4_mipi_speed_500M_bps);
            break;

        case 720:
            p_to_update_reg_setting = reg_setting_4_mipi_speed_720M_bps;
            to_update_reg_cnt = ARRAY_SIZE(reg_setting_4_mipi_speed_720M_bps);
            break;

        case 1000:
            p_to_update_reg_setting = reg_setting_4_mipi_speed_1G_bps;
            to_update_reg_cnt = ARRAY_SIZE(reg_setting_4_mipi_speed_1G_bps);
            break;

        case 1200:
            p_to_update_reg_setting = reg_setting_4_mipi_speed_1G2_bps;
            to_update_reg_cnt = ARRAY_SIZE(reg_setting_4_mipi_speed_1G2_bps);
            break;

        case 1500:
            p_to_update_reg_setting = reg_setting_4_mipi_speed_1G5_bps;
            to_update_reg_cnt = ARRAY_SIZE(reg_setting_4_mipi_speed_1G5_bps);
            break;

        default:
            p_to_update_reg_setting = NULL;
            to_update_reg_cnt = 0;
            DBG_ERROR("Invalid mipi speed: %d", sensor->force_mipi_speed);
            return TRUE;
    }

    for (i = 0; regs[i].reg != REG_NULL; i++) {
        for (j = 0; j < to_update_reg_cnt; j++)
        {
            if (regs[i].reg == p_to_update_reg_setting[j].reg)
            {
                regs[i].val = p_to_update_reg_setting[j].val;
                DBG_INFO("----update No:%d reg(0x%02x) to 0x%02x for mipi speed %d Mbps",
                    i, regs[i].reg, regs[i].val, sensor->force_mipi_speed);
            }
        }
    }

    return TRUE;
}

static int sensor_init_setting(struct sensor * sensor)
{
    int ret = 0;
    struct setting_rvd *p_sensor_init_setting = NULL;

    // create a copy of sensor_init_regs before modifing some registers's configure to avoid the original sensor_init_regs settings is changed.
    p_sensor_init_setting = kmalloc((sizeof(struct setting_rvd) *ARRAY_LEN(sensor_init_regs) ), GFP_KERNEL);
    if (!p_sensor_init_setting)
    {
        DBG_ERROR("kmalloc failure");
        return  -ENOMEM;
    }
    memcpy(p_sensor_init_setting, sensor_init_regs, sizeof(struct setting_rvd) *ARRAY_LEN(sensor_init_regs));
    // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE))
    {
        sensor_update_initsetting_4_powermode(sensor, p_sensor_init_setting, sensor->cur_pmode);
        sensor_update_initsetting_4_mipi_speed(sensor, p_sensor_init_setting);
    }

    ret = sensor_write_reg_list(sensor, p_sensor_init_setting, __LINE__);
    kfree(p_sensor_init_setting);
    if (ret) {
        DBG_ERROR("could not set init registers\n");
    }

    return ret;
}

static int sensor_initilize(struct sensor * sensor)
{
    int ret = 0;

#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
    sensor->cur_calib_sram_blk_idx = 0;
    sensor->cur_calib_sram_data_group_idx = 0;
#endif

    DBG_NOTICE("env_type=%d, measure_type=%d, work_mode=%d, framerate_type:%d, cur_pmode: %d...",
        sensor->cur_etype, sensor->cur_mtype, sensor->cur_wkmode, sensor->cur_frtype, sensor->cur_pmode);

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    // for ads6401 flood module, No MCU initialize register setting in the loaded script, so I always do it here.
    ret = mcuctrl_setting_init(sensor, sensor->cur_wkmode);
    if (ret < 0) {
        DBG_ERROR("Fail to set mcuctrl init registers, ret: %d\n", ret);
        return ret;
    }
#endif

    if (FALSE == sensor->load_script)
    {
        ret = sensor_init_setting(sensor);
        if (ret < 0) {
            DBG_ERROR("Fail to set sensor init registers, ret: %d\n", ret);
            return ret;
        }

        sensor_testpattern_enable(sensor);

        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
        {
            usleep_range(1000, 1500); // need some delay, otherwize VCSEL i2c operation may fail. 
            ret = vcseldrv_setting_init(sensor);
            if (ret < 0) {
                DBG_ERROR("could not set vcsel init registers\n");
                return ret;
            }
        }
    }

    hrtimer_start(&sensor->vop_adjust_timer, sensor->vop_adjust_delay, HRTIMER_MODE_REL);

    return ret;
}

static int sensor_set_fmt(struct v4l2_subdev * sd, 
    struct v4l2_subdev_pad_config * cfg, 
    struct v4l2_subdev_format * fmt)
{
    int ret = 0;
    struct sensor *sensor = to_sensor(sd);
    int wkmode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);
    mutex_lock(&sensor->mutex);

    //DBG_INFO("fmt->which:0x%x,V4L2_SUBDEV_FORMAT_TRY:0x%x, fmt->width:%d, fmt->height:%d", 
    //  fmt->which, V4L2_SUBDEV_FORMAT_TRY, fmt->format.width, fmt->format.height);
    wkmode = sensor_match_work_mode(fmt);
    if (wkmode < 0)
    {
        DBG_ERROR("find_best_fit_work_mode failed wkmode:%d\n", wkmode);
        ret = -EINVAL;
    }
    else {
        sensor->cur_wkmode    = wkmode;
        sensor->cur_sensor_mode        = &sensor_wkmode[wkmode];

        fmt->format.code        = SENSOR_MEDIA_BUS_FMT;
        fmt->format.width       = sensor->cur_sensor_mode->width;
        fmt->format.height      = sensor->cur_sensor_mode->height;
        fmt->format.field       = V4L2_FIELD_NONE;
        DBG_NOTICE("fmt->which:0x%x,V4L2_SUBDEV_FORMAT_TRY:0x%x, wkmode:%d mode->width:%d, mode->height:%d, probe_success: %d, load_script: %d, dbg_ctrl: 0x%x...",
            fmt->which, V4L2_SUBDEV_FORMAT_TRY, wkmode, sensor->cur_sensor_mode->width, sensor->cur_sensor_mode->height, sensor->probe_success, sensor->load_script, sensor->dbg_ctrl);

        if (sensor->probe_success) // on rk3588, set_fmt() will be called when excute to v4l2_async_register_subdev_sensor_common() of probe().
        {
            __v4l2_ctrl_s_ctrl(sensor->ctrl_linkfreqency, 0);
            __v4l2_ctrl_s_ctrl_int64(sensor->ctrl_pixelrate, to_pixel_rate(sensor->mipi_data_lanes));

            ret = sensor_initilize(sensor);
            if (ret < 0) {
                DBG_ERROR("Fail to sensor_initilize(), ret: %d\n", ret);
                goto unlock_and_return;
            }

            sensor_config_4_work_mode(sensor);
        }
    }

unlock_and_return:
    mutex_unlock(&sensor->mutex);

    return ret;
}


static int sensor_get_fmt(struct v4l2_subdev * sd, 
    struct v4l2_subdev_pad_config * cfg, 
    struct v4l2_subdev_format * fmt)
{
    int ret = 0;
    struct sensor * sensor = to_sensor(sd);
    const struct sensor_mode * mode = sensor->cur_sensor_mode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s, which:0x%x,V4L2_SUBDEV_FORMAT_TRY:0x%x", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name, fmt->which, V4L2_SUBDEV_FORMAT_TRY);
    mutex_lock(&sensor->mutex);

    if (fmt->which == V4L2_SUBDEV_FORMAT_TRY) {
#ifdef CONFIG_VIDEO_V4L2_SUBDEV_API
        fmt->format = *v4l2_subdev_get_try_format(sd, cfg, fmt->pad);
#else
        ret = -ENOTTY;
#endif
    }
    else {
        fmt->format.width   = mode->width;
        fmt->format.height  = mode->height;
        fmt->format.code    = SENSOR_MEDIA_BUS_FMT;
        fmt->format.field   = V4L2_FIELD_NONE;
    }

    mutex_unlock(&sensor->mutex);

    return ret;
}


static int sensor_enum_mbus_code(struct v4l2_subdev * sd, 
    struct v4l2_subdev_pad_config * cfg, 
    struct v4l2_subdev_mbus_code_enum * code)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    if (code->index != 0)
        return - EINVAL;

    code->code = SENSOR_MEDIA_BUS_FMT;

    return 0;
}


static int sensor_enum_frame_sizes(struct v4l2_subdev * sd, 
    struct v4l2_subdev_pad_config * cfg, 
    struct v4l2_subdev_frame_size_enum * fse)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    if (fse->index >= ARRAY_SIZE(sensor_wkmode))
        return - EINVAL;

    if (fse->code != SENSOR_MEDIA_BUS_FMT)
        return - EINVAL;

    DBG_INFO("fse->index:%d", fse->index);
    fse->min_width      = sensor_wkmode[fse->index].width;
    fse->max_width      = sensor_wkmode[fse->index].width;
    fse->max_height     = sensor_wkmode[fse->index].height;
    fse->min_height     = sensor_wkmode[fse->index].height;

    return 0;
}


static int sensor_g_frame_interval(struct v4l2_subdev * sd, 
    struct v4l2_subdev_frame_interval * fi)
{
    struct sensor * sensor = to_sensor(sd);
    const struct sensor_mode * mode = sensor->cur_sensor_mode;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, subdevice name:%s", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), sd->name);

    mutex_lock(&sensor->mutex);
    fi->interval = mode->max_fps;
    mutex_unlock(&sensor->mutex);

    return 0;
}

static int sensor_update_setting(
    struct sensor *sensor,
    AdapsEnvironmentType etype,
    AdapsMeasurementType mtype,
    AdapsVcselZoneCountType vcselzonecount_type,
    AdapsVcselMode vmode)
{
    int ret = 0;
    u8 reg, val;
    u8 mode_bit = 0;

    if (NULL == sensor)
    {
        DBG_ERROR("sensor is NULL");
        return -EINVAL;
    }

    // when test pattern enabled, we'd like to use the basic register settings (init + mode configure)
    if (sensor->dbg_ctrl & ADAPS_DBG_TESTPATTERN_ENABLE)
    {
        DBG_INFO("Use the basic register settings for test pattern data output...");
        return ret;
    }

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
#if defined(OPN7020_VCSEL_DRIVER_ENABLE)
    if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
    {
        vcseldrv_setting_update(sensor, etype, vcselzonecount_type, vmode);
    }
#endif
#endif

    if (ADAPS_PCM_MODE == sensor->cur_wkmode)
    {
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        if (false == sensor->force_enable_vcsel_4_pcm_mode)
        {
            reg = 0xBC;
            val = 0x60;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret)
            {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }

            reg = 0xCB;
            val = 0x00;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret)
            {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }
#endif

        // apply the user configured exposure values from SpadisApp if any.
        if (0 != sensor->grayExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, grayExposureCfg: 0x%x", sensor->grayExposureCfg);

            reg = 0xC2;
            val = sensor->grayExposureCfg;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->laserExposurePeriodCfg)
        {
            DBG_NOTICE("apply the user configured laserExposurePeriodCfg value, laserExposurePeriodCfg: 0x%x", sensor->laserExposurePeriodCfg);

            reg = 0xBC;
            val = BIT(7) | sensor->laserExposurePeriodCfg;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        return ret;
    }
    else {
        if (etype < AdapsEnvTypeIndoor || etype > AdapsEnvTypeOutdoor)
        {
            DBG_ERROR("Invalid EnvironmentType, etype:%d",etype);
            return -EINVAL;
        }
    
        if (mtype < AdapsMeasurementTypeNormal || mtype > AdapsMeasurementTypeFull)
        {
            DBG_ERROR("Invalid MeasurementType, etype:%d",mtype);
            return -EINVAL;
        }
    
        if (ADAPS_PTM_FHR_MODE == sensor->cur_wkmode)
        {
            mode_bit = 0x20;
        }
        else {
            mode_bit = 0x00;
        }
    
        if (AdapsEnvTypeIndoor == etype)
        {
            switch (mtype) {
                case AdapsMeasurementTypeFull:
                    mode_bit = 0x20; // Full-distance force use FHR mode
                    val = mode_bit | 0x6;
                    break;
    
                case AdapsMeasurementTypeShort:
                    val = mode_bit | 0x6;
                    break;
    
                default:
                    val = mode_bit | 0x4;
                    break;
            }
        }
        else {
            switch (mtype) {
                case AdapsMeasurementTypeFull:
                    mode_bit = 0x20; // Full-distance force use FHR mode
                    val = mode_bit | 0x6;
                    break;

                case AdapsMeasurementTypeShort:
                    mode_bit = 0x20; // Outdoor force use FHR mode
                    val = mode_bit | 0x2;
                    break;
    
                default:
                    mode_bit = 0x20; // Outdoor force use FHR mode
                    val = mode_bit | 0x0;
                    break;
            }
        }

        DBG_INFO("------etype:%d, mtype:%d, val for B6: 0x%02x, current workmode: %d",etype, mtype, val, sensor->cur_wkmode);
        reg = 0xB6;
        ret = sensor_write_reg_8bit_value(sensor, reg, val);
        if (ret) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }

        if (AdapsMeasurementTypeFull == mtype)
        {
            reg = 0xBC;
            val = BIT(7) | VCSEL_LASER_PERIOD;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }

            reg = 0xBF;
            val = COARSE_EXPOSURE_TIME;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
    
            reg = 0xC0;
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
            if (AdapsEnvTypeIndoor == etype)
            {
                val = 0x3C; // 4800 us
            }
            else{
                if(0 == (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_OD_9V_CONFIG))
                {
                    val = 0x3C; // 4800 us
                }
                else
                {
                    val = 0x5A; // 7200 us for  outdoor 9v config
                }
            }
#else
            val = FINE_EXPOSURE_TIME;  // 0x26
#endif
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
    
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
            if ((AdapsEnvTypeOutdoor == etype) && (0 != (sensor->dbg_ctrl & ADAPS_DBG_ENABLE_OD_9V_CONFIG)))
            {
                reg = 0xDA;
                val = 0x6A;  //for outdoor 9v config
                ret = sensor_write_reg_8bit_value(sensor, reg, val);
                if (ret) {
                    DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                    return ret;
                }
            }
#endif
        }
    
        // apply the user configured exposure values from SpadisApp if any.
        if (0 != sensor->coarseExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, coarseExposureCfg: 0x%x", sensor->coarseExposureCfg);

            reg = 0xBF;
            val = sensor->coarseExposureCfg;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->fineExposureCfg)
        {
            DBG_NOTICE("apply the user configured exposure value, fineExposureCfg: 0x%x", sensor->fineExposureCfg);

            reg = 0xC0;
            val = sensor->fineExposureCfg;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }

        if (0 != sensor->laserExposurePeriodCfg)
        {
            DBG_NOTICE("apply the user configured laserExposurePeriodCfg value, laserExposurePeriodCfg: 0x%x", sensor->laserExposurePeriodCfg);
        
            reg = 0xBC;
            val = BIT(7) | sensor->laserExposurePeriodCfg;
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
            if (ret) {
                DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
                return ret;
            }
        }
    }

    return ret;
}

static int sensor_framerate_setting(struct sensor * sensor)
{
    int ret = 0;
    u8 reg, val;

    if (sensor->cur_frtype >= AdapsFramerateType15FPS && sensor->cur_frtype <= AdapsFramerateType60FPS)
    {
        reg = 0xA6;
        ret = sensor_read_reg_8bit_value(sensor, reg, &val);
        if (ret) {
            DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n",reg, ret);
            return ret;
        }
        val = val & 0x03; //get the bit1-bit0 value

        val |= (sensor->cur_frtype - 1) << 2;
        ret = sensor_write_reg_8bit_value(sensor, reg, val);
        if (ret) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
    }

    return ret;
}

static void sensor_get_module_inf(struct sensor * sensor, 
    struct rkmodule_inf * inf)
{
    memset(inf, 0, sizeof(*inf));
    strscpy(inf->base.sensor, SENSOR_NAME, sizeof(inf->base.sensor));
    strscpy(inf->base.module, sensor->module_name, sizeof(inf->base.module));
    strscpy(inf->base.lens, sensor->len_name, sizeof(inf->base.lens));
}

static long sensor_ioctl(struct v4l2_subdev * sd, unsigned int cmd, void *arg)
{
    struct rkmodule_bus_config *bus_config;
    struct sensor *sensor = to_sensor(sd);
    long ret = 0;
    ktime_t kt_req = ktime_get();

    TRACE_IOCTL("----- Sensor_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, RKMODULE_GET_MODULE_INFO:0x%lx", 
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid, 
        smp_processor_id(), RKMODULE_GET_MODULE_INFO
        );

    switch (cmd)
    {
        case RKMODULE_GET_MODULE_INFO:
            sensor_get_module_inf(sensor, (struct rkmodule_inf *) arg);
            TRACE_IOCTL("current sensor_ioctl_cmd: %x", cmd);
            break;

        case RKMODULE_GET_CSI_DSI_INFO:
            *(int *)arg = RKMODULE_CSI_INPUT;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            break;

        case RKMODULE_GET_BUS_CONFIG:
            bus_config = (struct rkmodule_bus_config *)arg;
            bus_config->bus.bus_type = V4L2_MBUS_CSI2_DPHY;
            bus_config->bus.lanes = sensor->mipi_data_lanes;
            /*
             * for rk356x: dphy0 is used just for full mode,
             *             dphy1 is used just for split mode,uses lane0_1,
             *             dphy2 is used just for split mode,uses lane2_3
             *
             * csi2_dphy0: used for csi2 dphy full mode,
                       is mutually exclusive with
                       csi2_dphy1 and csi2_dphy2
             * csi2_dphy1: used for csi2 dphy split mode,
                       physical lanes use lane0 and lane1,
                       can be used with csi2_dphy2  parallel
             * csi2_dphy2: used for csi2 dphy split mode,
                       physical lanes use lane2 and lane3,
                       can be used with csi2_dphy1  parallel
             *
             */
            bus_config->bus.phy_mode = PHY_SPLIT_01;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            //DBG_INFO("phy_mode %d, lanes %d\n", bus_config->bus.phy_mode, bus_config->bus.lanes);
            break;

#if 0
        case RKMODULE_GET_HDR_CFG:
            hdr = (struct rkmodule_hdr_cfg *)arg;
            hdr->esp.mode = HDR_NORMAL_VC;
            hdr->hdr_mode = NO_HDR;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            //DBG_INFO("cmd:0x%x,RKMODULE_GET_HDR_CFG:0x%lx", cmd, RKMODULE_GET_HDR_CFG);
            break;

        case RKMODULE_GET_CHANNEL_INFO:
            ch_info = (struct rkmodule_channel_info *)arg;
            ch_info->vc = V4L2_MBUS_CSI2_CHANNEL_0;
            ch_info->width = sensor->cur_sensor_mode->width;
            ch_info->height = sensor->cur_sensor_mode->height;
            ch_info->bus_fmt = SENSOR_MEDIA_BUS_FMT;
            ch_info->data_type = SENSOR_RAW_DATA_TYPE;
            ch_info->data_bit = 8;
            TRACE_IOCTL(" current sensor_ioctl_cmd: %x", cmd);
            break;

        case RKMODULE_GET_START_STREAM_SEQ:
#endif
        default:
            ret = -ENOIOCTLCMD;
            TRACE_IOCTL("cmd:0x%x,RKMODULE_GET_MODULE_INFO:0x%lx,RKMODULE_GET_CHANNEL_INFO:0x%lx", cmd, RKMODULE_GET_MODULE_INFO,RKMODULE_GET_CHANNEL_INFO);
            break;
    }

    TRACE_IOCTL("=END= Sensor_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ret: %ld", 
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        ret
        );

    if (0 != ret && -ENOIOCTLCMD != ret)
    {
        DBG_ERROR("client: %s (%d), cmd: 0x%x,ENOIOCTLCMD: 0x%x ret: %ld", current->comm, current->pid, cmd, ENOIOCTLCMD, ret);
    }

    return ret;
}

static int sensor_write_tdc_delay_setting(struct sensor * sensor)
{
    int ret = 0;
    u8 reg, val;

    reg = 0xc3;
    val = sensor->tdc_delay_major;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    reg = 0xc4;
    val = sensor->tdc_delay_minor;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret) {
        DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
        return ret;
    }

    return ret;
}

static int sensor_read_and_compare_sramdata(struct sensor * sensor, u32 op_sram_size, u8 op_sram_reg, u8 *orignal_cali_sram_data)
{
    int j,ret = 0;
    u8 reg, val;
    u32 len;
    u8 *cali_sram_data_for_verify;

    if (NULL == sensor) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    if (NULL == orignal_cali_sram_data) {
        DBG_ERROR("Null pointer");
        return -EINVAL;
    }

    reg = 0xD3;
    ret = sensor_read_reg_8bit_value(sensor, reg, &val);
    if (ret) {
        DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n",reg, ret);
        return ret;
    }
    DBG_INFO("PLL register: 0x%x", val);
    if (0x00 == (val & 0x80)){
        DBG_ERROR("Need PLL lock before read ROI SRAM register.");
        return -EPERM;
    }

    cali_sram_data_for_verify = kmalloc((sizeof(u8) * op_sram_size), GFP_KERNEL);
    if (!cali_sram_data_for_verify) {
        DBG_ERROR("kmalloc failure");
        ret = -ENOMEM;
        return ret;
    }

    reg = op_sram_reg;
    len = op_sram_size;
    ret = sensor_burst_read_reg(sensor, reg, cali_sram_data_for_verify, len);
    if (ret < 0) {
        DBG_ERROR("Fail to read sensor sram register, ret:%d", ret);
    }

    if (0 < ret)
    {
        ret = 0;
    }
    for (j=0; j<op_sram_size; j++)
    {
        if (cali_sram_data_for_verify[j] != orignal_cali_sram_data[j])
        {
            DBG_ERROR("---Oops, cali_sram_data_for_verify[%d] 0x%x is not equal to orignal_cali_sram_data[j]:0x%x\n",
                j, cali_sram_data_for_verify[j], orignal_cali_sram_data[j]);
            ret = -EIO;
        }
    }
    if (0 == ret)
    {
        DBG_NOTICE("---SRAM write and readback (size:%d) matched!!!\n", len);
    }
    kfree(cali_sram_data_for_verify);
    cali_sram_data_for_verify = NULL;

    return ret;
}

static int sensor_write_sram_register(struct sensor * sensor, u8 reg, u32 length, u8 *buffer, int callline)
{
    int ret = 0;
    u8 *roi_sram_buf_to_write = NULL;
    s64 us_delta;
    ktime_t start;

    roi_sram_buf_to_write = kmalloc((sizeof(u8) * length), GFP_KERNEL);
    if (!roi_sram_buf_to_write) {
        DBG_ERROR("kmalloc failure");
        ret = -ENOMEM;
        return ret;
    }

    // create another buffer copy for anchorX operation to keep the original ROI sram data not be changed.
    memcpy(roi_sram_buf_to_write, buffer, length);
#if defined(ROISRAM_ANCHOR_PREPROCCESS_ENABLE)
    sensor_roisram_anchor_preproccess(sensor, roi_sram_buf_to_write, length);
#endif

    start = ktime_get();
    ret = sensor_burst_write_reg(sensor, 
        reg,
        roi_sram_buf_to_write,
        length);
    if (ret) {
        DBG_ERROR("fail to write sram registers, reg: 0x%x\n", reg);
        kfree(roi_sram_buf_to_write);
        return ret;
    }

    us_delta = ktime_us_delta(ktime_get(), start);

    if (us_delta > sensor->max_costtime_4_roisram_write)
        sensor->max_costtime_4_roisram_write = us_delta;

    if (us_delta < sensor->min_costtime_4_roisram_write)
        sensor->min_costtime_4_roisram_write = us_delta;

    if (sensor->dbg_ctrl & ADAPS_DBG_ROISRAM_RB_4_VERIFY) {
        DBG_INFO("Write ROI SRAM (reg: 0x%02x, size: %d bytes) costs %lld us, call from line: %d...\n",
            reg, length, us_delta, callline);

        ret = sensor_read_and_compare_sramdata(sensor, length, reg, roi_sram_buf_to_write);
        hexdump((const char *) roi_sram_buf_to_write, 64, "first 64 bytes of current ROI SRAM");
    }
    kfree(roi_sram_buf_to_write);

    return ret;
}

static int sensor_write_sramdata(struct sensor * sensor)
{
    int ret = 0;
    u8 reg, val;
    u8 sram_offset_initial_value=0;
    u8 *p_sramdata = NULL;
#if defined(SAVE_ROISRAM_DATA_TO_FILE)
    char filename[128];
    int sram_index = 1;
#endif

    u32 op_sram_size = PER_ROISRAM_GROUP_SIZE;
    u8 op_sram_reg = CALIB_SRAM_REG_BASE0;

    if (NULL == sensor->eeprom_data)
    {
        DBG_ERROR("eeprom data is not available yet!");
        return -EFAULT;
    }

    p_sramdata = sensor->eeprom_data->sramData;

    reg = 0xD3;
    ret = sensor_read_reg_8bit_value(sensor, reg, &val);
    if (ret) {
        DBG_ERROR("fail to read sensor register:0x%x, ret:%d\n",reg, ret);
        return ret;
    }
    DBG_INFO("PLL register: 0x%x", val);
    if (0x00 == (val & 0x80)){
        DBG_ERROR("Need PLL lock before writing ROI SRAM register.");
        return -EPERM;
    }

    memcpy(sensor->roi_sram_data_to_write, p_sramdata, op_sram_size);

#if defined(SAVE_ROISRAM_DATA_TO_FILE)
    sram_index = 1;
    sprintf(filename, "/tmp/ads6401_sram%d.bin", sram_index);
    save_buffer_to_file(sensor->roi_sram_data_to_write, PER_ROISRAM_GROUP_SIZE, filename);
    sram_index = 0;
    sprintf(filename, "/tmp/ads6401_sram%d.bin", sram_index);
    save_buffer_to_file(&sensor->roi_sram_data_to_write[PER_ROISRAM_GROUP_SIZE], PER_ROISRAM_GROUP_SIZE, filename);
#endif

    reg = CSRU_SRAM_OFFSET_REG;
    val = sram_offset_initial_value;
    ret = sensor_write_reg_8bit_value(sensor, reg, val);
    if (ret) {
        DBG_ERROR("fail to write sram offset register, reg: 0x%x\n", reg);
        return ret;
    }

    ret = sensor_write_sram_register(sensor, op_sram_reg, op_sram_size, sensor->roi_sram_data_to_write, __LINE__);
    return ret;
}

static int __sensor_start_stream(struct sensor * sensor)
{
    int ret;

    // restore the initial values before start a new streaming...
#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    sensor->min_fsync_irq_gap = 500000; // set a enough big (> the min value of all work mode) value as initially, so that it must be re-assgined value.
    sensor->max_fsync_irq_gap = 0;
    sensor->fsync_irq_times = 0;
    sensor->last_fsync_irq_time = 0;
#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
    sensor->roi_switch_req_times = 0;
#endif
#endif

    /* In case these controls are set before streaming */
    mutex_unlock(&sensor->mutex);
    ret = v4l2_ctrl_handler_setup(&sensor->ctrl_handler);
    mutex_lock(&sensor->mutex);
    if (ret) {
        DBG_ERROR("fail to v4l2_ctrl_handler_setup");
        return ret;
    }

    if (true == sensor->load_script)
    {
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
        // for script load mode, need sensor initialize firstly for spot module, 
        if (NULL != sensor->loaded_sensor_reg_setting && 0 != sensor->loaded_sensor_reg_setting_cnt)
        {
            ret = sensor_write_reg_list(sensor, (const struct setting_rvd *) sensor->loaded_sensor_reg_setting, __LINE__);
            if (ret) {
                DBG_ERROR("fail to write sensor setting registers\n");
                return ret;
            }
        }
        else {
            DBG_ERROR("Invalid loaded_sensor_reg_setting, %p, %d", sensor->loaded_sensor_reg_setting, sensor->loaded_sensor_reg_setting_cnt);
            return -EINVAL;
        }

        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
        {
            usleep_range(1000, 1500); // need some delay, otherwize VCSEL i2c operation may fail. 
            ret = vcseldrv_setting_init(sensor);
            if (ret < 0) {
                DBG_ERROR("could not set vcsel init registers\n");
                return ret;
            }
        }
#else
        // for script load mode, need vcsel initialize firstly for flood module, 
        if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_VCSEL_DRVIER))
        {
            usleep_range(1000, 1500); // need some delay, otherwize VCSEL i2c operation may fail. 
            ret = vcseldrv_setting_init(sensor);
            if (ret < 0) {
                DBG_ERROR("could not set vcsel init registers\n");
                return ret;
            }
        }

        if (NULL != sensor->loaded_sensor_reg_setting && 0 != sensor->loaded_sensor_reg_setting_cnt)
        {
            ret = sensor_write_reg_list(sensor, (const struct setting_rvd *) sensor->loaded_sensor_reg_setting, __LINE__);
            if (ret) {
                DBG_ERROR("fail to write sensor setting registers\n");
                return ret;
            }
        }
        else {
            DBG_ERROR("Invalid loaded_sensor_reg_setting, %p, %d", sensor->loaded_sensor_reg_setting, sensor->loaded_sensor_reg_setting_cnt);
            return -EINVAL;
        }
#endif
        if (ADAPS_PCM_MODE != sensor->cur_wkmode)
        {
            if (sensor->roi_sram_rolling)
            {
                ret = sensor_switch_roi_sram(sensor, true);
                if (ret) {
                    DBG_ERROR("fail to write sramdata registers\n");
                    return ret;
                }
            }
            else {
                // firstly, try to write ROI sram from the loaded script
                if (0 != sensor->loaded_roi_sram_size)
                {
                    ret = sensor_write_sram_register(sensor, CALIB_SRAM_REG_BASE0, sensor->loaded_roi_sram_size, sensor->loaded_roi_sram, __LINE__);
                    if (ret < 0) {
                        DBG_ERROR("fail to write sramdata registers[0x%x].\n", CALIB_SRAM_REG_BASE0);
                        return ret;
                    }
                }
                else {
                    ret = sensor_write_sramdata(sensor);
                    if (ret) {
                        DBG_ERROR("fail to write sramdata registers\n");
                        return ret;
                    }
                }
            }

        }
    }

    // It is suggested we write ROI sram before stream-on, so I already ignore the stream-on register in script, I'm compensating it here.
    switch (sensor->reset_mipi_4_streamon)
    {
        case STREAM_ON_WITH_MIPI_IP_RESET_FIRST:
            ret = sensor_write_reg_list(sensor, stream_on_with_mipi_reset_first, __LINE__);
            break;

        case STREAM_ON_FIRST_AND_THEN_RESET_MIPI_IP:
            ret = sensor_write_reg_list(sensor, stream_on_first_and_then_reset_mipi, __LINE__);
            break;

        default:
            ret = sensor_write_reg_list(sensor, sensor_streamon_regs, __LINE__);
            break;
    }
    if (ret) {
        DBG_ERROR("fail to write stream on registers\n");
        return ret;
    }

    if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
        int rc;
        char *temp_buf;

        temp_buf = kzalloc(PAGE_SIZE, GFP_KERNEL);

        if (!temp_buf) {
            return -ENOMEM;
        }

        rc = calc_frequency(sensor, temp_buf, PAGE_SIZE);
        if (rc >= 0)
        {
            printk_multilines(temp_buf, rc);
        }
        kfree(temp_buf);

        sensor_reg_dump(sensor, false, false, __func__, __LINE__);

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
#if defined(OPN7020_VCSEL_DRIVER_ENABLE)
        sensor_vcsel_reg_dump(sensor, false);
#endif
#endif

        tps62864_reg_dump(sensor, false);

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        mcuctrl_reg16_dump(sensor, PhotonIC5015_REG_BASE, PhotonIC5015_REG_COUNT, __func__, __LINE__, false); // vcsel driver PhotonIC 5015 registers
        mcuctrl_reg16_dump(sensor, MCUCTRL_REG_BASE, MCUCTRL_REG_COUNT, __func__, __LINE__, false); // mcu controller related registers
#endif
    }

    sensor_timer_adjust_vop(sensor, true); // get the temperature and set the first vop voltage as soon after stream-on, since the inside temperature may be high already (may worked a long time before now).

    return ret;
}

static int __sensor_stop_stream(struct sensor * sensor)
{
    int ret;
    ktime_t start;
    s64 us_delta;
    u8 val8 = 0;
    int times = 0;

    start = ktime_get();
    ret = sensor_write_reg_list(sensor, sensor_streamoff_regs, __LINE__);
    if (ret) {
        DBG_ERROR("fail to write stream off registers\n");
    }

    do {
        ret = sensor_read_reg_8bit_value(sensor, 0xAD, &val8);
        us_delta = ktime_us_delta(ktime_get(), start);
        if (ret < 0) {
            DBG_INFO("Fail to read status register of the sensor, ret: %d.\n", ret);
        }
        else {
            if (0 == (val8 & 0xF))
            {
                ret = 0;
                DBG_INFO("Sensor is idle, mipi data transfer is done now, times: %d, waited %lld us.\n", times, us_delta);
                break;
            }
            else {
                DBG_INFO("Sensor is not idle (0x%x), mipi data is transferring..., times: %d, waited %lld us.\n", (val8 & 0xF), times, us_delta);
            }
        }

        if (SENSOR_IDLE_WAIT_TIMEOUT < us_delta)
        {
            DBG_ERROR("Timeout to wait to sensor idle, already waited %lld us.\n", us_delta);
            ret = -ETIMEDOUT;
            break;
        }

        usleep_range(1000, 1200);
        times++;
    } while (1);

    return ret;
}

static int sensor_s_stream(struct v4l2_subdev * sd, int on)
{
    struct sensor * sensor = to_sensor(sd);
    int ret = 0;
    const char * const wkmode_names[] = {
            [ADAPS_PTM_PHR_MODE] = "PHR-Mode",
            [ADAPS_PCM_MODE] = "PCM-Mode",
            [ADAPS_PTM_FHR_MODE] = "FHR-Mode",
    };

    DBG_NOTICE("---dbg_ctrl: 0x%x, on:%d, streaming: %d, load_script: %d, roi_sram_rolling: %d, wkmode:%d (%s), mtype:%d, etype:%d, power mode:%d, frtype:%d, vcsel mode:%d, v_zone_cnt:%d, linkFreq:%d, pixelRate: %lld, drv_version: %s---", 
        sensor->dbg_ctrl, 
        on,
        sensor->streaming,
        sensor->load_script,
        sensor->roi_sram_rolling,
        sensor->cur_wkmode,
        wkmode_names[sensor->cur_wkmode],
        sensor->cur_mtype,
        sensor->cur_etype,
        sensor->cur_pmode,
        sensor->cur_frtype,
        sensor->cur_vmode,
        sensor->cur_v_zone_cnt,
        SENSOR_LINK_FREQ,
        to_pixel_rate(sensor->mipi_data_lanes),
        FULL_VERSION_STRING
        );
    mutex_lock(&sensor->mutex);
    on = !!on;
    if (on == sensor->streaming)
        goto unlock_and_return;

    if (on) {
        ret = __sensor_start_stream(sensor);
        if (ret) {
            DBG_ERROR("start stream failed ret:%d\n", ret);
            goto unlock_and_return;
        }
#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
        mcuctrl_vop_adjust_enable(sensor, true);
#endif
        sensor->stream_start = ktime_get();
#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        sensor->fsync_irq_times = 0;
#endif
    } else {
        sensor->stream_start = 0;
#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
        mcuctrl_vop_adjust_enable(sensor, false);
#endif
        __sensor_stop_stream(sensor);
    }

    sensor->streaming = on;

unlock_and_return:
    mutex_unlock(&sensor->mutex);

    return ret;
}

static int sensor_s_power(struct v4l2_subdev * sd, int on)
{
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;

    mutex_lock(&sensor->mutex);

    TRACE_POWER_CTRL("--on: %d, power_on:%d, from process <%s> %d...", 
        on, sensor->power_on,
        current->comm, current->pid);

    /* If the power state is not modified - no work to do. */
    if (sensor->power_on == !!on)
        goto unlock_and_return;

    if (strcmp(current->comm, "v4l_id") == 0) // this is special for rockchip SoC Linux platform
    {
        // Ignore the real power on/off for v4l_id's requests.
        //
        // during the system startup, /usr/lib/udev/v4l_id will try to identify the v4l device, this driver does not need real power on, only return 0 should be enough,
        goto unlock_and_return;
    }

    if (on) {
        ret = sensor_set_power_on(sensor, __LINE__);
        if (ret < 0) {
            DBG_ERROR("Fail to __sensor_power_on(), ret: %d\n", ret);
            goto unlock_and_return;
        }

        sensor->test_pattern_enabled = false;

#if defined(DUMP_POWERON_REGISTER_ENABLE)
        if (sensor->dbg_ctrl & ADAPS_DBG_DUMP_REGS) {
            sensor_reg_dump(sensor, false, false, __func__, __LINE__);
        }
#endif

    } else {
        // when power off, clear all loaded data (user must re-load it next time if need).
        sensor->allow_roi_switch = false;
        sensor->roi_sram_rolling = false;
        // clear all possible loaded data for loaded_sensor_reg_setting, loaded_vcsel_reg_setting, loaded_roi_sram
        memset(sensor->loaded_sensor_reg_setting, 0, REG_SETTING_BUF_MAX_SIZE_PER_SEG*2 + (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP * MAX_CALIB_SRAM_ROTATION_GROUP_CNT));
        sensor->loaded_roi_sram_size = 0;
        sensor->loaded_sensor_reg_setting_cnt = 0;
        sensor->loaded_vcsel_reg_setting_cnt = 0;

        sensor_set_power_off(sensor, __LINE__);
    }

unlock_and_return:
    mutex_unlock(&sensor->mutex);

    return ret;
}

#ifdef CONFIG_VIDEO_V4L2_SUBDEV_API
static int sensor_close(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh)
{
    u32 closing_from_client = CURRENT_CLIENT;
    struct sensor *sensor = to_sensor(sd);

    mutex_lock(&sensor->mutex);

    TRACE_V4L2_CB("---- S_CLOSE  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );
    //dump_stack();

    if (CLIENT_TO_PID(sensor->client_id_4_sensor) != CLIENT_TO_PID(closing_from_client))
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: opened id: (%d:%d), closing id: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_sensor), CLIENT_TO_TID(sensor->client_id_4_sensor),
            CLIENT_TO_PID(closing_from_client), CLIENT_TO_TID(closing_from_client)
            );
    }

    sensor->client_id_4_sensor = 0;
    sensor->client_task_4_sensor = NULL;
    mutex_unlock(&sensor->mutex);

    return 0;
}

static int sensor_open(struct v4l2_subdev *sd, struct v4l2_subdev_fh *fh)
{
    int             ret = 0;
    struct sensor *sensor = to_sensor(sd);
    u32 opening_from_client = CURRENT_CLIENT;

    mutex_lock(&sensor->mutex);

    TRACE_V4L2_CB("---- S_OPEN  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
    if (0 != sensor->client_id_4_sensor)
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: Sensor was opened already\nOpened client: (%d:%d), re-opening client: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_sensor), CLIENT_TO_TID(sensor->client_id_4_sensor),
            CLIENT_TO_PID(opening_from_client), CLIENT_TO_TID(opening_from_client)
            );
        ret = -EIO;
        goto unlock_and_return;
    }
#endif

    sensor->client_id_4_sensor = opening_from_client;
    sensor->client_task_4_sensor = current;

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
unlock_and_return:
#endif

    mutex_unlock(&sensor->mutex);

    return ret;
}
#endif


static int sensor_enum_frame_interval(struct v4l2_subdev *sd, 
    struct v4l2_subdev_pad_config *cfg, 
    struct v4l2_subdev_frame_interval_enum *fie)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, fie->index:%d, fie->code: 0x%x, SENSOR_MEDIA_BUS_FMT: 0x%x", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        fie->index, fie->code, SENSOR_MEDIA_BUS_FMT);

    if (fie->index >= ARRAY_SIZE(sensor_wkmode))
        return - EINVAL;

    if (fie->code != SENSOR_MEDIA_BUS_FMT)
        return - EINVAL;

    DBG_INFO("fie->index:%d", fie->index);
    fie->width          = sensor_wkmode[fie->index].width;
    fie->height         = sensor_wkmode[fie->index].height;
    fie->interval       = sensor_wkmode[fie->index].max_fps;

    return 0;
}


static int sensor_g_mbus_config(struct v4l2_subdev *sd, unsigned int pad_id, 
    struct v4l2_mbus_config *config)
{
    struct sensor *sensor = to_sensor(sd);
    u32 val = 0;

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, pad_id:%d", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        pad_id);
    val                 = 1 << (sensor->mipi_data_lanes - 1) | V4L2_MBUS_CSI2_CHANNEL_0 | V4L2_MBUS_CSI2_CONTINUOUS_CLOCK;
    config->type        = V4L2_MBUS_CSI2_DPHY;
    config->flags       = val;

    return 0;
}

static int sensor_get_selection(struct v4l2_subdev *sd,
           struct v4l2_subdev_pad_config *cfg,
           struct v4l2_subdev_selection  *sel)
{
    struct sensor *sensor = to_sensor(sd);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, sel->target:%d", 
        current->comm, current->tgid, current->pid, 
        smp_processor_id(),
        sel->target);

    sensor->crop.left = 0;
    sensor->crop.top  = 0;
    sensor->crop.width  = sensor->cur_sensor_mode->width;
    sensor->crop.height = sensor->cur_sensor_mode->height;
    //DBG_INFO("sel->target: %d, width:%d, height:%d", sel->target, sensor->crop.width, sensor->crop.height);
    sel->r = sensor->crop;

    return 0;
}

#ifdef CONFIG_VIDEO_V4L2_SUBDEV_API
static const struct v4l2_subdev_internal_ops sensor_internal_ops =
{
    .open = sensor_open, 
    .close = sensor_close,
};
#endif

static const struct v4l2_subdev_core_ops sensor_core_ops =
{
    .s_power            = sensor_s_power, 
    .ioctl              = sensor_ioctl, 
};


static const struct v4l2_subdev_video_ops sensor_video_ops =
{
    .s_stream           = sensor_s_stream, 
    .g_frame_interval   = sensor_g_frame_interval, 
};


static const struct v4l2_subdev_pad_ops sensor_pad_ops =
{
    .enum_mbus_code     = sensor_enum_mbus_code, 
    .enum_frame_size    = sensor_enum_frame_sizes, 
    .enum_frame_interval = sensor_enum_frame_interval, 
    .get_fmt            = sensor_get_fmt, 
    .set_fmt            = sensor_set_fmt, 
    .get_mbus_config    = sensor_g_mbus_config, 
    .get_selection      = sensor_get_selection,
};


static const struct v4l2_subdev_ops sensor_subdev_ops =
{
    .core               = &sensor_core_ops, 
    .video              = &sensor_video_ops, 
    .pad                = &sensor_pad_ops, 
};


static int sensor_set_ctrl(struct v4l2_ctrl * ctrl)
{
    int ret = 0;
#if defined(ENABLE_V4L2_CID_EXPOSURE)
    u8 reg, val;
#endif
    struct sensor *sensor = container_of(ctrl->handler, struct sensor, ctrl_handler);

    TRACE_V4L2_CB("client: %s (%d:%d) is running on CPU %d, ctrl->id: 0x%x, ctrl->val: %d, V4L2_CID_EXPOSURE: 0x%x",
        current->comm, current->tgid, current->pid,
        smp_processor_id(),
        ctrl->id, ctrl->val, V4L2_CID_EXPOSURE);

    switch (ctrl->id)
    {
        case V4L2_CID_EXPOSURE:
#if defined(ENABLE_V4L2_CID_EXPOSURE)
            val = ctrl->val & 0xFF;
            if (ADAPS_PCM_MODE == sensor->cur_wkmode)
            {
                reg = 0xC2;
            }
            else {
                reg = 0xC0;
            }
            DBG_NOTICE("---dbg_ctrl: 0x%02x, power_on:%d, streaming: %d, wkmode:%d, mtype:%d, etype:%d, power mode:%d, ctrl->val:0x%x, reg:0x%x, val:0x%x---", 
                sensor->dbg_ctrl, 
                sensor->power_on,
                sensor->streaming,
                sensor->cur_wkmode, 
                sensor->cur_mtype,
                sensor->cur_etype,
                sensor->cur_pmode,
                ctrl->val,
                reg,
                val
                );
            ret = sensor_write_reg_8bit_value(sensor, reg, val);
#endif
            break;

        default:
            DBG_INFO("%s Unhandled id:0x%x, val:0x%x\n", 
                __func__, ctrl->id, ctrl->val);
            break;
    }

    return ret;
}


static const struct v4l2_ctrl_ops sensor_ctrl_ops =
{
    .s_ctrl = sensor_set_ctrl, 
};

static int sensor_initialize_controls(struct sensor * sensor)
{
    const struct sensor_mode *mode;
    struct v4l2_ctrl_handler *handler;
    int             ret;
    s64 pixel_rate;

    handler             = &sensor->ctrl_handler;
    mode                = sensor->cur_sensor_mode;
    ret                 = v4l2_ctrl_handler_init(handler, 8);

    if (ret)
        return ret;

    handler->lock       = &sensor->mutex;

    sensor->ctrl_linkfreqency = v4l2_ctrl_new_int_menu(handler, &sensor_ctrl_ops, V4L2_CID_LINK_FREQ,
        0, 0, sensor_link_freq_items);

    pixel_rate = to_pixel_rate(sensor->mipi_data_lanes);
    sensor->ctrl_pixelrate = v4l2_ctrl_new_std(handler, &sensor_ctrl_ops, V4L2_CID_PIXEL_RATE,
        0, pixel_rate, 1, pixel_rate);

#if defined(ENABLE_V4L2_CID_EXPOSURE)
    sensor->ctrl_exposure    = v4l2_ctrl_new_std(handler, &sensor_ctrl_ops,
        V4L2_CID_EXPOSURE, SENSOR_EXPOSURE_MIN,
        SENSOR_EXPOSURE_MAX, SENSOR_EXPOSURE_STEP, mode->exp_def);
#endif

    if (handler->error) {
        ret = handler->error;
        DBG_ERROR("Failed to init controls(%d)\n", ret);
        goto err_free_handler;
    }

    sensor->subdev.ctrl_handler = handler;

    return 0;

err_free_handler:
    v4l2_ctrl_handler_free(handler);

    return ret;
}

static int sensor_check_sensor_id(struct sensor *sensor)
{
    u32 id  = 0;
    int ret;

    ret = sensor_read_reg(sensor, SENSOR_REG_CHIP_ID, 2, &id);

#if !defined(IGNORE_REAL_COMMUNICATION)
    if (id != CHIP_ID && id != CHIP_ID_VER2) {
        DBG_ERROR("Unexpected sensor id(%06x), ret(%d)\n", id, ret);
        return -ENODEV;
    }
#endif

    DBG_INFO("Detected %s sensor, chipid: 0x%x\n", SENSOR_NAME, id);
    sensor->chipid = id & 0xFFFF;

    return 0;
}

#if defined(REGULATOR_ENABLE)
static int sensor_configure_regulators(struct sensor * sensor)
{
    int i;

    for (i = 0; i < SENSOR_NUM_SUPPLIES; i++)
        sensor->supplies[i].supply = sensor_supply_names[i];

    return devm_regulator_bulk_get(&sensor->sensor_i2c->dev, 
        SENSOR_NUM_SUPPLIES, 
        sensor->supplies);
}
#endif

static int sensor_get_i2c_bus_frequency(struct sensor *sensor)
{
    int ret;
    struct platform_device *pdev_4_i2c_bus;

    pdev_4_i2c_bus = to_platform_device(sensor->sensor_i2c->adapter->dev.parent);
    if (pdev_4_i2c_bus == NULL) {
        DBG_ERROR("pdev_4_i2c_bus is NULL...");
        return -EIO;
    }

    ret = device_property_read_u32(&pdev_4_i2c_bus->dev, "clock-frequency", &sensor->i2c_bus_freq_hz);
    return ret;
}

static ssize_t register_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);

#if 0
    if (false == sensor->power_on)
    {
        printk2console("Register can't be dumped without power on.");
        return 0;
    }
#endif

    sensor_reg_dump(sensor, false, true, __func__, __LINE__);

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
#if defined(OPN7020_VCSEL_DRIVER_ENABLE)
    sensor_vcsel_reg_dump(sensor, true);
#endif
#endif

    tps62864_reg_dump(sensor, true);

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    mcuctrl_reg16_dump(sensor, PhotonIC5015_REG_BASE, PhotonIC5015_REG_COUNT, __func__, __LINE__, true); // vcsel driver PhotonIC 5015 registers
    mcuctrl_reg16_dump(sensor, MCUCTRL_REG_BASE, MCUCTRL_REG_COUNT, __func__, __LINE__, true); // mcu controller related registers
#endif

    return 0;
}

static ssize_t register_store(struct device * dev,
                struct device_attribute * attr,
                const char * buf,
                size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    u32  data;
    u8  val;
    unsigned int len;
    u8 reg;
    int ret;

    ret = sscanf(buf, "write %02hhx %02hhx", &reg, &val);
    if (ret == 2) {
        ret = sensor_write_reg_8bit_value(sensor, reg, val);
        printk2console("Write reg[0x%02x] to 0x%02x, ret: %d...", reg, val, ret);

        return ret ? ret : count;
    }

    ret = sscanf(buf, "read %02hhx %d", &reg, &len);
    if (ret == 2 && len <= 4) {
        ret = sensor_read_reg(sensor, reg, len, &data);

        printk2console("read reg[0x%02x]=0x%x, ret:%d\n", reg, data, ret);
        return ret ? ret : count;
    }
    else {
        return -EINVAL;
    }
}

static DEVICE_ATTR_RW(register);

static void generate_stream_duration(struct sensor *sensor, char *buf)
{
    if (0 == sensor->stream_start)
    {
        buf[0] = '\0';
    }
    else {
        s64 us_delta = ktime_us_delta(ktime_get(), sensor->stream_start);
        u32 stream_seconds = us_delta / 1000000;

        sprintf(buf, " (%d:%02d:%02d)", stream_seconds/3600, (stream_seconds % 3600)/60, stream_seconds % 60);
    }

    return ;
}

static void get_sensor_role(struct sensor *sensor, char *buf)
{
    int ret;

    if (0 == sensor->stream_start)
    {
        sprintf(buf, "%s", "NA");
    }
    else {
        u8 val = 0;

        ret = sensor_read_reg_8bit_value(sensor, 0xA4, &val);
        if (ret < 0)
        {
            sprintf(buf, "%s", "NA");
        }
        else {
            if (1 == (val & 0x01))
            {
                sprintf(buf, "%s", "Master");
            }
            else {
                sprintf(buf, "%s", "Slave");
            }
        }
    }

    return ;
}

static void get_module_type(struct sensor *sensor, u32 *ret_type)
{
    *ret_type = SWIFT_MODULE_TYPE;

    return ;
}

static char * get_kernel_buildtime(void)
{
    char *p = UTS_VERSION + 8; // skip '#250 SMP' at the begin of UTS_VERSION

    while (' ' == *p)   // skip the SPACE at the begin if any.
    {
        p++;
    }

    return p;
}

static ssize_t info_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE,
        "%s\n"
        "Version:                       %s\n"
        "Build Time:                    %s\n"
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        "MCU firmware version:          %d.%d.%d.%d\n"
#endif
        "I2C Bus Num:                   %d\n"
        "I2C bus frequency:             %dHz\n"
        "I2C address for ads6401:       0x%x\n"
        "Current TTY:                   %s\n"
        "tdc_delay_major:               0x%x\n"
        "tdc_delay_minor:               0x%x\n\n",

        DRIVER_NAME,
        FULL_VERSION_STRING,
        get_kernel_buildtime(),
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        (sensor->mcuctrl_fw_version >> 24 & 0xFF),
        (sensor->mcuctrl_fw_version >> 16 & 0xFF),
        (sensor->mcuctrl_fw_version >> 8 & 0xFF),
        (sensor->mcuctrl_fw_version & 0xFF),
#endif
        client->adapter->nr,
        sensor->i2c_bus_freq_hz,
        client->addr,
        get_current_tty()->name,
        sensor->tdc_delay_major,
        sensor->tdc_delay_minor
        );
}
static DEVICE_ATTR_RO(info);

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
static int calc_freq_hz(ktime_t evt_start, ktime_t evt_end, int evt_times)
{
    s64 us_delta;
    int times_per_second = 0;

    us_delta = ktime_us_delta(evt_end, evt_start);
    times_per_second = (evt_times) / (us_delta / 1000000);

    return times_per_second;
}
#endif

static ssize_t force_vop_offset_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "%d0 mv\n", sensor->force_vop_offset);
}

static ssize_t force_vop_offset_store(struct device *dev,
                 struct device_attribute *attr,
                 const char *buf, size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    s16 val16;
    int err;

    err = kstrtos16(buf, 0, &val16);
    if (err)
        return -err;

    sensor->force_vop_offset = val16;

    printk2console("force_vop_offset is adjusted to %d0 mv\n", sensor->force_vop_offset);
    return count;
}
static DEVICE_ATTR_RW(force_vop_offset);

static ssize_t status_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    u32 module_type;
    char stream_duration[32];
    char sensor_role[16];
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor * sensor = to_sensor(sd);
    char *reset_mipi_4_streamon_names[] =
    {
        "No reset",
        "Before",
        "After",
    };

    char *gpio_level_names[] =
    {
        "Low",
        "High",
    };

    char *framerate_type_names[] =
    {
        "Uninitialized",
        "15",
        "25",
        "30",
        "60",
    };

    generate_stream_duration(sensor, stream_duration);
    get_sensor_role(sensor, sensor_role);
    get_module_type(sensor, &module_type);

#if 0
    dump_a_gpio(sensor->reset_gpio, "sensor_reset", __LINE__);
    dump_a_gpio(sensor->iovcc_en_gpio, "iovcc_en", __LINE__);
    dump_a_gpio(sensor->dvcc_en_gpio, "dvcc_en", __LINE__);
    dump_a_gpio(sensor->fsync_irq_gpio, "fsync_irq", __LINE__);
    dump_a_gpio(sensor->drverr_irq_gpio, "drverr_irq", __LINE__);
#endif

    return scnprintf(buf, PAGE_SIZE, 
        "probe success:                 %s\n"
        "static_data_ready:             %s\n"
        "eeprom_crc_matched:            %s\n"
        "dbg_ctrl:                      0x%x\n\n"

        "Sensor Chip id:                0x%x\n"
        "Sensor Role:                   %s\n"
        "Ads6401 module type:           %X\n"
        "raw level of reset_gpio:       %s\n"
        "raw level of iovcc_en_gpio:    %s\n"
        "raw level of dvcc_en_gpio:     %s\n"

#if defined(MINI_DEMO_BOX)
        "raw level of avcc_en_gpio:     %s\n"
        "raw level of drv_vcc_en_gpio:  %s\n"
        "raw level of vbat_en_gpio:     %s\n"
        "raw level of modType1_gpio:    %s\n"
        "raw level of modType2_gpio:    %s\n"
        "raw level of work_state_gpio:  %s\n"
#endif

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        "raw level of fsync_irq_gpio:   %s\n"
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
        "raw level of drverr_irq_gpio:  %s\n"
#endif

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        "frame_sync_irq:                %d (%d, %d Hz)\n"
        "frame_sync_irq_gap:            (%lld -- %lld) us\n"
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
        "vcsel_drv_err_irq:             %d (%d)\n"
#endif
        "Power_on:                      %s (%d)\n"
        "Load_script:                   %s\n"
        "Streaming:                     %s%s\n"
        "Vcsel driver initilized:       %s\n"
        "test_pattern_output_enabled:   %s\n"
        "current temperature:           %d.%02d degree\n"
        "current expected Vop:          -%d.%02d V\n"
        "current force_vop_offset:      %d0 mV\n"
        "vop conversion algo version:   V%d\n"
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE) && defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
        "current pvdd:                  %d.%02d V\n"
#endif
        "Curr workmode:                 %s\n"
        "Curr measurement type:         %s\n"
        "Curr enviroment type:          %s\n"
        "Curr power mode:               %s\n"
        "Curr image-frame-rate setting: %s fps\n"
        "anchor_x:                      %d\n"
        "anchor_y:                      %d\n"
        "rowSearchingRange:             %d\n"
        "colSearchingRange:             %d\n"
        "mipi data lanes:               %d\n"
#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
        "roi_sram_rolling:              %s\n"
        "loaded_roi_sram_size:          %d\n"
        "roi switch times:              %d\n"
        "cur_calib_sram_blk_idx:        %d\n"
        "cur_calib_sram_data_group_idx: %d/%d\n"
#endif
        "cost time for ROI sram write:  (%lld -- %lld) us\n"
        "Reset MIPI mode for stream_on: %s\n\n",

        false == sensor->probe_success ? "No" : "Yes",
        false == sensor->static_data_ready ? "No" : "Yes",
        false == sensor->eeprom_data_crc_matched ? "No" : "Yes",
        sensor->dbg_ctrl,

        sensor->chipid,
        sensor_role,
        module_type,
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->reset_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->iovcc_en_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->dvcc_en_gpio)],

#if defined(MINI_DEMO_BOX)
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->avcc_en_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->drv_vcc_en_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->vbat_en_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->hw_target_id1_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->hw_target_id2_gpio)],
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->work_state_led_gpio)],
#endif

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->fsync_irq_gpio)],
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
        gpio_level_names[gpiod_get_raw_value_cansleep(sensor->drverr_irq_gpio)],
#endif

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
        sensor->fsync_irq,
        sensor->fsync_irq_times,
        calc_freq_hz(sensor->first_fsync_irq_time, sensor->last_fsync_irq_time, sensor->fsync_irq_times),
        sensor->min_fsync_irq_gap, sensor->max_fsync_irq_gap,
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
        sensor->vcsel_drv_err_irq,
        sensor->vcsel_drv_err_irq_times,
#endif
        false == sensor->power_on ? "No" : "Yes",
        sensor->power_on_times,
        false == sensor->load_script ? "No" : "Yes",
        false == sensor->streaming ? "No" : "Yes",
        stream_duration,
        false == sensor->vcsel_inited ? "No" : "Yes",
        false == sensor->test_pattern_enabled ? "No" : "Yes",
        sensor->cur_temperature_x100 / 100,
        sensor->cur_temperature_x100 % 100,
        sensor->cur_vop_abs_x100 / 100,
        sensor->cur_vop_abs_x100 % 100,
        sensor->force_vop_offset,
        sensor->vop_algo_version,
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE) && defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
        sensor->cur_pvdd_x100 / 100,
        sensor->cur_pvdd_x100 % 100,
#endif
        work_mode_name[sensor->cur_wkmode],
        measurement_range_name[sensor->cur_mtype],
        environment_type_name[sensor->cur_etype],
        power_mode_names[sensor->cur_pmode],
        framerate_type_names[sensor->cur_frtype],
        sensor->anchor_x,
        sensor->anchor_y,
        sensor->rowSearchingRange,
        sensor->colSearchingRange,
        sensor->mipi_data_lanes,
#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
        false == sensor->roi_sram_rolling ? "No" : "Yes",
        sensor->loaded_roi_sram_size,
        sensor->roi_switch_req_times,
        sensor->cur_calib_sram_blk_idx,
        sensor->cur_calib_sram_data_group_idx, sensor->max_calib_sram_data_group_cnt,
#endif
        sensor->min_costtime_4_roisram_write,
        sensor->max_costtime_4_roisram_write,
        reset_mipi_4_streamon_names[sensor->reset_mipi_4_streamon]
        );
}
static DEVICE_ATTR_RO(status);

static ssize_t config_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    // do some build options valid check here
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)

    #if defined(VOP_ADJUST_BY_BUILT_IN_MCU) && defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    #error "Both VOP_ADJUST_BY_BUILT_IN_MCU and ENABLE_SOC_PWM_4_VOP_VOLTAGE should not be defined at the same time!!!"
    #endif

    #if !defined(VOP_ADJUST_BY_BUILT_IN_MCU) && !defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    #error "Either VOP_ADJUST_BY_BUILT_IN_MCU or ENABLE_SOC_PWM_4_VOP_VOLTAGE needs to be defined!!!"
    #endif

#else

#endif

#if MIPI_SPEED > MIPISPEED_200M_BPS && defined(ENABLE_SYS_CLK_125M)
    #error "ENABLE_SYS_CLK_125M only is available for mipi speed <= 200M bps."
#endif

#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ) && !defined(ENABLE_SENSOR_FSYNC_IRQ)
    #error "Build option ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ depends on ENABLE_SENSOR_FSYNC_IRQ!!!"
#endif

#if VCSEL_LASER_PERIOD > 127
    #error "VCSEL_LASER_PERIOD should <= 127 ns."
#endif

    return scnprintf(buf, PAGE_SIZE, 
        "Build switch options:\n"
        "---------------------------------------------------------\n"
        "MINI_DEMO_BOX:                                     %s\n"
        "ADS6401_MODULE_TYPE:                               %s\n"
        "CALIB_DATA_READY_IN_EEPROM_CHIP:                   %s\n"
        "FRAMERATE_TEST_4_60FPS:                            %s\n"
        "SENSOR_XCLK_FROM_SOC:                              %s\n"
        "IGNORE_PROBE_FAILURE:                              %s\n"
        "ENABLE_SYSFREQ_ADJUST_4_LOW_POWER:                 %s\n"
        "ENABLE_RUNTIME_REGISTER_UPDATE:                    %s\n"
        "ENABLE_SYS_CLK_125M:                               %s\n"
        "USE_DIV1_FOR_1G_MIPISPEED:                         %s\n"
        "ENABLE_VCSEL_DRV_ERROR_IRQ:                        %s\n"
        "VCSEL_ERR_DETECT_ENABLE:                           %s\n"
        "VOP_ADJUST_BY_BUILT_IN_MCU:                        %s\n"
        "ENABLE_SOC_PWM_4_VOP_VOLTAGE:                      %s\n"
        "ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ:             %s\n"
        "INTERNAL_DBG_ENABLE:                               %s\n"
        "ROISRAM_ANCHOR_PREPROCCESS_ENABLE:                 %s\n\n"

        "NON_CONTINUOUS_MIPI_CLK:                           %s\n"
        "MIPI_DATA_LANE_COUNT:                              %d\n"
        "MIPI_SPEED:                                        %d Mbps\n"
        "SOC_MIPI_RX_CLOCK_FREQ:                            %d MHz\n"
        "EEPROM_CHIP_CAPACITY:                              %d bytes\n"
        "ADAPS_DBG_ONCE:                                    0x%x\n\n",

#if defined(MINI_DEMO_BOX)
        "Yes",
#else
        "No",
#endif

        ADS6401_MODULE_TYPE_NAME,

#if defined(CALIB_DATA_READY_IN_EEPROM_CHIP)
        "Yes",
#else
        "No",
#endif

#if defined(FRAMERATE_TEST_4_60FPS)
        "Yes",
#else
        "No",
#endif

#if defined(SENSOR_XCLK_FROM_SOC)
        "Yes",
#else
        "No",
#endif

#if defined(IGNORE_PROBE_FAILURE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SYSFREQ_ADJUST_4_LOW_POWER)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_RUNTIME_REGISTER_UPDATE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SYS_CLK_125M)
        "Yes",
#else
        "No",
#endif

#if defined(USE_DIV1_FOR_1G_MIPISPEED)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
        "Yes",
#else
        "No",
#endif

#if defined(VCSEL_ERR_DETECT_ENABLE)
        "Yes",
#else
        "No",
#endif

#if defined(VOP_ADJUST_BY_BUILT_IN_MCU)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
        "Yes",
#else
        "No",
#endif

#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
        "Yes",
#else
        "No",
#endif

#if defined(INTERNAL_DBG_ENABLE)
        "Yes",
#else
        "No",
#endif

#if defined(ROISRAM_ANCHOR_PREPROCCESS_ENABLE)
        "Yes",
#else
        "No",
#endif

#if defined(NON_CONTINUOUS_MIPI_CLK)
        "Yes",
#else
        "No",
#endif

        SENSOR_DATA_LANE_COUNT,
        MIPI_SPEED,
        SOC_MIPI_RX_CLOCK_FREQ,
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
        FLOOD_MODULE_EEPROM_CAPACITY_SIZE,
#else
        SPOT_MODULE_EEPROM_CAPACITY_SIZE,
#endif
        ADAPS_DBG_ONCE
        );
}
static DEVICE_ATTR_RO(config);

static int calc_frequency(struct sensor *sensor, char *out_buf, int max_length)
{
    #define X10     10
    u8 reg;
    uint32_t data;
    int rc = 0;
    u8 val8 = 0;
    u8 xclk = SENSOR_XVCLK_FREQ_M;

    uint32_t syspll_Fvco = 0;
    uint32_t mipipll_Fvco = 0;
    uint32_t syspll_clk = 0;    // mclk, mesh clock
    uint32_t mipi_clk_X10 = 0; // Linux kernel doesn't support float type, so X 10 here.
    char mipi_clk_string[16];
    uint32_t mipi_TxEscClk = 0;
    uint32_t mipi_speed_per_lane = 0;
    uint32_t sys_clk = 0;
    uint32_t tdc_clk = 0;

    u8 sysclk_div_m = 0;
    u8 sysclk_div_n = 0;
    u8 syspll_id = 0;       // input divider
    u8 syspll_od = 0;       // output divider
    u8 syspll_fb = 0;       // feedback divider
    u8 syspll_ld = 0;       // laser divider

    u16 mipipll_div_ns = 0;
    u8 mipipll_div_ms = 0;
    u8 mipipll_div_ps = 0;
    u8 mipi_dphy_tx_frange_cfg = 0;
    u8 mipi_dphy_tx_freq_range = 0;
    u8 mipi_tx_delay_cfg = 0;

    if (false == sensor->power_on)
    {
        printk2console("System frequency can't be caculated without power on.");
        return -EPERM;
    }

    reg = 0xA9;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    mipi_tx_delay_cfg = val8;

    reg = 0xA5;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    sysclk_div_n = (val8 & 0x0F);
    sysclk_div_m = ((val8 >> 4) & 0x0F);

    reg = 0xD4;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    syspll_id = ((val8 >> 4) & 0x07);
    syspll_od = (1 << ((val8 & 0x03) + 1));

    reg = 0xD5;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    syspll_fb = val8;

    reg = 0xD6;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    syspll_ld = (1 << (val8 & 0x03));

    reg = 0xE6;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    mipipll_div_ns = ((val8 << 8) & 0x100);
    reg = 0xE7;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    mipipll_div_ns |= val8;

    reg = 0xE9;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    mipipll_div_ps = (val8 & 0x1F);
    mipipll_div_ms = ((val8 >> 5) & 0x07);

    reg = 0x81;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    mipi_dphy_tx_frange_cfg = ((val8 >> 3) & 0x4);
    DBG_INFO("data: 0x%x, val8: 0x%x, mipi_dphy_tx_frange_cfg: 0x%x", data, val8, mipi_dphy_tx_frange_cfg);
    reg = 0x7E;
    rc = sensor_read_reg_8bit_value(sensor, reg, &val8);
    val8 = (val8 >> 2) & 0x3;
    mipi_dphy_tx_frange_cfg |= val8;
    DBG_INFO("data: 0x%x, val8: 0x%x, mipi_dphy_tx_frange_cfg: 0x%x", data, val8, mipi_dphy_tx_frange_cfg);

    mipi_dphy_tx_freq_range = 6 * (1 << mipi_dphy_tx_frange_cfg);

    if (0 == syspll_id)
    {
        DBG_ERROR("syspll_id can not be 0.");
        return -EINVAL;
    }

    if (0 == mipipll_div_ms)
    {
        DBG_ERROR("mipipll_div_ms can not be 0.");
        return -EINVAL;
    }

    if (0 == mipipll_div_ps)
    {
        DBG_ERROR("mipipll_div_ps can not be 0.");
        return -EINVAL;
    }

    syspll_Fvco = (xclk * syspll_fb) / syspll_id;
    tdc_clk = syspll_Fvco * 8;
    syspll_clk = syspll_Fvco / syspll_od;
    mipi_TxEscClk = syspll_clk / 15;
    if (0 == sysclk_div_m || 0 == sysclk_div_n)
    {
        sys_clk = syspll_clk;
    }
    else {
        sys_clk = (syspll_clk * sysclk_div_m) / sysclk_div_n;
    }

    mipipll_Fvco = (xclk * mipipll_div_ns) / mipipll_div_ms;
    mipi_clk_X10 = mipipll_Fvco * X10 / (mipipll_div_ps * 8);
    mipi_speed_per_lane = mipi_clk_X10 * 8 / X10;

    if (0 != (mipi_clk_X10 % X10))
    {
        sprintf(mipi_clk_string, "%d.%d", mipi_clk_X10 / 10, mipi_clk_X10 % 10);
    }
    else {
        sprintf(mipi_clk_string, "%d", mipi_clk_X10 / 10);
    }

    rc = scnprintf(out_buf, max_length,
        "System frequency list:\n"
        "FORCE_MIPI_TX_DELAY:           0x%02x\n"
        "FORCE_MIPI_SPEED:              %d Mbps\n\n"

        "sysclk_div_m:                  %d\n"
        "sysclk_div_n:                  %d\n"
        "syspll_id:                     %d\n"
        "syspll_od:                     %d\n"
        "syspll_fb:                     %d\n"
        "syspll_ld:                     %d\n"
        "mipi_tx_delay_cfg:             %d\n"
        "mipi_dphy_tx_pll_frange_config:%d\n"
        "mipipll_div_ns:                %d\n"
        "mipipll_div_ms:                %d\n"
        "mipipll_div_ps:                %d\n\n"

        "xclk:                          %d MHz\n"
        "syspll_Fvco (1G - 2G Hz):      %d MHz\n"
        "syspll_clk:                    %d MHz\n"
        "sys_clk (>= 3*XCLK):           %d MHz\n"
        "tdc_clk:                       %d MHz\n\n"

        "mipipll_Fvco (1G - 2G Hz):     %d MHz\n"
        "mipi_clk:                      %s MHz\n"
        "mipi_dphy_tx_pll_freq_range:   %d ~ %d MHz\n"
        "mipi_TxEscClk:                 %d MHz\n"
        "mipi_frame_end_delay:          %d us\n"
        "mipi_packet_delay:             %d us\n"
        "mipi_speed (per_lane):         %d Mbps\n"
        "SOC_MIPI_RX_CLOCK_FREQ:        %d MHz\n\n",

        sensor->force_mipi_tx_delay,
        sensor->force_mipi_speed,

        sysclk_div_m,
        sysclk_div_n,
        syspll_id,
        syspll_od,
        syspll_fb,
        syspll_ld,
        mipi_tx_delay_cfg,
        mipi_dphy_tx_frange_cfg,
        mipipll_div_ns,
        mipipll_div_ms,
        mipipll_div_ps,

        xclk,
        syspll_Fvco,
        syspll_clk,
        sys_clk,
        tdc_clk,

        mipipll_Fvco,
        mipi_clk_string,
        mipi_dphy_tx_freq_range, mipi_dphy_tx_freq_range*2,
        mipi_TxEscClk,
        4 * (1 << ((mipi_tx_delay_cfg >> 6) & 0x3)),
        mipi_tx_delay_cfg & 0x3F,
        mipi_speed_per_lane,
        SOC_MIPI_RX_CLOCK_FREQ
        );

    return rc;
}

static ssize_t frequency_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int rc = 0;

    rc = calc_frequency(sensor, buf, PAGE_SIZE);

    if (0 > rc)
    {
        return -EINVAL;
    }

    return rc;
}
static DEVICE_ATTR_RO(frequency);

static ssize_t reset_mipi_4_streamon_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "%d\n", sensor->reset_mipi_4_streamon);
}

static ssize_t reset_mipi_4_streamon_store(struct device *dev,
                 struct device_attribute *attr,
                 const char *buf, size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int val;
    int err;

    err = kstrtoint(buf, 0, &val);
    if (err)
        return -err;

    if (val >= STREAM_ON_WITHOUT_MIPI_IP_RESET && val <= STREAM_ON_FIRST_AND_THEN_RESET_MIPI_IP)
    {
        sensor->reset_mipi_4_streamon = val;
    }
    else {
        return -EINVAL;
    }

    return count;
}
static DEVICE_ATTR_RW(reset_mipi_4_streamon);


static ssize_t manual_powerctl_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;
    char cmd[20];

    ret = sscanf(buf, "%s", cmd);
    if (ret == 1) {
        if (3 == count) {
            ret = memcmp(cmd,"On",3);
            if (0 == ret)
            {
                ret = sensor_set_power_on(sensor, __LINE__);
                printk2console("manual power on %s, ret: %d\n", 0 == ret ? "successfully" : "failure", ret);
                ret = 0; // avoid "write error: Operation not permitted"
            }
            else {
                printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
                return -EINVAL;
            }
        }
        else if (4 == count) {
            ret = memcmp(cmd,"Off",3);
            if (0 == ret)
            {
                //u32 bk_dbg_ctrl = sensor->dbg_ctrl;
                //sensor->dbg_ctrl = ADAPS_DBG_DISABLE_VCSEL_DRVIER;
                sensor_set_power_off(sensor, __LINE__);
                //sensor->dbg_ctrl = bk_dbg_ctrl;
                printk2console("manual power off successfully");
                ret = 0; // avoid "write error: Operation not permitted"
            }
            else {
                printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
                return -EINVAL;
            }
        }
    }
    else {
        printk2console("ret %d, count:%ld, buf:%s...", ret, count, buf);
        return -EINVAL;
    }

    return ret ? -1 : count;
}

static DEVICE_ATTR_WO(manual_powerctl);

static ssize_t vop_adjust_interval_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    return scnprintf(buf, PAGE_SIZE, "%lld ns\n", sensor->vop_adjust_delay);
}

static ssize_t vop_adjust_interval_store(struct device *dev,
                 struct device_attribute *attr,
                 const char *buf, size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    unsigned long val;
    int err;

    err = kstrtoul(buf, 0, &val);
    if (err)
        return -err;

    sensor->vop_adjust_delay = val;

    return count;
}
static DEVICE_ATTR_RW(vop_adjust_interval);

#if !defined(VOP_ADJUST_BY_BUILT_IN_MCU)
#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
static ssize_t vop_pwm_test_show(struct device *dev,
                struct device_attribute *attr, char *buf)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    struct pwm_state state;

    pwm_get_state(sensor->pwm_4_vop.pwm_dev, &state);

    return scnprintf(buf, PAGE_SIZE, 
        "period_ns:             %d ns\n"
        "duty_ns:               %d ns\n"
        "current set voltage:   %d\n"
        "current status:        %s\n\n",

        sensor->pwm_4_vop.current_period_ns,
        sensor->pwm_4_vop.current_duty_ns,
        sensor->pwm_4_vop.current_set_voltage,
        true == state.enabled ? "Enabled" : "Disabled"
    );
}

static ssize_t vop_pwm_test_store(struct device *dev,
                                    struct device_attribute *attr,
                                    const char *buf,
                                    size_t count)
{
    struct i2c_client *client = to_i2c_client(dev);
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);
    int ret = 0;
    int test_case;
    int param2;
    int duty_ns;

    ret = sscanf(buf, "%d %d", &test_case, &param2);
    if (2 == ret) {
        if (2 == test_case) // test_case:2 set PWM duty by voltage (x10 mv)
        {
            s16 voltage = 0;
            if (param2 < VOP_VOLTAGE_MIN || param2 > VOP_VOLTAGE_MAX)   // volt's unit is 10mv
            {
                printk2console("Invalid voltage: %d.%d\n", param2/100, param2%100);
                return -EINVAL;
            }

            voltage = param2;
            duty_ns = sensor_vop_pwm_convert_voltage_to_duty(sensor, voltage);
            ret = sensor_vop_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("Vop voltage is adjusted to -%d.%d v\n", param2/100, param2%100);
            }
        }
        else if (3 == test_case) // test_case:3 set PWM duty by duty (ns)
        {
            duty_ns = param2;
            if (duty_ns < 0 || duty_ns > sensor->pwm_4_vop.current_period_ns)
            {
                printk2console("Invalid duty_ns: %d, since period_ns is %d ns\n", duty_ns, sensor->pwm_4_vop.current_duty_ns);
                return -EINVAL;
            }

            ret = sensor_vop_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else if (4 == test_case) // test_case:4 set PWM duty by permillage 
        {
            int permillage = param2;
            if (permillage < 0 || permillage > PWM_VOLTAGE_ADJUST_STEPS)
            {
                printk2console("Invalid permillage: %d\n", permillage);
                return -EINVAL;
            }

            duty_ns = (sensor->pwm_4_vop.current_period_ns * permillage) / PWM_VOLTAGE_ADJUST_STEPS;
            ret = sensor_vop_pwm_set_duty(sensor, duty_ns);
            if (ret < 0)
            {
                return ret;
            }
            else {
                printk2console("PWM duty is adjusted to %d ns\n", duty_ns);
            }
        }
        else {
            return -EINVAL;
        }
    }
    else if (1 == ret) {
        if (0 == test_case) // test_case:0  disable PWM
        {
            sensor_vop_pwm_disable(sensor);
            printk2console("Vop PWM is disabled\n");
        }
        else if (1 == test_case) // test_case:1  enable PWM
        {
            sensor_vop_pwm_enable(sensor);
            printk2console("Vop PWM is enabled\n");
        }
        else {
            return -EINVAL;
        }
    }
    else {
        return -EINVAL;
    }

    return count;
}

static DEVICE_ATTR_RW(vop_pwm_test);
#endif
#endif

#if defined(INTERNAL_DBG_ENABLE)
#include "ads6401_internal.c"
#endif

static struct attribute *my_drv_attrs[] = {
    &dev_attr_register.attr,
    &dev_attr_info.attr,
    &dev_attr_status.attr,
    &dev_attr_config.attr,
    &dev_attr_frequency.attr,
    &dev_attr_vop_adjust_interval.attr,
    &dev_attr_force_vop_offset.attr,
    &dev_attr_reset_mipi_4_streamon.attr,
    &dev_attr_manual_powerctl.attr,
#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    &dev_attr_vop_pwm_test.attr,
#endif

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    &dev_attr_vbat_pwm_test.attr,
    &dev_attr_force_enable_vcsel_4_pcm_mode.attr,
#else
#if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    &dev_attr_pvdd_pwm_test.attr,
#endif
#endif

#if defined(INTERNAL_DBG_ENABLE)
    &dev_attr_i2c_address.attr,
    &dev_attr_reset_gpio.attr,
    &dev_attr_force_sensor_role.attr,
    &dev_attr_manual_reset_mipi.attr,
    &dev_attr_mipi_performance_dbg.attr,
    &dev_attr_eeprom_restore.attr,
    &dev_attr_eeprom_write_test.attr,
    &dev_attr_otp_data_read.attr,
    &dev_attr_otp_info.attr,
#endif
    NULL,
};

static const struct attribute_group my_drv_attrs_group = {
    .attrs = my_drv_attrs,
};

static int cam_sensor_register_attrib_group(struct device *dev)
{
    return sysfs_create_group(&dev->kobj, &my_drv_attrs_group);
}

static int cam_sensor_adaps_dbg_set(void *data, u64 val)
{
    struct sensor *sensor = (struct sensor *)data;

    //DBG_INFO(CAM_SENSOR, "val:0x%x, adaps_debug:0x%x, streaming:%d...\r\n",val,sensor->dbg_ctrl, sensor->streaming);

    //when ADAPS_DBG_ONCE bit is set, we can dump some data for specified registers.
    if (val > ADAPS_DBG_ONCE)
    {
        // CMD: adb root
        // CMD: adb remount
        // CMD: adb shell "echo 0x90 > /sys/kernel/debug/adaps/dbg_ctrl"

        // only when stream ON state, the followng dump is available
        if (sensor->streaming) {
            // CMD: adb shell "echo 0x82 > /sys/kernel/debug/adaps/dbg_ctrl"
            // CMD: adb shell "echo 0x8f > /sys/kernel/debug/adaps/dbg_ctrl" will dump all registers without the skip sign XX.
            if (val & ADAPS_DBG_DUMP_REGS) {
                sensor_reg_dump(sensor, false, true, __func__, __LINE__);
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
#if defined(OPN7020_VCSEL_DRIVER_ENABLE)
                sensor_vcsel_reg_dump(sensor, true);
#endif
#endif

                tps62864_reg_dump(sensor, true);

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
                mcuctrl_reg16_dump(sensor, PhotonIC5015_REG_BASE, PhotonIC5015_REG_COUNT, __func__, __LINE__, true); // vcsel driver PhotonIC 5015 registers
                mcuctrl_reg16_dump(sensor, MCUCTRL_REG_BASE, MCUCTRL_REG_COUNT, __func__, __LINE__, true); // mcu controller related registers
#endif
            }
            // CMD: adb shell "echo 0xC0 > /sys/kernel/debug/adaps/dbg_ctrl"
            else if (val & ADAPS_DBG_DUMP_SRAM_REG) {
                // todo
            }
        }
        return 0;
    }

    sensor->dbg_ctrl = (val & 0xffffffff);

    return 0;
}

static int cam_sensor_adaps_dbg_get(void *data, u64 *val)
{
    struct sensor *sensor = (struct sensor *)data;

    *val = sensor->dbg_ctrl;

    return 0;
}

DEFINE_SIMPLE_ATTRIBUTE(cam_sensor_adaps_dbg_control,
    cam_sensor_adaps_dbg_get, cam_sensor_adaps_dbg_set, "0x%0llx\n\n");

#if 0
static uint64_t integer_pow(uint64_t base, uint64_t exp)
{
    uint64_t result = 1;
    while (exp)
    {
        if (exp & 1)
           result *= base;
        exp >>= 1;
        base *= base;
    }

    return result;
}
#endif

static int sensor_get_vop_algo_version(struct sensor *sensor)
{
    #define OTP_TEMPERATURE_HIGH_4_V3               7000
    #define V2_LOT_ID_CNT_4_V2                      2
    #define OTP_LOT_ID_LENGTH                       6
    int i;
    int ret = 0;
    const u8 vop_v2_productId[V2_LOT_ID_CNT_4_V2][OTP_LOT_ID_LENGTH] = {
        {0x50, 0x50, 0x54, 0x32, 0x34, 0x32},     // PPT242
        {0x50, 0x54, 0x32, 0x31, 0x33, 0x31}      // PT2131
    };

    sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_1;    // set to V1 by default

    if (OTP_TEMPERATURE_HIGH_4_V3 == sensor->otp_T_high)
    {
        sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_3;
    }
    else {
        for (i = 0; i < V2_LOT_ID_CNT_4_V2; i++)
        {
            if (0 == memcmp(vop_v2_productId[i], sensor->otp_product_id, OTP_LOT_ID_LENGTH))
            {
                sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_2;
                break;
            }
        }
    }

    return ret;
}

// the returned value(Vop) is X100 too, and it is absolute value, since the real vop is negative
static uint32_t calc_vop_per_temperature_v1(struct sensor *sensor, uint32_t temperature_x100)
{

#if 0
    uint32_t vop_volt_abs_x100 = 0;

    /* the old formula from SpadisPC
        double temperature;
        double Vop;

        #define TEMPERATURE_VOP_COEFFICIENT_1    22.68
        #define TEMPERATURE_VOP_COEFFICIENT_2    0.0332
        #define TEMPERATURE_VOP_COEFFICIENT_3    0.000537
        #define TEMPERATURE_VOP_COEFFICIENT_4    -0.00000307

        Vop = TEMPERATURE_VOP_COEFFICIENT_1 \
            + TEMPERATURE_VOP_COEFFICIENT_2 * temperature \
            + TEMPERATURE_VOP_COEFFICIENT_3 * temperature * temperature \
            + TEMPERATURE_VOP_COEFFICIENT_4 * temperature * temperature * temperature;
    */
    #define TEMPERATURE_VOP_COEFFICIENT_1       2268 // X100
    #define TEMPERATURE_VOP_COEFFICIENT_2       332 // X10000
    #define TEMPERATURE_VOP_COEFFICIENT_3       537 // X1000000
    #define TEMPERATURE_VOP_COEFFICIENT_4       307 // X100000000

    uint32_t Vop1_x100, Vop2_x100, Vop3_x100, Vop4_x100;

    Vop1_x100 = TEMPERATURE_VOP_COEFFICIENT_1;

    Vop2_x100 = TEMPERATURE_VOP_COEFFICIENT_2 * temperature_x100 / integer_pow(10,4);
    Vop3_x100 = (uint32_t)(((uint64_t)TEMPERATURE_VOP_COEFFICIENT_3 * ((uint64_t)temperature_x100) * ((uint64_t)temperature_x100)) / integer_pow(10,8));
    Vop4_x100 = (uint32_t)(((uint64_t)TEMPERATURE_VOP_COEFFICIENT_4 * ((uint64_t)temperature_x100) * ((uint64_t)temperature_x100) * ((uint64_t)temperature_x100)) / integer_pow(10,12));

    vop_volt_abs_x100 = Vop1_x100 + Vop2_x100 + Vop3_x100 - Vop4_x100;
    //DBG_NOTICE("---temperature_x_100:%d, vop_volt_abs_x100:%d ---",temperature_x100, vop_volt_abs_x100);

    return vop_volt_abs_x100;
#else

    /* the new formula,
        double temperature;
        double Vop;

        if (temperature <= 25) {
            Vop = 0.033 * temperature + Vbd - 0.825;
        }
        else {
            Vop = 0.061 * temperature + Vbd - 1.525;
        }
    */

    uint32_t new_vop_volt_abs_x100 = 0;

    if (0 == sensor->t_point_x100[SWIFT_VOP_ALGO_VER_1 - 1])
    {
        sensor->t_point_x100[SWIFT_VOP_ALGO_VER_1 - 1] = OTP_TEMPERATURE_LOW;
    }

    if (temperature_x100 <= sensor->t_point_x100[SWIFT_VOP_ALGO_VER_1 - 1]) {
        new_vop_volt_abs_x100 = (33 * temperature_x100)/1000 + sensor->otp_vbd_low - 83;
    }
    else {
        new_vop_volt_abs_x100 = (61 * temperature_x100)/1000 + sensor->otp_vbd_low - 153;
    }

    return new_vop_volt_abs_x100;
#endif
}

// the returned value(Vop) is X100 too, and it is absolute value, since the real vop is negative
static uint32_t calc_vop_per_temperature_v2(struct sensor *sensor, uint32_t temperature_x100)
{
    /*
        double temperature;
        double Vop;

        Tpoint = (3.165 - (Vbd_high - Vbd_low)) / 0.024
        Tpoint_x100 = ((317 - (Vbd_high_x100 - Vbd_low_x100)) * 1000) / 24
        Tpoint_x100 = ((317 - (Vbd_high_x100 - Vbd_low_x100)) * 125) / 3

        if (temperature <= Tpoint) {
            Vop = 0.033 * temperature + Vbd_low - 0.825;
        }
        else {
            Vop = 0.057 * temperature + Vbd_high - 3.99;
        }
    */

    uint32_t new_vop_volt_abs_x100 = 0;

    if (0 == sensor->t_point_x100[SWIFT_VOP_ALGO_VER_2 - 1])
    {
        sensor->t_point_x100[SWIFT_VOP_ALGO_VER_2 - 1] = ((317 - (sensor->otp_vbd_high - sensor->otp_vbd_low)) * 125) / 3;
    }

    if (temperature_x100 <= sensor->t_point_x100[SWIFT_VOP_ALGO_VER_2 - 1]) {
        new_vop_volt_abs_x100 = (33 * temperature_x100)/1000 + sensor->otp_vbd_low - 83;
    }
    else {
        new_vop_volt_abs_x100 = (57 * temperature_x100)/1000 + sensor->otp_vbd_high - 399;
    }

    return new_vop_volt_abs_x100;
}

// the returned value(Vop) is X100 too, and it is absolute value, since the real vop is negative
static uint32_t calc_vop_per_temperature_v3(struct sensor *sensor, uint32_t temperature_x100)
{
    /*
        double temperature;
        double Vop;

        Tpoint = (Khigh * Thigh - Klow * Tlow + Vbd_low - Vbd_high) / (Khigh - Klow)

        if (temperature <= Tpoint) {
            Vop = Klow * (temperature - Tlow) + Vbd_low;
        }
        else {
            Vop = Khigh * (temperature - Thigh) + Vbd_high;
        }
    */

    uint32_t new_vop_volt_abs_x100 = 0;

    if (0 == sensor->t_point_x100[SWIFT_VOP_ALGO_VER_3 - 1])
    {
        sensor->t_point_x100[SWIFT_VOP_ALGO_VER_3 - 1] = (sensor->otp_K_high * sensor->otp_T_high - sensor->otp_K_low * sensor->otp_T_low + (sensor->otp_vbd_low - sensor->otp_vbd_high)*1000) / (sensor->otp_K_high - sensor->otp_K_low);
    }

    if (temperature_x100 <= sensor->t_point_x100[SWIFT_VOP_ALGO_VER_3 - 1]) {
        new_vop_volt_abs_x100 = (sensor->otp_K_low * (temperature_x100 - sensor->otp_T_low) / 1000) + sensor->otp_vbd_low;
    }
    else {
        int tmp = (temperature_x100 - sensor->otp_T_high);
        tmp = ((int) sensor->otp_K_high * tmp / 1000);
        tmp += (int) sensor->otp_vbd_high;
        new_vop_volt_abs_x100 = (uint32_t) tmp;
    }
    DBG_INFO("***otp_K_high: %u, otp_T_high: %u, otp_K_low: %u, otp_T_low: %u, otp_vbd_low: %u, otp_vbd_high: %u, t_point_x100: %u, new_vop_volt_abs_x100: %d***",
        sensor->otp_K_high, sensor->otp_T_high, sensor->otp_K_low, sensor->otp_T_low, sensor->otp_vbd_low, sensor->otp_vbd_high, sensor->t_point_x100[SWIFT_VOP_ALGO_VER_3 - 1], new_vop_volt_abs_x100);

    return new_vop_volt_abs_x100;
}

static int sensor_timer_adjust_vop(struct sensor *sensor, bool first_read)
{
    int ret = 0;
    u32 temperature_x100;
    static u32 read_temperature_times = 0;
    u32 v1_vop_abs_x100 = 0;
    u32 v2_vop_abs_x100 = 0;
    u32 v3_vop_abs_x100 = 0;

    read_temperature_times++;
    ret = sensor_get_inside_temperature(sensor, &temperature_x100);
    if (ret < 0)
    {
        DBG_ERROR("Fail to read sensor inside temperature, ret:%d", ret);
        return ret;
    }

    if (first_read || (temperature_x100 < CHIP_TEMPERATURE_MIN_THRESHOLD))
    {
        DBG_NOTICE("***temperature_x100: %d, first_read: %d***",temperature_x100, first_read);
    }

    if ((!first_read) && (temperature_x100 == sensor->cur_temperature_x100))
    {
        // temperature doesn't change, return
        return ret;
    }

    if (temperature_x100 < CHIP_TEMPERATURE_MIN_THRESHOLD)
    {
        DBG_ERROR("read_temperature_times: %d, current temperature (%d.%d) < %d degree, use %d degree instead.",
            read_temperature_times, temperature_x100/100, temperature_x100%100,
            CHIP_TEMPERATURE_MIN_THRESHOLD/100, CHIP_TEMPERATURE_MIN_THRESHOLD/100
            );
        temperature_x100 = CHIP_TEMPERATURE_MIN_THRESHOLD;
    }
    if (temperature_x100 > CHIP_TEMPERATURE_MAX_THRESHOLD)
    {
        DBG_ERROR("read_temperature_times: %d, current temperature (%d.%d) > %d degree, use %d degree instead.",
            read_temperature_times, temperature_x100/100, temperature_x100%100,
            CHIP_TEMPERATURE_MAX_THRESHOLD/100, CHIP_TEMPERATURE_MAX_THRESHOLD/100
            );
        temperature_x100 = CHIP_TEMPERATURE_MAX_THRESHOLD;  // todo: is this reasonable?
    }

    sensor->cur_temperature_x100 = temperature_x100;
    v1_vop_abs_x100 = calc_vop_per_temperature_v1(sensor, sensor->cur_temperature_x100);
    v2_vop_abs_x100 = calc_vop_per_temperature_v2(sensor, sensor->cur_temperature_x100);

    if (SWIFT_VOP_ALGO_VER_3 == sensor->vop_algo_version)
    {
        v3_vop_abs_x100 = calc_vop_per_temperature_v3(sensor, sensor->cur_temperature_x100);
        sensor->cur_vop_abs_x100 = v3_vop_abs_x100 + sensor->force_vop_offset;
    }
    else if (SWIFT_VOP_ALGO_VER_2 == sensor->vop_algo_version)
    {
        sensor->cur_vop_abs_x100 = v2_vop_abs_x100 + sensor->force_vop_offset;
    }
    else
    {
        sensor->cur_vop_abs_x100 = v1_vop_abs_x100 + sensor->force_vop_offset;
    }

    if (sensor->dbg_ctrl & ADAPS_DBG_VOLTAGE_UPDATE)
    {
        DBG_NOTICE("***temperature_x100: %u, expected_vop_abs_x100: %d, force_vop_offset_x100: %d, vop_algo_v%u, t_point_x100: %d, v1_vop_abs_x100: %u, v2_vop_abs_x100: %u, v3_vop_abs_x100: %u***",
            temperature_x100, sensor->cur_vop_abs_x100, sensor->force_vop_offset, sensor->vop_algo_version, sensor->t_point_x100[sensor->vop_algo_version - 1], v1_vop_abs_x100, v2_vop_abs_x100, v3_vop_abs_x100);
    }

#if !defined(VOP_ADJUST_BY_BUILT_IN_MCU)
    set_vop_voltage(sensor, 0 - sensor->cur_vop_abs_x100);
#endif

    return ret;
}

static void sensor_work_handler(struct work_struct *work)
{
    struct sensor *sensor = container_of(work, struct sensor, vop_adjust_work);

    if (sensor->streaming)
    {
        sensor_timer_adjust_vop(sensor, false);
    }

    return;
}

static enum hrtimer_restart sensor_vop_adjust_timer_func(struct hrtimer *timer)
{
    struct sensor *sensor = container_of(timer, struct sensor, vop_adjust_timer);

    if (false == sensor->power_on)
    {
        DBG_NOTICE("vop_adjust_timer is exiting since power off");
        return HRTIMER_NORESTART;
    }
    queue_work(sensor->vop_adjust_wq, &sensor->vop_adjust_work);
    hrtimer_forward_now(&sensor->vop_adjust_timer, sensor->vop_adjust_delay);
    return HRTIMER_RESTART;
}

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
static int sensor_switch_roi_sram(struct sensor *sensor, bool firstWriteSRAM)
{
    uint8_t reg;
    int ret;
    u8  val;

    if (false == sensor->allow_roi_switch)
    {
        DBG_ERROR("roi switch are not allowed, please check\n");
        return -EPERM;
    }

    if (sensor->roi_sram_rolling)
    {
        if (0 == sensor->cur_calib_sram_blk_idx)
        {
            reg = CALIB_SRAM_REG_BASE0;
        }
        else {
            reg = CALIB_SRAM_REG_BASE1;
        }

        ret = sensor_write_sram_register(sensor, reg, PER_ROISRAM_GROUP_SIZE, &sensor->loaded_roi_sram[sensor->cur_calib_sram_data_group_idx * PER_ROISRAM_GROUP_SIZE], __LINE__);
        if (ret < 0) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
        if (0 != (sensor->dbg_ctrl & ADAPS_DBG_TRACE_ROI_SWITCH)) {
            DBG_NOTICE("Write ROI SRAM (reg: 0x%02x, size: %d bytes), switch_req_times: %d, sram_blk_idx: %d, sram_data_group_idx: %d...\n",
                reg, PER_ROISRAM_GROUP_SIZE, sensor->roi_switch_req_times, sensor->cur_calib_sram_blk_idx, sensor->cur_calib_sram_data_group_idx);
            hexdump((const char *) &sensor->loaded_roi_sram[sensor->cur_calib_sram_data_group_idx * PER_ROISRAM_GROUP_SIZE], 16, "first 16 bytes of this ROI SRAM update");
        }

        // change the index for next ROI sram switch write
        sensor->cur_calib_sram_data_group_idx++;
        if (sensor->cur_calib_sram_data_group_idx >= sensor->max_calib_sram_data_group_cnt)
        {
            sensor->cur_calib_sram_data_group_idx = 0;
        }
    }

    if (!firstWriteSRAM)
    {
        reg = 0xAC;
        if (1 == sensor->cur_calib_sram_blk_idx)
        {
            val = 0x03;
        }
        else {
            val = 0x01;
        }

        ret = sensor_write_reg_8bit_value(sensor, reg, val);
        if (ret < 0) {
            DBG_ERROR("fail to write sensor register, reg: 0x%x, ret:%d\n", reg, ret);
            return ret;
        }
        sensor->roi_switch_req_times++;

        if (1 == sensor->roi_switch_req_times)
        {
            DBG_NOTICE("ROI switch is triggered, fsync_roi_switch_delay: %d ms---",
                sensor->fsync_roi_swt_delay_ms);
        }

    }

    // change the index for next ROI sram switch write
    if (0 == sensor->cur_calib_sram_blk_idx)
    {
        sensor->cur_calib_sram_blk_idx = 1;
    }
    else {
        sensor->cur_calib_sram_blk_idx = 0;
    }

    return ret;
}

static void sensor_roi_switch_workqueue_function(struct work_struct *work)
{
    int ret;
    struct sensor *sensor = container_of(work, struct sensor, sensor_roiswitch_work);
    int delay_us = sensor->fsync_roi_swt_delay_ms*1000;

    if (0 != delay_us)
    {
        usleep_range(delay_us, delay_us+1000); // some delay
    }
    ret = sensor_switch_roi_sram(sensor, false);
    if (ret < 0)
    {
        DBG_ERROR("roi switch failed, ret: %d\n", ret);
        return ;
    }
}
#endif

static irqreturn_t sensor_fsync_irq(int irq, void *privateData)
{
    struct sensor *sensor = (struct sensor *)privateData;
    ktime_t fsync_irq_time;
    s64 us_delta;

    fsync_irq_time = ktime_get();
    sensor->fsync_irq_times++;
    if (1 == sensor->fsync_irq_times)
    {
        sensor->first_fsync_irq_time = ktime_get();
    }
    else {
        us_delta = ktime_us_delta(ktime_get(), sensor->last_fsync_irq_time);
        if (0 != sensor->last_fsync_irq_time)
        {
            if (us_delta > sensor->max_fsync_irq_gap) sensor->max_fsync_irq_gap = us_delta;
            if (us_delta < sensor->min_fsync_irq_gap) sensor->min_fsync_irq_gap = us_delta;
        }
    }

    sensor->last_fsync_irq_time = fsync_irq_time;

    if ((true == sensor->power_on) // first fsync come before sensor->streaming become TRUE.
        && (ADAPS_PCM_MODE != sensor->cur_wkmode) 
        && (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_ROI_SWITCH))) {

        spin_lock(&sensor->sensor_lock);

#if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
        if (0 != (sensor->dbg_ctrl & ADAPS_DBG_TRACE_FSYNC_IRQ)) {
            DBG_NOTICE("%s (%d:%d) on CPU %d, allow_roi_switch: %s, irq times: %d, fsync_irq_gap: %lld (%lld to %lld) us, curr_roi_idx: %d, streaming: %d",
                current->comm, current->tgid, current->pid, smp_processor_id(), 
                false == sensor->allow_roi_switch ? "No" : "Yes",
                sensor->fsync_irq_times, us_delta,
                sensor->min_fsync_irq_gap, sensor->max_fsync_irq_gap, sensor->cur_calib_sram_blk_idx, sensor->streaming);
        }

        if (false != sensor->allow_roi_switch)
        {
            queue_work(sensor->sensor_roiswitch_wq, &sensor->sensor_roiswitch_work);
        }

#endif

        spin_unlock(&sensor->sensor_lock);
    }

    return IRQ_HANDLED;
}
#endif

static int sensor_read_module_static_data(struct sensor *sensor)
{
    #define OTP_PRODUCT_ID_OFFSET            0x0C

    int ret = 0;
    u8 *p_tdcDelay=NULL;
    u16 val16;
    uint16_t i;

    sensor->otp_T_low = OTP_TEMPERATURE_LOW;

    ret = sensor_read_otp_word(sensor, 0x05, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x05, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_adc_vref = val16;
    
    ret = sensor_read_otp_word(sensor, 0x0A, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x0A, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_vbe25 = val16;

    ret = sensor_read_otp_word(sensor, 0x0B, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x0B, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_vbd_low = val16;
    DBG_INFO("sensor->otp_vbd_low: %d\n", sensor->otp_vbd_low);

    ret = sensor_read_otp_word(sensor, 0x1B, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x1B, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_vbd_high = val16;

    ret = sensor_read_otp_word(sensor, 0x1C, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x1C, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_T_high = (val16 & 0xFF) * 100;  // X 100 to keep same unit as current temperature.

    ret = sensor_read_otp_word(sensor, 0x1D, &val16);
    if (ret < 0) {
        DBG_ERROR("Fail to read otp data offset 0x1D, ret: %d\n", ret);
        return ret;
    }
    sensor->otp_K_high = (val16 & 0xFF);
    sensor->otp_K_low = ((val16 >> 8) & 0xFF);

    for (i = 0; i < SWIFT_PRODUCT_ID_SIZE / 2; i++) {
        ret = sensor_read_otp_word(sensor, OTP_PRODUCT_ID_OFFSET + i, &val16);
        if (ret < 0) {
            DBG_ERROR("Fail to read otp data offset 0x%x, ret: %d\n", OTP_PRODUCT_ID_OFFSET + i, ret);
            return ret;
        }

        sensor->otp_product_id[i * 2] = (val16 >> 8) & 0xFF;
        sensor->otp_product_id[i * 2 + 1] = val16  & 0xFF;
    }
    sensor_get_vop_algo_version(sensor);

    DBG_INFO("eeprom_data_size=%d", sensor->eeprom_data_size);

    ret = eeprom_read(sensor, 0, sensor->eeprom_data_size, (u8 *) sensor->eeprom_data);
    if (ret < 0) {
        DBG_ERROR( "Fail to read eeprom data, ret: %d.", ret);
        return ret;
    }

    if (0 == sensor_check_eeprom_crc(sensor))
    {
        sensor->eeprom_data_crc_matched = true;
        create_eeprom_blob_file(sensor, sensor->debugfs_root, (u8 *) sensor->eeprom_data, sensor->eeprom_data_size, "ads6401_eeprom_data");
    }
    else {
        sensor->eeprom_data_crc_matched = false;
        create_eeprom_blob_file(sensor, sensor->debugfs_root, (u8 *) sensor->eeprom_data, sensor->eeprom_data_size, "ads6401_eeprom_data_crc_mismatched");
    }

    sensor->static_data_ready = true;

    p_tdcDelay = (uint8_t *) sensor->eeprom_data->tdcDelay;
    sensor->tdc_delay_major = *p_tdcDelay;
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    p_tdcDelay += sizeof(uint8_t);
#else
    p_tdcDelay += sizeof(uint32_t);
#endif
    sensor->tdc_delay_minor = *p_tdcDelay;

    if (0x0 == sensor->tdc_delay_major || 0x1F < sensor->tdc_delay_major)
    {
        sensor->tdc_delay_major = 0x0A;
    }

    if (0x0 == sensor->tdc_delay_minor || 0xF < sensor->tdc_delay_minor)
    {
        sensor->tdc_delay_minor = 0x08;
    }

    return ret;
}

static int sensor_get_module_static_data(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_module_static_data temp;
    void __user *uarg = (void __user *)arg;

    if (NULL == sensor->eeprom_data)
    {
        DBG_ERROR("eeprom data is not available yet!");
        ret = -EFAULT;
    }

    memset(&temp, 0, sizeof(temp));
    get_module_type(sensor, &temp.module_type);
    temp.eeprom_capacity = sensor->eeprom_capacity;
    temp.otp_vbe25 = sensor->otp_vbe25;
    temp.otp_vbd = sensor->otp_vbd_low;
    temp.otp_adc_vref = sensor->otp_adc_vref;
    memcpy(temp.chip_product_id, sensor->otp_product_id, SWIFT_PRODUCT_ID_SIZE);
    sprintf(temp.sensor_drv_version, "%d.%d.%d", VERSION_MAJOR, VERSION_MINOR, VERSION_REVISION);
    temp.ready = sensor->static_data_ready;
    temp.eeprom_crc_matched = sensor->eeprom_data_crc_matched;

    if (copy_to_user((u16 *)uarg, &temp, sizeof(struct adaps_dtof_module_static_data)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_get_dtof_runtime_status_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_runtime_status_param temp;
    void __user *uarg = (void __user *)arg;

    temp.test_pattern_enabled = sensor->test_pattern_enabled;
    temp.inside_temperature_x100 = sensor->cur_temperature_x100;
    temp.expected_vop_abs_x100 = sensor->cur_vop_abs_x100;
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE) && defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)
    temp.expected_pvdd_x100 = sensor->cur_pvdd_x100;
#else
    temp.expected_pvdd_x100 = 0;
#endif

    if (copy_to_user((u16 *)uarg, &temp, sizeof(struct adaps_dtof_runtime_status_param)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_get_exposure_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    struct adaps_dtof_exposure_param temp;
    void __user *uarg = (void __user *)arg;

    temp.exposure_period = sensor->cur_laser_exposure_period & 0x7F;   // Mask bit7, which is exposure enable bit.
    temp.ptm_coarse_exposure_value = sensor->cur_coarse_exposure_val;
    temp.ptm_fine_exposure_value = sensor->cur_fine_exposure_val;
    temp.pcm_gray_exposure_value = sensor->cur_gray_exposure_val;

    if (copy_to_user((u16 *)uarg, &temp, sizeof(struct adaps_dtof_exposure_param)))
    {
        ret = -EFAULT;
    }

    return ret;
}

static long sensor_set_dtof_intial_param(struct sensor *sensor, unsigned long arg)
{
    long ret = 0;
    void __user *uarg = (void __user *)arg;
    struct adaps_dtof_intial_param temp;
    struct adaps_dtof_intial_param *param;

    if (copy_from_user(&temp, (struct adaps_dtof_intial_param *)uarg, sizeof(struct adaps_dtof_intial_param)))
    {
        ret = -EFAULT;
        return ret;
    }

    param = &temp;

    if (param->env_type < AdapsEnvTypeIndoor || param->env_type > AdapsEnvTypeOutdoor)
    {
        DBG_ERROR("Invalid env_type=%d",
            param->env_type);
        return -EINVAL;
    }

    if (param->measure_type < AdapsMeasurementTypeNormal || param->measure_type > AdapsMeasurementTypeFull)
    {
        DBG_ERROR("Invalid measure_type=%d",
            param->measure_type);
        return -EINVAL;
    }

    if (param->framerate_type < AdapsFramerateType15FPS || param->framerate_type > AdapsFramerateType60FPS)
    {
        DBG_ERROR("Invalid framerate_type=%d",
            param->framerate_type);
        return -EINVAL;
    }

    if (param->vcselzonecount_type < AdapsVcselZoneCount1 || param->vcselzonecount_type > AdapsVcselZoneCount4)
    {
        DBG_ERROR("Invalid vcselzonecount_type=%d",
            param->vcselzonecount_type);
        return -EINVAL;
    }

    if (param->power_mode < AdapsPowerModeNormal || param->power_mode > AdapsPowerModeDiv3)
    {
        DBG_ERROR("Invalid power_mode=%d",
            param->power_mode);
        return -EINVAL;
    }

    DBG_NOTICE("env_type=%d, measure_type=%d, framerate_type=%d, grayExposure:%d, fineExposure:%d",
        param->env_type,param->measure_type,param->framerate_type, param->grayExposure, param->fineExposure);
    sensor->cur_etype = param->env_type;
    sensor->cur_mtype = param->measure_type;
#if defined(FRAMERATE_TEST_4_60FPS)
    sensor->cur_frtype = AdapsFramerateType60FPS;
#else
    sensor->cur_frtype = param->framerate_type;
#endif
    sensor->cur_v_zone_cnt = param->vcselzonecount_type;
    sensor->cur_pmode = param->power_mode;
    sensor->anchor_x = param->colOffset;
    sensor->anchor_y = param->rowOffset;
    sensor->rowSearchingRange = param->rowSearchingRange;
    sensor->colSearchingRange = param->colSearchingRange;

    sensor->coarseExposureCfg = param->coarseExposure;
    sensor->fineExposureCfg = param->fineExposure;
    sensor->grayExposureCfg = param->grayExposure;
    sensor->laserExposurePeriodCfg = param->laserExposurePeriod;

    sensor->roi_sram_rolling = param->roi_sram_rolling;
    if (sensor->roi_sram_rolling)
    {
        sensor->allow_roi_switch = true;
    }

    return 0;
}


static long sensor_update_dtof_runtime_param(struct sensor *sensor, unsigned long arg)
{
    bool changed = false;
    long ret = 0;
    void __user *uarg = (void __user *)arg;
    struct adaps_dtof_runtime_param temp;
    struct adaps_dtof_runtime_param *dtof_runtime_param;

    if (copy_from_user(&temp, (struct adaps_dtof_runtime_param *)uarg, sizeof(struct adaps_dtof_runtime_param)))
    {
        ret = -EFAULT;
        return ret;
    }

    dtof_runtime_param = &temp;

    //DBG_INFO("env_type=%d,measure_type=%d,vcsel_mode=%d",dtof_runtime_param->env_type,dtof_runtime_param->measure_type,dtof_runtime_param->vcsel_mode);
    //DBG_INFO("env_valid=%d,measure_valid=%d,vcsel_valid=%d",dtof_runtime_param->env_valid,dtof_runtime_param->measure_valid,dtof_runtime_param->vcsel_valid);
    if (dtof_runtime_param->env_valid)
    {
        if (dtof_runtime_param->env_type < AdapsEnvTypeIndoor || dtof_runtime_param->env_type > AdapsEnvTypeOutdoor)
        {
            DBG_ERROR("Invalid env_type=%d",
                dtof_runtime_param->env_type);
            return -EINVAL;
        }

        if (sensor->cur_etype != dtof_runtime_param->env_type)
        {
            changed = true;
            sensor->cur_etype = dtof_runtime_param->env_type;
        }
    }

    if (dtof_runtime_param->measure_valid)
    {
        if (dtof_runtime_param->measure_type < AdapsMeasurementTypeNormal || dtof_runtime_param->measure_type > AdapsMeasurementTypeFull)
        {
            DBG_ERROR("Invalid measure_type=%d",
                dtof_runtime_param->measure_type);
            return -EINVAL;
        }

        if (sensor->cur_mtype != dtof_runtime_param->measure_type)
        {
            changed = true;
            sensor->cur_mtype = dtof_runtime_param->measure_type;
        }
    }

    if (dtof_runtime_param->vcsel_valid)
    {
        if (dtof_runtime_param->vcsel_mode < AdapsVcselModeOn || dtof_runtime_param->vcsel_mode > AdapsVcselModeOff)
        {
            DBG_ERROR("Invalid vcsel_mode=%d",
                dtof_runtime_param->vcsel_mode);
            return -EINVAL;
        }

        if (sensor->cur_vmode != dtof_runtime_param->vcsel_mode)
        {
            changed = true;
            sensor->cur_vmode = dtof_runtime_param->vcsel_mode;
        }
    }

    if (changed)
    {
        return sensor_update_setting(sensor,
            sensor->cur_etype,
            sensor->cur_mtype,
            sensor->cur_v_zone_cnt,
            sensor->cur_vmode);
    }
    else {
        //DBG_INFO("No change is needed.");
        return 0;
    }
}

static int loaded_script_valid_check(struct sensor *sensor, external_config_script_param_t *cfg_script_param)
{
    int i;
    u16 addr;
    u8 value;
    u8 req_work_mode = ADAPS_MODE_MAX;
    const struct setting_rvd *pRegList = NULL;

    if (0 == cfg_script_param->sensor_reg_setting_cnt)
    {
        DBG_ERROR("sensor_reg_setting_cnt can not be 0");
        return -EINVAL;
    }

    if (0 == cfg_script_param->vcsel_reg_setting_cnt)
    {
        DBG_ERROR("vcsel_reg_setting_cnt can not be 0");
        return -EINVAL;
    }

    req_work_mode = cfg_script_param->work_mode;
    pRegList = (const struct setting_rvd *) sensor->loaded_sensor_reg_setting;

    for (i = 0; i < cfg_script_param->sensor_reg_setting_cnt; i++) {
        addr = pRegList[i].reg;
        value = pRegList[i].val;

        switch (addr)
        {
            case 0xB6:
                if (ADAPS_PCM_MODE == req_work_mode)
                {
                    if (0 == (value & BIT(0))) // for PCM mode, the bit0 should be 1
                    {
                        DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                        return -EINVAL;
                    }
                }
                else {
                    if (0 != (value & BIT(0))) // for non-PCM mode, the bit0 should be 0
                    {
                        DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                        return -EINVAL;
                    }

                    if (ADAPS_PTM_PHR_MODE == req_work_mode)
                    {
                        if (0 != (value & BIT(5))) // for PHR mode, the bit5 should be 0
                        {
                            DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                            return -EINVAL;
                        }
                    }
                    else {
                        if (0 == (value & BIT(5))) // for FHR mode, the bit5 should be 1
                        {
                            DBG_ERROR("Requested work mode (%d) seems mismatch the register[0x%02x] setting in the loaded script", req_work_mode, addr);
                            return -EINVAL;
                        }
                    }
                }
                break;


            default:
                break;
        }
    }

    return 0;
}

static int misc_device_open(struct inode *inode, struct file *file)
{
    int ret = 0;
    struct mm_struct *mm = current->mm;
    u32 opening_from_client = CURRENT_CLIENT;
    struct miscdevice *miscdev = file->private_data;

    struct sensor *sensor = container_of(miscdev, struct sensor, misc_device);
    file->private_data = sensor;

    MUTEX_LOCK(&sensor->misc_mutex);

    if (NULL == sensor->mmap_buffer_base)
    {
        DBG_ERROR("Null pointer for mmap_buffer_base, need alloc buffer firstly.");
        ret = -ENODATA;
        goto unlock_and_return;
    }

    TRACE_IOCTL("---- M_OPEN  from %s (%d:%d) on CPU %d",
        current->comm, current->tgid, current->pid,
        smp_processor_id()
        );

#if defined(DEVICE_CONCURRENCY_OPEN_CHECK)
    if (0 != sensor->client_id_4_misc)
    {
        DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: Misc device was opened already\nOpened client: (%d:%d), re-opening client: (%d:%d)",
            CLIENT_TO_PID(sensor->client_id_4_misc), CLIENT_TO_TID(sensor->client_id_4_misc),
            CLIENT_TO_PID(opening_from_client), CLIENT_TO_TID(opening_from_client)
            );
        ret = -EIO;
        goto unlock_and_return;
    }
#endif

    sensor->client_id_4_misc = opening_from_client;
    sensor->client_task_4_misc = current;

    DBG_INFO("sensor->mmap_buffer_base: %p, 0x%lx", sensor->mmap_buffer_base, (unsigned long)sensor->mmap_buffer_base);
    DBG_INFO("client: %s (%d)", current->comm, current->pid);
    DBG_INFO("code  section: [0x%lx   0x%lx]", mm->start_code, mm->end_code);
    DBG_INFO("data  section: [0x%lx   0x%lx]", mm->start_data, mm->end_data);
    DBG_INFO("brk   section: s: 0x%lx, c: 0x%lx", mm->start_brk, mm->brk);
    DBG_INFO("mmap  section: s: 0x%lx", mm->mmap_base);
    DBG_INFO("stack section: s: 0x%lx", mm->start_stack);
    DBG_INFO("arg   section: [0x%lx   0x%lx]", mm->arg_start, mm->arg_end);
    DBG_INFO("env   section: [0x%lx   0x%lx]\n", mm->env_start, mm->env_end);

    // restore the default values
    sensor->load_script = false;
    sensor->loaded_roi_sram_size = 0;

unlock_and_return:
    MUTEX_UNLOCK(&sensor->misc_mutex);

    return ret;
}

static int misc_device_release(struct inode *inode, struct file *file)
{
    u32 closing_from_client = CURRENT_CLIENT;
    struct sensor *sensor = (struct sensor *) file->private_data;

    if (NULL != sensor)
    {
        MUTEX_LOCK(&sensor->misc_mutex);

        TRACE_IOCTL("---- M_RELEASE  from %s (%d:%d) on CPU %d",
            current->comm, current->tgid, current->pid,
            smp_processor_id()
            );

        if (CLIENT_TO_PID(sensor->client_id_4_misc) != CLIENT_TO_PID(closing_from_client))
        {
            DBG_ERROR("*** POSSIBLE CONCURRENT ISSUE ***: opened id: (%d:%d), closing id: (%d:%d)",
                CLIENT_TO_PID(sensor->client_id_4_misc), CLIENT_TO_TID(sensor->client_id_4_misc),
                CLIENT_TO_PID(closing_from_client), CLIENT_TO_TID(closing_from_client)
                );
        }

        sensor->client_id_4_misc = 0;
        sensor->client_task_4_misc = NULL;
        file->private_data = NULL;

        MUTEX_UNLOCK(&sensor->misc_mutex);
    }

    return 0;
}

static int misc_device_mmap(struct file *file, struct vm_area_struct *vma)
{
    unsigned long offset;
    unsigned long pfn_start;
    unsigned long virt_start;
    unsigned long size;
    int ret = 0;
    struct sensor *sensor;

    if (NULL == vma || NULL == file->private_data)
    {
        DBG_ERROR("Null pointer, vma: %p, file->private_data: %p", vma, file->private_data);
        return -EINVAL;
    }

    sensor = (struct sensor *) file->private_data;

    MUTEX_LOCK(&sensor->misc_mutex);

    if (NULL == sensor->mmap_buffer_base)
    {
        DBG_ERROR("Null pointer for mmap_buffer_base, need alloc buffer firstly.");
        ret = -ENODATA;
        goto unlock_and_return;
    }

    if (0 == sensor->mmap_buffer_max_size)
    {
        DBG_ERROR("Uninitilized mmap buffer max size.");
        ret = -EINVAL;
        goto unlock_and_return;
    }

    size = vma->vm_end - vma->vm_start;
    offset = vma->vm_pgoff << PAGE_SHIFT;
    pfn_start = (virt_to_phys(sensor->mmap_buffer_base) >> PAGE_SHIFT) + vma->vm_pgoff;
    virt_start = (unsigned long)sensor->mmap_buffer_base + offset;

    DBG_INFO("phy: 0x%lx, offset: 0x%lx, size: 0x%lx, vm_flags: 0x%lx, vm_page_prot: 0x%llx\n",
        pfn_start << PAGE_SHIFT, offset, size, vma->vm_flags, vma->vm_page_prot.pgprot);

    if (!(vma->vm_flags & (VM_WRITE | VM_READ)))
    //if (vma->vm_flags & VM_WRITE) // for read-only maping
    {
        DBG_ERROR("Invalid reuqest flag: 0x%lx, PROT_READ | PROT_WRITE: 0x%x, VM_WRITE | VM_READ: 0x%x",
            vma->vm_flags, PROT_READ | PROT_WRITE, VM_WRITE | VM_READ);
        ret = -EACCES;
        goto unlock_and_return;
    }

    if (vma->vm_flags & VM_EXEC)
    {
        DBG_ERROR("No execute is allowed, vm_flags: 0x%lx",
            vma->vm_flags);
        ret = -EACCES;
        goto unlock_and_return;
    }

    if (size > sensor->mmap_buffer_max_size)
    {
        DBG_ERROR("Invalid Request mmap size:%ld(> %d)", size, sensor->mmap_buffer_max_size);
        ret = -EINVAL;
        goto unlock_and_return;
    }

    ret = remap_pfn_range(vma, vma->vm_start, pfn_start, size, vma->vm_page_prot);
    if (ret)
    {
        DBG_INFO("remap_pfn_range failed at [0x%lx  0x%lx], ret: %d\n", vma->vm_start, vma->vm_end, ret);
    }
    else {
        DBG_INFO("map 0x%lx to 0x%lx (userspace address), size: 0x%lx, TASK_SIZE:  0x%lx\n", virt_start, vma->vm_start, size, TASK_SIZE);
    }

unlock_and_return:
    MUTEX_UNLOCK(&sensor->misc_mutex);

    return ret;
}

static long __maybe_unused misc_device_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    register_op_data_t register_op_data;
    u32 val32 = 0;
    u8 reg8 = 0;
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    u16 reg16 = 0;
#endif
    u8 val8 = 0;
    struct sensor *sensor = (struct sensor*) file->private_data;
    void __user *uarg = (void __user *)arg;
    long ret = 0;
    external_config_script_param_t ex_cfg_script_param;
    external_roisram_data_size_t ex_roisram_data_param;
#if defined(INTERNAL_DBG_ENABLE)
    struct adaps_dtof_update_eeprom_data upd_eeprom_data_param;
    u8 *pEEPROM_data = (u8 *) sensor->eeprom_data;
#endif
    ktime_t kt_req = ktime_get();

    TRACE_IOCTL("----- M_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ADAPS_GET_DTOF_MODULE_STATIC_DATA:0x%lx, eeprom_data_size: %d",
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid,
        smp_processor_id(), ADAPS_GET_DTOF_MODULE_STATIC_DATA, sensor->eeprom_data_size
        );

    switch (cmd)
    {
        case ADAPS_GET_DTOF_MODULE_STATIC_DATA:
             ret = sensor_get_module_static_data(sensor, arg);
             break;

        case ADAPS_GET_DTOF_RUNTIME_STATUS_PARAM:
             ret = sensor_get_dtof_runtime_status_param(sensor, arg);
             break;

        case ADAPS_SET_DTOF_INITIAL_PARAM:
             ret = sensor_set_dtof_intial_param(sensor, arg);
             break;

        case ADAPS_UPDATE_DTOF_RUNTIME_PARAM:
             if (FALSE == sensor->load_script)
             {
                ret = sensor_update_dtof_runtime_param(sensor, arg);
             }
             break;

        case ADAPS_GET_DTOF_EXPOSURE_PARAM:
             ret = sensor_get_exposure_param(sensor, arg);
             break;

        case ADTOF_SET_DEVICE_REGISTER:
            if (copy_from_user(&register_op_data, (register_op_data_t *)uarg, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }
#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
            if (I2C_ADDR_4_VCSELDRV == register_op_data.i2c_address)
            {
                reg8 = register_op_data.reg_addr & 0xFF;
                val8 = register_op_data.reg_val & 0xFF;
                ret = i2c_dev_burst_write_reg(sensor, sensor->vcsel_i2c, reg8, &val8, 1);
            }
            else 
#else
            if (I2C_ADDR_4_MCUCTRL == register_op_data.i2c_address)
            {
                reg16 = register_op_data.reg_addr;
                val8 = register_op_data.reg_val & 0xFF;
            	ret = mcuctrl_write_reg(sensor, reg16, &val8, 1);
            }
            else 
#endif
            {
                reg8 = register_op_data.reg_addr & 0xFF;
                val8 = register_op_data.reg_val & 0xFF;
                ret = sensor_write_reg_8bit_value(sensor, reg8, val8);
            }
            break;

        case ADTOF_GET_DEVICE_REGISTER:
            if (copy_from_user(&register_op_data, (register_op_data_t *)uarg, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
            if (I2C_ADDR_4_VCSELDRV == register_op_data.i2c_address)
            {
                reg8 = register_op_data.reg_addr & 0xFF;
                ret = i2c_dev_read_reg(sensor, sensor->vcsel_i2c, reg8, 1, &val32);
                if (ret < 0) {
                    break;
                }
                register_op_data.reg_val = val32 & 0xFF;
            }
            else 
#else
            if (I2C_ADDR_4_MCUCTRL == register_op_data.i2c_address)
            {
                reg16 = register_op_data.reg_addr;
                ret = mcuctrl_reg_read(sensor, reg16, &val8);
                if (ret < 0) {
                    break;
                }
                register_op_data.reg_val = val8;
            }
            else 
#endif
            {
                reg8 = register_op_data.reg_addr & 0xFF;
                ret = sensor_read_reg_8bit_value(sensor, reg8, &val8);
                if (ret < 0) {
                    break;
                }
                register_op_data.reg_val = val8;
            }

            if (copy_to_user((register_op_data_t *)uarg, &register_op_data, sizeof(register_op_data_t)))
            {
                ret = -EFAULT;
                break;
            }
            break;

        case ADTOF_SET_EXTERNAL_CONFIG_SCRIPT:
            if (copy_from_user(&ex_cfg_script_param, (external_config_script_param_t *)uarg, sizeof(external_config_script_param_t)))
            {
                ret = -EFAULT;
                break;
            }

            if (ex_cfg_script_param.sensor_reg_setting_cnt)
            {
                ret = loaded_script_valid_check(sensor, &ex_cfg_script_param);
                if (0 != ret)
                {
                    // if there is any error in loaded script, return failure to user space.
                    break;
                }

                if (0 == (sensor->dbg_ctrl & ADAPS_DBG_DISABLE_LOAD_SCRIPT))
                {
                    sensor->load_script = true;
                }
                sensor->loaded_sensor_reg_setting_cnt = ex_cfg_script_param.sensor_reg_setting_cnt;
                sensor->loaded_vcsel_reg_setting_cnt = ex_cfg_script_param.vcsel_reg_setting_cnt;
            }

            sensor->cur_wkmode            = ex_cfg_script_param.work_mode;

            DBG_NOTICE("script start dbg_ctrl: 0x%x, workMode: %d (%s), reg sensor_reg_setting_cnt: %u, reg vcsel_reg_setting_cnt: %u, load_script: %d."
                , sensor->dbg_ctrl
                , sensor->cur_wkmode, work_mode_name[sensor->cur_wkmode], sensor->loaded_sensor_reg_setting_cnt
                , sensor->loaded_vcsel_reg_setting_cnt, sensor->load_script);
            break;

        case ADTOF_SET_EXTERNAL_ROISRAM_DATA_SIZE:
            if (copy_from_user(&ex_roisram_data_param, (external_roisram_data_size_t *)uarg, sizeof(external_roisram_data_size_t)))
            {
                ret = -EFAULT;
                break;
            }
            sensor->loaded_roi_sram_size = ex_roisram_data_param.roi_sram_size;

            if (ex_roisram_data_param.roi_sram_size > 0)
            {
                if (0 != (ex_roisram_data_param.roi_sram_size % PER_ROISRAM_GROUP_SIZE))
                {
                    ret = -EINVAL;
                    break;
                }

                if (ex_roisram_data_param.roi_sram_size > ALL_ROISRAM_GROUP_SIZE)
                {
                    sensor->max_calib_sram_data_group_cnt = ex_roisram_data_param.roi_sram_size / PER_ROISRAM_GROUP_SIZE;
                    if (sensor->roi_sram_rolling)
                    {
                        sensor->allow_roi_switch = true;
                    }
                }
                else {
                    sensor->allow_roi_switch = false;
                    sensor->roi_sram_rolling = false;
                }

                create_loaded_roisram_blob_file(sensor, sensor->debugfs_root, sensor->loaded_roi_sram, sensor->loaded_roi_sram_size, "loaded_roisram_data");
            }

            DBG_NOTICE("Load_roi_sram_size: %u, roi_sram_rolling: %d, ", sensor->loaded_roi_sram_size, sensor->roi_sram_rolling);
            break;

#if defined(INTERNAL_DBG_ENABLE)
        case ADTOF_UPDATE_EEPROM_DATA:
             if (copy_from_user(&upd_eeprom_data_param, (struct adaps_dtof_update_eeprom_data *)uarg, sizeof(struct adaps_dtof_update_eeprom_data)))
             {
                 ret = -EFAULT;
                 break;
             }

             ret = sensor_update_eeprom_data(sensor, pEEPROM_data + upd_eeprom_data_param.offset, upd_eeprom_data_param.offset, upd_eeprom_data_param.length);
             if (ret > 0) // this means update success for sensor_update_eeprom_data().
             {
                ret = 0;
             }
             break;
#endif

        default:
            ret = -ENOIOCTLCMD;
            DBG_NOTICE("Unhandled cmd:0x%x", cmd);
            break;
    }

    if (0 != ret && -ENOIOCTLCMD != ret)
    {
        DBG_ERROR("client: %s (process_id:thread_id=%d:%d) is running on CPU %d, userId: %d cmd: 0x%x, ret: %ld",
            current->comm, current->tgid, current->pid,
            smp_processor_id(),
            __kuid_val(current->cred->uid),
            cmd, ret);
    }

    TRACE_IOCTL("=END= M_IOCTL cmd: %x request_ns: %llx from %s (%d:%d) on CPU %d, ret: %ld",
        cmd, ktime_to_ns(kt_req),
        current->comm, current->tgid, current->pid,
        smp_processor_id(),
        ret
        );

    return ret;
}

static const struct file_operations misc_device_fops = {
    .owner = THIS_MODULE,
    .open = misc_device_open,
    .mmap = misc_device_mmap,
    .unlocked_ioctl = misc_device_ioctl,
    .release = misc_device_release,
};


static int sensor_probe(struct i2c_client * client, 
    const struct i2c_device_id * id)
{
    struct device *dev = &client->dev;
    struct v4l2_subdev *sd;
    struct device_node *node = dev->of_node;
    char            facing[2];
    struct sensor   *sensor;
    int             ret;
#if defined(SENSOR_XCLK_FROM_SOC)
    unsigned long rate;
#endif
    unsigned long virt_addr;

    DBG_NOTICE("-Start probe(), ads6401_module_type: %s, driver_version: %s, Build Time: %s---", 
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        get_kernel_buildtime()
        );

    //console_loglevel = LOGLEVEL_DEBUG; // enable printk output to the console (uart tty)
    sensor = devm_kzalloc(dev, sizeof(*sensor), GFP_KERNEL);
    if (!sensor)
        return - ENOMEM;

    i2c_set_clientdata(client, sensor);
    sensor->sensor_i2c = client;
    sensor->dev         = &client->dev;
    dev_set_drvdata(sensor->dev, sensor);

    ret = of_property_read_u32(node, RKMODULE_CAMERA_MODULE_INDEX, 
        &sensor->module_index);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_FACING, 
        &sensor->module_facing);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_NAME, 
        &sensor->module_name);
    ret |= of_property_read_string(node, RKMODULE_CAMERA_LENS_NAME, 
        &sensor->len_name);

    if (ret) {
        DBG_ERROR("could not get module information!\n");
        return - EINVAL;
    }

    sensor->dbg_ctrl = DEFAULT_DBG_CTRL;
    sensor->version_code = VERSION_CODE;
    sensor->cur_wkmode = ADAPS_PCM_MODE;
    sensor->cur_sensor_mode    = &sensor_wkmode[sensor->cur_wkmode];
    sensor->cur_etype = AdapsEnvTypeUninitilized;
    sensor->cur_mtype = AdapsMeasurementTypeUninitilized;
    sensor->cur_frtype = AdapsFramerateTypeUninitilized;
    sensor->cur_pmode = AdapsPowerModeDiv3;
    sensor->cur_v_zone_cnt = AdapsVcselZoneCount4;
    sensor->cur_vmode = AdapsVcselModeOn;
    sensor->anchor_x = 0;
    sensor->anchor_y = 0;
    sensor->reset_mipi_4_streamon = MIPI_RESET_DEFAULT_CFG;
    sensor->force_mipi_tx_delay = 0xFF;
    sensor->mipi_data_lanes = SENSOR_DATA_LANE_COUNT;
    sensor->probe_success = false;
    sensor->min_costtime_4_roisram_write = 500000; // set a enough big value as initially, so that it must be re-assgined value.
    sensor->max_costtime_4_roisram_write = 0; // set a 0 value as initially, so that it must be re-assgined value.
    sensor->vop_algo_version = SWIFT_VOP_ALGO_VER_UNKNOWN;
    sensor->static_data_ready = false;
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    sensor->eeprom_capacity = FLOOD_MODULE_EEPROM_CAPACITY_SIZE;
    sensor->eeprom_page_size = FLOOD_MODULE_EEPROM_PAGE_SIZE;
    sensor->eeprom_data_size = sizeof(swift_flood_module_eeprom_data_t);
#else
    sensor->eeprom_capacity = SPOT_MODULE_EEPROM_CAPACITY_SIZE;
    sensor->eeprom_page_size = SPOT_MODULE_EEPROM_PAGE_SIZE;
    sensor->eeprom_data_size = sizeof(swift_spot_module_eeprom_data_t);
#endif

#if 0 //defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
    sensor->allow_roi_switch = true;
#endif

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    sensor->force_enable_vcsel_4_pcm_mode = ENABLE_VCSEL_4_PCM_MODE_CFG;
#endif

#if defined(SENSOR_XCLK_FROM_SOC)
    sensor->xvclk       = devm_clk_get(dev, "xvclk");
    if (IS_ERR(sensor->xvclk)) {
        DBG_ERROR("Failed to get xvclk\n");
        return -EINVAL;
    }

    ret = clk_set_rate(sensor->xvclk, SENSOR_XVCLK_FREQ);
    if (ret < 0) {
        DBG_ERROR("Failed to set xvclk rate (24MHz)\n");
        return ret;
    }

    rate = clk_get_rate(sensor->xvclk);
    if (rate != SENSOR_XVCLK_FREQ){
        DBG_ERROR("xvclk(%lu Hz) mismatched 24MHz\n", rate);
        return ret;
    }
#endif

    sensor->reset_gpio = devm_gpiod_get(dev, "reset", GPIOD_OUT_HIGH);

    if (IS_ERR(sensor->reset_gpio)) {
        DBG_ERROR("Failed to get reset-gpio\n");
    }

    sensor->iovcc_en_gpio = devm_gpiod_get(dev, "iovcc_en", GPIOD_OUT_LOW);

    if (IS_ERR(sensor->iovcc_en_gpio)) {
        DBG_ERROR("Failed to get iovcc_en-gpio\n");
    }

    sensor->dvcc_en_gpio = devm_gpiod_get(dev, "dvcc_en", GPIOD_OUT_LOW);

    if (IS_ERR(sensor->dvcc_en_gpio)) {
        DBG_ERROR("Failed to get dvcc_en-gpio\n");
    }

#if defined(MINI_DEMO_BOX)
    sensor->avcc_en_gpio = devm_gpiod_get(dev, "avcc_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->avcc_en_gpio)) {
        DBG_ERROR("Failed to get avcc_en-gpio\n");
    }

    sensor->drv_vcc_en_gpio = devm_gpiod_get(dev, "drv_vcc_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->drv_vcc_en_gpio)) {
        DBG_ERROR("Failed to get drv_vcc_en-gpio\n");
    }

    sensor->vbat_en_gpio = devm_gpiod_get(dev, "vbat_en", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->vbat_en_gpio)) {
        DBG_ERROR("Failed to get vbat_en-gpio\n");
    }

    sensor->hw_target_id1_gpio = devm_gpiod_get(dev, "hw_target_id1", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->hw_target_id1_gpio)) {
        DBG_ERROR("Failed to get hw_target_id1-gpio\n");
    }

    sensor->hw_target_id2_gpio = devm_gpiod_get(dev, "hw_target_id2", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->hw_target_id2_gpio)) {
        DBG_ERROR("Failed to get hw_target_id2-gpio\n");
    }

    sensor->work_state_led_gpio = devm_gpiod_get(dev, "work_state_led", GPIOD_OUT_LOW);
    if (IS_ERR(sensor->work_state_led_gpio)) {
        DBG_ERROR("Failed to get work_state_led-gpio\n");
    }

#endif

    sensor->fsync_irq_gpio = devm_gpiod_get_optional(dev, "fsync_irq", GPIOD_FLAGS_BIT_NONEXCLUSIVE);
    if (IS_ERR(sensor->fsync_irq_gpio))
    {
        DBG_ERROR("Failed to get fsync_irq-gpio, %ld\n", PTR_ERR(sensor->fsync_irq_gpio));
        return PTR_ERR(sensor->fsync_irq_gpio);
    }

    sensor->drverr_irq_gpio = devm_gpiod_get_optional(dev, "drverr_irq", GPIOD_FLAGS_BIT_NONEXCLUSIVE);
    if (IS_ERR(sensor->drverr_irq_gpio))
    {
        DBG_ERROR("Failed to get drverr_irq-gpio, %ld\n", PTR_ERR(sensor->drverr_irq_gpio));
        return PTR_ERR(sensor->drverr_irq_gpio);
    }
    DBG_INFO("----- sensor->fsync_irq_gpio = %p, sensor->drverr_irq_gpio = %p...\n", sensor->fsync_irq_gpio, sensor->drverr_irq_gpio);

    /* use dummy devices for tps62864 */
    sensor->dvcc_regulator_i2c = devm_i2c_new_dummy_device(dev,client->adapter, TPS62864_I2C_ADDR);
    if (IS_ERR(sensor->dvcc_regulator_i2c))
    {
        DBG_ERROR("create dvcc_regulator dummy i2c device failed");
        return -EINVAL;
    }

#if (ADS6401_MODULE_FLOOD != SWIFT_MODULE_TYPE)
    #if defined(OPN7020_VCSEL_DRIVER_ENABLE)
        /* use dummy devices for vcsel functions */
        sensor->vcsel_i2c = devm_i2c_new_dummy_device(dev,client->adapter, I2C_ADDR_4_VCSELDRV);
        if (IS_ERR(sensor->vcsel_i2c))
        {
            DBG_ERROR("create vcsel dummy i2c device failed");
            goto err_clean_entity;
        }
    #endif

    #if defined(ENABLE_SOC_PWM_4_PVDD_VOLTAGE)

        sensor->pwm_4_pvdd.pwm_dev = devm_pwm_get(dev, PWM_NAME_IN_DTS_FOR_VBAT_OR_PVDD);
        if (IS_ERR(sensor->pwm_4_pvdd.pwm_dev)) {
            DBG_ERROR( "Fail to get PWM device for pvdd.");
            return PTR_ERR(sensor->pwm_4_pvdd.pwm_dev);
        }
        else {
            struct pwm_args pwmargs;
            struct pwm_state state;

            /* Sync up PWM state. */
            pwm_get_args(sensor->pwm_4_pvdd.pwm_dev, &pwmargs);
            pwm_init_state(sensor->pwm_4_pvdd.pwm_dev, &state);

            state.period = pwmargs.period;
            state.duty_cycle = PWM_INITDUTYCYCLE_4_PVDD;
            state.polarity = PWM_POLARITY_4_PVDD;
            ret = pwm_apply_state(sensor->pwm_4_pvdd.pwm_dev, &state);
            if (ret) {
                DBG_ERROR("failed to apply initial PWM state: %d\n", ret);
            }

            sensor->pwm_4_pvdd.current_period_ns = state.period;
            sensor->pwm_4_pvdd.current_duty_ns = state.duty_cycle;
        }

    #endif

#else
    /* use dummy devices for mcu controller */
    sensor->mcuctrl_i2c = devm_i2c_new_dummy_device(dev,client->adapter, I2C_ADDR_4_MCUCTRL);
    if (IS_ERR(sensor->mcuctrl_i2c))
    {
        DBG_ERROR("create mcuctrl dummy i2c device failed");
        return -EINVAL;
    }

    sensor->pwm_4_vbat.pwm_dev = devm_pwm_get(dev, PWM_NAME_IN_DTS_FOR_VBAT_OR_PVDD);
    if (IS_ERR(sensor->pwm_4_vbat.pwm_dev)) {
        DBG_ERROR( "Fail to get PWM device for Vbat.");
        return PTR_ERR(sensor->pwm_4_vbat.pwm_dev);
    }
    else {
        struct pwm_args pwmargs;
        struct pwm_state state;

        /* Sync up PWM state. */
        pwm_get_args(sensor->pwm_4_vbat.pwm_dev, &pwmargs);
        pwm_init_state(sensor->pwm_4_vbat.pwm_dev, &state);

        state.period = pwmargs.period;
        state.duty_cycle = PWM_INITDUTYCYCLE_4_VBAT;
        state.polarity = PWM_POLARITY_4_VBAT;
        ret = pwm_apply_state(sensor->pwm_4_vbat.pwm_dev, &state);
        if (ret) {
            DBG_ERROR("failed to apply initial PWM state: %d\n", ret);
        }

        sensor->pwm_4_vbat.current_period_ns = state.period;
        sensor->pwm_4_vbat.current_duty_ns = state.duty_cycle;
    }
#endif

#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    sensor->pwm_4_vop.pwm_dev = devm_pwm_get(dev, PWM_NAME_IN_DTS_FOR_VOP);
    if (IS_ERR(sensor->pwm_4_vop.pwm_dev)) {
        DBG_ERROR( "Fail to get PWM device for Vop, %ld.", PTR_ERR(sensor->pwm_4_vop.pwm_dev));
        return PTR_ERR(sensor->pwm_4_vop.pwm_dev);
    }
    else {
        struct pwm_args pwmargs;
        struct pwm_state state;

        /* Sync up PWM state. */
        pwm_get_args(sensor->pwm_4_vop.pwm_dev, &pwmargs);
        pwm_init_state(sensor->pwm_4_vop.pwm_dev, &state);

        state.period = pwmargs.period;
        state.duty_cycle = PWM_INITDUTYCYCLE_4_VOP;
        state.polarity = PWM_POLARITY_4_VOP;
        ret = pwm_apply_state(sensor->pwm_4_vop.pwm_dev, &state);
        if (ret) {
            DBG_ERROR("failed to apply initial PWM state: %d\n", ret);
        }

        sensor->pwm_4_vop.current_period_ns = state.period;
        sensor->pwm_4_vop.current_duty_ns = state.duty_cycle;
        //DBG_ERROR("PWM period: %lld ns, polarity: %d\n", pwmargs.period, pwmargs.polarity);
        //pwm_config(sensor->pwm_4_vop.pwm_dev, sensor->pwm_4_vop.current_duty_ns, sensor->pwm_4_vop.current_period_ns);
    }
#endif

#if defined(REGULATOR_ENABLE)
    ret = sensor_configure_regulators(sensor);
    if (ret) {
        DBG_ERROR("Failed to get power regulators\n");
        return ret;
    }
#endif

    ret = sensor_set_power_on(sensor, __LINE__);
    if (ret)
    {
        DBG_ERROR("sensor_power_on failed\n");
#if !defined(IGNORE_PROBE_FAILURE) 
        goto err_power_off;
#endif
    }

    ret = sensor_check_sensor_id(sensor);
    if (ret)
    {
        DBG_ERROR("sensor_check_sensor_id failed\n");
#if !defined(IGNORE_PROBE_FAILURE) 
        goto err_power_off;
#endif
    }

    spin_lock_init(&sensor->sensor_lock);
    mutex_init(&sensor->mutex);

    sd = &sensor->subdev;
    v4l2_i2c_subdev_init(sd, sensor->sensor_i2c, &sensor_subdev_ops);
    ret = sensor_initialize_controls(sensor);
    if (ret)
    {
        DBG_ERROR("sensor_initialize_controls failed\n");
        goto err_destroy_mutex;
    }

#ifdef CONFIG_VIDEO_V4L2_SUBDEV_API
    sd->internal_ops    = &sensor_internal_ops;
    sd->flags           |= V4L2_SUBDEV_FL_HAS_DEVNODE | V4L2_SUBDEV_FL_HAS_EVENTS;
#endif

#if defined(CONFIG_MEDIA_CONTROLLER) 
    sensor->pad.flags   = MEDIA_PAD_FL_SOURCE;
    sd->entity.function = MEDIA_ENT_F_CAM_SENSOR;
    ret = media_entity_pads_init(&sd->entity, 1, &sensor->pad);
    if (ret < 0)
    {
        DBG_ERROR("media_entity_pads_init failed\n");
        goto err_free_handler;
    }
#endif

    memset(facing, 0, sizeof(facing));

    if (strcmp(sensor->module_facing, "back") == 0)
        facing[0] = 'b';
    else 
        facing[0] = 'f';

    snprintf(sd->name, sizeof(sd->name), "m%02d_%s_%s %s",
         sensor->module_index, facing,
         SENSOR_NAME, dev_name(sd->dev));
    ret = v4l2_async_register_subdev_sensor_common(sd);
    if (ret) {
        DBG_ERROR("v4l2 async register subdev failed\n");
        goto err_clean_entity;
    }

    hrtimer_init(&sensor->vop_adjust_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    sensor->vop_adjust_timer.function = sensor_vop_adjust_timer_func;
    sensor->vop_adjust_delay = ns_to_ktime(VOP_ADJUST_INTERVAL * NSEC_PER_MSEC);

    if (!hrtimer_is_hres_active(&sensor->vop_adjust_timer))
    {
        DBG_NOTICE("HR timer unavailable, restricting vop_adjust_timer to low resolution\n");
    }

    /* request work queue */
    sensor->vop_adjust_wq = create_singlethread_workqueue(SENSOR_NAME"_vop_wq");
    if (!sensor->vop_adjust_wq) {
        DBG_ERROR("could not create workqueue");
        goto err_clean_entity2;
    }
    INIT_WORK(&sensor->vop_adjust_work, sensor_work_handler);

#if defined(ENABLE_SENSOR_FSYNC_IRQ)
    sensor->fsync_irq = of_irq_get(client->dev.of_node, 0);
    if (sensor->fsync_irq < 0) {
        DBG_ERROR("Failed to get frame sync interrupt number\n");
        goto err_clean_entity;
    }
    DBG_INFO("fsync_irq:%d!\n", sensor->fsync_irq);

    if (sensor->fsync_irq > 0) {
        ret = devm_request_threaded_irq(dev, sensor->fsync_irq,
                        NULL, sensor_fsync_irq,
                        IRQF_TRIGGER_FALLING | IRQF_ONESHOT,
                        SENSOR_NAME "_frame_sync", sensor);
        if (ret < 0) {
            DBG_ERROR("irq %d request failed, %d\n",
                sensor->fsync_irq, ret);
            goto err_clean_entity;
        }

        #if defined(ENABLE_SENSOR_ROI_SWITCH_BY_FSYNC_IRQ)
        /* request work queue */
        sensor->sensor_roiswitch_wq = create_singlethread_workqueue(SENSOR_NAME"_roisw_wq");
        if (!sensor->sensor_roiswitch_wq) {
            ret = -ENOMEM;
            DBG_ERROR("could not create workqueue for sensor roi_switch.");
            goto err_clean_entity;
        }
        INIT_WORK(&sensor->sensor_roiswitch_work, sensor_roi_switch_workqueue_function);
        #endif
    }
#endif

#if defined(ENABLE_VCSEL_DRV_ERROR_IRQ)
    sensor->vcsel_drv_err_irq = of_irq_get(client->dev.of_node, 1);
    if (sensor->vcsel_drv_err_irq < 0) {
        DBG_ERROR("Failed to get vcsel_drv_err interrupt number\n");
        goto err_clean_entity;
    }
    DBG_INFO("vcsel_drv_err_irq:%d!\n", sensor->vcsel_drv_err_irq);

    if (sensor->vcsel_drv_err_irq > 0) {
        ret = devm_request_threaded_irq(dev, sensor->vcsel_drv_err_irq,
                        NULL, vcsel_err_handle_handler,
                        IRQF_TRIGGER_FALLING | IRQF_ONESHOT,
                        SENSOR_NAME "_vcsel_drv_err", sensor);
        if (ret < 0) {
            DBG_ERROR("irq %d request failed, %d\n",
                sensor->vcsel_drv_err_irq, ret);
            goto err_clean_entity;
        }

    }
#endif

    sensor->debugfs_root = debugfs_create_dir("adaps", NULL);
    if (!sensor->debugfs_root)
    {
        DBG_ERROR("Fail to debugfs_create_dir:adaps...");
        goto err_clean_entity3;
    }

    sensor->misc_device.minor = MISC_DYNAMIC_MINOR;
    sensor->misc_device.name = SENSOR_NAME "_misc";
    sensor->misc_device.fops = &misc_device_fops;
    sensor->misc_device.parent = sensor->dev;

    ret = misc_register(&sensor->misc_device);
    if (ret) {
        DBG_ERROR("Failed to register msic device");
        goto err_clean_entity3;
	}

    mutex_init(&sensor->misc_mutex);

    sensor->mmap_buffer_max_size = MAX(SPOT_MODULE_EEPROM_CAPACITY_SIZE,FLOOD_MODULE_EEPROM_CAPACITY_SIZE)
        + REG_SETTING_BUF_MAX_SIZE_PER_SEG
        + REG_SETTING_BUF_MAX_SIZE_PER_SEG
        + (PER_CALIB_SRAM_ZONE_SIZE * ZONE_COUNT_PER_SRAM_GROUP * MAX_CALIB_SRAM_ROTATION_GROUP_CNT);

    // NOTE: mmap buffer size (the third parameter of remap_pfn_range()) must be an integer multiple of PAGE_SIZE
    if (0 != sensor->mmap_buffer_max_size % PAGE_SIZE)
    {
        sensor->mmap_buffer_max_size = ((sensor->mmap_buffer_max_size/PAGE_SIZE) +1) * PAGE_SIZE;
    }

    sensor->mmap_buffer_base = kzalloc((sensor->mmap_buffer_max_size * sizeof(u8)), GFP_KERNEL);
    if (NULL == sensor->mmap_buffer_base) {
        DBG_ERROR("Fail to alloc mmap buffer");
        ret = -ENOMEM;
        goto err_clean_entity3;
    }
#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    sensor->eeprom_data       = (swift_flood_module_eeprom_data_t *) sensor->mmap_buffer_base;
#else
    sensor->eeprom_data       = (swift_spot_module_eeprom_data_t *) sensor->mmap_buffer_base;
#endif
    sensor->loaded_sensor_reg_setting = sensor->mmap_buffer_base + MAX(SPOT_MODULE_EEPROM_CAPACITY_SIZE,FLOOD_MODULE_EEPROM_CAPACITY_SIZE);
    sensor->loaded_vcsel_reg_setting = sensor->loaded_sensor_reg_setting + REG_SETTING_BUF_MAX_SIZE_PER_SEG;
    sensor->loaded_roi_sram = sensor->loaded_vcsel_reg_setting + REG_SETTING_BUF_MAX_SIZE_PER_SEG;
    sensor->loaded_roi_sram_size = 0;

    /*reserve kmalloc memory as pages to make them remapable*/
    for (virt_addr = (unsigned long)sensor->mmap_buffer_base;
            virt_addr < (unsigned long)sensor->mmap_buffer_base + sensor->mmap_buffer_max_size;
            virt_addr += PAGE_SIZE) {
        SetPageReserved(virt_to_page((virt_addr)));
    }

#if (ADS6401_MODULE_FLOOD == SWIFT_MODULE_TYPE)
    generate_crc32_table(); // only need run once after power on.
#endif

#if defined(CALIB_DATA_READY_IN_EEPROM_CHIP)
    /* use dummy devices for eeprom functions */
    sensor->eeprom_i2c = devm_i2c_new_dummy_device(dev,client->adapter, I2C_ADDRESS_4_EEPROM);
    if (IS_ERR(sensor->eeprom_i2c))
    {
        DBG_ERROR("create eeprom dummy i2c device failed");
        goto err_clean_entity3;
    }
#endif

    ret = sensor_read_module_static_data(sensor);
    if (ret < 0) {
        DBG_ERROR( "Fail to read calibrate data, ret: %d.", ret);
#if !defined(IGNORE_PROBE_FAILURE) 
        goto err_clean_entity3;
#endif
    }

    sensor_set_power_off(sensor, __LINE__);

    sensor_get_i2c_bus_frequency(sensor);
    ret = cam_sensor_register_attrib_group(dev);
    if (ret) {
        DBG_ERROR( "Error creating sysfs attribute group.");
        goto err_clean_entity3;
    }

    if (!debugfs_create_file("dbg_ctrl", 0644, sensor->debugfs_root, sensor, &cam_sensor_adaps_dbg_control))
    {
        DBG_ERROR("Fail to debugfs_create_file:dbg_ctrl...");
        goto err_clean_entity3;
    }

    sensor->probe_success = true;
    DBG_NOTICE("---done, console_loglevel:%d, eeprom_data_size:%d, sizeof(float):%ld, ads6401_module_type: %s, driver_version: %s, mmap_buffer_max_size: %d---", 
        console_loglevel,
        sensor->eeprom_data_size,
        sizeof(float),
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        sensor->mmap_buffer_max_size
        );
    return 0;

err_clean_entity3:
    cancel_work_sync(&sensor->vop_adjust_work);
    destroy_workqueue(sensor->vop_adjust_wq);
err_clean_entity2:
    hrtimer_cancel(&sensor->vop_adjust_timer);
    err_clean_entity:
#if defined(CONFIG_MEDIA_CONTROLLER) 
    media_entity_cleanup(&sd->entity);
#endif

err_free_handler:
    v4l2_ctrl_handler_free(&sensor->ctrl_handler);

err_destroy_mutex:
    mutex_destroy(&sensor->mutex);
    mutex_destroy(&sensor->misc_mutex);

#if !defined(IGNORE_PROBE_FAILURE) 
err_power_off:
#endif
    sensor_set_power_off(sensor, __LINE__);
    DBG_ERROR("---failure, ret:%d, ads6401_module_type: %s, driver_version: %s, Build Time: %s---", 
        ret,
        ADS6401_MODULE_TYPE_NAME,
        FULL_VERSION_STRING,
        get_kernel_buildtime()
        );

    return ret;
}

static int sensor_remove(struct i2c_client * client)
{
    struct v4l2_subdev *sd = i2c_get_clientdata(client);
    struct sensor *sensor = to_sensor(sd);

    if (sensor->debugfs_root)
    {
        debugfs_remove_recursive(sensor->debugfs_root);
    }

    mutex_destroy(&sensor->misc_mutex);

    misc_deregister(&sensor->misc_device);

    if (sensor->mmap_buffer_base) {
        unsigned long virt_addr;
        for (virt_addr = (unsigned long)sensor->mmap_buffer_base;
             virt_addr < (unsigned long)sensor->mmap_buffer_base + sensor->mmap_buffer_max_size;
             virt_addr += PAGE_SIZE) {
            ClearPageReserved(virt_to_page((virt_addr)));
        }

        kfree(sensor->mmap_buffer_base);
    }

    cancel_work_sync(&sensor->vop_adjust_work);
    destroy_workqueue(sensor->vop_adjust_wq);
    hrtimer_cancel(&sensor->vop_adjust_timer);
    v4l2_async_unregister_subdev(sd);

#if defined(CONFIG_MEDIA_CONTROLLER) 
    media_entity_cleanup(&sd->entity);
#endif

    v4l2_ctrl_handler_free(&sensor->ctrl_handler);
    mutex_destroy(&sensor->mutex);

#if defined(ENABLE_SOC_PWM_4_VOP_VOLTAGE)
    pwm_disable(sensor->pwm_4_vop.pwm_dev);
    pwm_put(sensor->pwm_4_vop.pwm_dev);
#endif

    return 0;
}

#if IS_ENABLED(CONFIG_OF)
static const struct of_device_id sensor_of_match[] =
{
    { .compatible = DEV_COMPATIBLE_STRING },
    { .compatible = MINI_BOX_COMPATIBLE_STRING },
    {},
};


MODULE_DEVICE_TABLE(of, sensor_of_match);
#endif

static const struct i2c_device_id sensor_match_id[] =
{
    { DEV_COMPATIBLE_STRING, 0 },
    { MINI_BOX_COMPATIBLE_STRING, 0 },
    { },
};

static struct i2c_driver cam_sensor_i2c_driver = {
    .driver = {
        .name = SENSOR_NAME,
        .of_match_table = of_match_ptr(sensor_of_match),
    },
    .probe      = &sensor_probe,
    .remove     = &sensor_remove,
    .id_table   = sensor_match_id,
};

static int __init sensor_mod_init(void)
{
    int32_t rc = 0;

    rc = i2c_add_driver(&cam_sensor_i2c_driver);
    if (rc < 0)
        DBG_ERROR( "i2c_add_driver failed rc = %d", rc);

    return rc;
}

static void __exit sensor_mod_exit(void)
{
    i2c_del_driver(&cam_sensor_i2c_driver);
}

device_initcall_sync(sensor_mod_init);
module_exit(sensor_mod_exit);

MODULE_DESCRIPTION(DRIVER_NAME);
MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("david.chen@adaps-ph.com");
MODULE_VERSION(FULL_VERSION_STRING);

