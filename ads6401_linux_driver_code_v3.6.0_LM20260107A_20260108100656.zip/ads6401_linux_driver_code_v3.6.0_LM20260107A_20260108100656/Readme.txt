The Linux kernel driver code for adaps ADS6401 dToF sensor
Release version: v3.6.0_LM20260107A
Release time: 2026/01/08 10:06:56
Released by: david.chen

  This is ads6401 dToF driver code for Linux, we had tested it on Linux kernel 5.10.110 (rk3568 SoC);

  There are four types of dToF modules based on the ADS6401 chip:
    Spot module
    Small-Flood module
    Big FoV Flood module
    Big FoV V2 Flood module

  You can select the proper type at the begin of ads6401.c:
    #define SWIFT_MODULE_TYPE               ADS6401_MODULE_BIG_FOV_FLOOD_V2  // (ADS6401_MODULE_SPOT / ADS6401_MODULE_SMALL_FLOOD / ADS6401_MODULE_BIG_FOV_FLOOD / ...), refer to adaps_types.h

  The following files are not mandatory to port, but they can enhance the functionality of the Rockchip CIF driver,
  adding a device attribute 'rkcif_rx_status' to allow you to check whether the driver layer receives MIPI frames
  and if there are any MIPI errors, etc.
    drivers/media/platform/rockchip/cif/capture.c
    drivers/media/platform/rockchip/cif/dev.c
    drivers/media/platform/rockchip/cif/dev.h

  If you have any questions, please feel free to contact us (https://adapsphotonics.com/).

Rockchip rk3568:
  https://www.rock-chips.com/a/en/products/RK35_Series/2021/0113/1276.html

