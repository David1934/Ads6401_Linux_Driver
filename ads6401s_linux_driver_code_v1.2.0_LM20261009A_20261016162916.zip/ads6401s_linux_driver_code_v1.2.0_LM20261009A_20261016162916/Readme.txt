The Linux kernel driver code for adaps ADS6401S dToF sensor
Release version: v1.2.0_LM20261009A
Release time: 2026/10/16 16:29:16
Released by: david.chen

  This is ads6401s dToF driver code for Linux, we had tested it on Linux kernel 5.10.110 (rk3568 SoC);

  The following files are not mandatory to port, but they can enhance the functionality of the Rockchip CIF driver,
  adding a device attribute 'rkcif_rx_status' to allow you to check whether the driver layer receives MIPI frames
  and if there are any MIPI errors, etc.
    drivers/media/platform/rockchip/cif/capture.c
    drivers/media/platform/rockchip/cif/dev.c
    drivers/media/platform/rockchip/cif/dev.h

  If you have any questions, please feel free to contact us (https://adapsphotonics.com/).

Rockchip rk3568:
  https://www.rock-chips.com/a/en/products/RK35_Series/2021/0113/1276.html

