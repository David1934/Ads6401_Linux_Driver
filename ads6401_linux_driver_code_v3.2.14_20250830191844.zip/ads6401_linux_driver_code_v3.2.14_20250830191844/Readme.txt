The Linux kernel driver code for adaps ADS6401 dToF sensor
Release version: v3.2.14
Release time: 2025/08/30 19:18:44
Released by: david.chen

  This is ads6401 dToF driver code for Linux, we had tested it on Linux kernel 5.10.110 (rk3568 SoC);

  There are two kinds of dToF modules from ads6401 chip, one is SPOT module, the other is FLOOD module;
  You can select the proper type at the begin of ads6401.c:
    #define SWIFT_MODULE_TYPE               ADS6401_MODULE_SPOT  // ADS6401_MODULE_FLOOD

  If you have any questions, please feel free to contact us (https://adapsphotonics.com/).

Rockchip rk3568:
  https://www.rock-chips.com/a/en/products/RK35_Series/2021/0113/1276.html

